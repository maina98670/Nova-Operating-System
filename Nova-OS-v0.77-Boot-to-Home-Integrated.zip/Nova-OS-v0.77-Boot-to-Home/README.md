# Nova OS v0.77 — latest refinements

See [README-v0.77-REFINEMENT.md](README-v0.77-REFINEMENT.md) for the same-version changes and the Colab/Ubuntu testing instructions. See [Six-area completion status](docs/v0.77-SIX-AREA-COMPLETION-STATUS.md) for verified work and outstanding hardware/boot requirements.

---

# Nova OS v0.77 — Integration Foundation

See **README-v0.77.md** for the 14-system integration status, APK staging, optional Waydroid and testing instructions.

# Nova OS v0.76 — Polished Experience

Start with [README-v0.76.md](README-v0.76.md) for the browser-first release, account setup, eight apps and testing instructions. The original source and earlier release guides are retained.

# Nova OS v0.75 — Modern UI and Connectivity

Read [README-v0.75.md](README-v0.75.md) for the v0.75 scope, tests, and hardware limitations.

**Latest update: [v0.74 Native Mobile Apps integration](README-v0.74.md).**

# Nova OS v0.73 — Platform Integration Preview

**Status: 12-system source and API integration tested; NOT a completed Android-equivalent system. ARM64 QEMU boot NOT verified in the authoring environment.**

This release evolves v0.72 and preserves your original Nova v0.60 source (104 workspace modules), the nine historical archives and M0–M3 boot prototypes. It retains the original Rust Settings, Contacts, Files and read-only Messages bridge, the original Rust App Manager and compositor **protocol** runtime, and the native Qt shell. Preserved source does not mean every binary is installed/running.

## New in v0.73

- **Independent GUI processes:** the guest's Qt launcher starts separately managed Qt app windows (using the same Nova Qt code focused on one app view), lists the running child PIDs and allows graceful termination. This is process-level operation, not per-app kernel isolation or original CLI-to-GUI porting. QEMU session sets `NOVA_SEPARATE_APPS=1`; Colab preview stays embedded.
- **Real package-service prototype:** install, list and uninstall checksum-verified **data-only** `org.nova.*` resource ZIPs. The installer checks size, archive paths, duplicate entries, file manifest, and SHA256. It never executes package contents, has **no publisher signatures**, and does not support APKs.
- **Data recovery:** create private Nova GUI/data backups, list them and safely stage recovery without overwriting live data. The original Rust database and system disk are **not included**.
- **Diagnostics:** real RAM, storage, network interface and ALSA device observations; labels never claim absent hardware works.
- **QEMU session:** changes Weston kiosk mode to desktop mode for independent app windows; resource limits and service hardening have been added to the Nova backend service. The virtual machine can be tested with 1 GB RAM via `NOVA_VM_RAM_MB=1024`.
- **New acceptance checks:** 55 Python tests, 12-system source evidence report and an expanded ARM64 guest smoke test for Rust, runtime, Qt, diagnostics, packages, backups and file round trips.

All existing v0.72 features including Qt Home, Files, Settings, Notes, Contacts, local Messages, Gallery, notifications and navigation remain.

## What still prevents declaring a stable Android-like OS

1. The full ARM64 disk build and boot **must be executed and visually verified** in QEMU on Ubuntu.
2. **Linux** is the kernel, **systemd** is PID 1, and **Weston** is the pixel compositor. The original Nova Init and Nova compositor protocol libraries are preserved but do not replace these systems yet.
3. Original Rust app CLI binaries are preserved/compiled by the build pipeline but most are not graphical processes. Qt independently launched views are **not** those binaries.
4. Apps still share one Linux user; this is **not a production-grade per-app sandbox**. No signed app executable installer or OTA mechanism is present.
5. Wi-Fi pairing, Bluetooth, telephony, SMS transmission, camera capture, power and phone-specific drivers require future hardware integration. Networking/audio diagnostics are **not** hardware control.

See `docs/INTEGRATION-12-SYSTEMS.md` for the honest completion matrix and exact missing parts of each of the 12 goals.

## Fast testing in Google Colab

Open `Nova-OS-v0.73-Platform-Integration-Colab.ipynb` in Colab and upload the v0.73 ZIP on the first cell. Run cells sequentially. Colab will attempt to install Rust, build the original native bridge in strict mode, run tests and the API, render optional Qt offscreen images, and check packages, backups and diagnostics. **Colab is not a native ARM64 OS boot test.**

## Source tests on Linux

```bash
cd Nova-OS-v0.73-Platform-Integration
python3 scripts/audit-source.py
python3 scripts/preflight.py --strict-source
python3 -m unittest discover -s tests -v
python3 scripts/verify-12-systems.py
python3 scripts/release-gate.py
```

## Build and boot ARM64 on Ubuntu

Requirements: Ubuntu 24.04 desktop/VM, sudo, internet, >= 12 GB free storage, cross compiler, Rust toolchain and QEMU system/user emulation. Install:

```bash
sudo apt update
sudo apt install -y ca-certificates curl build-essential pkg-config libssl-dev \
  gcc-aarch64-linux-gnu file qemu-system-arm qemu-user-static debootstrap \
  binfmt-support rsync e2fsprogs python3
# If Rust absent, install stable via the official rustup installer.
```

Run from the extracted package:

```bash
./scripts/build-all-arm64.sh
python3 vm/smoke-arm64-qemu.py --timeout 600
python3 scripts/release-gate.py --require-boot
./vm/run-arm64-qemu.sh
# Optional low-memory profile (needs working GUI):
NOVA_VM_RAM_MB=1024 ./vm/run-arm64-qemu.sh
```

When booted, examine the Qt GUI **inside QEMU's own display**, open different application windows, check the Recent app PID list, close an app, save and reopen a file, create a recovery snapshot and test persistence after a reboot. The smoke harness cannot check actual display pixels or prove an Android-like touch interface. If no display is available, use `./vm/run-arm64-qemu.sh --vnc` with a local VNC viewer.

Guest troubleshooting:

```bash
systemctl status nova-runtime nova-shell nova-catalog --no-pager
journalctl -b -u nova-runtime -u nova-shell -u nova-catalog --no-pager
cat /home/nova/nova-desktop.log
cat /home/nova/weston.log
ls -l /run/nova/*.sock
```

## Python preview only (not a boot)

If you only want the lightweight browser shell on Linux:

```bash
python3 graphics-shell/server.py --no-browser
# Open http://127.0.0.1:8767
```

That preview runs without Rust **only if strict mode is not requested**, and explicitly reports the fallback. To require the original Rust bridge: build it with `./build-native.sh`, then set `NOVA_REQUIRE_RUST_BRIDGE=1` before starting the API. Native Qt requires PyQt5 and a desktop Wayland/X11 display.

## Release decision

**Source gate**: 55 automated tests passed in authoring environment. **ARM64 boot gate**: unverified; run QEMU smoke on Ubuntu. **Production stable**: NO. No claim is made that all 12 goals are finished. This is an integrated development checkpoint with documented, measurable blockers.
