#!/usr/bin/env python3
"""Read-only ADB inventory; never unlocks, flashes, erases or reboots a phone."""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

PROPS = {
    "manufacturer": "ro.product.manufacturer",
    "model": "ro.product.model",
    "codename": "ro.product.device",
    "soc": "ro.soc.model",
    "board_platform": "ro.board.platform",
    "architecture": "ro.product.cpu.abi",
    "android_release": "ro.build.version.release",
    "android_sdk": "ro.build.version.sdk",
    "slot_suffix": "ro.boot.slot_suffix",
    "dynamic_partitions": "ro.boot.dynamic_partitions",
    "verified_boot_state": "ro.boot.verifiedbootstate",
    "flash_locked": "ro.boot.flash.locked",
    "bootimage_header_version": "ro.boot.bootimage.header.version",
    "kernel_hardware": "ro.hardware",
}


def execute(args, timeout=12):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return p.stdout.strip() if p.returncode == 0 else None


def inspect(adb="adb"):
    if not shutil.which(adb) and not Path(adb).is_file():
        raise RuntimeError("ADB not found. Install Android Platform Tools on the computer connected to your phone.")
    state = execute([adb, "get-state"])
    if state != "device":
        raise RuntimeError("Exactly one authorized USB-debugging device must be available. Run 'adb devices' locally to diagnose; do not share serial numbers.")
    device = {}
    for label, prop in PROPS.items():
        device[label] = execute([adb, "shell", "getprop", prop]) or None
    device["kernel_release"] = execute([adb, "shell", "uname", "-r"]) or None
    # Partition NAMES only: never read raw partition contents or identifiable by-id paths.
    part_names = execute([adb, "shell", "ls", "-1", "/dev/block/by-name"]) or ""
    partitions = sorted({x.strip() for x in part_names.splitlines() if x.strip() and not x.startswith("ls:")})
    return {
        "report_format": "nova-v0.77-read-only-adb-inventory",
        "device": device,
        "partition_names": partitions,
        "note": "Only device model, boot configuration and partition names. No serial number or user data captured. Results can be incomplete on restricted devices."
    }


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", default="phone-report.json")
    ap.add_argument("--adb", default="adb", help="Path to adb executable")
    args=ap.parse_args(argv)
    try:
        report=inspect(args.adb)
    except RuntimeError as exc:
        print("NOT READY:", exc, file=sys.stderr)
        return 2
    dest=Path(args.output).resolve()
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print("Read-only report saved:",dest)
    print("Model:",report["device"].get("model"),"Codename:",report["device"].get("codename"))
    print("Review the JSON before sharing. No phone changes were made.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
