#!/usr/bin/env python3
"""Explicit Waydroid integration acceptance. NEVER auto-enables container or installs APKs.

Usage: python3 scripts/android-live-acceptance.py --apk /path/test.apk --package org.example.app --confirm
Only use a trusted, known-good app that you are authorized to install.
"""
import argparse
import json
import os
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'integration'))
from android_compat import AndroidBridge


def main():
    ap=argparse.ArgumentParser(description='Nova v0.77 optional Android runtime acceptance on supported Linux host')
    ap.add_argument('--apk',type=Path)
    ap.add_argument('--package')
    ap.add_argument('--confirm',action='store_true',help='Allow installing and launching the provided APK')
    ap.add_argument('--uninstall-after',action='store_true',help='Remove test APK after launch')
    args=ap.parse_args()
    runtime=AndroidBridge(Path(os.environ.get('NOVA_CONFIG_DIR',Path.home()/'.config/nova-os')))
    preflight=runtime.status()
    print(json.dumps({'preflight':preflight},indent=2))
    if not (args.apk and args.package and args.confirm):
        print('READ-ONLY. Supply --apk, --package and --confirm to run actual Waydroid acceptance.')
        return 2
    if not preflight['execution_available']:
        print('BLOCKED. Waydroid not running or user has not enabled runtime. No APK installed.')
        return 3
    try:
        from android_compat import inspect_apk
        apk=args.apk.resolve(strict=True)
        info=inspect_apk(apk)
        print('APK integrity:',json.dumps(info,indent=2))
        # Android Package Manager verifies actual signing; ZIP inspection cannot.
        runtime._run('app','install',str(apk),timeout=120)
        print('INSTALL COMMAND SUCCEEDED. Checking app inventory ...')
        output=runtime.packages()['output']
        if args.package not in output:
            print('FAIL: requested application package not visible in Waydroid app list')
            return 4
        runtime.launch(args.package)
        print('LAUNCH COMMAND SUCCEEDED; manual GUI functionality check still required')
        if args.uninstall_after:
            runtime.remove(args.package)
            if args.package in runtime.packages()['output']:
                print('FAIL: app still in list after uninstall')
                return 5
            print('UNINSTALL VERIFIED')
        return 0
    except (OSError,ValueError,RuntimeError,PermissionError) as error:
        print('FAILED:',error)
        return 1

if __name__=='__main__':
    raise SystemExit(main())
