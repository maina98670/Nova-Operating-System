#!/usr/bin/env python3
"""Inventory every original Nova milestone and check canonical Rust workspace references.
Does not infer that a passing inventory makes packages runtime-integrated.
"""
from __future__ import annotations
import json, pathlib, sys, tomllib, zipfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
workspace = ROOT/'source-v0.60'
toml = workspace/'Cargo.toml'
archive_dir = ROOT/'history'/'snapshots'
expected = ['v0.07','v0.13','v0.20','v0.27','v0.33','v0.40','v0.47','v0.53','v0.60']
errors=[]
manifest=tomllib.loads(toml.read_text(encoding='utf-8'))
members=manifest['workspace']['members']
missing=[x for x in members if not (workspace/x/'Cargo.toml').exists()]
errors.extend('Missing Cargo manifest: '+x for x in missing)
archives={}
for ver in expected:
    p=archive_dir/f'{ver}.zip'
    if not p.is_file():errors.append('Missing milestone archive: '+ver);continue
    with zipfile.ZipFile(p) as z:
        bad=z.testzip()
        if bad:errors.append(f'Invalid ZIP: {ver}: {bad}')
        archives[ver]={'entries':len(z.infolist()),'bytes':p.stat().st_size}
for k in ['m0','m1','m2','m3']:
    if not (ROOT/'boot'/'legacy'/k).is_dir():errors.append('Missing boot prototype: '+k)
for p in ['native-bridge/Cargo.toml','graphics-shell/server.py','vm/build-arm64-qemu.sh','vm/run-arm64-qemu.sh','vm/guest/nova-desktop-session']:
    if not (ROOT/p).is_file():errors.append('Missing integration component: '+p)
components=['libs','apps','tools']
result={
 'release':'Nova v0.77 Integration Foundation',
 'historical_milestone_archives':archives,
 'workspace_members_declared':len(members),
 'workspace_members_with_manifest':len(members)-len(missing),
 'libraries':len([x for x in members if x.startswith('libs/')]),
 'applications':len([x for x in members if x.startswith('apps/')]),
 'tools':len([x for x in members if x.startswith('tools/')]),
 'boot_prototypes':['m0','m1','m2','m3'],
 'integration_note':'All sources retained, but not all components execute in the guest at boot.',
 'problems':errors,
}
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
