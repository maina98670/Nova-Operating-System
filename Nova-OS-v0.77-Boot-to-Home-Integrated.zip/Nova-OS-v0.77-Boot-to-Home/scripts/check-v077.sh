#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/audit-source.py
python3 -m unittest discover -s tests -q
if command -v node >/dev/null; then node --check graphics-shell/static/modern.js; fi
python3 scripts/release-gate.py
python3 scripts/android-preflight.py
if [[ -f MANIFEST.sha256 ]]; then python3 scripts/verify-integrity.py; fi
printf '\n[NOVA] Source checks complete. ARM64 boot remains a separate required test.\n'
