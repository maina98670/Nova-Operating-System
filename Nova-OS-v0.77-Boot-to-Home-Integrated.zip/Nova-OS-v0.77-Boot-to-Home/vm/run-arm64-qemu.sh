#!/usr/bin/env bash
# Graphical ARM64 VM: Weston displays the native Nova Qt/Wayland shell on guest virtio-gpu.
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOTFS="$DIR/out/rootfs"
IMAGE="$DIR/out/nova-arm64.ext4"
[[ -f "$IMAGE" ]] || { echo 'Run ./vm/build-arm64-qemu.sh to create disk first.' >&2; exit 2; }
KERNEL=$(find "$ROOTFS/boot" -maxdepth 1 -type f -name 'vmlinuz-*' | sort -V | tail -1)
INITRD=$(find "$ROOTFS/boot" -maxdepth 1 -type f -name 'initrd.img-*' | sort -V | tail -1)
[[ -f "$KERNEL" && -f "$INITRD" ]] || { echo 'Missing ARM64 kernel/initrd' >&2; exit 2; }
command -v qemu-system-aarch64 >/dev/null || { echo 'Install qemu-system-arm' >&2; exit 2; }
# M2 early PID1 handoff is gated; default remains well-understood systemd boot.
M2_INIT_APPEND=''
case "${NOVA_ENABLE_M2_INIT:-0}" in
  0) ;;
  1)
    [[ -x "$ROOTFS/sbin/nova-early-init" ]] || { echo 'M2 init binary absent; build M0-M3 artifacts first.' >&2; exit 2; }
    M2_INIT_APPEND=' init=/sbin/nova-early-init'
    echo '[nova] Experimental M2 early PID1 -> systemd handoff enabled'
    ;;
  *) echo 'NOVA_ENABLE_M2_INIT must be 0 or 1' >&2; exit 2;;
esac
RAM_MB="${NOVA_VM_RAM_MB:-2048}"
case "$RAM_MB" in 1024|1536|2048|3072|4096) ;; *) echo 'NOVA_VM_RAM_MB must be 1024, 1536, 2048, 3072 or 4096.' >&2; exit 2;; esac
DISPLAY_ARGS=(-display gtk,gl=off)
case "${1:-}" in
  '') ;;
  --vnc) DISPLAY_ARGS=(-display vnc=127.0.0.1:1); echo 'View QEMU virtual screen via local VNC client on 127.0.0.1:5901.';;
  --headless) DISPLAY_ARGS=(-display none); echo 'Serial-only boot diagnostic mode: graphical UI NOT visible.';;
  *) echo 'Usage: ./vm/run-arm64-qemu.sh [--vnc|--headless]' >&2; exit 2;;
esac
echo 'Starting Nova ARM64 graphical VM. Look for the Nova desktop in the QEMU display window.'
echo 'Serial escape: Ctrl+A then X. Diagnostic HTTP endpoint: http://127.0.0.1:8767'
exec qemu-system-aarch64 \
  -machine virt -cpu cortex-a53 -smp 2 -m "$RAM_MB" \
  -kernel "$KERNEL" -initrd "$INITRD" \
  -append "root=/dev/vda rw rootwait console=ttyAMA0 console=tty0 loglevel=4${M2_INIT_APPEND}" \
  -drive if=none,file="$IMAGE",format=raw,id=nova-root \
  -device virtio-blk-pci,drive=nova-root \
  -device virtio-gpu-pci -device virtio-keyboard-pci -device virtio-mouse-pci \
  -netdev user,id=net0,hostfwd=tcp:127.0.0.1:8767-:8767 \
  -device virtio-net-pci,netdev=net0 \
  -serial mon:stdio "${DISPLAY_ARGS[@]}"
