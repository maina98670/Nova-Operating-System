# Nova OS — Day 1 (M0 Verification, per the Complete Build Guide)

Four folders, one per milestone the Guide's Day 1 covers. Each has its
own README with exact status. Quick summary:

- **m0/** — boot chain. Cross-compiled init binary verified; kernel
  Image build was interrupted by sandbox limits (background process
  killed between commands) — 133 kernel objects compiled before the
  cutoff. Needs a real machine to finish `make Image`.
- **m1/** — framebuffer + real boot splash. Two versions (placeholder
  block, and the real splash.raw bitmap blit). Both cross-compiled
  clean. Same kernel-build limitation as M0.
- **m2/** — Nova Init (Rust), PID 1. Compiles clean on host target;
  cross-compiling to aarch64 needs `rustup target add
  aarch64-unknown-linux-gnu`, not reachable from this sandbox.
- **m3/** — Nova Display Server (compositor). Today's real work: found
  and fixed 6 genuine wlroots-0.17 API-drift bugs, now **compiles and
  links successfully** — a first for this component. Not yet run
  against a live display (needs your machine's desktop session).

Run each folder's `build_and_run.sh` / `*-build_and_run.sh` script on
your own Linux machine, in order (m0 first). Every README documents
exactly what to expect as success and what's already been verified
versus what's still open.
