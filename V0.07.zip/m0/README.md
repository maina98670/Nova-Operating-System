# Nova OS — M0 Starter Package

Everything here was built and verified working (partially — see note below)
in a sandboxed environment on 2026-08-09, matching Section 14 of the
Nova OS Guide. Bring this folder to your own Linux machine to finish M0.

## What's in this folder

- **init.c** — Nova's minimal M0 init program (PID 1 stand-in). Prints a
  boot message and idles. This is the "Nova Init" placeholder until the
  real Rust-based Nova Init (M2) replaces it.
- **initramfs.cpio.gz** — a working initramfs containing the compiled
  `init` binary, ready to boot as-is.
- **kernel.config** — a trimmed Linux 6.8.0 aarch64 kernel config
  (defconfig with DRM, sound, USB, wireless, Bluetooth, touchscreen,
  and media support disabled to keep build time down — these get
  re-enabled progressively at M1+ as they're actually needed).
- **build_and_run.sh** — one script that installs the toolchain, builds
  the kernel from the included config, and boots it in QEMU.

## What was actually verified in the sandbox

- QEMU 8.2.2 and the aarch64 cross-compiler toolchain installed and ran
  cleanly.
- `init.c` was cross-compiled successfully into a real aarch64 static
  binary and packaged into the initramfs included here.
- Linux 6.8.0 kernel source was fetched and configuration was generated
  and trimmed — 133 kernel object files compiled successfully before
  the sandbox's background-process limit interrupted the build.

## What's left — the actual M0 milestone

Run `build_and_run.sh` on your own machine. The kernel build is the one
part the sandbox couldn't finish (it kills background processes between
commands, and only had 1 CPU core available). On a normal machine with
multiple cores this should take a few minutes, not hours.

**Success looks like:** QEMU launches and prints:
```
=== NOVA OS ===
M0: Boot chain working. This is Nova Init (PID 1).
```

That's M0 complete — Nova 0.1, per the versioning table in Section 15
of the guide. From there, M1 (framebuffer output / boot splash) is next.

## Troubleshooting

- If `apt-get install linux-source` isn't available on your distro,
  grab any Linux kernel source (kernel.org, or your distro's package)
  version 6.x — the included `kernel.config` should still mostly apply
  via `make olddefconfig`, which fills in any new options with defaults.
- If QEMU hangs at boot with no output, double check the `-append
  "console=ttyAMA0"` flag matches — this is required for serial output
  on the `virt` machine type.
