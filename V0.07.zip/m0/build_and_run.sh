#!/bin/bash
# Nova OS — M0: Boot chain in QEMU (aarch64 virt)
# Run this on a real Linux machine (not a sandbox) — needs to run
# uninterrupted, multiple CPU cores recommended.
set -e

echo "=== Nova OS M0 build ==="

# 1. Install toolchain (Ubuntu/Debian — adjust for your distro)
echo "[1/5] Installing toolchain..."
sudo apt-get update
sudo apt-get install -y qemu-system-arm gcc-aarch64-linux-gnu \
    flex bison bc libssl-dev libelf-dev cpio build-essential

# 2. Get kernel source (Linux 6.8, matches the config included here)
echo "[2/5] Fetching kernel source..."
if [ ! -d "linux-source-6.8.0" ]; then
    sudo apt-get install -y linux-source
    tar xjf /usr/src/linux-source-6.8.0.tar.bz2
fi

# 3. Apply the trimmed config from this package
echo "[3/5] Applying kernel config..."
cp kernel.config linux-source-6.8.0/.config
cd linux-source-6.8.0
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
make olddefconfig

# 4. Build the kernel (this is the part the sandbox couldn't finish —
#    should take a few minutes on a real multi-core machine)
echo "[4/5] Building kernel Image (this takes a few minutes)..."
make -j$(nproc) Image
cd ..

# 5. Boot it in QEMU with Nova's init as the initramfs
echo "[5/5] Booting Nova OS M0 in QEMU..."
echo "You should see: '=== NOVA OS === M0: Boot chain working.'"
echo "Press Ctrl+A then X to exit QEMU."
echo ""
qemu-system-aarch64 \
    -M virt \
    -cpu cortex-a53 \
    -kernel linux-source-6.8.0/arch/arm64/boot/Image \
    -initrd initramfs.cpio.gz \
    -append "console=ttyAMA0" \
    -nographic \
    -m 512M
