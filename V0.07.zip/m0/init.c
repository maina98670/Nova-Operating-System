#include <unistd.h>
#include <sys/reboot.h>

int main() {
    const char msg[] = "\n\n=== NOVA OS ===\nM0: Boot chain working. This is Nova Init (PID 1).\n\n";
    write(1, msg, sizeof(msg)-1);
    while (1) { pause(); }
    return 0;
}
