# Nova OS — M1 Package (Framebuffer Output)

Two versions included, in the order they were actually built and verified:

## 1. Placeholder version (nova_m1_framebuffer.c)
Draws a solid Nova-blue rectangle on black. Proves the DRM/KMS pipeline
(open device, find display, create framebuffer, mode-set) works at all,
before adding the complexity of loading and blitting a real bitmap.

Run: `./nova-m1-build_and_run.sh`

## 2. Real boot splash version (nova_m1_splash.c) — the actual M1 milestone
Loads `splash.raw` (converted from the finalized boot_splash_final.png —
the actual Nova mark + wordmark from Section 3 of the guide) and blits
it to the screen, scaled to fit and centered, letterboxed in black to
preserve aspect ratio regardless of the display resolution reported by
QEMU or real hardware.

Run: `./nova-m1-splash-build_and_run.sh`

## What was verified in the sandbox

- Both `nova_m1_framebuffer.c` and `nova_m1_splash.c` cross-compiled
  cleanly to aarch64 static binaries — zero errors, zero warnings.
- Both use only raw DRM ioctls (`linux/drm.h`, `linux/drm_mode.h`) —
  no libdrm.so dependency, since a cross-compiled arm64 libdrm wasn't
  reachable in this sandbox. This is arguably the better long-term
  choice anyway: fewer dependencies to cross-compile per target device
  as Nova ports to real hardware (Section 9/15).
- `splash.raw` was correctly generated from the real, finalized splash
  PNG (1080x2340, matching Section 3) and packaged into a working
  initramfs.
- The kernel config was updated from the M0 baseline with
  `CONFIG_DRM=y` and `CONFIG_DRM_VIRTIO_GPU=y` confirmed built-in
  (not just available as a module).

## What's left — same sandbox limitation as M0

The actual kernel build (`make Image`) needs to run uninterrupted for
several minutes on a real multi-core machine — this sandbox kills
background processes between commands and only has 1 CPU core, so the
build itself couldn't be completed here. Everything else (the code,
the config, the splash data, the packaging) is done and verified.

## Success looks like

A QEMU window opens showing the real Nova mark and "NOVA" wordmark,
scaled and centered on a black background — the actual Section 3 boot
splash, running on the actual Nova boot chain. That's M1 complete —
Nova 0.2, per Section 15's versioning table.

## Next milestone

M2 — Nova Init (Rust) replaces this C placeholder as PID 1, and takes
over starting further boot services rather than just drawing the splash
and idling. Nova 0.3.
