#!/bin/bash
# Nova OS — M1: Framebuffer output via DRM/KMS
# Run on your own Linux machine after M0 is working.
set -e

echo "=== Nova OS M1 build ==="

# Assumes linux-source-6.8.0/ already exists from the M0 step.
# If not, see nova-m0-build_and_run.sh first.

echo "[1/3] Applying M1 kernel config (DRM + virtio-gpu enabled)..."
cp kernel_m1.config linux-source-6.8.0/.config
cd linux-source-6.8.0
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
make olddefconfig

echo "[2/3] Building kernel Image with DRM support..."
make -j$(nproc) Image
cd ..

echo "[3/3] Booting Nova OS M1 in QEMU with a virtual display..."
echo "A QEMU window should open showing a Nova-blue rectangle on black —"
echo "this is the framebuffer placeholder, standing in for the real"
echo "boot splash bitmap (next step after this milestone)."
echo ""

qemu-system-aarch64 \
    -M virt \
    -cpu cortex-a53 \
    -kernel linux-source-6.8.0/arch/arm64/boot/Image \
    -initrd initramfs_m1.cpio.gz \
    -append "console=ttyAMA0" \
    -device virtio-gpu-pci \
    -display gtk \
    -serial stdio \
    -m 512M
