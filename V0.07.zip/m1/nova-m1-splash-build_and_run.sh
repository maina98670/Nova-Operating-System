#!/bin/bash
# Nova OS — M1 (final): Real boot splash rendered via DRM/KMS
# Run on your own Linux machine, after M0 and the placeholder M1 work.
set -e

echo "=== Nova OS M1 (real splash) build ==="

echo "[1/3] Applying M1 kernel config (DRM + virtio-gpu enabled)..."
cp kernel_m1.config linux-source-6.8.0/.config
cd linux-source-6.8.0
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
make olddefconfig

echo "[2/3] Building kernel Image..."
make -j$(nproc) Image
cd ..

echo "[3/3] Booting Nova OS with the real boot splash..."
echo "A QEMU window should open showing the actual finalized Nova mark"
echo "and NOVA wordmark, scaled and centered on black — this is the"
echo "real Section 3 boot splash, not a placeholder."
echo ""

qemu-system-aarch64 \
    -M virt \
    -cpu cortex-a53 \
    -kernel linux-source-6.8.0/arch/arm64/boot/Image \
    -initrd initramfs_splash.cpio.gz \
    -append "console=ttyAMA0" \
    -device virtio-gpu-pci \
    -display gtk \
    -serial stdio \
    -m 512M
