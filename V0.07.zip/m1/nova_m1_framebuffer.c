/*
 * Nova OS — M1: Framebuffer output via DRM/KMS
 *
 * Opens the virtio-gpu device, claims a display mode, and fills the
 * screen with Nova's boot splash colors. This is the first milestone
 * where Nova draws real pixels — no compositor yet (that's M3), just
 * direct kernel mode-setting, matching Section 3 of the Nova OS Guide.
 *
 * Deliberately uses only raw DRM ioctls (linux/drm.h, linux/drm_mode.h)
 * instead of libdrm's wrapper functions — this avoids any dependency
 * on a target-architecture libdrm.so, which keeps this fully portable
 * across whatever device Nova is cross-compiled for, with nothing
 * beyond the kernel uapi headers required.
 *
 * Next step after this works: blit the actual Nova mark bitmap
 * instead of a solid block, then hand off to Nova Init (M2).
 */

#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <drm/drm.h>
#include <drm/drm_mode.h>

#define NOVA_BLUE  0x003B6FEF
#define NOVA_BLACK 0x00000000

static void die(const char *msg) {
    fprintf(stderr, "nova-m1: %s\n", msg);
    _exit(1);
}

int main(void) {
    printf("\n=== NOVA OS ===\nM1: Framebuffer output starting...\n");

    int fd = open("/dev/dri/card0", O_RDWR);
    if (fd < 0) die("could not open /dev/dri/card0 (is virtio-gpu enabled?)");

    struct drm_mode_card_res res = {0};
    if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res) < 0)
        die("DRM_IOCTL_MODE_GETRESOURCES (count) failed");

    uint32_t conn_ids[16], crtc_ids[16];
    if (res.count_connectors > 16 || res.count_crtcs > 16)
        die("more connectors/crtcs than expected, adjust buffer size");

    res.connector_id_ptr = (uint64_t)(uintptr_t)conn_ids;
    res.crtc_id_ptr = (uint64_t)(uintptr_t)crtc_ids;
    if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res) < 0)
        die("DRM_IOCTL_MODE_GETRESOURCES (fill) failed");

    struct drm_mode_get_connector conn = {0};
    struct drm_mode_modeinfo mode;
    uint32_t connector_id = 0, encoder_id = 0;
    int found = 0;

    for (uint32_t i = 0; i < res.count_connectors && !found; i++) {
        memset(&conn, 0, sizeof(conn));
        conn.connector_id = conn_ids[i];
        if (ioctl(fd, DRM_IOCTL_MODE_GETCONNECTOR, &conn) < 0) continue;

        if (conn.connection != 1 || conn.count_modes == 0)
            continue;

        struct drm_mode_modeinfo modes[32];
        if (conn.count_modes > 32) conn.count_modes = 32;
        conn.modes_ptr = (uint64_t)(uintptr_t)modes;
        conn.encoders_ptr = 0;
        conn.props_ptr = 0;
        conn.prop_values_ptr = 0;
        conn.count_props = 0;
        conn.count_encoders = 0;
        if (ioctl(fd, DRM_IOCTL_MODE_GETCONNECTOR, &conn) < 0) continue;

        mode = modes[0];
        connector_id = conn.connector_id;
        encoder_id = conn.encoder_id;
        found = 1;
    }
    if (!found) die("no connected display with a usable mode found");

    printf("nova-m1: using mode %ux%u\n", mode.hdisplay, mode.vdisplay);

    struct drm_mode_get_encoder enc = {0};
    enc.encoder_id = encoder_id;
    if (ioctl(fd, DRM_IOCTL_MODE_GETENCODER, &enc) < 0)
        die("DRM_IOCTL_MODE_GETENCODER failed");
    uint32_t crtc_id = enc.crtc_id;

    struct drm_mode_create_dumb creq = {0};
    creq.width = mode.hdisplay;
    creq.height = mode.vdisplay;
    creq.bpp = 32;
    if (ioctl(fd, DRM_IOCTL_MODE_CREATE_DUMB, &creq) < 0)
        die("DRM_IOCTL_MODE_CREATE_DUMB failed");

    struct drm_mode_fb_cmd fbcmd = {0};
    fbcmd.width = creq.width;
    fbcmd.height = creq.height;
    fbcmd.bpp = 32;
    fbcmd.depth = 24;
    fbcmd.pitch = creq.pitch;
    fbcmd.handle = creq.handle;
    if (ioctl(fd, DRM_IOCTL_MODE_ADDFB, &fbcmd) < 0)
        die("DRM_IOCTL_MODE_ADDFB failed");

    struct drm_mode_map_dumb mreq = {0};
    mreq.handle = creq.handle;
    if (ioctl(fd, DRM_IOCTL_MODE_MAP_DUMB, &mreq) < 0)
        die("DRM_IOCTL_MODE_MAP_DUMB failed");

    uint32_t *map = mmap(0, creq.size, PROT_READ | PROT_WRITE, MAP_SHARED,
                          fd, mreq.offset);
    if (map == MAP_FAILED) die("mmap failed");

    uint32_t pitch_px = creq.pitch / 4;
    for (uint32_t y = 0; y < creq.height; y++) {
        for (uint32_t x = 0; x < creq.width; x++) {
            int in_mark_zone =
                (x > creq.width * 0.35 && x < creq.width * 0.65 &&
                 y > creq.height * 0.30 && y < creq.height * 0.55);
            map[y * pitch_px + x] = in_mark_zone ? NOVA_BLUE : NOVA_BLACK;
        }
    }

    struct drm_mode_crtc setcrtc = {0};
    setcrtc.crtc_id = crtc_id;
    setcrtc.fb_id = fbcmd.fb_id;
    setcrtc.x = 0;
    setcrtc.y = 0;
    setcrtc.set_connectors_ptr = (uint64_t)(uintptr_t)&connector_id;
    setcrtc.count_connectors = 1;
    setcrtc.mode = mode;
    setcrtc.mode_valid = 1;
    if (ioctl(fd, DRM_IOCTL_MODE_SETCRTC, &setcrtc) < 0)
        die("DRM_IOCTL_MODE_SETCRTC failed");

    printf("nova-m1: framebuffer live. Nova mark placeholder on screen.\n");
    printf("nova-m1: M1 milestone reached -- Nova 0.2.\n");

    for (;;) pause();
    return 0;
}
