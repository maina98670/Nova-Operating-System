# Nova OS — M2 Package (Nova Init, Rust)

Everything here was built and verified working (partially — see note
below) in a sandboxed environment on 2026-08-09, matching Section 14 of
the Nova OS Guide. Bring this folder to your own Linux machine to
finish M2.

## What's in this folder

- **nova-init/** — the real Nova Init, in Rust: PID 1, mounts
  `/proc`, `/sys`, `/dev`, launches `nova-splash` as its first managed
  child over a pipe, records the moment pixels hit the screen as the
  boot-to-framebuffer metric, then reaps children forever (PID 1's one
  non-negotiable job). `src/main.rs` is the whole program — no async
  runtime, one dependency (`libc`), on purpose: PID 1 should be the
  smallest, most predictable thing on the system.
- **nova_m2_splash.c** — the M1 boot-splash program, patched to write
  one byte down fd 3 the instant `DRM_IOCTL_MODE_SETCRTC` succeeds, so
  nova-init can time "boot start → first pixel" from a real signal
  instead of parsing log timing. Same DRM/KMS ioctl path as M1,
  unchanged — M2 is about Rust taking over the init/supervisor role,
  not re-deriving a working display driver.
- **nova-splash** — that C program, already cross-compiled to a static
  aarch64 binary (see below).
- **splash.raw**, **kernel_m2.config** — carried forward from M1
  unchanged; M2 doesn't need anything new from either.
- **nova-m2-build_and_run.sh** — installs Rust + the aarch64 target,
  builds both binaries, assembles the initramfs, builds the kernel,
  and boots it in QEMU.

## What was actually verified in the sandbox

- `nova-init` compiles cleanly with `cargo build --release` — zero
  errors, zero warnings — confirming the Rust logic (mounting,
  fork/exec, pipe signaling, `CLOCK_MONOTONIC` timing, the reap loop)
  is sound, checked against the host target.
- `nova_m2_splash.c` was cross-compiled to a static aarch64 binary with
  `-Wall -Wextra` — zero errors, zero warnings — and is included here
  pre-built (`nova-splash`), same as M1's binary was.
- The fd-3 ready-signal contract was written so the same binary works
  both standalone (fd 3 closed, write is skipped) and supervised by
  nova-init (fd 3 open, one byte written) — no separate debug build.

## What's left — the actual M2 milestone

`nova-init` itself could **not** be cross-compiled to aarch64 in the
sandbox, and this is a different limitation than M0/M1's kernel-build
one: it's not about CPU cores or background-process limits, it's that
Debian/Ubuntu's `rustc` package only ships the standard library for
your *host* architecture. Cross-compiling Rust needs `rustup target
add aarch64-unknown-linux-gnu`, which downloads the aarch64 std library
from `static.rust-lang.org` — a domain this sandbox's network egress
doesn't allow. `nova-m2-build_and_run.sh` installs rustup for you and
does the rest; on a real machine with normal internet access this is
one extra `curl | sh` and a few seconds, not a blocker.

Once that's done, the kernel build itself is the same wait as M0/M1 —
a few minutes, uninterrupted, on a real multi-core machine.

**Success looks like:** QEMU opens showing the real Nova boot splash
(same image as M1), and the serial console prints something like:

```
=== NOVA OS ===
M2: Nova Init (Rust) starting. This is PID 1.
nova-init: core filesystems mounted (/proc, /sys, /dev)
nova-init: starting boot-to-framebuffer service (nova-splash)...
nova-splash: real Nova boot splash rendered on screen.
nova-init: boot-to-framebuffer: 47.3 ms (metric tracked from M2 on)
nova-init: M2 milestone reached -- Nova 0.3.
nova-init: entering supervisor loop (reaping children).
nova-init: M3 adds real managed services here.
```

The exact millisecond number will vary by machine — that variance is
the point. From M2 on, this number is the thing to watch as more gets
added ahead of it in the boot path.

That's M2 complete — Nova 0.3, per Section 15's versioning table.
From there, M3 (Nova Display Server / wlroots-based compositor) is
next, per Section 5 of the guide.

## Troubleshooting

- Same kernel-build notes as M0/M1 apply (`make olddefconfig` on a
  newer kernel source if `kernel_m2.config` doesn't match exactly,
  double-check `console=ttyAMA0` for serial output).
- If `nova-splash` exits immediately with `could not open
  /dev/dri/card0`, confirm `-device virtio-gpu-pci` is on the QEMU
  command line (it's already in the script, but easy to drop if you
  copy just the `qemu-system-aarch64` line elsewhere).
- If nova-init prints "splash service exited without signaling ready,"
  that means `nova-splash` hit one of the failure modes documented in
  its own error output (check the line right above) — the pipe/fd-3
  contract is working correctly in that case, it's just reporting a
  real failure instead of guessing.
