// Nova OS — M2: Nova Init (Rust), PID 1
//
// Replaces the M0 C placeholder (init.c) as PID 1. Responsibilities at
// this milestone, per Section 5 of the Nova OS Guide:
//   - be PID 1: mount the core filesystems a Linux userspace needs
//   - start the boot-to-framebuffer service (the M1 splash binary) as
//     its first managed child, rather than doing the drawing itself
//   - track boot-to-framebuffer time as a metric from here on
//   - reap children (PID 1's non-negotiable job — nothing else does it)
//
// Deliberately kept to std + libc, no async runtime, no extra deps:
// PID 1 should be the smallest, most predictable thing on the system.
//
// Splash drawing itself stays in C (nova_m2_splash.c, a small patch of
// the M1 splash binary) rather than being re-ported to Rust here. The
// DRM/KMS ioctl path is unchanged, verified working code from M1 — the
// M2 milestone is "Rust replaces the init/supervisor role," not
// "rewrite the display driver," and re-deriving the raw ioctl struct
// layouts by hand in Rust would be a good way to introduce a silent
// struct-padding bug in exactly the code that's hardest to debug over
// serial console. Nova Display Server (M3) is where the display path
// itself becomes a first-class Rust component.

use libc::{c_void, timespec};
use std::ffi::CString;
use std::os::unix::io::RawFd;
use std::process::exit;
use std::ptr;

const SPLASH_BIN: &str = "/bin/nova-splash";

fn mono_now() -> timespec {
    let mut ts = timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    unsafe {
        libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut ts as *mut timespec);
    }
    ts
}

fn elapsed_ms(start: &timespec, end: &timespec) -> f64 {
    let secs = (end.tv_sec - start.tv_sec) as f64;
    let nanos = (end.tv_nsec - start.tv_nsec) as f64;
    secs * 1000.0 + nanos / 1_000_000.0
}

fn println_boot(msg: &str) {
    // Write directly to fd 1 — stdout may not be line-buffered the same
    // way this early in boot, and PID 1 shouldn't depend on libc's
    // buffering behavior working out for a message that matters.
    let line = format!("{msg}\n");
    unsafe {
        libc::write(1, line.as_ptr() as *const c_void, line.len());
    }
}

/// Mount one of the core pseudo-filesystems PID 1 is responsible for.
/// Ignores "already mounted" (EBUSY) so this is safe to re-run.
fn mount_fs(source: &str, target: &str, fstype: &str, flags: libc::c_ulong) {
    let c_source = CString::new(source).unwrap();
    let c_target = CString::new(target).unwrap();
    let c_fstype = CString::new(fstype).unwrap();

    // mkdir the mountpoint if it doesn't exist yet — ENOENT would
    // otherwise fail the mount silently-ish (errno, no crash, no fs).
    let c_target_dir = CString::new(target).unwrap();
    unsafe {
        libc::mkdir(c_target_dir.as_ptr(), 0o755);
    }

    let ret = unsafe {
        libc::mount(
            c_source.as_ptr(),
            c_target.as_ptr(),
            c_fstype.as_ptr(),
            flags,
            ptr::null(),
        )
    };

    if ret != 0 {
        let errno = std::io::Error::last_os_error();
        if errno.raw_os_error() != Some(libc::EBUSY) {
            println_boot(&format!(
                "nova-init: warning: mount {target} ({fstype}) failed: {errno}"
            ));
        }
    }
}

fn mount_core_filesystems() {
    mount_fs("proc", "/proc", "proc", 0);
    mount_fs("sysfs", "/sys", "sysfs", 0);
    mount_fs("devtmpfs", "/dev", "devtmpfs", 0);
}

/// Fork + exec the splash binary with its stdout/fd 3 wired so it can
/// signal "first pixel drawn" back to init without us having to parse
/// its human-readable log output to find that moment.
fn launch_splash() -> Option<(libc::pid_t, RawFd)> {
    let mut fds: [RawFd; 2] = [0, 0];
    if unsafe { libc::pipe(fds.as_mut_ptr()) } != 0 {
        println_boot("nova-init: warning: pipe() failed, splash timing unavailable");
        return None;
    }
    let (read_fd, write_fd) = (fds[0], fds[1]);

    let pid = unsafe { libc::fork() };
    match pid {
        -1 => {
            println_boot("nova-init: warning: fork() failed, splash not started");
            None
        }
        0 => {
            // Child: becomes the splash process.
            unsafe {
                libc::close(read_fd);
                // Duplicate the write end onto fd 3 — nova-splash writes
                // a single byte there right after DRM_IOCTL_MODE_SETCRTC
                // succeeds, i.e. the instant pixels are actually on screen.
                libc::dup2(write_fd, 3);
                libc::close(write_fd);

                let path = CString::new(SPLASH_BIN).unwrap();
                let argv0 = CString::new(SPLASH_BIN).unwrap();
                let argv: [*const libc::c_char; 2] = [argv0.as_ptr(), ptr::null()];
                libc::execv(path.as_ptr(), argv.as_ptr());
                // execv only returns on failure.
                let line = b"nova-init: exec of nova-splash failed\n";
                libc::write(1, line.as_ptr() as *const c_void, line.len());
                libc::_exit(127);
            }
        }
        child_pid => {
            unsafe { libc::close(write_fd) };
            Some((child_pid, read_fd))
        }
    }
}

/// Block until the splash child writes its ready byte, or until it
/// exits/closes the pipe without doing so (crash, missing binary, no
/// display found — any of the M1-documented failure modes).
fn wait_for_splash_ready(read_fd: RawFd) -> bool {
    let mut buf = [0u8; 1];
    let n = unsafe { libc::read(read_fd, buf.as_mut_ptr() as *mut c_void, 1) };
    unsafe { libc::close(read_fd) };
    n == 1
}

/// PID 1's non-negotiable job: reap every child, forever, including
/// ones it didn't start itself (re-parented orphans land here too).
fn reap_forever() -> ! {
    loop {
        unsafe {
            let mut status: libc::c_int = 0;
            let pid = libc::waitpid(-1, &mut status, 0);
            if pid == -1 {
                // ECHILD: nothing to reap right now. Sleep briefly
                // rather than busy-spin.
                libc::usleep(200_000);
            }
        }
    }
}

fn main() {
    let pid = unsafe { libc::getpid() };
    if pid != 1 {
        // Not fatal in a dev/QEMU context where someone runs the binary
        // directly to sanity-check it, but PID 1 behavior (reaping,
        // mounting) only makes sense as the real init.
        eprintln!(
            "nova-init: warning: running as PID {pid}, not PID 1 — \
             mount/reap behavior below only makes sense as real init"
        );
    }

    let boot_start = mono_now();

    println_boot("");
    println_boot("=== NOVA OS ===");
    println_boot("M2: Nova Init (Rust) starting. This is PID 1.");

    mount_core_filesystems();
    println_boot("nova-init: core filesystems mounted (/proc, /sys, /dev)");

    println_boot("nova-init: starting boot-to-framebuffer service (nova-splash)...");

    match launch_splash() {
        Some((_splash_pid, read_fd)) => {
            if wait_for_splash_ready(read_fd) {
                let now = mono_now();
                let ms = elapsed_ms(&boot_start, &now);
                println_boot(&format!(
                    "nova-init: boot-to-framebuffer: {ms:.1} ms (metric tracked from M2 on)"
                ));
                println_boot("nova-init: M2 milestone reached -- Nova 0.3.");
            } else {
                println_boot(
                    "nova-init: splash service exited without signaling ready \
                     — no boot-to-framebuffer time recorded this boot",
                );
            }
        }
        None => {
            println_boot("nova-init: continuing without splash service");
        }
    }

    println_boot("nova-init: entering supervisor loop (reaping children).");
    println_boot("nova-init: M3 adds real managed services here.");

    reap_forever();
}

// Silence "never constructed" lint noise for the exit() import kept
// around for the day this needs a clean non-PID-1 exit path (tests,
// or a future `nova-init --check-config` mode).
#[allow(dead_code)]
fn _unused() {
    exit(0);
}
