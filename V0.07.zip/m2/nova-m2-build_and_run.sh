#!/bin/bash
# Nova OS — M2: Nova Init (Rust) replaces the C placeholder as PID 1
# Run this on your own Linux machine (not a sandbox) — see the M0/M1
# packages for why: multi-core + uninterrupted background processes
# needed for the kernel build, and this milestone additionally needs
# real internet access to install a Rust target that a sandboxed apt
# mirror alone can't provide (see README.md for the exact reason).
set -e

echo "=== Nova OS M2 build ==="

# 1. Toolchain: reuse the M0/M1 aarch64 cross toolchain, add Rust +
#    the aarch64-unknown-linux-gnu target via rustup (not apt — apt's
#    rustc package only ships the std library for your host arch, not
#    aarch64; see README.md, "What's left").
echo "[1/6] Installing/checking toolchain..."
sudo apt-get update
sudo apt-get install -y qemu-system-arm gcc-aarch64-linux-gnu \
    flex bison bc libssl-dev libelf-dev cpio build-essential curl

if ! command -v rustup >/dev/null 2>&1; then
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
fi
rustup target add aarch64-unknown-linux-gnu

# 2. Build nova-init (Rust, PID 1)
echo "[2/6] Building nova-init for aarch64..."
cd nova-init
cargo build --release --target aarch64-unknown-linux-gnu
cd ..
cp nova-init/target/aarch64-unknown-linux-gnu/release/nova-init ./nova-init-bin

# 3. Build nova-splash (C, DRM/KMS boot-splash service, exec'd by
#    nova-init) — same source and flags verified working at M1/M2.
echo "[3/6] Building nova-splash for aarch64..."
aarch64-linux-gnu-gcc -static -O2 -Wall -Wextra \
    -I/usr/aarch64-linux-gnu/include \
    -o nova-splash nova_m2_splash.c

# 4. Assemble the initramfs: /init is nova-init (real PID 1 this time,
#    not the drawing program itself), /bin/nova-splash is the child
#    service it launches, /splash.raw is the same bitmap from M1.
echo "[4/6] Assembling initramfs..."
rm -rf initramfs_root
mkdir -p initramfs_root/bin initramfs_root/dev initramfs_root/proc initramfs_root/sys
cp nova-init-bin initramfs_root/init
cp nova-splash initramfs_root/bin/nova-splash
cp splash.raw initramfs_root/splash.raw
chmod +x initramfs_root/init initramfs_root/bin/nova-splash
( cd initramfs_root && find . | cpio -o -H newc | gzip > ../initramfs_m2.cpio.gz )

# 5. Kernel — same M1 config (DRM + virtio-gpu already built in;
#    nova-init doesn't need anything new from the kernel at M2).
echo "[5/6] Building kernel Image..."
cp kernel_m2.config linux-source-6.8.0/.config
cd linux-source-6.8.0
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
make olddefconfig
make -j$(nproc) Image
cd ..

# 6. Boot it
echo "[6/6] Booting Nova OS M2 in QEMU..."
echo "You should see nova-init's banner, the real boot splash, and a"
echo "printed 'boot-to-framebuffer: N.N ms' line — that line is the"
echo "M2 milestone. Press Ctrl+A then X to exit QEMU."
echo ""
qemu-system-aarch64 \
    -M virt \
    -cpu cortex-a53 \
    -kernel linux-source-6.8.0/arch/arm64/boot/Image \
    -initrd initramfs_m2.cpio.gz \
    -append "console=ttyAMA0" \
    -device virtio-gpu-pci \
    -display gtk \
    -serial stdio \
    -m 512M
