/*
 * Nova OS — M2: boot-splash service, launched and supervised by
 * nova-init (Rust) instead of running standalone as the M1 placeholder
 * init did. Identical DRM/KMS drawing path to nova_m1_splash.c — the
 * only change is signaling nova-init the instant pixels are on screen,
 * so it can record the boot-to-framebuffer metric from *this* process's
 * own measurement rather than guessing from log output timing.
 *
 * Raw file format (splash.raw):
 *   uint32 width  (little-endian)
 *   uint32 height (little-endian)
 *   width*height * uint32 pixels, format 0x00RRGGBB, row-major
 *
 * fd 3 contract: if fd 3 is open (nova-init dup2's the pipe write end
 * there before exec), write a single byte to it immediately after
 * DRM_IOCTL_MODE_SETCRTC succeeds, then close it. If fd 3 isn't open
 * (e.g. run standalone via nova-m1-splash-build_and_run.sh for a
 * manual smoke test), the write is skipped — same binary works either
 * way.
 */

#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <drm/drm.h>
#include <drm/drm_mode.h>

static void die(const char *msg) {
    fprintf(stderr, "nova-m1: %s\n", msg);
    _exit(1);
}

int main(void) {
    printf("\n=== NOVA OS ===\nM1: Framebuffer output starting (real splash)...\n");

    /* --- Load the splash bitmap --- */
    FILE *sf = fopen("/splash.raw", "rb");
    if (!sf) die("could not open /splash.raw (was it bundled in initramfs?)");
    uint32_t splash_w, splash_h;
    if (fread(&splash_w, 4, 1, sf) != 1 || fread(&splash_h, 4, 1, sf) != 1)
        die("splash.raw header read failed");
    size_t splash_pixels = (size_t)splash_w * splash_h;
    uint32_t *splash = malloc(splash_pixels * 4);
    if (!splash) die("out of memory reading splash");
    if (fread(splash, 4, splash_pixels, sf) != splash_pixels)
        die("splash.raw pixel data truncated");
    fclose(sf);
    printf("nova-m1: loaded splash bitmap %ux%u\n", splash_w, splash_h);

    /* --- Standard DRM/KMS setup (same as the placeholder version) --- */
    int fd = open("/dev/dri/card0", O_RDWR);
    if (fd < 0) die("could not open /dev/dri/card0 (is virtio-gpu enabled?)");

    struct drm_mode_card_res res = {0};
    if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res) < 0)
        die("DRM_IOCTL_MODE_GETRESOURCES (count) failed");

    uint32_t conn_ids[16], crtc_ids[16];
    if (res.count_connectors > 16 || res.count_crtcs > 16)
        die("more connectors/crtcs than expected");

    res.connector_id_ptr = (uint64_t)(uintptr_t)conn_ids;
    res.crtc_id_ptr = (uint64_t)(uintptr_t)crtc_ids;
    if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res) < 0)
        die("DRM_IOCTL_MODE_GETRESOURCES (fill) failed");

    struct drm_mode_get_connector conn = {0};
    struct drm_mode_modeinfo mode;
    uint32_t connector_id = 0, encoder_id = 0;
    int found = 0;

    for (uint32_t i = 0; i < res.count_connectors && !found; i++) {
        memset(&conn, 0, sizeof(conn));
        conn.connector_id = conn_ids[i];
        if (ioctl(fd, DRM_IOCTL_MODE_GETCONNECTOR, &conn) < 0) continue;
        if (conn.connection != 1 || conn.count_modes == 0) continue;

        struct drm_mode_modeinfo modes[32];
        if (conn.count_modes > 32) conn.count_modes = 32;
        conn.modes_ptr = (uint64_t)(uintptr_t)modes;
        conn.encoders_ptr = 0;
        conn.props_ptr = 0;
        conn.prop_values_ptr = 0;
        conn.count_props = 0;
        conn.count_encoders = 0;
        if (ioctl(fd, DRM_IOCTL_MODE_GETCONNECTOR, &conn) < 0) continue;

        mode = modes[0];
        connector_id = conn.connector_id;
        encoder_id = conn.encoder_id;
        found = 1;
    }
    if (!found) die("no connected display with a usable mode found");
    printf("nova-m1: using mode %ux%u\n", mode.hdisplay, mode.vdisplay);

    struct drm_mode_get_encoder enc = {0};
    enc.encoder_id = encoder_id;
    if (ioctl(fd, DRM_IOCTL_MODE_GETENCODER, &enc) < 0)
        die("DRM_IOCTL_MODE_GETENCODER failed");
    uint32_t crtc_id = enc.crtc_id;

    struct drm_mode_create_dumb creq = {0};
    creq.width = mode.hdisplay;
    creq.height = mode.vdisplay;
    creq.bpp = 32;
    if (ioctl(fd, DRM_IOCTL_MODE_CREATE_DUMB, &creq) < 0)
        die("DRM_IOCTL_MODE_CREATE_DUMB failed");

    struct drm_mode_fb_cmd fbcmd = {0};
    fbcmd.width = creq.width;
    fbcmd.height = creq.height;
    fbcmd.bpp = 32;
    fbcmd.depth = 24;
    fbcmd.pitch = creq.pitch;
    fbcmd.handle = creq.handle;
    if (ioctl(fd, DRM_IOCTL_MODE_ADDFB, &fbcmd) < 0)
        die("DRM_IOCTL_MODE_ADDFB failed");

    struct drm_mode_map_dumb mreq = {0};
    mreq.handle = creq.handle;
    if (ioctl(fd, DRM_IOCTL_MODE_MAP_DUMB, &mreq) < 0)
        die("DRM_IOCTL_MODE_MAP_DUMB failed");

    uint32_t *map = mmap(0, creq.size, PROT_READ | PROT_WRITE, MAP_SHARED,
                          fd, mreq.offset);
    if (map == MAP_FAILED) die("mmap failed");

    /* --- Blit splash, scaled to fit and centered, letterboxed in black --- */
    uint32_t pitch_px = creq.pitch / 4;

    /* black out the whole screen first (letterbox bars) */
    for (uint32_t i = 0; i < creq.height * pitch_px; i++) map[i] = 0x00000000;

    /* scale-to-fit while preserving aspect ratio */
    double scale = (double)creq.width / splash_w;
    double scale_h = (double)creq.height / splash_h;
    if (scale_h < scale) scale = scale_h;

    uint32_t draw_w = (uint32_t)(splash_w * scale);
    uint32_t draw_h = (uint32_t)(splash_h * scale);
    uint32_t off_x = (creq.width - draw_w) / 2;
    uint32_t off_y = (creq.height - draw_h) / 2;

    for (uint32_t y = 0; y < draw_h; y++) {
        uint32_t src_y = (uint32_t)(y / scale);
        if (src_y >= splash_h) src_y = splash_h - 1;
        for (uint32_t x = 0; x < draw_w; x++) {
            uint32_t src_x = (uint32_t)(x / scale);
            if (src_x >= splash_w) src_x = splash_w - 1;
            map[(off_y + y) * pitch_px + (off_x + x)] =
                splash[src_y * splash_w + src_x];
        }
    }

    struct drm_mode_crtc setcrtc = {0};
    setcrtc.crtc_id = crtc_id;
    setcrtc.fb_id = fbcmd.fb_id;
    setcrtc.x = 0;
    setcrtc.y = 0;
    setcrtc.set_connectors_ptr = (uint64_t)(uintptr_t)&connector_id;
    setcrtc.count_connectors = 1;
    setcrtc.mode = mode;
    setcrtc.mode_valid = 1;
    if (ioctl(fd, DRM_IOCTL_MODE_SETCRTC, &setcrtc) < 0)
        die("DRM_IOCTL_MODE_SETCRTC failed");

    printf("nova-splash: real Nova boot splash rendered on screen.\n");

    /* Signal nova-init: pixels are on screen right now, this instant.
     * Check fd 3 is actually a valid, open fd before writing to it —
     * fcntl(F_GETFD) is a cheap, side-effect-free way to ask "is this
     * open" without risking a write to some unrelated fd 3 if this
     * binary is ever run in a context where fd 3 means something else. */
    if (fcntl(3, F_GETFD) != -1) {
        uint8_t ready = 1;
        if (write(3, &ready, 1) < 0) {
            fprintf(stderr, "nova-splash: warning: ready signal write failed\n");
        }
        close(3);
    }

    for (;;) pause();
    return 0;
}
