# Nova OS — Day 1 Package (M0 Verification: nova-display / M3 fixed and linking)

Per the Complete Build Guide's Day 1 ("Verify & document M0-M3"), this
is the concrete finding from that verification pass: M3 (Nova Display
Server) had never actually been compiled against real wlroots in any
prior session. It has now been compiled, debugged, and linked
successfully for the first time.

## What was actually done today

`libwlroots-dev` installed clean this time (the earlier session's
package-mirror inconsistency is gone). Compiling against the real
wlroots 0.17.1 API surfaced 6 genuine bugs — API drift between
whatever wlroots version the code was originally written against and
what's actually installed, exactly as the prior README predicted
("most likely minor... an argument order, a field name that moved").
All six are fixed in `nova-display.c` and `meson.build`:

1. Missing `-DWLR_USE_UNSTABLE` compiler flag, required by wlroots
   0.17's headers — added to `meson.build`.
2. Missing generated `xdg-shell-protocol.h` — `meson.build` now
   generates it via a `custom_target` calling `wayland-scanner`
   against the real protocol XML from the `wayland-protocols`
   package, rather than assuming it already exists.
3. `xdg_toplevel->events.destroy` doesn't exist in 0.17 — the
   `destroy` signal moved to `xdg_toplevel->base->events.destroy`
   (the underlying `wlr_xdg_surface`). Fixed, and the handler was
   renamed `server_new_xdg_surface` and now listens on
   `xdg_shell->events.new_surface` (`new_toplevel` doesn't exist
   either — `new_surface` fires for both toplevels and popups, so the
   handler now checks `role == WLR_XDG_SURFACE_ROLE_TOPLEVEL` and
   returns early for popups).
4. `wlr_seat->keyboards` doesn't exist (that field lives on
   `wlr_seat_client`, not `wlr_seat`) — Nova now tracks its own
   `struct wl_list keyboards` on `nova_server`, matching the existing
   `outputs`/`toplevels` list pattern already used elsewhere in the
   file, and checks that instead.
5. `wlr_backend_autocreate()`'s signature changed — takes a
   `struct wl_display *` directly now, not the event loop.
6. `wlr_output_layout_create()` takes no arguments in 0.17 (used to
   take the display).

## What was actually verified in this sandbox

- `meson setup build` configures cleanly against real wlroots 0.17.1,
  wayland-server 1.22.0, wayland-protocols 1.45, xkbcommon 1.6.0,
  pixman 0.42.2.
- `ninja -C build` **compiles and links successfully** — a real
  62KB ELF binary (`nova-display`), dynamically linked against genuine
  `libwlroots.so.12`, `libEGL`, `libgbm`, `libdrm`, confirmed via
  `file` and `ldd`. Only cosmetic `unused-parameter` warnings remain
  (normal for wl_listener callbacks that don't use every argument).
- **Run attempted**: with no `DISPLAY`/`WAYLAND_DISPLAY` and no real
  DRM card in this sandbox, `wlr_backend_autocreate` correctly starts
  looking for a DRM device (`Waiting for a DRM card device`) and the
  process reaches Nova's own startup message (`=== NOVA OS === M3:
  Nova Display Server starting.`) before the environment's lack of a
  real GPU/display becomes the limiting factor — this is the expected,
  correct behavior for a sandbox with no display hardware or nested
  compositor available, not a code bug.

## What's left

Run this on your own machine, nested inside your desktop session
(`nova-m3-build_and_run.sh` handles this) — that gives `wlr_backend_autocreate`
a real X11 or Wayland session to attach a window to, which this
sandbox cannot provide. Success there means an actual window opens.

## Day 1 status against the Complete Build Guide's Definition of Done

M3 now builds and links from a clean checkout in an environment that
never had it compiled before — the literal Day 1 acceptance test.
What remains for full DoD is running it against a real display (your
machine, not this sandbox) and completing the M0-M2 side of the same
verification pass. M4 (Core OS) should not start until that's done,
per the Guide's own sequencing rule.
