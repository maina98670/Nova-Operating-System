/*
 * Nova OS — M3: Nova Display Server
 *
 * A minimal wlroots-based Wayland compositor. Structurally this follows
 * wlroots' own reference compositor (tinywl) — that's the standard,
 * deliberately-minimal starting point every real wlroots compositor
 * (Sway, river, etc.) grew from, not a Nova-specific shortcut. What's
 * Nova-specific is the instrumentation: this milestone's job per
 * Section 5 of the guide is "zero-copy buffer pipeline implemented and
 * benchmarked (frame latency, not just 'it renders')" and "input-to-
 * photon latency becomes a tracked metric" — so the parts that matter
 * here are the two listener blocks that turn a real input event
 * timestamp and a real KMS presentation timestamp into a printed
 * number, not the window-management boilerplate around them.
 *
 * Zero-copy buffer pipeline: this is wlroots' default behavior once a
 * DRM backend + GBM allocator + GLES2/Vulkan renderer are wired up via
 * wlr_renderer_autocreate() / wlr_allocator_autocreate() below — client
 * buffers are DMA-BUFs imported by reference into the scene graph, not
 * copied. There is no separate "zero-copy mode" to implement on top of
 * that; the benchmarking half of that roadmap line is the latency
 * numbers this file prints on every frame.
 *
 * Input-to-photon latency: every libinput event (keyboard, pointer)
 * carries event->time_msec, a hardware-clock timestamp from the input
 * device itself. Every KMS page-flip completion (wlr_output "present"
 * event) carries a real presentation timestamp from the display
 * hardware/DRM driver, not "whenever our render call returned." The
 * gap between the most recent unconsumed input timestamp and the next
 * presentation timestamp is genuine input-to-photon latency — not frame
 * latency (render duration) and not vsync-to-vsync interval.
 *
 * virtio-input: no special-casing needed. wlr_backend_autocreate()
 * already drives input through libinput, and libinput already speaks
 * evdev, which is what virtio-input devices present as under QEMU
 * (same as under real hardware). The "handling" this milestone asks
 * for is the keyboard/pointer listeners below existing at all, not a
 * virtio-specific code path.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wayland-server-core.h>
#include <wlr/backend.h>
#include <wlr/render/allocator.h>
#include <wlr/render/wlr_renderer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_cursor.h>
#include <wlr/types/wlr_data_device.h>
#include <wlr/types/wlr_input_device.h>
#include <wlr/types/wlr_keyboard.h>
#include <wlr/types/wlr_output.h>
#include <wlr/types/wlr_output_layout.h>
#include <wlr/types/wlr_pointer.h>
#include <wlr/types/wlr_scene.h>
#include <wlr/types/wlr_seat.h>
#include <wlr/types/wlr_subcompositor.h>
#include <wlr/types/wlr_xcursor_manager.h>
#include <wlr/types/wlr_xdg_shell.h>
#include <wlr/util/log.h>
#include <xkbcommon/xkbcommon.h>

/* --- Latency tracking -----------------------------------------------
 * Deliberately simple: one pending-input timestamp slot, overwritten
 * by whichever input event happened most recently. On the next
 * presented frame, whatever's sitting in that slot is "the input this
 * frame is a response to" for measurement purposes. A production
 * compositor would want per-surface, per-event correlation (did this
 * specific key press cause this specific redraw); for a benchmarking
 * metric at M3, "most recent input to next photon" is the honest,
 * simple thing to measure and is what the roadmap line asks for.
 */
struct nova_latency_tracker {
	bool pending;
	struct timespec input_time; /* CLOCK_MONOTONIC, derived from event->time_msec */
};

static void latency_mark_input(struct nova_latency_tracker *lt, uint32_t time_msec) {
	/* event->time_msec is relative to an arbitrary epoch shared with
	 * CLOCK_MONOTONIC on Linux input devices; convert to a timespec
	 * consistent with what wlr_output's present event reports. */
	lt->pending = true;
	lt->input_time.tv_sec = time_msec / 1000;
	lt->input_time.tv_nsec = (time_msec % 1000) * 1000000L;
}

static double timespec_diff_ms(struct timespec *a, struct timespec *b) {
	double sec_diff = (double)(b->tv_sec - a->tv_sec);
	double nsec_diff = (double)(b->tv_nsec - a->tv_nsec);
	return sec_diff * 1000.0 + nsec_diff / 1000000.0;
}

/* --- Server state ----------------------------------------------------*/

struct nova_server {
	struct wl_display *wl_display;
	struct wlr_backend *backend;
	struct wlr_renderer *renderer;
	struct wlr_allocator *allocator;
	struct wlr_compositor *compositor;
	struct wlr_subcompositor *subcompositor;
	struct wlr_data_device_manager *data_device_manager;

	struct wlr_output_layout *output_layout;
	struct wlr_scene *scene;
	struct wlr_scene_output_layout *scene_layout;
	struct wl_list outputs; /* nova_output::link */
	struct wl_listener new_output;

	struct wlr_xdg_shell *xdg_shell;
	struct wl_listener new_xdg_toplevel;
	struct wl_list toplevels; /* nova_toplevel::link */

	struct wlr_cursor *cursor;
	struct wlr_xcursor_manager *cursor_mgr;
	struct wl_listener cursor_motion;
	struct wl_listener cursor_button;

	struct wlr_seat *seat;
	struct wl_listener new_input;
	struct wl_listener request_cursor;
	struct wl_list keyboards; /* nova_keyboard::link */

	struct nova_latency_tracker latency;
};

struct nova_output {
	struct wl_list link;
	struct nova_server *server;
	struct wlr_output *wlr_output;
	struct wlr_scene_output *scene_output;
	struct wl_listener frame;
	struct wl_listener present;
	struct wl_listener destroy;
};

struct nova_toplevel {
	struct wl_list link;
	struct nova_server *server;
	struct wlr_xdg_toplevel *xdg_toplevel;
	struct wlr_scene_tree *scene_tree;
	struct wl_listener map;
	struct wl_listener unmap;
	struct wl_listener destroy;
};

/* --- Output / frame / present -----------------------------------------
 * `frame`   fires once per refresh cycle: render the scene into a buffer.
 * `present` fires when that buffer's page-flip actually lands on screen
 *           — this is the real photon-out-the-door timestamp, sourced
 *           from the DRM driver's page-flip completion, not from us.
 */

static void output_frame_notify(struct wl_listener *listener, void *data) {
	struct nova_output *output = wl_container_of(listener, output, frame);
	struct wlr_scene *scene = output->server->scene;
	struct wlr_scene_output *scene_output =
		wlr_scene_get_scene_output(scene, output->wlr_output);
	if (scene_output) {
		wlr_scene_output_commit(scene_output, NULL);
		struct timespec now;
		clock_gettime(CLOCK_MONOTONIC, &now);
		wlr_scene_output_send_frame_done(scene_output, &now);
	}
}

static void output_present_notify(struct wl_listener *listener, void *data) {
	struct nova_output *output = wl_container_of(listener, output, present);
	struct wlr_output_event_present *event = data;
	struct nova_latency_tracker *lt = &output->server->latency;

	if (!event->presented || !lt->pending) {
		return;
	}

	/* event->when is the driver-reported presentation time
	 * (CLOCK_MONOTONIC) — actual photons, not "render call returned." */
	struct timespec *presented_at = (struct timespec *)event->when;
	double ms = timespec_diff_ms(&lt->input_time, presented_at);
	lt->pending = false;

	if (ms >= 0.0 && ms < 2000.0) {
		/* Sanity window: a negative or huge delta means this frame
		 * wasn't actually caused by the pending input (e.g. an
		 * unrelated animation frame beat it to the screen) — don't
		 * print a misleading number for those. */
		fprintf(stderr, "nova-display: input-to-photon: %.1f ms\n", ms);
	}
}

static void output_destroy_notify(struct wl_listener *listener, void *data) {
	struct nova_output *output = wl_container_of(listener, output, destroy);
	wl_list_remove(&output->frame.link);
	wl_list_remove(&output->present.link);
	wl_list_remove(&output->destroy.link);
	wl_list_remove(&output->link);
	free(output);
}

static void server_new_output(struct wl_listener *listener, void *data) {
	struct nova_server *server = wl_container_of(listener, server, new_output);
	struct wlr_output *wlr_output = data;

	wlr_output_init_render(wlr_output, server->allocator, server->renderer);

	struct wlr_output_state state;
	wlr_output_state_init(&state);
	wlr_output_state_set_enabled(&state, true);
	struct wlr_output_mode *mode = wlr_output_preferred_mode(wlr_output);
	if (mode) {
		wlr_output_state_set_mode(&state, mode);
	}
	wlr_output_commit_state(wlr_output, &state);
	wlr_output_state_finish(&state);

	struct nova_output *output = calloc(1, sizeof(*output));
	output->server = server;
	output->wlr_output = wlr_output;

	output->frame.notify = output_frame_notify;
	wl_signal_add(&wlr_output->events.frame, &output->frame);
	output->present.notify = output_present_notify;
	wl_signal_add(&wlr_output->events.present, &output->present);
	output->destroy.notify = output_destroy_notify;
	wl_signal_add(&wlr_output->events.destroy, &output->destroy);

	wl_list_insert(&server->outputs, &output->link);

	struct wlr_output_layout_output *l_output =
		wlr_output_layout_add_auto(server->output_layout, wlr_output);
	struct wlr_scene_output *scene_output =
		wlr_scene_output_create(server->scene, wlr_output);
	wlr_scene_output_layout_add_output(server->scene_layout, l_output, scene_output);
	output->scene_output = scene_output;

	wlr_log(WLR_INFO, "nova-display: output %s connected (%dx%d)",
		wlr_output->name, wlr_output->width, wlr_output->height);
}

/* --- xdg_shell: window composition ------------------------------------*/

static void toplevel_map_notify(struct wl_listener *listener, void *data) {
	struct nova_toplevel *toplevel = wl_container_of(listener, toplevel, map);
	wl_list_insert(&toplevel->server->toplevels, &toplevel->link);
}

static void toplevel_unmap_notify(struct wl_listener *listener, void *data) {
	struct nova_toplevel *toplevel = wl_container_of(listener, toplevel, unmap);
	wl_list_remove(&toplevel->link);
}

static void toplevel_destroy_notify(struct wl_listener *listener, void *data) {
	struct nova_toplevel *toplevel = wl_container_of(listener, toplevel, destroy);
	wl_list_remove(&toplevel->map.link);
	wl_list_remove(&toplevel->unmap.link);
	wl_list_remove(&toplevel->destroy.link);
	free(toplevel);
}

static void server_new_xdg_surface(struct wl_listener *listener, void *data) {
	struct nova_server *server = wl_container_of(listener, server, new_xdg_toplevel);
	struct wlr_xdg_surface *xdg_surface = data;

	/* new_surface fires for every xdg_surface (toplevels and popups
	 * alike) -- only toplevels get composited as windows here; popups
	 * are handled by wlr_scene_xdg_surface_create at the parent's
	 * level once mapped, matching wlroots 0.17's tinywl reference. */
	if (xdg_surface->role != WLR_XDG_SURFACE_ROLE_TOPLEVEL) {
		return;
	}
	struct wlr_xdg_toplevel *xdg_toplevel = xdg_surface->toplevel;

	struct nova_toplevel *toplevel = calloc(1, sizeof(*toplevel));
	toplevel->server = server;
	toplevel->xdg_toplevel = xdg_toplevel;
	toplevel->scene_tree = wlr_scene_xdg_surface_create(
		&server->scene->tree, xdg_toplevel->base);
	toplevel->scene_tree->node.data = toplevel;
	xdg_toplevel->base->data = toplevel->scene_tree;

	toplevel->map.notify = toplevel_map_notify;
	wl_signal_add(&xdg_toplevel->base->surface->events.map, &toplevel->map);
	toplevel->unmap.notify = toplevel_unmap_notify;
	wl_signal_add(&xdg_toplevel->base->surface->events.unmap, &toplevel->unmap);
	toplevel->destroy.notify = toplevel_destroy_notify;
	wl_signal_add(&xdg_toplevel->base->events.destroy, &toplevel->destroy);
}

/* --- Input: pointer + keyboard, latency marking on every event --------*/

static void server_cursor_motion_notify(struct wl_listener *listener, void *data) {
	struct nova_server *server = wl_container_of(listener, server, cursor_motion);
	struct wlr_pointer_motion_event *event = data;
	latency_mark_input(&server->latency, event->time_msec);
	wlr_cursor_move(server->cursor, &event->pointer->base, event->delta_x, event->delta_y);
	wlr_seat_pointer_notify_motion(server->seat, event->time_msec,
		server->cursor->x, server->cursor->y);
}

static void server_cursor_button_notify(struct wl_listener *listener, void *data) {
	struct nova_server *server = wl_container_of(listener, server, cursor_button);
	struct wlr_pointer_button_event *event = data;
	latency_mark_input(&server->latency, event->time_msec);
	wlr_seat_pointer_notify_button(server->seat, event->time_msec,
		event->button, event->state);
}

struct nova_keyboard {
	struct wl_list link;
	struct nova_server *server;
	struct wlr_keyboard *wlr_keyboard;
	struct wl_listener key;
	struct wl_listener destroy;
};

static void keyboard_key_notify(struct wl_listener *listener, void *data) {
	struct nova_keyboard *keyboard = wl_container_of(listener, keyboard, key);
	struct wlr_keyboard_key_event *event = data;
	latency_mark_input(&keyboard->server->latency, event->time_msec);
	wlr_seat_set_keyboard(keyboard->server->seat, keyboard->wlr_keyboard);
	wlr_seat_keyboard_notify_key(keyboard->server->seat, event->time_msec,
		event->keycode, event->state);
}

static void keyboard_destroy_notify(struct wl_listener *listener, void *data) {
	struct nova_keyboard *keyboard = wl_container_of(listener, keyboard, destroy);
	wl_list_remove(&keyboard->link);
	wl_list_remove(&keyboard->key.link);
	wl_list_remove(&keyboard->destroy.link);
	free(keyboard);
}

static void server_new_keyboard(struct nova_server *server, struct wlr_input_device *device) {
	struct wlr_keyboard *wlr_keyboard = wlr_keyboard_from_input_device(device);

	struct xkb_context *context = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
	struct xkb_keymap *keymap = xkb_keymap_new_from_names(context, NULL,
		XKB_KEYMAP_COMPILE_NO_FLAGS);
	wlr_keyboard_set_keymap(wlr_keyboard, keymap);
	xkb_keymap_unref(keymap);
	xkb_context_unref(context);
	wlr_keyboard_set_repeat_info(wlr_keyboard, 25, 600);

	struct nova_keyboard *keyboard = calloc(1, sizeof(*keyboard));
	keyboard->server = server;
	keyboard->wlr_keyboard = wlr_keyboard;
	keyboard->key.notify = keyboard_key_notify;
	wl_signal_add(&wlr_keyboard->events.key, &keyboard->key);
	keyboard->destroy.notify = keyboard_destroy_notify;
	wl_signal_add(&device->events.destroy, &keyboard->destroy);
	wl_list_insert(&server->keyboards, &keyboard->link);

	wlr_seat_set_keyboard(server->seat, wlr_keyboard);
}

static void server_new_input(struct wl_listener *listener, void *data) {
	struct nova_server *server = wl_container_of(listener, server, new_input);
	struct wlr_input_device *device = data;

	switch (device->type) {
	case WLR_INPUT_DEVICE_KEYBOARD:
		server_new_keyboard(server, device);
		break;
	case WLR_INPUT_DEVICE_POINTER:
		wlr_cursor_attach_input_device(server->cursor, device);
		break;
	default:
		break;
	}

	uint32_t caps = WL_SEAT_CAPABILITY_POINTER;
	if (!wl_list_empty(&server->keyboards)) {
		caps |= WL_SEAT_CAPABILITY_KEYBOARD;
	}
	wlr_seat_set_capabilities(server->seat, caps);
}

static void seat_request_cursor_notify(struct wl_listener *listener, void *data) {
	struct nova_server *server = wl_container_of(listener, server, request_cursor);
	struct wlr_seat_pointer_request_set_cursor_event *event = data;
	struct wlr_seat_client *focused_client = server->seat->pointer_state.focused_client;
	if (focused_client == event->seat_client) {
		wlr_cursor_set_surface(server->cursor, event->surface,
			event->hotspot_x, event->hotspot_y);
	}
}

/* --- Entry point -------------------------------------------------------*/

int main(int argc, char *argv[]) {
	wlr_log_init(WLR_INFO, NULL);
	printf("\n=== NOVA OS ===\n");
	printf("M3: Nova Display Server starting.\n");

	struct nova_server server = {0};
	server.wl_display = wl_display_create();

	server.backend = wlr_backend_autocreate(server.wl_display, NULL);
	if (!server.backend) {
		wlr_log(WLR_ERROR, "nova-display: failed to create backend");
		return 1;
	}

	/* Renderer + allocator: this pairing (typically GLES2 renderer +
	 * GBM allocator on the DRM backend) is what makes buffer sharing
	 * zero-copy — client-committed buffers become DMA-BUFs the scene
	 * graph references directly, never a CPU-side copy. */
	server.renderer = wlr_renderer_autocreate(server.backend);
	wlr_renderer_init_wl_display(server.renderer, server.wl_display);
	server.allocator = wlr_allocator_autocreate(server.backend, server.renderer);

	server.compositor = wlr_compositor_create(server.wl_display, 5, server.renderer);
	server.subcompositor = wlr_subcompositor_create(server.wl_display);
	server.data_device_manager = wlr_data_device_manager_create(server.wl_display);

	server.output_layout = wlr_output_layout_create();
	wl_list_init(&server.outputs);
	server.new_output.notify = server_new_output;
	wl_signal_add(&server.backend->events.new_output, &server.new_output);

	server.scene = wlr_scene_create();
	server.scene_layout = wlr_scene_attach_output_layout(server.scene, server.output_layout);

	wl_list_init(&server.toplevels);
	server.xdg_shell = wlr_xdg_shell_create(server.wl_display, 3);
	server.new_xdg_toplevel.notify = server_new_xdg_surface;
	wl_signal_add(&server.xdg_shell->events.new_surface, &server.new_xdg_toplevel);

	server.cursor = wlr_cursor_create();
	wlr_cursor_attach_output_layout(server.cursor, server.output_layout);
	server.cursor_mgr = wlr_xcursor_manager_create(NULL, 24);
	server.cursor_motion.notify = server_cursor_motion_notify;
	wl_signal_add(&server.cursor->events.motion, &server.cursor_motion);
	server.cursor_button.notify = server_cursor_button_notify;
	wl_signal_add(&server.cursor->events.button, &server.cursor_button);

	server.seat = wlr_seat_create(server.wl_display, "seat0");
	wl_list_init(&server.keyboards);
	server.new_input.notify = server_new_input;
	wl_signal_add(&server.backend->events.new_input, &server.new_input);
	server.request_cursor.notify = seat_request_cursor_notify;
	wl_signal_add(&server.seat->events.request_set_cursor, &server.request_cursor);

	const char *socket = wl_display_add_socket_auto(server.wl_display);
	if (!socket) {
		wlr_log(WLR_ERROR, "nova-display: failed to open a wayland socket");
		return 1;
	}

	if (!wlr_backend_start(server.backend)) {
		wlr_log(WLR_ERROR, "nova-display: failed to start backend");
		return 1;
	}

	setenv("WAYLAND_DISPLAY", socket, true);
	printf("nova-display: running on WAYLAND_DISPLAY=%s\n", socket);
	printf("nova-display: M3 milestone reached -- Nova 0.4.\n");
	printf("nova-display: input-to-photon latency now printed to stderr per input event.\n");

	wl_display_run(server.wl_display);

	wl_display_destroy_clients(server.wl_display);
	wlr_scene_node_destroy(&server.scene->tree.node);
	wlr_xcursor_manager_destroy(server.cursor_mgr);
	wlr_cursor_destroy(server.cursor);
	wlr_output_layout_destroy(server.output_layout);
	wl_display_destroy(server.wl_display);
	return 0;
}
