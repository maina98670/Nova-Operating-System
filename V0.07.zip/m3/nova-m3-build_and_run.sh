#!/bin/bash
# Nova OS — M3: Nova Display Server
#
# Two separate things happen in this script, and they matter for
# different reasons:
#
#   1. A host-side build + *nested* run — this is the standard wlroots
#      development workflow (the same thing Sway/river developers do):
#      build nova-display for your own machine's architecture and run
#      it inside your existing desktop session as a window, via
#      wlroots' X11 or Wayland backend instead of the DRM backend. No
#      QEMU, no aarch64, no kernel involved — this is purely "does the
#      compositor logic work," in seconds instead of minutes.
#
#   2. Cross-building for the actual aarch64 QEMU target — see
#      README.md's "What's left" section before running this part.
#      Unlike M0-M2, this isn't a single static binary anymore:
#      nova-display links against wlroots, mesa/GBM/EGL, libinput,
#      libudev, libwayland, pixman, xkbcommon — a real shared-library
#      dependency graph that needs to exist *inside* the aarch64 guest,
#      not just get cross-compiled once. That's a target-rootfs problem
#      now, not a single-binary problem, and Buildroot (already step 2
#      of Section 14's checklist) is the right tool for it going
#      forward rather than hand-assembling cpio archives.

set -e

echo "=== Nova OS M3: host-side build + nested smoke test ==="

echo "[1/3] Installing build dependencies for your host architecture..."
sudo apt-get update
sudo apt-get install -y meson ninja-build pkg-config libwayland-dev \
    wayland-protocols libxkbcommon-dev libpixman-1-dev libdrm-dev \
    libgbm-dev libegl1-mesa-dev libgles2-mesa-dev libudev-dev \
    libinput-dev libwlroots-dev

echo "[2/3] Building nova-display..."
meson setup build
ninja -C build

echo "[3/3] Running nova-display nested in your current desktop session..."
echo "This opens a window that IS the Nova compositor — anything you"
echo "run with WAYLAND_DISPLAY pointed at its socket will composite"
echo "inside that window. Check the terminal for 'input-to-photon: N.N ms'"
echo "lines as you move the mouse or type inside it."
echo ""
WLR_BACKENDS=x11 ./build/nova-display
# If your host session is Wayland-native rather than X11, use instead:
#   WLR_BACKENDS=wayland ./build/nova-display

# --- Part 2: the real aarch64 target -----------------------------------
# Not run automatically by this script — read README.md's "What's left"
# first. In short: cross-compiling nova-display itself is the easy part
# (a normal meson cross-file + the aarch64 toolchain from M0/M1/M2 gets
# you there). What's new at M3 is that the *initramfs* now needs a real
# shared-library rootfs (wlroots + mesa/GBM/EGL + libinput + libudev +
# libwayland + pixman + xkbcommon, all built for aarch64), not one
# static binary. Buildroot's BR2_PACKAGE_WLROOTS (plus its Mesa/DRM/
# libinput package options) builds exactly that rootfs and is the
# concrete next step — this is the point in the project where the
# hand-rolled cpio approach from M0-M2 stops being the right tool.
