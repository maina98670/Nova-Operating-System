# Day 23 Change Log

Base: `nova-day22-package.zip`. First day of M7.

1. Added `docs/compositor-backend-decision-v1.md` — ADR: pure-Rust
   stack (Smithay) over wlroots, with real reasoning and honestly
   stated trade-offs.
2. Added `libs/nova-compositor-core`:
   - `model.rs` — `Surface`/`Output`/`Rect`/`SurfaceId`/`OutputId`.
   - `compositor.rs` — `Compositor` state machine: create/resize/move/
     retitle/close/raise a surface, `mark_damaged`, `resize_output`,
     `frame()`. 12 unit tests.
   - `protocol.rs` — separate wire protocol from `nova_ipc::Message`.
     9 message types, roundtrip-tested.
   - `server.rs` — `CompositorServer`, mirroring `AppManager::serve`.
   - `client.rs` — `CompositorClientBackend`, a real
     `nova_window_api::WaylandBackend` implementation.
3. Extended `libs/nova-ipc`: `SeqPacketSocket::send_bytes`/
   `recv_bytes` (raw, alongside the existing `Message`-typed
   `send`/`recv`) so `nova-compositor-core`'s separate protocol reuses
   this crate's socket plumbing instead of duplicating unsafe FFI.
4. Fixed a real gap in `libs/nova-window-api`: `WindowId` had no
   public constructor, meaning no crate outside `nova-window-api`
   could actually implement `WaylandBackend` — silently defeating the
   trait's own stated purpose since Day 19. Added
   `WindowId::from_raw`/`raw()`.
5. Added `apps/org.nova.compositor_demo_a`/`_b` — minimal demo apps
   proving two real, separate processes on one compositor output.
6. Added `tools/nova-day23-compositor-acceptance-test` — the literal
   DoD, live: two real processes, one output, correct per-surface
   damage isolation, correct ordering, and confirmed damage clearing.
7. Updated the workspace `Cargo.toml` with one new lib, two new apps,
   and one new tool.

Named but not built in this delivery (see README's "what's real and
what isn't" and the ADR): any actual Smithay/DRM/KMS integration, any
real pixel output. No GPU or display exists in this build environment
to target either against.

Day 24 (Desktop shell + launcher — lock screen, home screen, app
launcher) is next.
