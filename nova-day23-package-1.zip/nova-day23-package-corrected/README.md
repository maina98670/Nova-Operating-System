# Nova OS — Day 23 Package: Window Manager / Compositor Core

This package continues directly from the Day 22 package (M6 tagged
v0.27). This is the first day of **M7 — GUI & Window System (v0.33,
Days 23-28)**. **Assembled without running any tests or builds** —
files only. Nothing below has been compiled or verified in this pass.
Run `nova-day23-build_and_run.sh` yourself to actually confirm it.

## Day 23 goal

Per the Complete Build Guide:
1. Build (or formalize, if the existing apps' ad hoc `xdg_toplevel`
   handling already implies one) the actual compositor: surface
   management, damage tracking, output configuration.
2. Decide explicitly whether this is wlroots-based or built on "mature
   graphics facilities" more generally — write the decision down.

DoD: two or more existing apps (e.g. Settings and Camera) can run as
separate windows composited on the same output simultaneously, each
getting correct damage/redraw.

## Read this before anything else: what's real and what isn't

**There is no GPU or display in this build environment.** Every
compositor from wlroots to Smithay to a from-scratch one ultimately
needs to push real pixels through a real DRM/KMS device or a real
Wayland/X11 host — none of which exist here. Rather than fake that or
skip the day, this delivery draws the same honest line every
hardware-adjacent piece of this project has drawn since Day 16: build
the actual logic for real, name the boundary clearly.

**What's real**: `nova-compositor-core`'s surface management, damage
tracking, and output configuration — a genuine, unit-tested state
machine — plus a real cross-process IPC service and client, so two
actual separate OS processes really do create windows on one shared
output and the compositor really does track their damage correctly,
independently verifiable from outside both processes.

**What's not**: any pixel ever gets drawn anywhere. See
`docs/compositor-backend-decision-v1.md`.

## What's new

- **`docs/compositor-backend-decision-v1.md`** — the architecture
  decision, task 2. Recommends a pure-Rust stack (Smithay) over
  wlroots, with real reasoning (memory safety at the layer with the
  widest blast radius, consistency with this project's all-Rust
  codebase and eventual Rust kernel track) and honestly-stated
  trade-offs (Smithay is less battle-tested; the decision could be
  revisited once real M12 reference hardware is in hand).
- **`libs/nova-compositor-core`**:
  - `model.rs` — `Surface`, `Output`, `Rect` (with a real `union` for
    combining damage regions).
  - `compositor.rs` — `Compositor`: create/resize/move/retitle/close a
    surface, `raise` (z-order), `mark_damaged`, `resize_output`, and
    `frame()` — the actual damage-tracking algorithm: reports every
    damaged surface in bottom-to-top order plus output-level damage,
    then clears it. 12 unit tests, including the DoD itself
    ("two surfaces, only one damaged, only that one reported") as a
    unit test.
  - `protocol.rs` — a small, deliberately **separate** wire protocol
    from `nova_ipc::Message` (surface/output concerns aren't the
    app-lifecycle protocol's job) — reuses `nova_ipc::SeqPacketSocket`'s
    transport via new raw `send_bytes`/`recv_bytes` methods (see
    below) rather than duplicating unsafe socket FFI. Roundtrip-tested.
  - `server.rs` — `CompositorServer`, mirroring `AppManager::serve`'s
    own pattern exactly (`Arc<Mutex<..>>`, one thread per connection),
    plus direct locking-wrapper methods for external verification —
    the same reason `AppManager::notifications()` exists.
  - `client.rs` — `CompositorClientBackend`, a real implementation of
    `nova_window_api::WaylandBackend` — what makes that trait's own
    Day 19 promise ("the seam a real backend plugs into") literally
    true for the first time.
- **`libs/nova-ipc`**: added `SeqPacketSocket::send_bytes`/`recv_bytes`
  (raw byte-level, alongside the existing `Message`-typed `send`/`recv`)
  so the compositor's separate protocol can reuse this crate's
  well-tested socket plumbing instead of a second crate re-implementing
  the same `libc` calls.
- **`libs/nova-window-api`**: `WindowId` gets a public
  `from_raw`/`raw()` — without this, no crate outside `nova-window-api`
  could actually implement `WaylandBackend` at all (its private field
  meant no external constructor existed), which silently defeated the
  trait's whole stated purpose. Found and fixed as part of building
  the first real external implementation of it.
- **`apps/org.nova.compositor_demo_a`/`_b`** — two minimal demo apps
  (not modifications to Settings/Camera themselves — same call Days
  19-21 made for their own new-API demos) that each connect to App
  Manager and separately to the real compositor, creating a window
  there.
- **`tools/nova-day23-compositor-acceptance-test`** — the literal DoD:
  launches both demo apps as real, separate processes, waits for both
  to have created a real window on the same output, then damages one
  and confirms only that one is reported, damages both and confirms
  both in correct order, and confirms a third frame with nothing new
  damaged is empty (damage is actually cleared, not left stale).

## Run

```bash
./nova-day23-build_and_run.sh
```

Builds the workspace, runs `nova-ipc`/`nova-window-api`/
`nova-compositor-core`'s unit tests, then the live acceptance test.
Needs the same root-capable Linux environment as the Days 11–22 live
tests.

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction.
