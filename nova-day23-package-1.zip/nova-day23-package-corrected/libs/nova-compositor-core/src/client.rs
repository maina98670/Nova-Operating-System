//! The other end of `server.rs`: a real, cross-process
//! implementation of `nova_window_api::WaylandBackend`, connecting to
//! a running [`crate::server::CompositorServer`] over its own socket.
//! This is what makes Day 19's `WaylandBackend` trait's own promise
//! ("the seam a real M7 compositor client plugs into") literally true
//! — `Window::create(CompositorClientBackend::connect(...)?, ...)`
//! now really does create a surface tracked by a real, shared
//! compositor, visible to (and composited alongside) whatever any
//! other connected app created, unlike `StubBackend`'s
//! process-local-only `HashMap`.
//!
//! `state()` reads from a small local cache this backend keeps,
//! updated on every successful call — the same thing a real Wayland
//! client does (track its own window's last-known configured state
//! locally, updated by the compositor's acks/events), rather than a
//! round trip per query. Keeps the wire protocol from needing a
//! `QuerySurface` message just for this.

use crate::protocol::{Message, SOCKET_PATH};
use nova_ipc::SeqPacketSocket;
use nova_window_api::{WaylandBackend, WindowError, WindowId, WindowState};
use std::collections::HashMap;
use std::io;

pub struct CompositorClientBackend {
    conn: SeqPacketSocket,
    app_id: String,
    output: u32,
    cache: HashMap<WindowId, WindowState>,
}

impl CompositorClientBackend {
    /// Connects to a compositor server already listening at
    /// `socket_path` (typically [`SOCKET_PATH`]) — analogous to
    /// `nova_app_runtime::connect_and_handshake` connecting to App
    /// Manager's socket, but for the separate compositor protocol.
    pub fn connect(socket_path: &str, app_id: &str, output: u32) -> io::Result<Self> {
        let conn = SeqPacketSocket::connect(socket_path)?;
        Ok(Self { conn, app_id: app_id.to_string(), output, cache: HashMap::new() })
    }

    pub fn connect_default(app_id: &str, output: u32) -> io::Result<Self> {
        Self::connect(SOCKET_PATH, app_id, output)
    }

    fn request(&self, msg: Message) -> Result<Message, WindowError> {
        self.conn.send_bytes(&msg.encode()).map_err(|e| WindowError::Backend(e.to_string()))?;
        let bytes = self.conn.recv_bytes().map_err(|e| WindowError::Backend(e.to_string()))?;
        Message::decode(&bytes).map_err(|e| WindowError::Backend(e.to_string()))
    }

    fn expect_ack(&self, msg: Message) -> Result<(), WindowError> {
        match self.request(msg)? {
            Message::Ack => Ok(()),
            Message::Error { message } => Err(WindowError::Backend(message)),
            other => Err(WindowError::Backend(format!("unexpected response: {other:?}"))),
        }
    }
}

impl WaylandBackend for CompositorClientBackend {
    fn create_window(&mut self, title: &str, width: u32, height: u32) -> Result<WindowId, WindowError> {
        let msg = Message::CreateSurface { app_id: self.app_id.clone(), output: self.output, title: title.to_string(), x: 0, y: 0, width, height };
        match self.request(msg)? {
            Message::SurfaceCreated { surface } => {
                let id = WindowId::from_raw(surface);
                self.cache.insert(id, WindowState { title: title.to_string(), width, height, open: true });
                Ok(id)
            }
            Message::Error { message } => Err(WindowError::Backend(message)),
            other => Err(WindowError::Backend(format!("unexpected response: {other:?}"))),
        }
    }

    fn resize(&mut self, id: WindowId, width: u32, height: u32) -> Result<(), WindowError> {
        self.expect_ack(Message::ResizeSurface { surface: id.raw(), width, height })?;
        if let Some(state) = self.cache.get_mut(&id) {
            state.width = width;
            state.height = height;
        }
        Ok(())
    }

    fn set_title(&mut self, id: WindowId, title: &str) -> Result<(), WindowError> {
        self.expect_ack(Message::SetTitle { surface: id.raw(), title: title.to_string() })?;
        if let Some(state) = self.cache.get_mut(&id) {
            state.title = title.to_string();
        }
        Ok(())
    }

    fn close(&mut self, id: WindowId) -> Result<(), WindowError> {
        self.expect_ack(Message::CloseSurface { surface: id.raw() })?;
        if let Some(state) = self.cache.get_mut(&id) {
            state.open = false;
        }
        Ok(())
    }

    fn state(&self, id: WindowId) -> Result<WindowState, WindowError> {
        self.cache.get(&id).cloned().ok_or(WindowError::NotFound(id))
    }
}
