//! The compositor's actual core logic: surface management, damage
//! tracking, output configuration. This is Day 23's literal first
//! task, built as a real, pure state machine with **no dependency on
//! any GPU/rendering API** — see this crate's own `Cargo.toml`
//! description and `docs/compositor-backend-decision-v1.md` for why
//! that boundary is deliberate, not a shortcut: there is no GPU or
//! display to render to in this environment, so what's built here is
//! everything a compositor's core logic actually needs to get right
//! *before* rendering — what's damaged, in what order, on which
//! output — fully real and unit-tested, with the actual pixel-pushing
//! step named as the honest gap it is.
//!
//! [`frame`](Compositor::frame) is the core algorithm: given an
//! output, report every surface that needs redrawing (in bottom-to-
//! top compositing order) and the region that changed, then clear
//! that damage — the same mark-then-clear cycle a real compositor
//! runs every frame. A caller (a real renderer, eventually) uses this
//! to know exactly what work is needed instead of redrawing
//! everything every frame.

use crate::model::{Output, OutputId, Rect, Surface, SurfaceId};
use std::collections::HashMap;

#[derive(Debug)]
pub enum CompositorError {
    OutputNotFound(OutputId),
    SurfaceNotFound(SurfaceId),
}

impl std::fmt::Display for CompositorError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CompositorError::OutputNotFound(id) => write!(f, "no output with id {id:?}"),
            CompositorError::SurfaceNotFound(id) => write!(f, "no surface with id {id:?}"),
        }
    }
}
impl std::error::Error for CompositorError {}

/// One output's redraw work for one frame: every damaged surface (in
/// bottom-to-top compositing order) with its damage rect in output
/// coordinates, plus any output-level damage (e.g. from a resolution
/// change, or the gap a just-closed surface left behind). Calling
/// `Compositor::frame` clears everything this reports — it's a
/// one-time report of "what changed since the last frame call", not a
/// standing query.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FrameDamage {
    pub output: OutputId,
    pub damaged_surfaces: Vec<(SurfaceId, Rect)>,
    pub output_damage: Option<Rect>,
}

impl FrameDamage {
    pub fn is_empty(&self) -> bool {
        self.damaged_surfaces.is_empty() && self.output_damage.is_none()
    }
}

#[derive(Default)]
pub struct Compositor {
    outputs: HashMap<OutputId, Output>,
    surfaces: HashMap<SurfaceId, Surface>,
    next_output_id: u32,
    next_surface_id: u32,
}

impl Compositor {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn create_output(&mut self, name: &str, width: u32, height: u32) -> OutputId {
        self.next_output_id += 1;
        let id = OutputId(self.next_output_id);
        self.outputs.insert(id, Output { id, name: name.to_string(), width, height, stack: Vec::new(), output_damage: None });
        id
    }

    pub fn output(&self, id: OutputId) -> Option<&Output> {
        self.outputs.get(&id)
    }

    pub fn surface(&self, id: SurfaceId) -> Option<&Surface> {
        self.surfaces.get(&id)
    }

    /// Surfaces on `output`, bottom-to-top compositing order.
    pub fn surfaces_on(&self, output: OutputId) -> Vec<&Surface> {
        match self.outputs.get(&output) {
            Some(o) => o.stack.iter().filter_map(|id| self.surfaces.get(id)).collect(),
            None => Vec::new(),
        }
    }

    /// Creates a new, topmost surface on `output`. A brand-new surface
    /// is damaged over its entire geometry — it's never been drawn,
    /// so the whole thing needs to be.
    pub fn create_surface(&mut self, app_id: &str, output: OutputId, title: &str, geometry: Rect) -> Result<SurfaceId, CompositorError> {
        if !self.outputs.contains_key(&output) {
            return Err(CompositorError::OutputNotFound(output));
        }
        self.next_surface_id += 1;
        let id = SurfaceId(self.next_surface_id);
        self.surfaces.insert(id, Surface { id, app_id: app_id.to_string(), output, title: title.to_string(), geometry, damage: Some(geometry) });
        self.outputs.get_mut(&output).unwrap().stack.push(id);
        Ok(id)
    }

    pub fn resize_surface(&mut self, id: SurfaceId, width: u32, height: u32) -> Result<(), CompositorError> {
        let surface = self.surfaces.get_mut(&id).ok_or(CompositorError::SurfaceNotFound(id))?;
        let old = surface.geometry;
        surface.geometry.width = width;
        surface.geometry.height = height;
        // Union of old and new: correct whether growing (new area
        // needs drawing) or shrinking (old area needs the background
        // redrawn where the surface no longer covers it).
        surface.damage = Some(union_opt(surface.damage, old.union(&surface.geometry)));
        Ok(())
    }

    pub fn move_surface(&mut self, id: SurfaceId, x: i32, y: i32) -> Result<(), CompositorError> {
        let surface = self.surfaces.get_mut(&id).ok_or(CompositorError::SurfaceNotFound(id))?;
        let old = surface.geometry;
        surface.geometry.x = x;
        surface.geometry.y = y;
        surface.damage = Some(union_opt(surface.damage, old.union(&surface.geometry)));
        Ok(())
    }

    /// Title changes alone don't need a repaint of the surface's own
    /// content — no damage from this by itself, matching how a real
    /// compositor doesn't redraw a window's contents just because its
    /// title string changed (only its own chrome/decoration would,
    /// which this model doesn't render at all).
    pub fn set_title(&mut self, id: SurfaceId, title: &str) -> Result<(), CompositorError> {
        let surface = self.surfaces.get_mut(&id).ok_or(CompositorError::SurfaceNotFound(id))?;
        surface.title = title.to_string();
        Ok(())
    }

    /// Marks `region` (in the surface's own geometry) as needing
    /// redraw — what a client calls after it's actually drawn new
    /// content into its buffer. Accumulates: a second call before the
    /// next `frame` unions with, rather than replaces, prior damage.
    pub fn mark_damaged(&mut self, id: SurfaceId, region: Rect) -> Result<(), CompositorError> {
        let surface = self.surfaces.get_mut(&id).ok_or(CompositorError::SurfaceNotFound(id))?;
        surface.damage = Some(union_opt(surface.damage, region));
        Ok(())
    }

    /// Moves `id` to the top of its output's stack (frontmost) and
    /// marks it damaged, since a surface freshly on top needs
    /// redrawing there regardless of whether its own content changed.
    /// Occlusion of surfaces *below* it isn't modeled — see the module
    /// docs' scope note.
    pub fn raise(&mut self, id: SurfaceId) -> Result<(), CompositorError> {
        let surface = self.surfaces.get(&id).ok_or(CompositorError::SurfaceNotFound(id))?;
        let output = surface.output;
        let geometry = surface.geometry;
        let old_damage = surface.damage;

        let out = self.outputs.get_mut(&output).ok_or(CompositorError::OutputNotFound(output))?;
        out.stack.retain(|s| *s != id);
        out.stack.push(id);

        self.surfaces.get_mut(&id).unwrap().damage = Some(union_opt(old_damage, geometry));
        Ok(())
    }

    /// Removes the surface entirely and marks the region it used to
    /// occupy as **output** damage — nothing owns that region anymore,
    /// so it's the output's job to redraw whatever's now visible
    /// there (background, or another surface, once occlusion is
    /// modeled), not any remaining surface's.
    pub fn close_surface(&mut self, id: SurfaceId) -> Result<(), CompositorError> {
        let surface = self.surfaces.remove(&id).ok_or(CompositorError::SurfaceNotFound(id))?;
        if let Some(output) = self.outputs.get_mut(&surface.output) {
            output.stack.retain(|s| *s != id);
            output.output_damage = Some(union_opt(output.output_damage, surface.geometry));
        }
        Ok(())
    }

    /// A resolution change damages the whole output — nothing on
    /// screen can be trusted to still be valid at the old size.
    pub fn resize_output(&mut self, id: OutputId, width: u32, height: u32) -> Result<(), CompositorError> {
        let output = self.outputs.get_mut(&id).ok_or(CompositorError::OutputNotFound(id))?;
        output.width = width;
        output.height = height;
        output.output_damage = Some(union_opt(output.output_damage, Rect::new(0, 0, width, height)));
        Ok(())
    }

    /// The core damage-tracking algorithm: reports every damaged
    /// surface on `output` in bottom-to-top order, plus any pending
    /// output-level damage, then **clears all of it** — the same
    /// mark-then-clear cycle a real compositor's damage tracking runs
    /// once per frame, so calling this twice in a row with nothing
    /// marked damaged in between returns an empty `FrameDamage` the
    /// second time.
    pub fn frame(&mut self, output_id: OutputId) -> Result<FrameDamage, CompositorError> {
        let output = self.outputs.get_mut(&output_id).ok_or(CompositorError::OutputNotFound(output_id))?;
        let output_damage = output.output_damage.take();
        let stack = output.stack.clone();

        let mut damaged_surfaces = Vec::new();
        for id in stack {
            if let Some(surface) = self.surfaces.get_mut(&id) {
                if let Some(rect) = surface.damage.take() {
                    damaged_surfaces.push((id, rect));
                }
            }
        }

        Ok(FrameDamage { output: output_id, damaged_surfaces, output_damage })
    }
}

fn union_opt(existing: Option<Rect>, new: Rect) -> Rect {
    match existing {
        Some(r) => r.union(&new),
        None => new,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Rect;

    fn setup() -> (Compositor, OutputId) {
        let mut c = Compositor::new();
        let output = c.create_output("output-0", 1080, 2400);
        (c, output)
    }

    #[test]
    fn new_surface_is_damaged_over_its_full_geometry() {
        let (mut c, output) = setup();
        let geom = Rect::new(0, 0, 400, 600);
        let s = c.create_surface("org.nova.settings", output, "Settings", geom).unwrap();

        let frame = c.frame(output).unwrap();
        assert_eq!(frame.damaged_surfaces, vec![(s, geom)]);
    }

    #[test]
    fn second_frame_with_nothing_new_is_empty() {
        let (mut c, output) = setup();
        c.create_surface("org.nova.settings", output, "Settings", Rect::new(0, 0, 100, 100)).unwrap();
        c.frame(output).unwrap(); // consumes the initial damage
        let frame2 = c.frame(output).unwrap();
        assert!(frame2.is_empty());
    }

    /// The actual Day 23 DoD, expressed as a unit test: two surfaces
    /// on the same output, only one damaged -> only that one is
    /// reported.
    #[test]
    fn two_surfaces_same_output_only_one_damaged_reports_only_that_one() {
        let (mut c, output) = setup();
        let settings = c.create_surface("org.nova.settings", output, "Settings", Rect::new(0, 0, 400, 600)).unwrap();
        let camera = c.create_surface("org.nova.camera", output, "Camera", Rect::new(400, 0, 400, 600)).unwrap();
        c.frame(output).unwrap(); // consume both initial-creation damage entries

        c.mark_damaged(settings, Rect::new(0, 0, 50, 50)).unwrap();
        let frame = c.frame(output).unwrap();
        assert_eq!(frame.damaged_surfaces, vec![(settings, Rect::new(0, 0, 50, 50))]);
        assert!(!frame.damaged_surfaces.iter().any(|(id, _)| *id == camera), "camera was never marked damaged, so it must not appear");
    }

    #[test]
    fn both_damaged_reports_both_in_bottom_to_top_order() {
        let (mut c, output) = setup();
        let settings = c.create_surface("org.nova.settings", output, "Settings", Rect::new(0, 0, 400, 600)).unwrap();
        let camera = c.create_surface("org.nova.camera", output, "Camera", Rect::new(400, 0, 400, 600)).unwrap();
        c.frame(output).unwrap();

        c.mark_damaged(settings, Rect::new(0, 0, 10, 10)).unwrap();
        c.mark_damaged(camera, Rect::new(400, 0, 10, 10)).unwrap();
        let frame = c.frame(output).unwrap();
        // settings was created first, so it's lower in the stack (bottom-to-top).
        assert_eq!(frame.damaged_surfaces, vec![(settings, Rect::new(0, 0, 10, 10)), (camera, Rect::new(400, 0, 10, 10))]);
    }

    #[test]
    fn raise_moves_to_top_and_marks_damaged() {
        let (mut c, output) = setup();
        let a = c.create_surface("org.nova.a", output, "A", Rect::new(0, 0, 100, 100)).unwrap();
        let b = c.create_surface("org.nova.b", output, "B", Rect::new(0, 0, 100, 100)).unwrap();
        c.frame(output).unwrap();

        c.raise(a).unwrap();
        assert_eq!(c.output(output).unwrap().stack, vec![b, a]);
        let frame = c.frame(output).unwrap();
        assert!(frame.damaged_surfaces.iter().any(|(id, _)| *id == a));
    }

    #[test]
    fn close_surface_removes_it_and_damages_the_output_at_its_old_spot() {
        let (mut c, output) = setup();
        let geom = Rect::new(10, 10, 200, 200);
        let s = c.create_surface("org.nova.settings", output, "Settings", geom).unwrap();
        c.frame(output).unwrap();

        c.close_surface(s).unwrap();
        assert!(c.surface(s).is_none());
        assert!(c.surfaces_on(output).is_empty());

        let frame = c.frame(output).unwrap();
        assert!(frame.damaged_surfaces.is_empty(), "the closed surface itself reports no damage -- it's gone");
        assert_eq!(frame.output_damage, Some(geom), "but the output must redraw the gap it left behind");
    }

    #[test]
    fn resize_output_damages_the_whole_output() {
        let (mut c, output) = setup();
        c.frame(output).unwrap(); // nothing pending yet
        c.resize_output(output, 1440, 3200).unwrap();
        let frame = c.frame(output).unwrap();
        assert_eq!(frame.output_damage, Some(Rect::new(0, 0, 1440, 3200)));
    }

    #[test]
    fn resize_surface_damage_covers_old_and_new_geometry() {
        let (mut c, output) = setup();
        let s = c.create_surface("org.nova.settings", output, "Settings", Rect::new(0, 0, 400, 600)).unwrap();
        c.frame(output).unwrap();

        c.resize_surface(s, 200, 300).unwrap(); // shrink
        let frame = c.frame(output).unwrap();
        // union of (0,0,400,600) and (0,0,200,300) is just (0,0,400,600) --
        // the old, larger area, since the new one is fully inside it.
        assert_eq!(frame.damaged_surfaces, vec![(s, Rect::new(0, 0, 400, 600))]);
    }

    #[test]
    fn creating_a_surface_on_a_missing_output_is_an_error() {
        let mut c = Compositor::new();
        let result = c.create_surface("org.nova.x", OutputId(999), "X", Rect::new(0, 0, 1, 1));
        assert!(matches!(result, Err(CompositorError::OutputNotFound(_))));
    }

    #[test]
    fn operations_on_a_missing_surface_are_errors_not_panics() {
        let (mut c, _output) = setup();
        let missing = SurfaceId(999);
        assert!(matches!(c.resize_surface(missing, 1, 1), Err(CompositorError::SurfaceNotFound(_))));
        assert!(matches!(c.move_surface(missing, 0, 0), Err(CompositorError::SurfaceNotFound(_))));
        assert!(matches!(c.set_title(missing, "x"), Err(CompositorError::SurfaceNotFound(_))));
        assert!(matches!(c.mark_damaged(missing, Rect::new(0, 0, 1, 1)), Err(CompositorError::SurfaceNotFound(_))));
        assert!(matches!(c.raise(missing), Err(CompositorError::SurfaceNotFound(_))));
        assert!(matches!(c.close_surface(missing), Err(CompositorError::SurfaceNotFound(_))));
    }

    #[test]
    fn damage_accumulates_across_multiple_marks_before_a_frame() {
        let (mut c, output) = setup();
        let s = c.create_surface("org.nova.settings", output, "Settings", Rect::new(0, 0, 400, 600)).unwrap();
        c.frame(output).unwrap();

        c.mark_damaged(s, Rect::new(0, 0, 10, 10)).unwrap();
        c.mark_damaged(s, Rect::new(390, 590, 10, 10)).unwrap();
        let frame = c.frame(output).unwrap();
        assert_eq!(frame.damaged_surfaces, vec![(s, Rect::new(0, 0, 400, 600))]);
    }
}
