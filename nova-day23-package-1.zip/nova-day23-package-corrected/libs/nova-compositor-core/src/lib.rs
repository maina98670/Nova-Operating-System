//! Nova OS Day 23 — the compositor core.
//!
//! Per the Complete Build Guide's Day 23 row: "Build (or formalize, if
//! the existing apps' ad hoc `xdg_toplevel` handling already implies
//! one) the actual compositor: surface management, damage tracking,
//! output configuration."
//!
//! ## Honest starting point
//! The "existing apps' ad hoc `xdg_toplevel` handling" is the same
//! never-uploaded, earlier-session app-level work flagged since Day
//! 16 — nothing to formalize; this is built fresh. And more
//! fundamentally: **there is no GPU or display in this build
//! environment**, so nothing here produces actual pixels on a screen.
//! What's real: [`compositor::Compositor`] — surface management,
//! damage tracking, and output configuration as a genuine, unit-tested
//! state machine — plus a real cross-process service
//! ([`server::CompositorServer`]) and client
//! ([`client::CompositorClientBackend`], implementing
//! `nova_window_api::WaylandBackend`) so two separate app processes
//! really can create windows on one shared output and have the
//! compositor track their damage correctly, independently verifiable
//! by an outside test tool. See `docs/compositor-backend-decision-v1.md`
//! for the architecture decision this crate sits under, and this
//! module's own doc comments (`compositor.rs`, `server.rs`) for what's
//! deliberately simplified.
//!
//! ## What's deliberately out of scope here
//! - **Rendering.** No buffer/pixel concept exists at all — `frame()`
//!   reports *what* needs redrawing and *where*, not how to draw it.
//!   That's the seam this decision's chosen backend (Smithay) would
//!   fill, once there's real hardware to target (most naturally M12).
//! - **Occlusion.** A surface below another isn't treated as
//!   partially hidden; `frame()` reports every damaged surface's own
//!   damage independent of what's stacked above it. A real compositor
//!   clips against occluders before reporting damage; this one
//!   doesn't yet.
//! - **Output discovery protocol.** Apps assume output id `1` (see
//!   the demo apps' own doc comments) rather than querying for it.
//! - **Input.** Still `nova-input-api`'s job (Day 19), still honestly
//!   `NotYetAvailable` — nothing here changes that.

pub mod client;
pub mod compositor;
pub mod model;
pub mod protocol;
pub mod server;

pub use compositor::{Compositor, CompositorError, FrameDamage};
pub use model::{Output, OutputId, Rect, Surface, SurfaceId};
