//! Data model for the compositor core: surfaces, outputs, geometry,
//! and damage regions. No I/O, no rendering — see `compositor.rs` for
//! the actual state machine built on these types.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct SurfaceId(pub u32);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct OutputId(pub u32);

/// A pixel rectangle: top-left `(x, y)`, `width` x `height`. Used both
/// for a surface's placement on an output and for damage regions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Rect {
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
}

impl Rect {
    pub fn new(x: i32, y: i32, width: u32, height: u32) -> Self {
        Self { x, y, width, height }
    }

    /// The smallest rect containing both `self` and `other` — how
    /// per-surface damage regions get combined for one output's
    /// per-frame damage report, so a caller doesn't have to walk a
    /// growing list of small rects itself.
    pub fn union(&self, other: &Rect) -> Rect {
        let x = self.x.min(other.x);
        let y = self.y.min(other.y);
        let right = (self.x + self.width as i32).max(other.x + other.width as i32);
        let bottom = (self.y + self.height as i32).max(other.y + other.height as i32);
        Rect { x, y, width: (right - x) as u32, height: (bottom - y) as u32 }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Surface {
    pub id: SurfaceId,
    pub app_id: String,
    pub output: OutputId,
    pub title: String,
    pub geometry: Rect,
    /// `None` = not currently damaged (nothing to redraw for this
    /// surface). `Some(rect)` = the region that changed since this
    /// surface was last composited, in this surface's own local
    /// coordinates.
    pub damage: Option<Rect>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Output {
    pub id: OutputId,
    pub name: String,
    pub width: u32,
    pub height: u32,
    /// Bottom of stack first, top (frontmost, drawn last) at the end
    /// — the same convention most compositors use for a z-order list.
    pub stack: Vec<SurfaceId>,
    /// Sub-region of the output that's changed since the last
    /// `Compositor::frame` call for this output and hasn't been
    /// reported yet — e.g. from a resolution change, or the gap left
    /// behind by a closed surface. Distinct from any one surface's own
    /// damage.
    pub output_damage: Option<Rect>,
}
