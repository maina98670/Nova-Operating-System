//! The compositor's own wire protocol — deliberately **separate**
//! from `nova_ipc::Message` (the App-Manager-facing app-lifecycle
//! protocol from Day 11 onward). This is a genuinely different
//! concern — surface/output management, not app permissions/
//! lifecycle — and real Wayland itself is many separate protocol
//! interfaces, not one giant enum; growing `nova_ipc::Message`
//! further for GUI-specific messages would blur what that already-
//! versioned protocol spec is actually for.
//!
//! Transport reuses `nova_ipc::SeqPacketSocket`'s raw
//! `send_bytes`/`recv_bytes` (added this same day, specifically for
//! this) rather than a second crate re-implementing the same unsafe
//! `libc` socket calls. Encoding here is a small, independent
//! length-prefixed scheme — not shared with `nova_ipc::Message`'s own
//! private encoding helpers, the same "small enough that a shared
//! dependency isn't worth the coupling" call `nova-cli`'s
//! `manifest_util.rs` already made for a different pair of concerns.

use std::io;

/// Separate socket from the app-lifecycle protocol's
/// `nova_ipc::SOCKET_PATH` — a different service, a different socket.
pub const SOCKET_PATH: &str = "/run/nova/compositor.sock";

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Message {
    CreateSurface { app_id: String, output: u32, title: String, x: i32, y: i32, width: u32, height: u32 },
    SurfaceCreated { surface: u32 },
    ResizeSurface { surface: u32, width: u32, height: u32 },
    MoveSurface { surface: u32, x: i32, y: i32 },
    SetTitle { surface: u32, title: String },
    MarkDamaged { surface: u32, x: i32, y: i32, width: u32, height: u32 },
    CloseSurface { surface: u32 },
    /// Acknowledges any request above that doesn't have its own
    /// specific response (everything except `CreateSurface`, which
    /// gets `SurfaceCreated`).
    Ack,
    Error { message: String },
}

impl Message {
    fn type_byte(&self) -> u8 {
        match self {
            Message::CreateSurface { .. } => 0x01,
            Message::SurfaceCreated { .. } => 0x02,
            Message::ResizeSurface { .. } => 0x03,
            Message::MoveSurface { .. } => 0x04,
            Message::SetTitle { .. } => 0x05,
            Message::MarkDamaged { .. } => 0x06,
            Message::CloseSurface { .. } => 0x07,
            Message::Ack => 0x08,
            Message::Error { .. } => 0x09,
        }
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut out = vec![self.type_byte()];
        match self {
            Message::CreateSurface { app_id, output, title, x, y, width, height } => {
                put_str(&mut out, app_id);
                out.extend_from_slice(&output.to_le_bytes());
                put_str(&mut out, title);
                out.extend_from_slice(&x.to_le_bytes());
                out.extend_from_slice(&y.to_le_bytes());
                out.extend_from_slice(&width.to_le_bytes());
                out.extend_from_slice(&height.to_le_bytes());
            }
            Message::SurfaceCreated { surface } => out.extend_from_slice(&surface.to_le_bytes()),
            Message::ResizeSurface { surface, width, height } => {
                out.extend_from_slice(&surface.to_le_bytes());
                out.extend_from_slice(&width.to_le_bytes());
                out.extend_from_slice(&height.to_le_bytes());
            }
            Message::MoveSurface { surface, x, y } => {
                out.extend_from_slice(&surface.to_le_bytes());
                out.extend_from_slice(&x.to_le_bytes());
                out.extend_from_slice(&y.to_le_bytes());
            }
            Message::SetTitle { surface, title } => {
                out.extend_from_slice(&surface.to_le_bytes());
                put_str(&mut out, title);
            }
            Message::MarkDamaged { surface, x, y, width, height } => {
                out.extend_from_slice(&surface.to_le_bytes());
                out.extend_from_slice(&x.to_le_bytes());
                out.extend_from_slice(&y.to_le_bytes());
                out.extend_from_slice(&width.to_le_bytes());
                out.extend_from_slice(&height.to_le_bytes());
            }
            Message::CloseSurface { surface } => out.extend_from_slice(&surface.to_le_bytes()),
            Message::Ack => {}
            Message::Error { message } => put_str(&mut out, message),
        }
        out
    }

    pub fn decode(data: &[u8]) -> io::Result<Message> {
        let mut r = Reader { data, pos: 0 };
        let type_byte = r.u8()?;
        Ok(match type_byte {
            0x01 => Message::CreateSurface {
                app_id: r.str()?,
                output: r.u32()?,
                title: r.str()?,
                x: r.i32()?,
                y: r.i32()?,
                width: r.u32()?,
                height: r.u32()?,
            },
            0x02 => Message::SurfaceCreated { surface: r.u32()? },
            0x03 => Message::ResizeSurface { surface: r.u32()?, width: r.u32()?, height: r.u32()? },
            0x04 => Message::MoveSurface { surface: r.u32()?, x: r.i32()?, y: r.i32()? },
            0x05 => Message::SetTitle { surface: r.u32()?, title: r.str()? },
            0x06 => Message::MarkDamaged { surface: r.u32()?, x: r.i32()?, y: r.i32()?, width: r.u32()?, height: r.u32()? },
            0x07 => Message::CloseSurface { surface: r.u32()? },
            0x08 => Message::Ack,
            0x09 => Message::Error { message: r.str()? },
            other => return Err(err(&format!("unknown compositor message type 0x{other:02X}"))),
        })
    }
}

fn put_str(out: &mut Vec<u8>, s: &str) {
    let bytes = s.as_bytes();
    out.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
    out.extend_from_slice(bytes);
}

fn err(msg: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, msg.to_string())
}

struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    fn u8(&mut self) -> io::Result<u8> {
        let b = *self.data.get(self.pos).ok_or_else(|| err("truncated: u8"))?;
        self.pos += 1;
        Ok(b)
    }

    fn u32(&mut self) -> io::Result<u32> {
        let bytes = self.data.get(self.pos..self.pos + 4).ok_or_else(|| err("truncated: u32"))?;
        self.pos += 4;
        Ok(u32::from_le_bytes(bytes.try_into().unwrap()))
    }

    fn i32(&mut self) -> io::Result<i32> {
        self.u32().map(|v| v as i32)
    }

    fn str(&mut self) -> io::Result<String> {
        let len = self.u32()? as usize;
        let bytes = self.data.get(self.pos..self.pos + len).ok_or_else(|| err("truncated: str"))?;
        self.pos += len;
        String::from_utf8(bytes.to_vec()).map_err(|_| err("invalid utf-8"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn roundtrip(m: Message) {
        let encoded = m.encode();
        let decoded = Message::decode(&encoded).expect("decode failed");
        assert_eq!(m, decoded);
    }

    #[test]
    fn every_message_type_round_trips() {
        roundtrip(Message::CreateSurface { app_id: "org.nova.settings".into(), output: 1, title: "Settings".into(), x: 0, y: 0, width: 400, height: 600 });
        roundtrip(Message::SurfaceCreated { surface: 7 });
        roundtrip(Message::ResizeSurface { surface: 7, width: 500, height: 700 });
        roundtrip(Message::MoveSurface { surface: 7, x: -10, y: 20 });
        roundtrip(Message::SetTitle { surface: 7, title: "Renamed".into() });
        roundtrip(Message::MarkDamaged { surface: 7, x: 0, y: 0, width: 50, height: 50 });
        roundtrip(Message::CloseSurface { surface: 7 });
        roundtrip(Message::Ack);
        roundtrip(Message::Error { message: "no such output".into() });
    }

    #[test]
    fn negative_coordinates_round_trip_correctly() {
        roundtrip(Message::MoveSurface { surface: 1, x: -1234, y: -5678 });
    }

    #[test]
    fn decode_rejects_truncated_data() {
        let encoded = Message::CreateSurface { app_id: "x".into(), output: 1, title: "y".into(), x: 0, y: 0, width: 1, height: 1 }.encode();
        let truncated = &encoded[..encoded.len() - 3];
        assert!(Message::decode(truncated).is_err());
    }

    #[test]
    fn decode_rejects_unknown_type_byte() {
        assert!(Message::decode(&[0xFF]).is_err());
    }
}
