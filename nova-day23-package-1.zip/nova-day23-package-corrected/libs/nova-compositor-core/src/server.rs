//! The compositor as a running service — mirrors
//! `nova-app-manager::AppManager`'s own `serve()` pattern (`Arc<Mutex<..>>`
//! state, one thread per connection) so anyone already familiar with
//! that crate recognizes this one immediately.
//!
//! Like every service in this repo so far (see Day 22's `nova
//! run` module docs), this is a **transient** service — whatever
//! process calls `serve()` owns it for as long as that process runs.
//! There's still no persistent Nova system daemon; that gap is named,
//! not hidden, in `nova-cli::run`'s own module doc from Day 22 and
//! applies equally here.

use crate::compositor::{Compositor, CompositorError, FrameDamage};
use crate::model::{Output, OutputId, Rect, Surface, SurfaceId};
use crate::protocol::Message;
use nova_ipc::SeqPacketSocket;
use std::io;
use std::sync::{Arc, Mutex};
use std::thread;

pub struct CompositorServer {
    inner: Arc<Mutex<Compositor>>,
}

impl Default for CompositorServer {
    fn default() -> Self {
        Self::new()
    }
}

impl CompositorServer {
    pub fn new() -> Self {
        Self { inner: Arc::new(Mutex::new(Compositor::new())) }
    }

    /// Binds the compositor's own socket (separate from App Manager's
    /// — see `protocol`'s module doc) and starts accepting
    /// connections, one thread per client, the same pattern
    /// `AppManager::serve` already uses.
    pub fn serve(&self, socket_path: &str) -> io::Result<thread::JoinHandle<()>> {
        let listener = SeqPacketSocket::listen(socket_path)?;
        let inner = self.inner.clone();
        Ok(thread::spawn(move || loop {
            match listener.accept() {
                Ok(conn) => {
                    let inner = inner.clone();
                    thread::spawn(move || handle_connection(inner, conn));
                }
                Err(_) => break, // listener closed / fatal accept error
            }
        }))
    }

    // --- Direct, locking-wrapper access for whatever process is
    // hosting this server (a live acceptance test, or an eventual
    // shell) to introspect real state without going over its own
    // socket to itself -- the exact pattern
    // `AppManager::notifications()`/`process_list()` already
    // established for the same reason: external verification that
    // doesn't have to trust a client's own claims about itself.

    pub fn create_output(&self, name: &str, width: u32, height: u32) -> OutputId {
        self.inner.lock().unwrap().create_output(name, width, height)
    }

    pub fn output(&self, id: OutputId) -> Option<Output> {
        self.inner.lock().unwrap().output(id).cloned()
    }

    pub fn surface(&self, id: SurfaceId) -> Option<Surface> {
        self.inner.lock().unwrap().surface(id).cloned()
    }

    pub fn surfaces_on(&self, output: OutputId) -> Vec<Surface> {
        self.inner.lock().unwrap().surfaces_on(output).into_iter().cloned().collect()
    }

    pub fn mark_damaged(&self, id: SurfaceId, region: Rect) -> Result<(), CompositorError> {
        self.inner.lock().unwrap().mark_damaged(id, region)
    }

    pub fn frame(&self, output: OutputId) -> Result<FrameDamage, CompositorError> {
        self.inner.lock().unwrap().frame(output)
    }
}

fn handle_connection(inner: Arc<Mutex<Compositor>>, conn: SeqPacketSocket) {
    loop {
        let bytes = match conn.recv_bytes() {
            Ok(b) => b,
            Err(_) => break, // client disconnected
        };
        let msg = match Message::decode(&bytes) {
            Ok(m) => m,
            Err(e) => {
                let _ = conn.send_bytes(&Message::Error { message: e.to_string() }.encode());
                continue;
            }
        };

        let response = dispatch(&inner, msg);
        if conn.send_bytes(&response.encode()).is_err() {
            break;
        }
    }
}

fn dispatch(inner: &Arc<Mutex<Compositor>>, msg: Message) -> Message {
    let mut c = inner.lock().unwrap();
    match msg {
        Message::CreateSurface { app_id, output, title, x, y, width, height } => {
            match c.create_surface(&app_id, OutputId(output), &title, Rect::new(x, y, width, height)) {
                Ok(id) => Message::SurfaceCreated { surface: id.0 },
                Err(e) => Message::Error { message: e.to_string() },
            }
        }
        Message::ResizeSurface { surface, width, height } => match c.resize_surface(SurfaceId(surface), width, height) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::MoveSurface { surface, x, y } => match c.move_surface(SurfaceId(surface), x, y) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::SetTitle { surface, title } => match c.set_title(SurfaceId(surface), &title) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::MarkDamaged { surface, x, y, width, height } => match c.mark_damaged(SurfaceId(surface), Rect::new(x, y, width, height)) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::CloseSurface { surface } => match c.close_surface(SurfaceId(surface)) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        // SurfaceCreated/Ack/Error are server -> client only; a client
        // sending one is a protocol misuse, reported honestly rather
        // than silently ignored.
        other => Message::Error { message: format!("not a valid client request: {other:?}") },
    }
}
