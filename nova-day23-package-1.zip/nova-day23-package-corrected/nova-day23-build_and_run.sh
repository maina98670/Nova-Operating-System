#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 23: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 23: nova-ipc + nova-window-api + nova-compositor-core unit tests ==="
cargo test -p nova-ipc -p nova-window-api -p nova-compositor-core

echo
echo "=== Nova OS Day 23: live acceptance ==="
echo "Launches two real, separate demo app processes, each creating a window on the same"
echo "real compositor output, then proves per-surface damage tracking from outside both"
echo "apps. Needs the same root-capable Linux environment as the Day 11-22 live tests."
cargo run -p nova-day23-compositor-acceptance-test

echo
echo "Day 23 build + tests + live acceptance completed."
