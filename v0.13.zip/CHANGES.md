# Nova OS — Verification Fixes (Days 2–10)

This archive mirrors the original package's folder structure and
contains **every file for Days 2 through 10** — unchanged days
included as-is, changed days with fixes applied. Drop the whole tree
into your repo, or cherry-pick individual day folders.

**All of Days 2–10 have been built, tested, and their live Definition
of Done run end to end** — every result in the table at the bottom of
this file was actually observed, not assumed.

## Added: missing workspace `Cargo.toml` (Day 2)

Day 2 had the same structural gap as Days 3/4/5 below — no top-level
workspace `Cargo.toml`, so `cargo test -p nova-procmgr` etc. failed
with `could not find Cargo.toml`. Added, matching the same pattern:

- `Day02-ProcessManager/Cargo.toml` — members: `libs/nova-procmgr`,
  `system/nova-procmgrd`, `tools/nova-procmgr-test`

Once added, Day 2 built and passed clean on the first real run — no
source bugs found. All 10 `nova-procmgr` unit tests and 4
`nova-procmgrd` protocol tests passed, and the live end-to-end test
(real client + real server over a real Unix domain socket) confirmed
spawn -> list -> get -> terminate -> observe the `terminated` state
transition, entirely through Nova's Process Manager API.

## Added: missing workspace `Cargo.toml` (Days 3, 4, 5)

Days 3, 4, and 5 shipped without a top-level workspace `Cargo.toml`,
so `cargo test -p <crate>` / `cargo build -p <crate>` failed with
`could not find Cargo.toml`. Days 6–9 already had this file; these
three didn't. Added, matching the same pattern:

- `Day03-MemoryManager/Cargo.toml` — members: `libs/nova-memmgr`,
  `tools/nova-memtest-hog`, `tools/nova-memmgr-test`
- `Day04-FilesystemManager/Cargo.toml` — members: `libs/nova-fsmgr`,
  `tools/nova-fsmgr-test`
- `Day05-DeviceManager/Cargo.toml` — members: `libs/nova-devmgr`,
  `tools/nova-devmgr-test`

## Fixed: Day 8 — `load_or_default` returning zeroed defaults

**Bug:** `load_or_default<T: Default>()` calls the standard `T::default()`
trait method when a config file is missing. Both `ExampleServiceConfig`
(test-only struct in the library) and `DemoServiceConfig` (in the live
`nova-config-test` binary) used `#[derive(Default)]`, which just zero-fills
each field (`max_connections: 0, log_level: ""`) — completely disconnected
from the hand-written sensible defaults (`64`, `"INFO"`) defined nearby.
Caught by the library's own unit test
(`missing_config_file_uses_defaults_not_an_error`), which failed with
`left: ... 0, "" ... right: ... 64, "INFO"`.

**Fix:** replaced the derive with a manual `impl Default` that returns the
intended values, in both places.

- `Day08-Configuration/libs/nova-config/src/lib.rs`
  (`ExampleServiceConfig`, inside the `#[cfg(test)]` module)
- `Day08-Configuration/tools/nova-config-test/src/main.rs`
  (`DemoServiceConfig`)

## Fixed: Day 10 — `ps` never showed service-managed processes

**Bug:** `nova-init` keeps its own `ProcessManager` (`boot.processes`)
purely to back the `ps` console command — but nothing ever spawns
anything into it. The actual `test-echo` / `test-crasher` processes are
tracked inside `ServiceManager`'s own **private, separate**
`ProcessManager`, which had no public accessor. Result: `ps` after
`svc start test-echo` printed nothing for it. Caught by the Section 9.10
acceptance script (`scripts/nova-m4-acceptance-test.sh`):
`[FAIL] list processes (test-echo appears after start) -- expected to
find: sleep`.

**Fix:**
- `Day10-Integration-Console-Acceptance-Tag/libs/nova-svcmgr/src/lib.rs`
  — added `pub fn processes(&self) -> &ProcessManager` to `ServiceManager`,
  exposing its internal process tracker read-only.
- `Day10-Integration-Console-Acceptance-Tag/system/nova-init/src/main.rs`
  — the `"ps"` console command now also iterates
  `boot.services.processes().list()`, so both directly-spawned and
  service-managed processes show up.

## Verification result after these fixes

All of Days 3–10 build clean and pass their own live Definition of
Done / acceptance criteria:

| Day | Result |
|---|---|
| 2 — Process Manager | 10+4 unit tests, live DoD PASS (workspace file added) |
| 3 — Memory Manager | 5/5 unit tests, live DoD PASS |
| 4 — Filesystem Manager | 7/7 unit tests, live DoD PASS |
| 5 — Device Manager | 7/7 unit tests, live DoD PASS |
| 6 — Service Manager | 8/8 unit tests, live DoD PASS |
| 7 — Logging | 8+7 unit tests, live DoD PASS |
| 8 — Configuration | 7/7 unit tests (after fix), live DoD PASS |
| 9 — Nova Core API | 2/2 facade tests, doc example PASS |
| 10 — Integration/Console | builds clean, 22/22 acceptance checks PASS (after fix) |

Day 10's `git tag` step (per
`docs/nova-m4-boot-runtime-overview.md`) is still yours to run once
these fixes are merged into your working tree.
