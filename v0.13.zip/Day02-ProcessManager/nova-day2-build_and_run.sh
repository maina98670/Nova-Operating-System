#!/bin/bash
# Nova OS — Day 2: Process Manager (M4, per the Complete Build Guide)
# Unlike M0-M3, this needs NO cross-compilation or QEMU — it's real
# Linux process-management logic, fully testable on any Linux machine,
# including this very sandbox (already verified — see README.md).
set -e

echo "=== Nova OS Day 2: Process Manager ==="

echo "[1/3] Running nova-procmgr library unit tests (10 tests, spawns real processes)..."
cargo test -p nova-procmgr

echo "[2/3] Running nova-procmgrd protocol unit tests (4 tests)..."
cargo test -p nova-procmgrd

echo "[3/3] Building the real server + test client, then running them live..."
cargo build -p nova-procmgrd -p nova-procmgr-test

export NOVA_PROCMGR_SOCK="${NOVA_PROCMGR_SOCK:-/tmp/nova-procmgr.sock}"
rm -f "$NOVA_PROCMGR_SOCK"

./target/debug/nova-procmgrd &
SERVER_PID=$!
sleep 0.5

echo ""
echo "=== Live end-to-end test: real client against real server over a real Unix socket ==="
./target/debug/nova-procmgr-test
CLIENT_EXIT=$?

kill $SERVER_PID 2>/dev/null || true
rm -f "$NOVA_PROCMGR_SOCK"

exit $CLIENT_EXIT
