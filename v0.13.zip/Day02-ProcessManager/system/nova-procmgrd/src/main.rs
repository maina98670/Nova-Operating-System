//! Nova Process Manager daemon — binds a Unix domain socket and
//! serves `nova_procmgrd_proto::handle_command` to any connected
//! client, one thread per connection. This is the actual system
//! service M2's Nova Init would start (per Section 1's boot sequence:
//! Init starts services in order; this is one of them) — running it
//! standalone here, outside Nova Init, is exactly how it's tested in
//! this sandbox without needing a full OS boot.

use nova_procmgr::ProcessManager;
use nova_procmgrd_proto::handle_command;
use std::env;
use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::sync::{Arc, Mutex};
use std::thread;

fn socket_path() -> String {
    env::var("NOVA_PROCMGR_SOCK").unwrap_or_else(|_| "/run/nova/procmgr.sock".to_string())
}

fn handle_client(stream: UnixStream, pm: Arc<Mutex<ProcessManager>>) {
    let reader = BufReader::new(stream.try_clone().expect("clone stream"));
    let mut writer = stream;
    for line in reader.lines() {
        let line = match line {
            Ok(l) => l,
            Err(_) => break,
        };
        if line.is_empty() {
            continue;
        }
        let response = {
            let mut pm = pm.lock().expect("procmgr lock poisoned");
            handle_command(&mut pm, &line)
        };
        if writer.write_all(response.as_bytes()).is_err() {
            break;
        }
        if writer.write_all(b"\n---\n").is_err() {
            break; // end-of-response marker, since LIST responses are multi-line
        }
    }
}

fn main() {
    let path = socket_path();
    let _ = std::fs::remove_file(&path); // stale socket from a prior run

    if let Some(parent) = std::path::Path::new(&path).parent() {
        let _ = std::fs::create_dir_all(parent);
    }

    let listener = UnixListener::bind(&path).unwrap_or_else(|e| {
        eprintln!("nova-procmgrd: could not bind {path}: {e}");
        std::process::exit(1);
    });
    println!("nova-procmgrd: listening on {path}");
    println!("nova-procmgrd: Day 2 (Process Manager) service starting -- Nova 0.4x (M4 in progress)");

    let pm = Arc::new(Mutex::new(ProcessManager::new()));

    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                let pm = pm.clone();
                thread::spawn(move || handle_client(stream, pm));
            }
            Err(e) => eprintln!("nova-procmgrd: accept error: {e}"),
        }
    }
}
