//! Nova Process Manager daemon protocol.
//!
//! Deliberately simple line-based text framing rather than a binary
//! wire format — scoped to Day 2's actual need (a real client/server
//! boundary to satisfy the Guide's DoD, not new protocol
//! infrastructure). `nova-ipc`'s binary framing is purpose-built for
//! the app-control handshake (Hello/HelloAck/ColdStartReport,
//! Section 11's protocol doc); process management is a different
//! system service with different, simpler needs, so it gets its own
//! small protocol rather than overloading nova-ipc's.
//!
//! `handle_command` is the actual logic, kept separate from any
//! socket I/O so it's fully unit-testable — the same "logic separate
//! from OS-layer plumbing" discipline as every `libs/` crate.
//!
//! Commands (one per line):
//!   SPAWN <command> [args...]   -> "OK <pid>" | "ERR <message>"
//!   LIST                        -> "OK <count>" then one line per
//!                                   process: "<pid> <ppid> <state> <command>"
//!   GET <pid>                   -> "OK <pid> <ppid> <state> <exit_code|-> <command>"
//!                                   | "ERR not_found"
//!   TERMINATE <pid>             -> "OK" | "ERR <message>"

use nova_procmgr::{ProcessManager, ProcessState, RestartPolicy};

fn state_str(s: ProcessState) -> &'static str {
    match s {
        ProcessState::Running => "running",
        ProcessState::Sleeping => "sleeping",
        ProcessState::DiskSleep => "disksleep",
        ProcessState::Zombie => "zombie",
        ProcessState::Stopped => "stopped",
        ProcessState::Terminated => "terminated",
        ProcessState::Unknown => "unknown",
    }
}

/// Handles one command line, returning the full response (may be
/// multi-line for LIST). No socket I/O here at all — this function is
/// exercised directly by unit tests below, and separately by
/// `main.rs` over a real `UnixListener`.
pub fn handle_command(pm: &mut ProcessManager, line: &str) -> String {
    pm.reap_zombies(); // keep state fresh before answering any query

    let line = line.trim();
    let mut parts = line.split_whitespace();
    let cmd = match parts.next() {
        Some(c) => c,
        None => return "ERR empty_command".to_string(),
    };

    match cmd {
        "SPAWN" => {
            let command = match parts.next() {
                Some(c) => c,
                None => return "ERR missing_command".to_string(),
            };
            let args: Vec<&str> = parts.collect();
            match pm.spawn(command, &args, RestartPolicy::Never) {
                Ok(pid) => format!("OK {pid}"),
                Err(e) => format!("ERR {e}"),
            }
        }
        "LIST" => {
            let list = pm.list();
            let mut out = format!("OK {}", list.len());
            for info in list {
                out.push('\n');
                out.push_str(&format!(
                    "{} {} {} {}",
                    info.pid,
                    info.ppid,
                    state_str(info.state),
                    info.command
                ));
            }
            out
        }
        "GET" => {
            let pid: u32 = match parts.next().and_then(|s| s.parse().ok()) {
                Some(p) => p,
                None => return "ERR invalid_pid".to_string(),
            };
            match pm.get(pid) {
                Some(info) => format!(
                    "OK {} {} {} {} {}",
                    info.pid,
                    info.ppid,
                    state_str(info.state),
                    info.exit_code.map(|c| c.to_string()).unwrap_or_else(|| "-".to_string()),
                    info.command
                ),
                None => "ERR not_found".to_string(),
            }
        }
        "TERMINATE" => {
            let pid: u32 = match parts.next().and_then(|s| s.parse().ok()) {
                Some(p) => p,
                None => return "ERR invalid_pid".to_string(),
            };
            match pm.terminate(pid) {
                Ok(()) => "OK".to_string(),
                Err(e) => format!("ERR {e}"),
            }
        }
        other => format!("ERR unknown_command:{other}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;
    use std::time::Duration;

    #[test]
    fn spawn_list_get_terminate_full_cycle() {
        let mut pm = ProcessManager::new();

        let spawn_resp = handle_command(&mut pm, "SPAWN sleep 2");
        assert!(spawn_resp.starts_with("OK "), "unexpected: {spawn_resp}");
        let pid: u32 = spawn_resp.strip_prefix("OK ").unwrap().trim().parse().unwrap();

        thread::sleep(Duration::from_millis(100));

        let list_resp = handle_command(&mut pm, "LIST");
        assert!(list_resp.starts_with("OK 1"));
        assert!(list_resp.contains(&pid.to_string()));

        let get_resp = handle_command(&mut pm, &format!("GET {pid}"));
        assert!(get_resp.starts_with("OK"));
        assert!(get_resp.contains("running") || get_resp.contains("sleeping"));

        let term_resp = handle_command(&mut pm, &format!("TERMINATE {pid}"));
        assert_eq!(term_resp, "OK");

        let get_after = handle_command(&mut pm, &format!("GET {pid}"));
        assert!(get_after.contains("terminated"));
    }

    #[test]
    fn get_unknown_pid_returns_err() {
        let mut pm = ProcessManager::new();
        assert_eq!(handle_command(&mut pm, "GET 999999"), "ERR not_found");
    }

    #[test]
    fn unknown_command_returns_err() {
        let mut pm = ProcessManager::new();
        assert!(handle_command(&mut pm, "FROBNICATE").starts_with("ERR unknown_command"));
    }

    #[test]
    fn spawn_missing_command_returns_err() {
        let mut pm = ProcessManager::new();
        assert_eq!(handle_command(&mut pm, "SPAWN"), "ERR missing_command");
    }
}
