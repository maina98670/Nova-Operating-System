//! Nova Process Manager test client — the literal Day 2 Definition of
//! Done: "From a test client: create a process, list it with correct
//! PID/state/parent, terminate it, and observe the state transition
//! -- all through Nova's Process Manager API, not `ps`/`kill`
//! directly."
//!
//! This binary is that test client. It never calls `ps` or `kill` (or
//! any libc process APIs) itself — every observation of the spawned
//! process's existence, state, and termination comes back over the
//! socket from `nova-procmgrd`, which is the actual point: proving
//! the API boundary works as a real client/server system, not just
//! as library calls within one process (which `nova-procmgr`'s own
//! unit tests already cover separately).

use std::env;
use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::UnixStream;
use std::process;
use std::thread;
use std::time::Duration;

fn socket_path() -> String {
    env::var("NOVA_PROCMGR_SOCK").unwrap_or_else(|_| "/run/nova/procmgr.sock".to_string())
}

/// Sends one command, reads until the "---" end-of-response marker
/// `nova-procmgrd` sends after every reply (since LIST responses are
/// multi-line), and returns the response body.
fn send_command(stream: &mut UnixStream, cmd: &str) -> String {
    writeln!(stream, "{cmd}").expect("write to procmgrd failed");
    let mut reader = BufReader::new(stream.try_clone().expect("clone stream"));
    let mut response = String::new();
    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line).expect("read from procmgrd failed");
        if n == 0 || line.trim() == "---" {
            break;
        }
        response.push_str(&line);
    }
    response.trim_end().to_string()
}

fn fail(msg: &str) -> ! {
    eprintln!("nova-procmgr-test: FAIL -- {msg}");
    process::exit(1);
}

fn main() {
    let path = socket_path();
    println!("nova-procmgr-test: connecting to {path}");
    let mut stream = UnixStream::connect(&path).unwrap_or_else(|e| {
        fail(&format!("could not connect to nova-procmgrd at {path}: {e} (is it running?)"));
    });

    // --- Step 1: create a process, entirely through the API ---
    println!("nova-procmgr-test: SPAWN sleep 3");
    let spawn_resp = send_command(&mut stream, "SPAWN sleep 3");
    println!("  <- {spawn_resp}");
    let pid: u32 = spawn_resp
        .strip_prefix("OK ")
        .unwrap_or_else(|| fail(&format!("unexpected SPAWN response: {spawn_resp}")))
        .trim()
        .parse()
        .unwrap_or_else(|_| fail("SPAWN did not return a valid pid"));
    println!("nova-procmgr-test: spawned pid {pid}");

    thread::sleep(Duration::from_millis(150));

    // --- Step 2: list it, verify correct PID/state/parent ---
    println!("nova-procmgr-test: LIST");
    let list_resp = send_command(&mut stream, "LIST");
    println!("  <- {list_resp}");
    if !list_resp.contains(&pid.to_string()) {
        fail(&format!("spawned pid {pid} not present in LIST output"));
    }

    println!("nova-procmgr-test: GET {pid}");
    let get_resp = send_command(&mut stream, &format!("GET {pid}"));
    println!("  <- {get_resp}");
    let fields: Vec<&str> = get_resp.trim_start_matches("OK ").split_whitespace().collect();
    if fields.len() < 3 {
        fail(&format!("malformed GET response: {get_resp}"));
    }
    let (reported_pid, reported_ppid, reported_state) = (fields[0], fields[1], fields[2]);
    if reported_pid != pid.to_string() {
        fail(&format!("GET returned wrong pid: expected {pid}, got {reported_pid}"));
    }
    if reported_ppid == "0" {
        fail("GET returned ppid=0, expected the real parent (nova-procmgrd's pid)");
    }
    if reported_state != "running" && reported_state != "sleeping" {
        fail(&format!("expected running/sleeping state before termination, got {reported_state}"));
    }
    println!(
        "nova-procmgr-test: verified pid={reported_pid} ppid={reported_ppid} state={reported_state}"
    );

    // --- Step 3: terminate it, through the API ---
    println!("nova-procmgr-test: TERMINATE {pid}");
    let term_resp = send_command(&mut stream, &format!("TERMINATE {pid}"));
    println!("  <- {term_resp}");
    if term_resp != "OK" {
        fail(&format!("TERMINATE did not return OK: {term_resp}"));
    }

    // --- Step 4: observe the state transition ---
    println!("nova-procmgr-test: GET {pid} (after termination)");
    let get_after = send_command(&mut stream, &format!("GET {pid}"));
    println!("  <- {get_after}");
    if !get_after.contains("terminated") {
        fail(&format!("expected state=terminated after TERMINATE, got: {get_after}"));
    }

    println!();
    println!("nova-procmgr-test: PASS -- Day 2 Definition of Done satisfied end-to-end");
    println!("nova-procmgr-test: create -> list (correct pid/ppid/state) -> terminate -> observe transition,");
    println!("nova-procmgr-test: all through Nova's Process Manager API, zero calls to ps/kill.");
}
