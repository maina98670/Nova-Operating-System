# Nova OS — Day 3 Package: Memory Manager (M4 continues)

Per the Complete Build Guide, Day 3's focus is the Memory Manager —
same "supervising layer over what Linux already does" discipline as
Day 2's Process Manager, plus one genuinely new piece of policy: an
explicit, deterministic allocation-failure boundary.

## What's in this package

- **libs/nova-memmgr** — reads real per-process memory accounting
  (`VmSize`, `VmRSS`) straight from `/proc/<pid>/status` — never a
  separate Nova-tracked estimate that could drift from reality. Also
  defines `spawn_with_memory_limit`, which enforces a hard virtual
  address space ceiling via `RLIMIT_AS`, set in the child process
  between fork and exec.
- **tools/nova-memtest-hog** — the deliberate allocation-failure
  exerciser. Grows a buffer in real, page-touched 1MB chunks using
  Rust's *fallible* `Vec::try_reserve` (not ordinary `Vec` growth,
  which aborts the whole process on failure with no `Result` to
  react to) until allocation fails, then exits cleanly at a defined
  code (42) — turning "out of memory" into a handled event instead of
  a crash.
- **tools/nova-memmgr-test** — the real test process the Day 3 DoD
  describes literally: queries its own memory, queries a sibling
  process's memory, spawns the hog under a real 20MB limit, and
  confirms both a clean exit code (not a crash signal) and that it
  itself is completely unaffected afterward.

## Why RLIMIT_AS specifically

`RLIMIT_AS` bounds total virtual address space. When a process under
this limit tries to allocate past it, the allocation call itself fails
immediately and cleanly with `ENOMEM` — no SIGSEGV, no waiting for
system-wide physical memory pressure to trip Linux's OOM killer (which
could kill an unrelated process instead of the one actually
misbehaving). That's the literal meaning of Day 3's task: "define and
test the out-of-memory path explicitly, don't leave it to whatever
Linux's OOM killer does by default."

## What was actually verified in this sandbox — all of it, live

- **`cargo test -p nova-memmgr`: 5/5 passing** — including spawning a
  real process under a 200MB limit (proves the limit doesn't break
  normal operation) and a deliberately absurd 1-byte limit (proves the
  failure path itself doesn't hang or panic).
- **The full live Definition of Done, run for real.** Actual output
  from this sandbox:

  ```
  nova-memmgr-test: starting (pid 512)
  nova-memmgr-test: querying own memory accounting...
    pid=512 vsize=3352KB rss=2216KB
  nova-memmgr-test: spawning a sibling process to query...
    pid=513 vsize=2704KB rss=1688KB
  nova-memmgr-test: verified own AND another process's memory accounting -- step 2 done
  nova-memmgr-test: spawning .../nova-memtest-hog under a 20MB RLIMIT_AS limit...
  nova-memtest-hog: allocation failed cleanly after 16 chunks (~16 MB) -- exiting with code 42
  nova-memmgr-test: hog exited cleanly with code 42 -- allocation failure handled as designed
  nova-memmgr-test: confirming this process is still completely healthy...
    pid=512 vsize=3352KB rss=2416KB (still healthy)

  nova-memmgr-test: PASS -- Day 3 Definition of Done satisfied end-to-end
  ```

  The hog hit its real limit at ~16MB out of the 20MB ceiling
  (accounting for the binary, loader, and stack overhead already
  consuming address space before user allocation starts) — exactly
  the deterministic behavior `RLIMIT_AS` is supposed to produce. Exit
  code 42, zero signals, and the caller's own memory accounting
  (`pid=512`) was queried again afterward and found completely
  unaffected — literally proving "without crashing the Memory Manager
  itself."

## Nothing left unverified

Same as Day 2: no "test it on your machine" caveat. Run
`nova-day3-build_and_run.sh` yourself to reproduce this exact result.

## Next: Day 4

Per the Guide's M4 table, Day 4 is the Filesystem Manager.
