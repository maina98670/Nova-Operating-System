//! Nova Memory Manager — M4 Day 3.
//!
//! Same discipline as Day 2's Process Manager: this is a supervising
//! layer that reads Linux's own real memory accounting from `/proc`
//! (never estimates or tracks a separate, potentially-stale copy),
//! plus one genuinely new piece of policy — defining an *explicit*,
//! deterministic allocation-failure boundary via `RLIMIT_AS`, instead
//! of leaving out-of-memory handling to whatever the Linux OOM killer
//! decides at whatever moment physical memory pressure trips it.
//!
//! Why `RLIMIT_AS` specifically: it bounds a process's total virtual
//! address space. When a process under this limit tries to allocate
//! past it, the allocation call itself (`mmap`/`brk`, underneath
//! `malloc`) fails cleanly and immediately with `ENOMEM` — no SIGSEGV,
//! no OOM-killer picking an unrelated victim process under system-wide
//! memory pressure. That determinism is exactly what Day 3's task
//! list asks for ("define and test the out-of-memory path explicitly,
//! don't leave it to whatever Linux's OOM killer does by default").
//!
//! Maps to Day 3's five task bullets:
//! - Allocation interfaces -> `spawn_with_memory_limit`
//! - Memory accounting (per-process, queryable) -> `query`, `query_self`
//! - Virtual-memory interface -> `MemoryInfo::vsize_bytes` (from
//!   `/proc/<pid>/status`'s VmSize, the kernel's own VM accounting)
//! - Process isolation/protection -> the `RLIMIT_AS` enforcement in
//!   `spawn_with_memory_limit`
//! - Allocation failure handling -> tested against the real
//!   `nova-memtest-hog` helper binary (see `tools/`), which uses
//!   Rust's fallible `try_reserve` to turn what would otherwise be an
//!   aborting allocation failure into a clean, observable exit code.

use libc::{rlimit, setrlimit, RLIMIT_AS};
use std::fs;
use std::io;
use std::os::unix::process::CommandExt;
use std::process::{Child, Command};

#[derive(Debug, Clone, Copy)]
pub struct MemoryInfo {
    pub pid: u32,
    /// Virtual memory size — the kernel's own VmSize, i.e. the same
    /// number `RLIMIT_AS` bounds. Not "how much RAM this process is
    /// using" on its own (see `rss_bytes` for that); this is Day 3's
    /// literal "virtual-memory interface" task.
    pub vsize_bytes: u64,
    /// Resident set size — actual physical memory currently mapped in,
    /// per the kernel's accounting.
    pub rss_bytes: u64,
}

fn parse_status_kb_field(status: &str, field: &str) -> Option<u64> {
    for line in status.lines() {
        if let Some(rest) = line.strip_prefix(field) {
            // Format: "VmSize:	  123456 kB"
            let digits: String = rest.chars().filter(|c| c.is_ascii_digit()).collect();
            return digits.parse::<u64>().ok().map(|kb| kb * 1024);
        }
    }
    None
}

/// Reads real memory accounting for `pid` from `/proc/<pid>/status`
/// — the kernel's own numbers, not a Nova-maintained estimate.
pub fn query(pid: u32) -> io::Result<MemoryInfo> {
    let status = fs::read_to_string(format!("/proc/{pid}/status"))?;
    let vsize_bytes = parse_status_kb_field(&status, "VmSize:").unwrap_or(0);
    let rss_bytes = parse_status_kb_field(&status, "VmRSS:").unwrap_or(0);
    Ok(MemoryInfo { pid, vsize_bytes, rss_bytes })
}

/// Convenience for the Day 3 DoD's literal "query its own... memory
/// accounting" — just `query` against the caller's own PID.
pub fn query_self() -> io::Result<MemoryInfo> {
    query(std::process::id())
}

/// Spawns `command` with a hard virtual-address-space ceiling of
/// `limit_bytes`, enforced by the kernel itself via `setrlimit`
/// (called in the child, after fork, before exec — this is why it
/// needs `unsafe`: `pre_exec` runs in a forked child with only
/// async-signal-safe operations allowed, and `setrlimit` is one of
/// the ones that's safe to call there).
///
/// This is the actual "process isolation/protection" mechanism for
/// Day 3, and also what makes allocation-failure handling
/// deterministic rather than dependent on system-wide memory pressure
/// (see module docs).
pub fn spawn_with_memory_limit(command: &str, args: &[&str], limit_bytes: u64) -> io::Result<Child> {
    let mut cmd = Command::new(command);
    cmd.args(args);
    unsafe {
        cmd.pre_exec(move || {
            let rl = rlimit { rlim_cur: limit_bytes, rlim_max: limit_bytes };
            if setrlimit(RLIMIT_AS, &rl) != 0 {
                return Err(io::Error::last_os_error());
            }
            Ok(())
        });
    }
    cmd.spawn()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;
    use std::time::Duration;

    #[test]
    fn query_self_returns_sane_nonzero_values() {
        let info = query_self().expect("query_self should succeed");
        assert_eq!(info.pid, std::process::id());
        assert!(info.vsize_bytes > 0, "a running process should have nonzero virtual size");
        assert!(info.rss_bytes > 0, "a running process should have nonzero resident size");
    }

    #[test]
    fn query_another_process_returns_real_accounting() {
        let mut child = Command::new("sleep").arg("2").spawn().expect("spawn sleep");
        let pid = child.id();
        thread::sleep(Duration::from_millis(100));

        let info = query(pid).expect("query should succeed for a running child");
        assert_eq!(info.pid, pid);
        assert!(info.vsize_bytes > 0);

        let _ = child.kill();
        let _ = child.wait();
    }

    #[test]
    fn query_nonexistent_pid_errors_cleanly() {
        let result = query(999_999);
        assert!(result.is_err());
    }

    #[test]
    fn spawn_with_memory_limit_enforces_the_limit() {
        // A process that just sleeps under a small-but-reasonable
        // limit should still start fine — proves the limit doesn't
        // break normal operation, only genuinely excessive allocation.
        let mut child =
            spawn_with_memory_limit("sleep", &["1"], 200 * 1024 * 1024).expect("spawn should succeed");
        let status = child.wait().expect("wait should succeed");
        assert!(status.success(), "a lightweight process should run fine under a 200MB limit");
    }

    #[test]
    fn spawn_with_memory_limit_rejects_absurdly_low_limit_gracefully() {
        // 1 byte is too small for the dynamic linker itself to even
        // start the process -- this should fail at spawn/exec time,
        // not hang or panic nova-memmgr itself. Either the spawn call
        // errors, or the child exits immediately with failure; either
        // outcome is an acceptable, non-crashing result for this test.
        match spawn_with_memory_limit("true", &[], 1) {
            Ok(mut child) => {
                let status = child.wait().expect("wait should not hang or panic");
                assert!(!status.success(), "a 1-byte limit should prevent successful execution");
            }
            Err(_) => { /* also an acceptable, clean failure mode */ }
        }
    }
}
