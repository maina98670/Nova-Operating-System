#!/bin/bash
# Nova OS — Day 3: Memory Manager (M4, per the Complete Build Guide)
# Like Day 2, this needs no cross-compilation or QEMU -- real Linux
# memory-management logic, fully testable on any Linux machine,
# already verified live in the sandbox this was built in.
set -e

echo "=== Nova OS Day 3: Memory Manager ==="

echo "[1/2] Running nova-memmgr library unit tests (5 tests, real /proc queries + RLIMIT_AS)..."
cargo test -p nova-memmgr

echo "[2/2] Building the hog + test client, then running the live Definition of Done..."
cargo build -p nova-memtest-hog -p nova-memmgr-test

echo ""
echo "=== Live end-to-end test: query own + another process's memory, then deliberately trigger a clean allocation failure ==="
./target/debug/nova-memmgr-test
