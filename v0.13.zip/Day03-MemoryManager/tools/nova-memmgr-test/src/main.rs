//! Nova Memory Manager test client — the literal Day 3 Definition of
//! Done: "A test process can query its own and another process's
//! memory accounting; a deliberate allocation-failure test exercises
//! the failure path without crashing the Memory Manager itself."
//!
//! This binary *is* that test process. It plays the role the DoD
//! describes directly: queries itself, queries a spawned sibling
//! process, then deliberately drives `nova-memtest-hog` into an
//! allocation failure under a real `RLIMIT_AS` limit and confirms
//! (a) the hog exits cleanly at the defined code, not a crash signal,
//! and (b) this test process — standing in for the Memory Manager
//! itself — is still completely fine afterward, proven by continuing
//! to run and query its own memory again at the end.

use nova_memmgr::{query, query_self, spawn_with_memory_limit};
use std::env;
use std::process::{self, Command};
use std::thread;
use std::time::Duration;

fn fail(msg: &str) -> ! {
    eprintln!("nova-memmgr-test: FAIL -- {msg}");
    process::exit(1);
}

fn hog_binary_path() -> String {
    env::var("NOVA_MEMTEST_HOG_PATH").unwrap_or_else(|_| {
        // Default: sibling binary in the same cargo target dir.
        let exe = env::current_exe().expect("current_exe should resolve");
        let dir = exe.parent().expect("exe should have a parent dir");
        dir.join("nova-memtest-hog").to_string_lossy().to_string()
    })
}

fn main() {
    println!("nova-memmgr-test: starting (pid {})", process::id());

    // --- Step 1: query own memory accounting ---
    println!("nova-memmgr-test: querying own memory accounting...");
    let own_info = query_self().unwrap_or_else(|e| fail(&format!("query_self failed: {e}")));
    println!(
        "  pid={} vsize={}KB rss={}KB",
        own_info.pid,
        own_info.vsize_bytes / 1024,
        own_info.rss_bytes / 1024
    );
    if own_info.vsize_bytes == 0 {
        fail("own vsize reported as 0 -- query path is broken");
    }

    // --- Step 2: query another process's memory accounting ---
    println!("nova-memmgr-test: spawning a sibling process to query...");
    let mut sibling = Command::new("sleep").arg("3").spawn().unwrap_or_else(|e| fail(&format!("spawn sleep failed: {e}")));
    let sibling_pid = sibling.id();
    thread::sleep(Duration::from_millis(100));

    let sibling_info = query(sibling_pid).unwrap_or_else(|e| fail(&format!("query(sibling) failed: {e}")));
    println!(
        "  pid={} vsize={}KB rss={}KB",
        sibling_info.pid,
        sibling_info.vsize_bytes / 1024,
        sibling_info.rss_bytes / 1024
    );
    if sibling_info.pid != sibling_pid {
        fail("queried the wrong process");
    }
    let _ = sibling.kill();
    let _ = sibling.wait();
    println!("nova-memmgr-test: verified own AND another process's memory accounting -- step 2 done");

    // --- Step 3: deliberately exercise the allocation-failure path ---
    let hog_path = hog_binary_path();
    println!("nova-memmgr-test: spawning {hog_path} under a 20MB RLIMIT_AS limit...");
    let limit_bytes: u64 = 20 * 1024 * 1024;
    let mut hog = spawn_with_memory_limit(&hog_path, &[], limit_bytes)
        .unwrap_or_else(|e| fail(&format!("spawn_with_memory_limit failed: {e}")));

    let status = hog.wait().unwrap_or_else(|e| fail(&format!("wait on hog failed: {e}")));

    #[cfg(unix)]
    {
        use std::os::unix::process::ExitStatusExt;
        if let Some(signal) = status.signal() {
            fail(&format!(
                "hog process was killed by signal {signal} (e.g. SIGSEGV/SIGKILL) -- \
                 this is exactly the undefined, uncontrolled failure Day 3 says to avoid"
            ));
        }
    }

    match status.code() {
        Some(42) => println!("nova-memmgr-test: hog exited cleanly with code 42 -- allocation failure handled as designed"),
        Some(other) => fail(&format!("hog exited with unexpected code {other} (expected 42)")),
        None => fail("hog exit status had no code at all"),
    }

    // --- Step 4: confirm the caller (standing in for the Memory
    //     Manager itself) was never affected ---
    println!("nova-memmgr-test: confirming this process is still completely healthy...");
    let own_info_after = query_self().unwrap_or_else(|e| fail(&format!("post-test query_self failed: {e}")));
    if own_info_after.vsize_bytes == 0 {
        fail("post-test self-query failed -- something about the hog's failure affected the caller");
    }
    println!(
        "  pid={} vsize={}KB rss={}KB (still healthy)",
        own_info_after.pid,
        own_info_after.vsize_bytes / 1024,
        own_info_after.rss_bytes / 1024
    );

    println!();
    println!("nova-memmgr-test: PASS -- Day 3 Definition of Done satisfied end-to-end");
    println!("nova-memmgr-test: queried own + another process's memory, drove a real allocation");
    println!("nova-memmgr-test: failure to a clean, defined exit code, and confirmed zero impact");
    println!("nova-memmgr-test: on the caller -- no crash, no signal, no undefined OOM-killer behavior.");
}
