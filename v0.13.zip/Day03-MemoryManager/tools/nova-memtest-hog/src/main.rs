//! nova-memtest-hog — Day 3's deliberate allocation-failure exerciser.
//!
//! Run under `nova_memmgr::spawn_with_memory_limit`, this process
//! grows a buffer in 1MB chunks, actually writing to every page of
//! each chunk (so the allocation is real and committed, not an
//! overcommit lie the kernel could paper over), until allocation
//! fails.
//!
//! The critical design choice: it uses `Vec::try_reserve`, Rust's
//! *fallible* allocation API, which returns `Err` on failure — as
//! opposed to ordinary `Vec` growth (`push`, `with_capacity`), where
//! Rust's default global allocator error handler *aborts the whole
//! process* on failure, no `Result`, no chance to react. That default
//! abort behavior is exactly the kind of undefined, uncontrolled
//! failure Day 3 says not to rely on ("don't leave it to whatever
//! Linux's OOM killer does by default") — `try_reserve` is what turns
//! "allocation failure" into an event Nova can define and test,
//! rather than a crash.
//!
//! On hitting the limit, this exits cleanly with code 42 — a defined,
//! documented signal meaning "the allocation-failure path was
//! exercised and handled correctly," not a crash of any kind.

use std::process;

const CHUNK_SIZE: usize = 1024 * 1024; // 1MB per growth step
const CLEAN_FAILURE_EXIT_CODE: i32 = 42;
/// Safety ceiling: if this many chunks succeed (i.e. >2GB), something
/// is wrong with the caller's memory limit setup, since this helper
/// is always meant to be run under a small RLIMIT_AS.
const MAX_CHUNKS_BEFORE_GIVING_UP: usize = 2048;

fn main() {
    println!("nova-memtest-hog: starting, allocating in {CHUNK_SIZE}-byte chunks until failure");

    let mut buffer: Vec<u8> = Vec::new();
    let mut chunks_allocated = 0usize;

    loop {
        match buffer.try_reserve(CHUNK_SIZE) {
            Ok(()) => {
                let old_len = buffer.len();
                buffer.resize(old_len + CHUNK_SIZE, 0xAA);
                // Touch every page in the new region to force real
                // physical commitment -- without this, the kernel's
                // overcommit could let try_reserve "succeed" for
                // memory that's never actually backed, which would
                // make this test meaningless.
                for i in (old_len..buffer.len()).step_by(4096) {
                    buffer[i] = 0x01;
                }
                chunks_allocated += 1;

                if chunks_allocated >= MAX_CHUNKS_BEFORE_GIVING_UP {
                    eprintln!(
                        "nova-memtest-hog: allocated {chunks_allocated} chunks ({} MB) without hitting a limit -- \
                         is this process actually running under a memory limit?",
                        chunks_allocated * CHUNK_SIZE / (1024 * 1024)
                    );
                    process::exit(1); // unexpected: not exercising the intended path
                }
            }
            Err(_) => {
                println!(
                    "nova-memtest-hog: allocation failed cleanly after {chunks_allocated} chunks \
                     (~{} MB) -- exiting with code {CLEAN_FAILURE_EXIT_CODE} (handled, not crashed)",
                    chunks_allocated * CHUNK_SIZE / (1024 * 1024)
                );
                process::exit(CLEAN_FAILURE_EXIT_CODE);
            }
        }
    }
}
