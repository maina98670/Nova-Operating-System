# Nova OS — Day 4 Package: Filesystem Manager (M4 continues)

Per the Complete Build Guide, Day 4's focus is the Filesystem Manager
— same "supervising layer over what Linux already does" discipline as
Days 2-3. File I/O wraps `std::fs` (Nova doesn't reimplement
open/read/write/close), and per Section 25, mounting uses the real
kernel `mount(2)`/`umount(2)` syscalls against ext4 (or another
mature filesystem) — no custom filesystem at this stage.

## What's in this package

- **libs/nova-fsmgr** — Nova's standard directory layout
  (`paths::SYSTEM/DATA/APPS/CONFIG/LOG/RUN/TMP` — the FHS-equivalent
  Day 4 asks for, feeding into Section 21's repo/deploy structure),
  file CRUD (`create_file`/`read_file`/`write_file`/`delete_file`/
  `rename_file`), and `mount`/`unmount` — a reusable, independently
  testable generalization of the same `mount(2)` pattern Nova Init
  (M2) already uses for `/proc`/`/sys`/`/dev`.
- **tools/nova-fsmgr-test** — the real test process the Day 4 DoD
  describes literally: a full file create/write/read/rename/delete
  cycle, then mounting a real tmpfs, writing a file inside it, and
  confirming that file vanishes after unmounting — proof it was a
  genuine separate mount, not just a directory.

## A visible reconciliation note

`nova-settings` (built in an earlier session, before this milestone
existed) reads `/etc/nova-version` and `/etc/nova-device-name`
directly as flat files. This module's `paths::CONFIG` formalizes
`/etc/nova/` as the real config directory going forward — a
deliberate, visible inconsistency rather than a silently-papered-over
one. Migrating Settings to the new layout is separate follow-up work,
not done as a side effect of this milestone. `paths::RUN`
(`/run/nova`) already matched what `nova-procmgrd` (Day 2) uses for
its socket, so at least that one was consistent by coincidence.

## What was actually verified in this sandbox — all of it, live

- **`cargo test -p nova-fsmgr`: 7/7 passing**, including a genuinely
  real mount: `day4_definition_of_done_mount_unmount_tmpfs` mounts an
  actual tmpfs (this sandbox runs as root, confirmed with `id` before
  writing any code), writes a file inside it, and confirms the file
  is gone after unmounting — the only way that's possible is if the
  mount was real.
- **The full live Definition of Done, run for real.** Actual output
  from this sandbox:

  ```
  nova-fsmgr-test: CREATE ".../crud.txt"
  nova-fsmgr-test: READ ".../crud.txt"
    <- "hello nova"
  nova-fsmgr-test: WRITE (overwrite) ".../crud.txt"
  nova-fsmgr-test: RENAME ".../crud.txt" -> ".../crud-renamed.txt"
  nova-fsmgr-test: DELETE ".../crud-renamed.txt"
  nova-fsmgr-test: file CRUD cycle verified -- step 1 done

  nova-fsmgr-test: MOUNT tmpfs at ".../mnt"
  nova-fsmgr-test: wrote a proof file inside the mount, confirmed present
  nova-fsmgr-test: UNMOUNT ".../mnt"
  nova-fsmgr-test: proof file is gone after unmount -- confirms this was a real, distinct mount

  nova-fsmgr-test: PASS -- Day 4 Definition of Done satisfied end-to-end
  ```

## Nothing left unverified

Same as Days 2-3: no "test it on your machine" caveat — this needs
root (already confirmed available) but no cross-compilation, kernel
build, or display. Run `nova-day4-build_and_run.sh` yourself to
reproduce this exact result.

## Next: Day 5

Per the Guide's M4 table, Day 5 is the Device Manager.
