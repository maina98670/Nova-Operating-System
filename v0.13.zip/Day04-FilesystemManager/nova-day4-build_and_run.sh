#!/bin/bash
# Nova OS — Day 4: Filesystem Manager (M4, per the Complete Build Guide)
# Real Linux filesystem/mount operations -- needs root (for the mount
# test specifically) but no cross-compilation or QEMU. Already
# verified live in the sandbox this was built in.
set -e

echo "=== Nova OS Day 4: Filesystem Manager ==="

echo "[1/2] Running nova-fsmgr library unit tests (7 tests, including a real tmpfs mount/unmount)..."
cargo test -p nova-fsmgr

echo "[2/2] Building and running the live Definition of Done test..."
cargo build -p nova-fsmgr-test
./target/debug/nova-fsmgr-test
