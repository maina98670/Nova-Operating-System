//! Nova Filesystem Manager test client — the literal Day 4 Definition
//! of Done, run as a standalone, visible process (same pattern as
//! Day 2's nova-procmgr-test and Day 3's nova-memmgr-test):
//! "A test file can be created, written, read back correctly,
//! renamed, and deleted through Nova's Filesystem Manager API; a
//! second filesystem/mount point can be mounted and unmounted
//! cleanly."

use nova_fsmgr::{create_file, delete_file, mount, read_file, rename_file, unmount, write_file};
use std::env;
use std::fs;
use std::path::PathBuf;
use std::process;

fn fail(msg: &str) -> ! {
    eprintln!("nova-fsmgr-test: FAIL -- {msg}");
    process::exit(1);
}

fn temp_path(name: &str) -> PathBuf {
    env::temp_dir().join(format!("nova-fsmgr-test-live-{}-{}", process::id(), name))
}

fn main() {
    println!("nova-fsmgr-test: starting");

    // --- Step 1: file CRUD cycle ---
    let path = temp_path("crud.txt");
    let renamed = temp_path("crud-renamed.txt");
    let _ = fs::remove_file(&path);
    let _ = fs::remove_file(&renamed);

    println!("nova-fsmgr-test: CREATE {path:?}");
    create_file(&path, b"hello nova").unwrap_or_else(|e| fail(&format!("create failed: {e}")));

    println!("nova-fsmgr-test: READ {path:?}");
    let contents = read_file(&path).unwrap_or_else(|e| fail(&format!("read failed: {e}")));
    if contents != b"hello nova" {
        fail("read-back content did not match what was written");
    }
    println!("  <- {:?}", String::from_utf8_lossy(&contents));

    println!("nova-fsmgr-test: WRITE (overwrite) {path:?}");
    write_file(&path, b"updated by test").unwrap_or_else(|e| fail(&format!("write failed: {e}")));
    let updated = read_file(&path).unwrap();
    if updated != b"updated by test" {
        fail("overwrite did not take effect");
    }

    println!("nova-fsmgr-test: RENAME {path:?} -> {renamed:?}");
    rename_file(&path, &renamed).unwrap_or_else(|e| fail(&format!("rename failed: {e}")));
    if path.exists() {
        fail("original path still exists after rename");
    }
    if !renamed.exists() {
        fail("renamed path does not exist");
    }

    println!("nova-fsmgr-test: DELETE {renamed:?}");
    delete_file(&renamed).unwrap_or_else(|e| fail(&format!("delete failed: {e}")));
    if renamed.exists() {
        fail("file still exists after delete");
    }
    println!("nova-fsmgr-test: file CRUD cycle verified -- step 1 done");
    println!();

    // --- Step 2: mount and unmount a real second filesystem ---
    let mountpoint = temp_path("mnt");
    let _ = fs::remove_dir_all(&mountpoint);
    fs::create_dir_all(&mountpoint).unwrap_or_else(|e| fail(&format!("could not create mountpoint dir: {e}")));

    println!("nova-fsmgr-test: MOUNT tmpfs at {mountpoint:?}");
    mount("nova-test-tmpfs", &mountpoint, "tmpfs", 0, Some("size=4m"))
        .unwrap_or_else(|e| fail(&format!("mount failed: {e} (needs root)")));

    let proof_file = mountpoint.join("proof.txt");
    create_file(&proof_file, b"only exists inside the mount")
        .unwrap_or_else(|e| fail(&format!("could not write inside mount: {e}")));
    if !proof_file.exists() {
        fail("file written inside the mount doesn't exist -- mount did not actually take effect");
    }
    println!("nova-fsmgr-test: wrote a proof file inside the mount, confirmed present");

    println!("nova-fsmgr-test: UNMOUNT {mountpoint:?}");
    unmount(&mountpoint).unwrap_or_else(|e| fail(&format!("unmount failed: {e}")));

    if proof_file.exists() {
        fail("proof file still exists after unmount -- this was not a real separate mount");
    }
    println!("nova-fsmgr-test: proof file is gone after unmount -- confirms this was a real, distinct mount");

    let _ = fs::remove_dir_all(&mountpoint);

    println!();
    println!("nova-fsmgr-test: PASS -- Day 4 Definition of Done satisfied end-to-end");
    println!("nova-fsmgr-test: file create/write/read/rename/delete, plus a real mount/unmount");
    println!("nova-fsmgr-test: cycle, all through Nova's Filesystem Manager API.");
}
