# Nova OS — Day 5 Package: Device Manager (M4 continues)

Per the Complete Build Guide, Day 5's focus is the Device Manager —
different in character from Days 2-4: this milestone is about a clean
abstraction boundary, not wrapping a Linux syscall. Per Section 4
("keep generic Nova code separate from hardware-specific code"), the
Device Manager only ever touches one `Device` trait, never a concrete
display/input/storage implementation — that separation is the actual
deliverable, since it's the seam M9 (Hardware Abstraction) and M12
(ARM64 reference-device port) will plug real drivers into later
without this module changing at all.

## What's in this package

- **libs/nova-devmgr** — the `Device` trait every device type
  conforms to, `DeviceType`/`DeviceStatus` enums, a `DeviceManager`
  registry (register/unregister/list/list_by_type/get), and `fakes::`
  — `FakeDisplay`/`FakeInput`/`FakeStorage`, matching the Day 5 DoD's
  explicit instruction to test with fake devices, not real hardware
  (that's other, later milestones' job).
- **tools/nova-devmgr-test** — the real test process the Day 5 DoD
  describes literally: registers one fake device of each type, lists
  them all back through the generic query API.

## Why fakes, not real devices

The Day 5 DoD is explicit: "Register a **test/fake** device of each of
the three types." This milestone is done when the abstraction and
registry work correctly — not when real display/input/storage
hardware is wired up, which is explicitly M9/M12's job. Using fakes
here also directly demonstrates the actual design goal: a real M9
driver implementing `Device` later will be handled by
`DeviceManager` in exactly the same way `FakeDisplay` is today, with
zero code changes to this module.

## What was actually verified in this sandbox — all of it, live

- **`cargo test -p nova-devmgr`: 7/7 passing**, including the literal
  DoD test (`day5_definition_of_done_register_and_list_all_three_types`).
- **The full live Definition of Done, run for real.** Actual output
  from this sandbox:

  ```
  nova-devmgr-test: registering a fake display...
  nova-devmgr-test: registering a fake input device...
  nova-devmgr-test: registering a fake storage device...

  nova-devmgr-test: querying all devices through the generic API...
    input0 [input] "Nova Fake Touchscreen" -- Online
    disp0 [display] "Nova Fake Display" -- Online
    storage0 [storage] "Nova Fake eMMC" -- Online

  nova-devmgr-test: PASS -- Day 5 Definition of Done satisfied end-to-end
  ```

## Nothing left unverified

Same as Days 2-4: no "test it on your machine" caveat — this needs
nothing beyond a Rust toolchain. Run `nova-day5-build_and_run.sh`
yourself to reproduce this exact result.

## Next: Day 6

Per the Guide's M4 table, Day 6 is the Service Manager — this is
where `nova-procmgr`'s `RestartPolicy` seam (Day 2) finally gets acted
on: actually restarting a crashed service, not just defining the
policy field for later use.
