//! Nova Device Manager — M4 Day 5.
//!
//! Unlike Days 2-4, this milestone isn't primarily about wrapping a
//! Linux syscall — it's about a clean abstraction boundary. Per
//! Section 4 ("keep generic Nova code separate from hardware-specific
//! code"), everything in this file only ever touches the `Device`
//! trait, never a concrete display/input/storage implementation. That
//! separation is the actual point of Day 5: it's the seam M9
//! (Hardware Abstraction) and M12 (ARM64 reference-device port) will
//! plug real drivers into later, without this module — or anything
//! that depends on it — needing to change at all.
//!
//! The Day 5 DoD explicitly asks for *fake* devices ("Register a
//! test/fake device of each of the three types"), which is the right
//! call: this milestone is done when the abstraction and registry
//! work correctly, not when real hardware is wired up (that's
//! explicitly other, later milestones' job).

use std::collections::HashMap;
use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum DeviceType {
    Display,
    Input,
    Storage,
}

impl fmt::Display for DeviceType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            DeviceType::Display => "display",
            DeviceType::Input => "input",
            DeviceType::Storage => "storage",
        };
        write!(f, "{s}")
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DeviceStatus {
    Online,
    Offline,
    Error,
}

/// The one struct/trait every device type conforms to (Day 5's first
/// task, literally). A real backing driver (M9/M12) implements this
/// exactly the same way a fake test device does — from the Device
/// Manager's point of view, there is no difference, which is the
/// entire design goal.
pub trait Device: Send {
    fn id(&self) -> &str;
    fn device_type(&self) -> DeviceType;
    fn name(&self) -> &str;
    fn status(&self) -> DeviceStatus;
}

/// What the generic query API returns — plain data, not a trait
/// object, so callers (e.g. a future Settings "device list" screen)
/// never need to know or care what concrete type backs a device. This
/// is what "generic APIs kept separate from hardware implementation"
/// looks like as an actual return type, not just a principle.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DeviceInfo {
    pub id: String,
    pub device_type: DeviceType,
    pub name: String,
    pub status: DeviceStatus,
}

#[derive(Debug)]
pub enum DeviceError {
    AlreadyRegistered(String),
    NotFound(String),
}

impl fmt::Display for DeviceError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DeviceError::AlreadyRegistered(id) => write!(f, "device already registered: {id}"),
            DeviceError::NotFound(id) => write!(f, "device not found: {id}"),
        }
    }
}

#[derive(Default)]
pub struct DeviceManager {
    devices: HashMap<String, Box<dyn Device>>,
}

impl DeviceManager {
    pub fn new() -> Self {
        DeviceManager::default()
    }

    pub fn register(&mut self, device: Box<dyn Device>) -> Result<(), DeviceError> {
        let id = device.id().to_string();
        if self.devices.contains_key(&id) {
            return Err(DeviceError::AlreadyRegistered(id));
        }
        self.devices.insert(id, device);
        Ok(())
    }

    pub fn unregister(&mut self, id: &str) -> Result<(), DeviceError> {
        self.devices.remove(id).map(|_| ()).ok_or_else(|| DeviceError::NotFound(id.to_string()))
    }

    fn to_info(device: &dyn Device) -> DeviceInfo {
        DeviceInfo {
            id: device.id().to_string(),
            device_type: device.device_type(),
            name: device.name().to_string(),
            status: device.status(),
        }
    }

    /// The generic query API Day 5's DoD asks for: list every
    /// registered device, of any type, as plain `DeviceInfo` — never
    /// the underlying trait object, never anything hardware-specific.
    pub fn list(&self) -> Vec<DeviceInfo> {
        self.devices.values().map(|d| Self::to_info(d.as_ref())).collect()
    }

    pub fn list_by_type(&self, device_type: DeviceType) -> Vec<DeviceInfo> {
        self.devices
            .values()
            .filter(|d| d.device_type() == device_type)
            .map(|d| Self::to_info(d.as_ref()))
            .collect()
    }

    pub fn get(&self, id: &str) -> Option<DeviceInfo> {
        self.devices.get(id).map(|d| Self::to_info(d.as_ref()))
    }

    pub fn count(&self) -> usize {
        self.devices.len()
    }
}

/// Fake devices for testing the Device Manager itself, matching the
/// Day 5 DoD's explicit instruction to use "a test/fake device of
/// each of the three types" — deliberately trivial, so nothing here
/// depends on real display/input/storage hardware, which is exactly
/// how a M9/M12 real driver's own tests could later swap in without
/// this module changing.
pub mod fakes {
    use super::*;

    pub struct FakeDisplay {
        pub id: String,
        pub name: String,
        pub status: DeviceStatus,
    }
    impl Device for FakeDisplay {
        fn id(&self) -> &str { &self.id }
        fn device_type(&self) -> DeviceType { DeviceType::Display }
        fn name(&self) -> &str { &self.name }
        fn status(&self) -> DeviceStatus { self.status }
    }

    pub struct FakeInput {
        pub id: String,
        pub name: String,
        pub status: DeviceStatus,
    }
    impl Device for FakeInput {
        fn id(&self) -> &str { &self.id }
        fn device_type(&self) -> DeviceType { DeviceType::Input }
        fn name(&self) -> &str { &self.name }
        fn status(&self) -> DeviceStatus { self.status }
    }

    pub struct FakeStorage {
        pub id: String,
        pub name: String,
        pub status: DeviceStatus,
    }
    impl Device for FakeStorage {
        fn id(&self) -> &str { &self.id }
        fn device_type(&self) -> DeviceType { DeviceType::Storage }
        fn name(&self) -> &str { &self.name }
        fn status(&self) -> DeviceStatus { self.status }
    }
}

#[cfg(test)]
mod tests {
    use super::fakes::*;
    use super::*;

    /// The literal Day 5 DoD: register a test/fake device of each of
    /// the three types, list them back through the generic API.
    #[test]
    fn day5_definition_of_done_register_and_list_all_three_types() {
        let mut mgr = DeviceManager::new();
        mgr.register(Box::new(FakeDisplay {
            id: "disp0".into(),
            name: "Fake Display".into(),
            status: DeviceStatus::Online,
        }))
        .expect("display registration should succeed");
        mgr.register(Box::new(FakeInput {
            id: "input0".into(),
            name: "Fake Touchscreen".into(),
            status: DeviceStatus::Online,
        }))
        .expect("input registration should succeed");
        mgr.register(Box::new(FakeStorage {
            id: "storage0".into(),
            name: "Fake eMMC".into(),
            status: DeviceStatus::Online,
        }))
        .expect("storage registration should succeed");

        assert_eq!(mgr.count(), 3);

        let all = mgr.list();
        assert_eq!(all.len(), 3);

        let types: std::collections::HashSet<DeviceType> = all.iter().map(|d| d.device_type).collect();
        assert!(types.contains(&DeviceType::Display));
        assert!(types.contains(&DeviceType::Input));
        assert!(types.contains(&DeviceType::Storage));

        // Query API is generic -- callers never see FakeDisplay/
        // FakeInput/FakeStorage, only plain DeviceInfo.
        let display_info = mgr.get("disp0").expect("should find disp0");
        assert_eq!(display_info.device_type, DeviceType::Display);
        assert_eq!(display_info.name, "Fake Display");
    }

    #[test]
    fn list_by_type_filters_correctly() {
        let mut mgr = DeviceManager::new();
        mgr.register(Box::new(FakeDisplay { id: "d1".into(), name: "D1".into(), status: DeviceStatus::Online }))
            .unwrap();
        mgr.register(Box::new(FakeDisplay { id: "d2".into(), name: "D2".into(), status: DeviceStatus::Offline }))
            .unwrap();
        mgr.register(Box::new(FakeInput { id: "i1".into(), name: "I1".into(), status: DeviceStatus::Online }))
            .unwrap();

        let displays = mgr.list_by_type(DeviceType::Display);
        assert_eq!(displays.len(), 2);
        let inputs = mgr.list_by_type(DeviceType::Input);
        assert_eq!(inputs.len(), 1);
        let storage = mgr.list_by_type(DeviceType::Storage);
        assert_eq!(storage.len(), 0);
    }

    #[test]
    fn duplicate_registration_is_rejected() {
        let mut mgr = DeviceManager::new();
        mgr.register(Box::new(FakeDisplay { id: "d1".into(), name: "D1".into(), status: DeviceStatus::Online }))
            .unwrap();
        let result = mgr.register(Box::new(FakeDisplay {
            id: "d1".into(),
            name: "Duplicate".into(),
            status: DeviceStatus::Online,
        }));
        assert!(matches!(result, Err(DeviceError::AlreadyRegistered(_))));
        assert_eq!(mgr.count(), 1, "the original registration should be untouched");
    }

    #[test]
    fn unregister_removes_device() {
        let mut mgr = DeviceManager::new();
        mgr.register(Box::new(FakeInput { id: "i1".into(), name: "I1".into(), status: DeviceStatus::Online }))
            .unwrap();
        assert_eq!(mgr.count(), 1);
        mgr.unregister("i1").expect("unregister should succeed");
        assert_eq!(mgr.count(), 0);
        assert!(mgr.get("i1").is_none());
    }

    #[test]
    fn unregister_unknown_device_errors_cleanly() {
        let mut mgr = DeviceManager::new();
        let result = mgr.unregister("does-not-exist");
        assert!(matches!(result, Err(DeviceError::NotFound(_))));
    }

    #[test]
    fn get_unknown_device_returns_none_not_panic() {
        let mgr = DeviceManager::new();
        assert!(mgr.get("nope").is_none());
    }

    #[test]
    fn device_status_reflects_through_generic_api() {
        let mut mgr = DeviceManager::new();
        mgr.register(Box::new(FakeStorage {
            id: "s1".into(),
            name: "Failing Disk".into(),
            status: DeviceStatus::Error,
        }))
        .unwrap();
        let info = mgr.get("s1").unwrap();
        assert_eq!(info.status, DeviceStatus::Error);
    }
}
