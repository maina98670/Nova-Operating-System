#!/bin/bash
# Nova OS — Day 5: Device Manager (M4, per the Complete Build Guide)
# Pure abstraction/registry logic -- no root, no cross-compilation, no
# QEMU needed. Already verified live in the sandbox this was built in.
set -e

echo "=== Nova OS Day 5: Device Manager ==="

echo "[1/2] Running nova-devmgr library unit tests (7 tests)..."
cargo test -p nova-devmgr

echo "[2/2] Building and running the live Definition of Done test..."
cargo build -p nova-devmgr-test
./target/debug/nova-devmgr-test
