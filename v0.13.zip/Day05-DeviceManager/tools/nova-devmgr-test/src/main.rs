//! Nova Device Manager test client — the literal Day 5 Definition of
//! Done, run as a standalone, visible process: "Register a test/fake
//! device of each of the three types (display, input, storage) and
//! list them back through the Device Manager's generic query API."

use nova_devmgr::fakes::{FakeDisplay, FakeInput, FakeStorage};
use nova_devmgr::{DeviceManager, DeviceStatus, DeviceType};
use std::process;

fn fail(msg: &str) -> ! {
    eprintln!("nova-devmgr-test: FAIL -- {msg}");
    process::exit(1);
}

fn main() {
    println!("nova-devmgr-test: starting");
    let mut mgr = DeviceManager::new();

    println!("nova-devmgr-test: registering a fake display...");
    mgr.register(Box::new(FakeDisplay {
        id: "disp0".into(),
        name: "Nova Fake Display".into(),
        status: DeviceStatus::Online,
    }))
    .unwrap_or_else(|e| fail(&format!("display registration failed: {e}")));

    println!("nova-devmgr-test: registering a fake input device...");
    mgr.register(Box::new(FakeInput {
        id: "input0".into(),
        name: "Nova Fake Touchscreen".into(),
        status: DeviceStatus::Online,
    }))
    .unwrap_or_else(|e| fail(&format!("input registration failed: {e}")));

    println!("nova-devmgr-test: registering a fake storage device...");
    mgr.register(Box::new(FakeStorage {
        id: "storage0".into(),
        name: "Nova Fake eMMC".into(),
        status: DeviceStatus::Online,
    }))
    .unwrap_or_else(|e| fail(&format!("storage registration failed: {e}")));

    println!();
    println!("nova-devmgr-test: querying all devices through the generic API...");
    let all = mgr.list();
    if all.len() != 3 {
        fail(&format!("expected 3 registered devices, got {}", all.len()));
    }
    for info in &all {
        println!("  {} [{}] \"{}\" -- {:?}", info.id, info.device_type, info.name, info.status);
    }

    let has_display = all.iter().any(|d| d.device_type == DeviceType::Display);
    let has_input = all.iter().any(|d| d.device_type == DeviceType::Input);
    let has_storage = all.iter().any(|d| d.device_type == DeviceType::Storage);
    if !(has_display && has_input && has_storage) {
        fail("listed devices did not include all three types");
    }

    println!();
    println!("nova-devmgr-test: PASS -- Day 5 Definition of Done satisfied end-to-end");
    println!("nova-devmgr-test: registered a fake display, input, and storage device;");
    println!("nova-devmgr-test: listed all three back through the generic query API,");
    println!("nova-devmgr-test: with zero hardware-specific code in the Device Manager itself.");
}
