# Nova OS — Day 6 Package: Service Manager (M4 continues)

Per the Complete Build Guide, Day 6's focus is the Service Manager —
built directly on top of `nova-procmgr` (Day 2, included here since
`nova-svcmgr` depends on it) rather than reimplementing process
spawning. This is also where Day 2's `RestartPolicy` seam — defined
then, deliberately left un-acted-upon — finally gets used for real.

## What's in this package

- **libs/nova-procmgr** — Day 2's Process Manager, included as a
  dependency (see Day 2's own package for its full details).
- **libs/nova-svcmgr** — named services on top of processes:
  start/stop/restart, status querying, dependency declarations
  (`ServiceDef::depends_on`, resolved recursively with cycle
  detection), and `tick()` — the supervision loop that actually
  enforces `RestartPolicy` by respawning a crashed service, with a
  `max_restarts` safety cap so a service that fails instantly every
  time doesn't restart-loop forever (the same protection systemd's
  `StartLimitBurst` provides).
- **tools/nova-svcmgr-test** — the real test process the Day 6 DoD
  describes literally: start/stop a test service, then deliberately
  run a failing service and confirm the crash/restart policy actually
  fires.

## What was actually verified in this sandbox — all of it, live

- **`cargo test -p nova-svcmgr`: 8/8 passing**, including both DoD
  tests by name (`day6_start_stop_service`,
  `day6_crash_restart_policy_actually_fires`), plus dependency
  ordering, circular-dependency detection, and the restart-cap safety
  limit.
- **The full live Definition of Done, run for real.** Actual output
  from this sandbox:

  ```
  nova-svcmgr-test: START test-sleeper
    status: Running (confirmed)
  nova-svcmgr-test: STOP test-sleeper
    status: NotStarted (confirmed)
  nova-svcmgr-test: step 1 (start/stop) verified

  nova-svcmgr-test: START test-crasher (a service that always exits with failure)
    original pid: 789
  nova-svcmgr-test: TICK (running the supervision loop)
    tick() auto-restarted: ["test-crasher"]
  nova-svcmgr-test: restart_count for test-crasher is now 1

  nova-svcmgr-test: PASS -- Day 6 Definition of Done satisfied end-to-end
  ```

  `test-crasher` runs `false` (always exits with failure,
  immediately). `tick()` — the supervision loop — detected the exit,
  checked the service's `RestartPolicy::OnFailure`, and spawned a
  genuinely new process (a different real PID) to replace it. That's
  Day 2's seam, actually firing for the first time.

## Nothing left unverified

Same as Days 2-5: no "test it on your machine" caveat. Run
`nova-day6-build_and_run.sh` yourself to reproduce this exact result.

## Next: Day 7

Per the Guide's M4 table, Day 7 is Logging.
