//! Nova Service Manager — M4 Day 6.
//!
//! Builds directly on `nova-procmgr` (Day 2) rather than reimplementing
//! process spawning/tracking — this is the same "supervising layer,
//! don't rebuild what already exists" discipline applied one level up:
//! `nova-procmgr` supervises Linux processes, `nova-svcmgr` supervises
//! *named services* on top of that.
//!
//! This is also where Day 2's `RestartPolicy` seam — defined then,
//! deliberately left un-acted-upon — finally gets used for real.
//! `tick()` is the supervision loop: it reaps exited processes via
//! the underlying `ProcessManager`, checks each managed service
//! against its own `RestartPolicy` (using `should_restart`, the exact
//! method Day 2 built for this), and actually respawns it if the
//! policy says to. That's the literal meaning of "Crash/restart
//! policy (define it explicitly...)" finally being enforced, not just
//! recorded.
//!
//! Maps to Day 6's four task bullets:
//! - Start/stop/restart -> `start`, `stop`, `restart`
//! - Status querying -> `status`
//! - Dependency declarations -> `ServiceDef::depends_on`, resolved
//!   recursively (with cycle detection) in `start`
//! - Crash/restart policy -> `tick`, acting on `RestartPolicy`

use nova_procmgr::{ProcessManager, ProcessState, RestartPolicy};
use std::collections::{HashMap, HashSet};
use std::fmt;

#[derive(Debug, Clone)]
pub struct ServiceDef {
    pub name: String,
    pub command: String,
    pub args: Vec<String>,
    pub restart_policy: RestartPolicy,
    pub depends_on: Vec<String>,
    /// Safety cap: how many times `tick()` will auto-restart this
    /// service before giving up. Without this, a service that fails
    /// instantly on every start (e.g. a genuine misconfiguration)
    /// would restart-loop forever — a real failure mode real init
    /// systems (systemd's `StartLimitBurst`, for instance) all guard
    /// against, so Nova should too rather than treating "the policy
    /// says restart" as an unconditional command.
    pub max_restarts: u32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ServiceStatus {
    NotStarted,
    Running,
    Stopped,
    /// Exited with failure and will not be auto-restarted again
    /// (either policy is Never, or max_restarts was hit).
    Failed,
}

#[derive(Debug)]
pub enum ServiceError {
    NotRegistered(String),
    NotRunning(String),
    CircularDependency(String),
    SpawnFailed(String, String),
}

impl fmt::Display for ServiceError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ServiceError::NotRegistered(n) => write!(f, "service not registered: {n}"),
            ServiceError::NotRunning(n) => write!(f, "service not running: {n}"),
            ServiceError::CircularDependency(n) => write!(f, "circular dependency detected involving: {n}"),
            ServiceError::SpawnFailed(n, e) => write!(f, "failed to spawn service {n}: {e}"),
        }
    }
}

struct RunningState {
    pid: u32,
    restart_count: u32,
    gave_up: bool,
}

pub struct ServiceManager {
    procmgr: ProcessManager,
    definitions: HashMap<String, ServiceDef>,
    running: HashMap<String, RunningState>,
}

impl ServiceManager {
    pub fn new() -> Self {
        ServiceManager { procmgr: ProcessManager::new(), definitions: HashMap::new(), running: HashMap::new() }
    }

    /// Declares a service without starting it — matching Day 6's
    /// "Dependency declarations between services" task as a distinct
    /// step from actually starting anything.
    pub fn register(&mut self, def: ServiceDef) {
        self.definitions.insert(def.name.clone(), def);
    }

    /// Starts `name`, first recursively starting anything it depends
    /// on that isn't already running. Cycle-safe: a dependency chain
    /// that loops back on itself returns an error instead of
    /// recursing forever.
    pub fn start(&mut self, name: &str) -> Result<u32, ServiceError> {
        let mut visiting = HashSet::new();
        self.start_inner(name, &mut visiting)
    }

    fn start_inner(&mut self, name: &str, visiting: &mut HashSet<String>) -> Result<u32, ServiceError> {
        if let Some(state) = self.running.get(name) {
            return Ok(state.pid); // already running, nothing to do
        }
        if !visiting.insert(name.to_string()) {
            return Err(ServiceError::CircularDependency(name.to_string()));
        }

        let def = self
            .definitions
            .get(name)
            .cloned()
            .ok_or_else(|| ServiceError::NotRegistered(name.to_string()))?;

        for dep in &def.depends_on {
            self.start_inner(dep, visiting)?;
        }

        let args: Vec<&str> = def.args.iter().map(String::as_str).collect();
        let pid = self
            .procmgr
            .spawn(&def.command, &args, def.restart_policy)
            .map_err(|e| ServiceError::SpawnFailed(name.to_string(), e.to_string()))?;

        self.running.insert(name.to_string(), RunningState { pid, restart_count: 0, gave_up: false });
        Ok(pid)
    }

    pub fn stop(&mut self, name: &str) -> Result<(), ServiceError> {
        let state = self.running.get(name).ok_or_else(|| ServiceError::NotRunning(name.to_string()))?;
        self.procmgr
            .terminate(state.pid)
            .map_err(|e| ServiceError::SpawnFailed(name.to_string(), e.to_string()))?;
        self.running.remove(name);
        Ok(())
    }

    pub fn restart(&mut self, name: &str) -> Result<u32, ServiceError> {
        if self.running.contains_key(name) {
            self.stop(name)?;
        }
        self.start(name)
    }

    pub fn status(&mut self, name: &str) -> ServiceStatus {
        let Some(state) = self.running.get(name) else {
            return ServiceStatus::NotStarted;
        };
        if state.gave_up {
            return ServiceStatus::Failed;
        }
        match self.procmgr.get(state.pid).map(|i| i.state) {
            Some(ProcessState::Running) | Some(ProcessState::Sleeping) => ServiceStatus::Running,
            Some(ProcessState::Terminated) | None => ServiceStatus::Stopped,
            _ => ServiceStatus::Running,
        }
    }

    /// The supervision loop: reaps exited processes, and for any
    /// managed service whose process has terminated, checks its
    /// `RestartPolicy` (via the underlying `ProcessManager`'s
    /// `should_restart`, Day 2's seam) and actually respawns it if
    /// warranted — this is Day 6's crash/restart policy *enforcement*,
    /// not just the policy's definition. Returns the names of
    /// services that were auto-restarted this call.
    pub fn tick(&mut self) -> Vec<String> {
        self.procmgr.reap_zombies();
        let mut restarted = Vec::new();

        let names: Vec<String> = self.running.keys().cloned().collect();
        for name in names {
            let pid = self.running[&name].pid;
            let terminated = matches!(self.procmgr.get(pid).map(|i| i.state), Some(ProcessState::Terminated));
            if !terminated {
                continue;
            }

            let should_restart = self.procmgr.should_restart(pid);
            let def = self.definitions.get(&name).cloned();
            let (restart_count, max_restarts) = {
                let state = self.running.get(&name).unwrap();
                (state.restart_count, def.as_ref().map(|d| d.max_restarts).unwrap_or(0))
            };

            if should_restart && restart_count < max_restarts {
                if let Some(def) = def {
                    let args: Vec<&str> = def.args.iter().map(String::as_str).collect();
                    match self.procmgr.spawn(&def.command, &args, def.restart_policy) {
                        Ok(new_pid) => {
                            self.running.insert(
                                name.clone(),
                                RunningState { pid: new_pid, restart_count: restart_count + 1, gave_up: false },
                            );
                            restarted.push(name);
                        }
                        Err(_) => {
                            if let Some(state) = self.running.get_mut(&name) {
                                state.gave_up = true;
                            }
                        }
                    }
                }
            } else {
                // Policy says don't restart, or the safety cap was
                // hit -- mark it Failed rather than silently leaving
                // a stale "running" entry pointing at a dead pid.
                if let Some(state) = self.running.get_mut(&name) {
                    state.gave_up = true;
                }
            }
        }

        restarted
    }

    pub fn restart_count(&self, name: &str) -> u32 {
        self.running.get(name).map(|s| s.restart_count).unwrap_or(0)
    }
}

impl Default for ServiceManager {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;
    use std::time::Duration;

    fn simple_service(name: &str, command: &str, args: &[&str], policy: RestartPolicy) -> ServiceDef {
        ServiceDef {
            name: name.to_string(),
            command: command.to_string(),
            args: args.iter().map(|s| s.to_string()).collect(),
            restart_policy: policy,
            depends_on: vec![],
            max_restarts: 5,
        }
    }

    /// First half of the Day 6 DoD: start/stop a test service.
    #[test]
    fn day6_start_stop_service() {
        let mut mgr = ServiceManager::new();
        mgr.register(simple_service("test-sleep", "sleep", &["5"], RestartPolicy::Never));

        assert_eq!(mgr.status("test-sleep"), ServiceStatus::NotStarted);
        mgr.start("test-sleep").expect("start should succeed");
        thread::sleep(Duration::from_millis(100));
        assert_eq!(mgr.status("test-sleep"), ServiceStatus::Running);

        mgr.stop("test-sleep").expect("stop should succeed");
        assert_eq!(mgr.status("test-sleep"), ServiceStatus::NotStarted);
    }

    /// Second half of the Day 6 DoD, the literal wording: "recover
    /// from a deliberately failed test service (verify the
    /// crash/restart policy actually fires)."
    #[test]
    fn day6_crash_restart_policy_actually_fires() {
        let mut mgr = ServiceManager::new();
        // `false` exits immediately with a nonzero status every time
        // -- a deliberately, repeatedly failing test service.
        mgr.register(simple_service("test-crasher", "false", &[], RestartPolicy::OnFailure));

        let original_pid = mgr.start("test-crasher").expect("start should succeed");
        thread::sleep(Duration::from_millis(150));

        let restarted = mgr.tick();
        assert!(
            restarted.contains(&"test-crasher".to_string()),
            "tick() should have auto-restarted the crashed service, restarted={restarted:?}"
        );
        assert_eq!(mgr.restart_count("test-crasher"), 1);

        let new_pid = mgr.running.get("test-crasher").unwrap().pid;
        assert_ne!(original_pid, new_pid, "restarted service should have a new pid");
    }

    #[test]
    fn never_policy_does_not_auto_restart() {
        let mut mgr = ServiceManager::new();
        mgr.register(simple_service("test-never", "false", &[], RestartPolicy::Never));
        mgr.start("test-never").unwrap();
        thread::sleep(Duration::from_millis(150));

        let restarted = mgr.tick();
        assert!(!restarted.contains(&"test-never".to_string()));
        assert_eq!(mgr.status("test-never"), ServiceStatus::Failed);
    }

    #[test]
    fn max_restarts_cap_is_enforced() {
        let mut mgr = ServiceManager::new();
        let mut def = simple_service("test-looper", "false", &[], RestartPolicy::Always);
        def.max_restarts = 2;
        mgr.register(def);

        mgr.start("test-looper").unwrap();
        // Tick repeatedly, simulating the supervision loop running
        // over time as the service keeps crashing immediately.
        let mut total_restarts = 0;
        for _ in 0..6 {
            thread::sleep(Duration::from_millis(80));
            total_restarts += mgr.tick().len();
        }

        assert_eq!(
            mgr.restart_count("test-looper"),
            2,
            "restart count should stop growing once max_restarts is hit"
        );
        assert!(total_restarts <= 2, "should never restart more than max_restarts times, got {total_restarts}");
    }

    #[test]
    fn dependency_starts_before_dependent() {
        let mut mgr = ServiceManager::new();
        mgr.register(simple_service("base", "sleep", &["2"], RestartPolicy::Never));
        let mut dependent = simple_service("dependent", "sleep", &["2"], RestartPolicy::Never);
        dependent.depends_on = vec!["base".to_string()];
        mgr.register(dependent);

        assert_eq!(mgr.status("base"), ServiceStatus::NotStarted);
        mgr.start("dependent").expect("starting dependent should also start base");

        assert_eq!(mgr.status("base"), ServiceStatus::Running, "dependency should have been auto-started");
        assert_eq!(mgr.status("dependent"), ServiceStatus::Running);

        mgr.stop("dependent").unwrap();
        mgr.stop("base").unwrap();
    }

    #[test]
    fn circular_dependency_is_detected_not_infinite_loop() {
        let mut mgr = ServiceManager::new();
        let mut a = simple_service("svc-a", "sleep", &["1"], RestartPolicy::Never);
        a.depends_on = vec!["svc-b".to_string()];
        let mut b = simple_service("svc-b", "sleep", &["1"], RestartPolicy::Never);
        b.depends_on = vec!["svc-a".to_string()];
        mgr.register(a);
        mgr.register(b);

        let result = mgr.start("svc-a");
        assert!(matches!(result, Err(ServiceError::CircularDependency(_))));
    }

    #[test]
    fn starting_unregistered_service_errors_cleanly() {
        let mut mgr = ServiceManager::new();
        let result = mgr.start("does-not-exist");
        assert!(matches!(result, Err(ServiceError::NotRegistered(_))));
    }

    #[test]
    fn stopping_a_not_running_service_errors_cleanly() {
        let mut mgr = ServiceManager::new();
        mgr.register(simple_service("idle", "sleep", &["1"], RestartPolicy::Never));
        let result = mgr.stop("idle");
        assert!(matches!(result, Err(ServiceError::NotRunning(_))));
    }
}
