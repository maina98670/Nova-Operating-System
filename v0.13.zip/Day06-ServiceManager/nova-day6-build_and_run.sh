#!/bin/bash
# Nova OS — Day 6: Service Manager (M4, per the Complete Build Guide)
# Real Linux process supervision -- no root, no cross-compilation, no
# QEMU needed. Already verified live in the sandbox this was built in.
# Includes nova-procmgr (Day 2) since nova-svcmgr builds directly on it.
set -e

echo "=== Nova OS Day 6: Service Manager ==="

echo "[1/2] Running nova-svcmgr library unit tests (8 tests, real crash/restart cycles)..."
cargo test -p nova-svcmgr

echo "[2/2] Building and running the live Definition of Done test..."
cargo build -p nova-svcmgr-test
./target/debug/nova-svcmgr-test
