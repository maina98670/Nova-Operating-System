//! Nova Service Manager test client — the literal Day 6 Definition of
//! Done, run as a standalone, visible process: "start/stop a test
//! service, and recover from a deliberately failed test service
//! (verify the crash/restart policy actually fires)."

use nova_procmgr::RestartPolicy;
use nova_svcmgr::{ServiceDef, ServiceManager, ServiceStatus};
use std::process;
use std::thread;
use std::time::Duration;

fn fail(msg: &str) -> ! {
    eprintln!("nova-svcmgr-test: FAIL -- {msg}");
    process::exit(1);
}

fn main() {
    let mut mgr = ServiceManager::new();
    println!("nova-svcmgr-test: starting");

    // --- Step 1: start/stop a test service ---
    mgr.register(ServiceDef {
        name: "test-sleeper".to_string(),
        command: "sleep".to_string(),
        args: vec!["5".to_string()],
        restart_policy: RestartPolicy::Never,
        depends_on: vec![],
        max_restarts: 0,
    });

    println!("nova-svcmgr-test: START test-sleeper");
    mgr.start("test-sleeper").unwrap_or_else(|e| fail(&format!("start failed: {e}")));
    thread::sleep(Duration::from_millis(100));
    if mgr.status("test-sleeper") != ServiceStatus::Running {
        fail("expected test-sleeper to be Running after start");
    }
    println!("  status: Running (confirmed)");

    println!("nova-svcmgr-test: STOP test-sleeper");
    mgr.stop("test-sleeper").unwrap_or_else(|e| fail(&format!("stop failed: {e}")));
    if mgr.status("test-sleeper") != ServiceStatus::NotStarted {
        fail("expected test-sleeper to be NotStarted after stop");
    }
    println!("  status: NotStarted (confirmed)");
    println!("nova-svcmgr-test: step 1 (start/stop) verified");
    println!();

    // --- Step 2: deliberately fail a test service, verify the
    //     crash/restart policy actually fires ---
    mgr.register(ServiceDef {
        name: "test-crasher".to_string(),
        command: "false".to_string(), // always exits with failure, immediately
        args: vec![],
        restart_policy: RestartPolicy::OnFailure,
        depends_on: vec![],
        max_restarts: 3,
    });

    println!("nova-svcmgr-test: START test-crasher (a service that always exits with failure)");
    let original_pid = mgr.start("test-crasher").unwrap_or_else(|e| fail(&format!("start failed: {e}")));
    println!("  original pid: {original_pid}");
    thread::sleep(Duration::from_millis(150));

    println!("nova-svcmgr-test: TICK (running the supervision loop)");
    let restarted = mgr.tick();
    if !restarted.contains(&"test-crasher".to_string()) {
        fail(&format!("expected tick() to auto-restart test-crasher, got restarted={restarted:?}"));
    }
    println!("  tick() auto-restarted: {restarted:?}");

    let restart_count = mgr.restart_count("test-crasher");
    println!("nova-svcmgr-test: restart_count for test-crasher is now {restart_count}");
    if restart_count == 0 {
        fail("restart_count should be at least 1 after the policy fired");
    }

    println!();
    println!("nova-svcmgr-test: PASS -- Day 6 Definition of Done satisfied end-to-end");
    println!("nova-svcmgr-test: started/stopped a test service cleanly, then confirmed");
    println!("nova-svcmgr-test: the crash/restart policy actually respawned a deliberately");
    println!("nova-svcmgr-test: failing service -- Day 2's RestartPolicy seam, finally acted on.");
}
