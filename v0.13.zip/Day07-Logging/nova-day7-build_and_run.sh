#!/bin/bash
# Nova OS — Day 7: Logging (M4, per the Complete Build Guide)
# Structured logging persisted through nova-fsmgr (Day 4), plus a
# real retrofit of nova-procmgrd (Day 2) to log through this instead
# of raw println!. No root, no cross-compilation, no QEMU needed.
set -e

echo "=== Nova OS Day 7: Logging ==="

echo "[1/3] Running nova-fsmgr tests (includes the new append_file, added today)..."
cargo test -p nova-fsmgr

echo "[2/3] Running nova-log library unit tests (7 tests)..."
cargo test -p nova-log

echo "[3/3] Building and running the live Definition of Done test..."
cargo build -p nova-log-test
./target/debug/nova-log-test

echo ""
echo "=== Bonus: the retrofitted nova-procmgrd, logging for real ==="
echo "Run this yourself to see it:"
echo "  cargo build -p nova-procmgrd"
echo "  NOVA_PROCMGR_SOCK=/tmp/procmgr.sock NOVA_PROCMGRD_LOG_PATH=/tmp/procmgrd.log ./target/debug/nova-procmgrd &"
echo "  cat /tmp/procmgrd.log   # real structured log entries"
