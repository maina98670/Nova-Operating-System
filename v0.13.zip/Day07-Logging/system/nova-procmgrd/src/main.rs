//! Nova Process Manager daemon — binds a Unix domain socket and
//! serves `nova_procmgrd_proto::handle_command` to any connected
//! client, one thread per connection. This is the actual system
//! service M2's Nova Init would start (per Section 1's boot sequence:
//! Init starts services in order; this is one of them) — running it
//! standalone here, outside Nova Init, is exactly how it's tested in
//! this sandbox without needing a full OS boot.
//!
//! **Day 7 retrofit**: this daemon previously logged via raw
//! `println!`/`eprintln!` (see Day 2's original version). It now logs
//! through `nova-log`, persisted via `nova-fsmgr::paths::LOG` — a
//! concrete instance of Day 7's third task ("Boot and service
//! diagnostics feeding into this same logging path -- retrofit ...
//! M4's own subsystems to log through it rather than raw console
//! prints"). This is one deliberately complete example of the
//! retrofit, not a claim that every M0-M6 subsystem has been migrated
//! in this pass — see the Day 7 README for what's in scope here
//! versus genuine follow-up work.

use nova_fsmgr::paths;
use nova_log::Logger;
use nova_procmgr::ProcessManager;
use nova_procmgrd_proto::handle_command;
use std::env;
use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::thread;

const SOURCE: &str = "nova-procmgrd";

fn socket_path() -> String {
    env::var("NOVA_PROCMGR_SOCK").unwrap_or_else(|_| "/run/nova/procmgr.sock".to_string())
}

fn log_path() -> PathBuf {
    env::var("NOVA_PROCMGRD_LOG_PATH")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from(paths::LOG).join("procmgrd.log"))
}

fn handle_client(stream: UnixStream, pm: Arc<Mutex<ProcessManager>>, logger: Arc<Mutex<Logger>>) {
    let reader = BufReader::new(stream.try_clone().expect("clone stream"));
    let mut writer = stream;
    for line in reader.lines() {
        let line = match line {
            Ok(l) => l,
            Err(e) => {
                logger.lock().unwrap().warning(SOURCE, &format!("client read error: {e}"));
                break;
            }
        };
        if line.is_empty() {
            continue;
        }
        logger.lock().unwrap().debug(SOURCE, &format!("received command: {line}"));
        let response = {
            let mut pm = pm.lock().expect("procmgr lock poisoned");
            handle_command(&mut pm, &line)
        };
        if writer.write_all(response.as_bytes()).is_err() {
            logger.lock().unwrap().warning(SOURCE, "failed to write response to client, dropping connection");
            break;
        }
        if writer.write_all(b"\n---\n").is_err() {
            break; // end-of-response marker, since LIST responses are multi-line
        }
    }
}

fn main() {
    // Ensure Nova's standard log directory exists (Day 4's
    // ensure_dirs, applied here to just the one directory this
    // service actually needs -- not the full ensure_standard_dirs
    // sweep, since that's Nova Init's job at real boot, not an
    // individual service's).
    if let Err(e) = nova_fsmgr::ensure_dirs(&[paths::LOG]) {
        eprintln!("nova-procmgrd: could not create log directory {}: {e} (logging to memory only)", paths::LOG);
    }

    let logger = Arc::new(Mutex::new(Logger::with_persistence(log_path())));
    logger.lock().unwrap().info(SOURCE, "Day 7 retrofit: now logging through nova-log, not raw println!");

    let path = socket_path();
    let _ = std::fs::remove_file(&path); // stale socket from a prior run

    if let Some(parent) = std::path::Path::new(&path).parent() {
        let _ = std::fs::create_dir_all(parent);
    }

    let listener = match UnixListener::bind(&path) {
        Ok(l) => l,
        Err(e) => {
            logger.lock().unwrap().critical(SOURCE, &format!("could not bind {path}: {e}"));
            std::process::exit(1);
        }
    };
    logger.lock().unwrap().info(SOURCE, &format!("listening on {path}"));

    let pm = Arc::new(Mutex::new(ProcessManager::new()));

    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                let pm = pm.clone();
                let logger = logger.clone();
                thread::spawn(move || handle_client(stream, pm, logger));
            }
            Err(e) => {
                logger.lock().unwrap().error(SOURCE, &format!("accept error: {e}"));
            }
        }
    }
}
