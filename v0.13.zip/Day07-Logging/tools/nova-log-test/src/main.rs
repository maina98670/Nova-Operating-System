//! Nova Logging test client — the literal Day 7 Definition of Done,
//! run as a standalone, visible process: "a test emits log lines at
//! each level and they're queryable/filterable afterward, not just
//! scrolling text."

use nova_log::{load_from_file, LogLevel, Logger};
use std::env;
use std::process;

fn fail(msg: &str) -> ! {
    eprintln!("nova-log-test: FAIL -- {msg}");
    process::exit(1);
}

fn main() {
    let log_path = env::temp_dir().join(format!("nova-log-test-live-{}.log", process::id()));
    let _ = std::fs::remove_file(&log_path);
    println!("nova-log-test: persisting to {log_path:?}");

    let mut logger = Logger::with_persistence(log_path.clone());

    println!("nova-log-test: emitting one log line at each of the five levels...");
    logger.debug("nova-log-test", "debug: verbose diagnostic detail");
    logger.info("nova-log-test", "info: normal operation");
    logger.warning("nova-log-test", "warning: something worth noting");
    logger.error("nova-log-test", "error: an operation failed");
    logger.critical("nova-log-test", "critical: needs immediate attention");

    if logger.all().len() != 5 {
        fail(&format!("expected 5 in-memory entries, got {}", logger.all().len()));
    }
    println!("  {} entries recorded in memory", logger.all().len());

    println!("nova-log-test: querying: filter_by_level(Warning) -- should return Warning/Error/Critical only");
    let warnings_and_above = logger.filter_by_level(LogLevel::Warning);
    if warnings_and_above.len() != 3 {
        fail(&format!("expected 3 entries at Warning-or-above, got {}", warnings_and_above.len()));
    }
    for e in &warnings_and_above {
        println!("  [{:?}] {}", e.level, e.message);
    }

    println!("nova-log-test: reading the persisted file back via load_from_file (through nova-fsmgr)...");
    let loaded = load_from_file(&log_path).unwrap_or_else(|e| fail(&format!("load_from_file failed: {e}")));
    if loaded.len() != 5 {
        fail(&format!("expected 5 persisted entries, got {}", loaded.len()));
    }
    println!("  {} entries loaded back from disk, structure intact:", loaded.len());
    for e in &loaded {
        println!("    ts={} level={:?} source={} message={:?}", e.timestamp_secs, e.level, e.source, e.message);
    }

    let _ = std::fs::remove_file(&log_path);

    println!();
    println!("nova-log-test: PASS -- Day 7 Definition of Done satisfied end-to-end");
    println!("nova-log-test: emitted structured logs at all 5 levels, filtered them by level,");
    println!("nova-log-test: and round-tripped them through a real file via nova-fsmgr -- queryable");
    println!("nova-log-test: and filterable, not scrolling text.");
}
