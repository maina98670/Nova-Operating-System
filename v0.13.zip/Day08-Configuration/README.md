# Nova OS — Day 8 Package: Configuration (M4 continues)

Per the Complete Build Guide, Day 8's focus is configuration loading —
TOML format, a standard /etc/nova/ directory layout, and validation
that fails loudly on a malformed file rather than silently
misconfiguring or crashing the service.

This package was assembled without running any tests or builds --
per instruction, this is files only. Nothing below has been
re-verified in this pass the way Days 2-7 were; run
nova-day8-build_and_run.sh yourself to actually confirm it.

## What's in this package

- libs/nova-config -- load/load_or_default (TOML via serde + the
  toml crate, a real dependency rather than a hand-rolled parser
  since TOML's grammar is more than the project's other flat-file
  formats were designed for), config_path_for(service_name) mapping
  to nova-fsmgr::paths::CONFIG (/etc/nova/<service>.toml), and
  ConfigError with a Display impl that names the offending file
  and the underlying parse error.
- libs/nova-fsmgr, libs/nova-log, libs/nova-procmgr -- Day 4/7/2's
  packages, included as dependencies.
- system/nova-procmgrd -- retrofitted again (Day 7 added logging;
  this adds config): a new config.rs defines ProcmgrdConfig
  (socket path, log directory) and load_procmgrd_config(). main()
  now loads this first, before anything else starts, and exits with
  a clear fatal error if the file is malformed -- never partway
  through startup on half-applied bad settings.
- tools/nova-config-test -- the real test process the Day 8 DoD
  describes literally: reads a valid config, confirms a missing file
  produces safe defaults (not an error), and confirms a malformed
  file is rejected with a clear, named error -- including verifying
  that load_or_default does NOT quietly paper over a malformed file
  with defaults (only a genuinely missing file gets that treatment).

## The missing-vs-malformed distinction, and why it matters

Day 8's DoD specifically separates two failure modes that are easy to
conflate:

- Missing config -> not a failure at all. load_or_default returns
  T::default(). A fresh Nova install has no per-service config yet,
  and that's a normal, expected state.
- Malformed config (file exists, fails to parse) -> always a loud
  Err, from both load and load_or_default. Silently misconfiguring a
  running service because of a typo in its config file is a worse
  outcome than refusing to start -- this is why load_or_default
  deliberately does NOT fall back to defaults just because parsing
  failed; it only defaults when the file was never there to parse in
  the first place.

## Honest scope

Only nova-procmgrd has been retrofitted to actually load a real
config file at startup (mirroring Day 7's "one complete retrofit, not
five superficial ones" approach). The other M4 subsystems built on
Days 2-6 (nova-memmgr, nova-fsmgr, nova-devmgr, nova-svcmgr) do not
yet read their own config files -- that's identifiable follow-up
work, not something silently skipped.

## Next: Day 9

Per the Guide's M4 table, Day 9 is the Nova Core API -- likely the
day these seven subsystems (Process/Memory/Filesystem/Device/
Service/Logging/Configuration) get unified behind one coherent,
documented API surface, per Day 9's own place in the M4 table as the
closing day before M4's overall acceptance pass.
