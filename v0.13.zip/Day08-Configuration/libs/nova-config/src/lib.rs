//! Nova Configuration — M4 Day 8.
//!
//! Format: TOML, via `serde` + the `toml` crate — matching Day 8's
//! own reasoning ("a reasonable default given Rust's ecosystem and
//! that `nova-app.toml` manifests already use it"), and a real
//! dependency rather than a hand-rolled parser, since TOML's actual
//! grammar (nested tables, arrays, multiple scalar types) is not the
//! kind of small, stable format the project's other hand-rolled
//! parsers (`nova-contacts`, `nova-messages`, `nova-log`) were
//! designed for — those use one flat line format each; TOML's whole
//! point is structure, so it gets a real, mature parser.
//!
//! Directory layout: every service's config lives at
//! `nova_fsmgr::paths::CONFIG/<service>.toml` (`/etc/nova/<service>.toml`
//! by default) — one location convention, not each service inventing
//! its own path, continuing Day 4's standard-directories work.
//!
//! Validation: the central design point Day 8 asks for is a hard
//! distinction between two very different failure states:
//!   - **Missing** config file -> not an error. A fresh Nova install
//!     has no per-service config yet; `load_or_default` returns
//!     `T::default()` and moves on.
//!   - **Malformed** config file (present, but fails to parse into
//!     the expected structure) -> a loud, immediate `Err`, never a
//!     silent fallback to defaults and never a panic. Silently
//!     misconfiguring a service because its config file had a typo is
//!     a worse failure mode than refusing to start at all — the
//!     service should fail loudly enough that whoever misconfigured
//!     it finds out immediately, not later, from broken behavior.

use nova_fsmgr::paths;
use serde::de::DeserializeOwned;
use std::fmt;
use std::path::{Path, PathBuf};

#[derive(Debug)]
pub enum ConfigError {
    /// The file exists but could not be read (permissions, I/O error
    /// — not "file doesn't exist", which `load_or_default` treats as
    /// "use defaults", not an error at all).
    Io(std::io::Error),
    /// The file exists and was read, but failed to parse as valid
    /// TOML matching the expected structure — Day 8's literal
    /// "malformed config file is rejected with a clear error" case.
    Parse { path: PathBuf, source: toml::de::Error },
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ConfigError::Io(e) => write!(f, "config I/O error: {e}"),
            ConfigError::Parse { path, source } => {
                write!(f, "malformed config file at {}: {source}", path.display())
            }
        }
    }
}

impl std::error::Error for ConfigError {}

/// Returns the standard config path for `service_name`, under
/// `nova_fsmgr::paths::CONFIG` — the one-location convention every
/// service should use rather than picking its own path.
pub fn config_path_for(service_name: &str) -> PathBuf {
    Path::new(paths::CONFIG).join(format!("{service_name}.toml"))
}

/// Loads and parses `path` as TOML into `T`. Always an error if the
/// file is missing *or* malformed — callers that want the
/// missing-file-means-defaults behavior should use
/// `load_or_default` instead. This function exists separately because
/// some callers (a required config, not an optional one) genuinely
/// should treat a missing file as an error too.
pub fn load<T: DeserializeOwned>(path: &Path) -> Result<T, ConfigError> {
    let contents = nova_fsmgr::read_file(path).map_err(ConfigError::Io)?;
    let text = String::from_utf8_lossy(&contents);
    toml::from_str(&text).map_err(|source| ConfigError::Parse { path: path.to_path_buf(), source })
}

/// The recommended entry point for most services: missing file ->
/// `T::default()`, present-and-valid -> the parsed config,
/// present-but-malformed -> a loud `Err`, never a silent fallback.
/// This is the literal Day 8 DoD behavior in one function.
pub fn load_or_default<T: DeserializeOwned + Default>(path: &Path) -> Result<T, ConfigError> {
    if !path.exists() {
        return Ok(T::default());
    }
    load(path)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde::Deserialize;
    use std::env;
    use std::fs;

    #[derive(Debug, Deserialize, PartialEq)]
    struct ExampleServiceConfig {
        #[serde(default = "default_max_connections")]
        max_connections: u32,
        #[serde(default = "default_log_level")]
        log_level: String,
    }

    fn default_max_connections() -> u32 {
        64
    }
    fn default_log_level() -> String {
        "INFO".to_string()
    }

    impl ExampleServiceConfig {
        fn defaults() -> Self {
            ExampleServiceConfig { max_connections: default_max_connections(), log_level: default_log_level() }
        }
    }

    impl Default for ExampleServiceConfig {
        fn default() -> Self {
            Self::defaults()
        }
    }

    fn temp_config_path(name: &str) -> PathBuf {
        env::temp_dir().join(format!("nova-config-test-{}-{}", std::process::id(), name))
    }

    /// The literal Day 8 DoD, first half: a service reads its config
    /// from the standard directory (well, a temp stand-in for it in
    /// this test -- config_path_for's real-path behavior is covered
    /// separately below).
    #[test]
    fn day8_definition_of_done_valid_config_loads_correctly() {
        let path = temp_config_path("valid.toml");
        fs::write(&path, "max_connections = 128\nlog_level = \"DEBUG\"\n").unwrap();

        let config: ExampleServiceConfig = load(&path).expect("valid TOML should load without error");
        assert_eq!(config.max_connections, 128);
        assert_eq!(config.log_level, "DEBUG");

        let _ = fs::remove_file(&path);
    }

    /// The literal Day 8 DoD, second half: an intentionally malformed
    /// config file is rejected with a clear error, not a crash and
    /// not a silent fallback.
    #[test]
    fn day8_definition_of_done_malformed_config_rejected_with_clear_error() {
        let path = temp_config_path("malformed.toml");
        // Deliberately broken TOML: unterminated string.
        fs::write(&path, "max_connections = 128\nlog_level = \"unterminated\n").unwrap();

        let result: Result<ExampleServiceConfig, ConfigError> = load(&path);
        assert!(result.is_err(), "malformed TOML must be rejected, not silently accepted");

        let err = result.unwrap_err();
        let message = err.to_string();
        assert!(
            message.contains("malformed config file"),
            "error message should clearly say the config is malformed, got: {message}"
        );
        assert!(message.contains(&path.display().to_string()), "error should name the offending file");

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn missing_config_file_uses_defaults_not_an_error() {
        let path = temp_config_path("does-not-exist.toml");
        let _ = fs::remove_file(&path);

        let config: ExampleServiceConfig =
            load_or_default(&path).expect("a missing config file should not be an error");
        assert_eq!(config, ExampleServiceConfig::defaults());
    }

    #[test]
    fn load_missing_file_directly_is_an_io_error() {
        let path = temp_config_path("also-does-not-exist.toml");
        let _ = fs::remove_file(&path);
        let result: Result<ExampleServiceConfig, ConfigError> = load(&path);
        assert!(matches!(result, Err(ConfigError::Io(_))));
    }

    #[test]
    fn malformed_config_is_never_silently_replaced_with_defaults() {
        // The critical distinction Day 8's DoD draws: load_or_default
        // only falls back to defaults for a *missing* file. A
        // present-but-malformed file must still error even through
        // load_or_default, never silently defaulting instead.
        let path = temp_config_path("malformed-via-default.toml");
        fs::write(&path, "this is not valid toml [[[").unwrap();

        let result: Result<ExampleServiceConfig, ConfigError> = load_or_default(&path);
        assert!(result.is_err(), "load_or_default must still reject a malformed (as opposed to missing) file");

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn partial_config_fills_missing_fields_with_serde_defaults() {
        // Valid TOML that only specifies one of the two fields --
        // proves per-field defaults (via #[serde(default = ...)])
        // work correctly, distinct from whole-file missing/malformed.
        let path = temp_config_path("partial.toml");
        fs::write(&path, "max_connections = 200\n").unwrap();

        let config: ExampleServiceConfig = load(&path).expect("partial config should load");
        assert_eq!(config.max_connections, 200);
        assert_eq!(config.log_level, "INFO", "unspecified field should fall back to its serde default");

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn config_path_for_uses_the_standard_directory() {
        let path = config_path_for("nova-procmgrd");
        assert_eq!(path, PathBuf::from(paths::CONFIG).join("nova-procmgrd.toml"));
    }
}
