#!/bin/bash
# Nova OS — Day 8: Configuration (M4, per the Complete Build Guide)
# TOML config loading with a hard missing-vs-malformed distinction.
# No root, no cross-compilation, no QEMU needed.
# NOTE: this package was assembled without running any tests or
# builds in the environment that created it -- run this script
# yourself to verify everything below actually works.
set -e

echo "=== Nova OS Day 8: Configuration ==="

echo "[1/3] Running nova-config library unit tests (8 tests)..."
cargo test -p nova-config

echo "[2/3] Building and running the live Definition of Done test..."
cargo build -p nova-config-test
./target/debug/nova-config-test

echo ""
echo "[3/3] Confirming nova-procmgrd (Day 2/7/8 retrofit) still builds with config support..."
cargo build -p nova-procmgrd
echo "nova-procmgrd now loads /etc/nova/nova-procmgrd.toml at startup: falls back to"
echo "defaults if the file is absent, and refuses to start with a clear error if the"
echo "file is present but malformed."
