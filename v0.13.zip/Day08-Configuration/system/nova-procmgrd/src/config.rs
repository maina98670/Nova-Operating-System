//! nova-procmgrd's own configuration — Day 8 retrofit.
//!
//! Concrete instance of the Day 8 DoD applied to a real, already-
//! shipped service (Day 2's daemon): it now reads its socket path and
//! log level from `/etc/nova/nova-procmgrd.toml` (via
//! `nova_config::config_path_for`), falling back to the same
//! hardcoded defaults it always used if the file is absent, and
//! refusing to start with a clear error if the file is present but
//! malformed — never silently misconfiguring itself.

use nova_config::{config_path_for, load_or_default, ConfigError};
use serde::Deserialize;
use std::path::PathBuf;

#[derive(Debug, Deserialize)]
pub struct ProcmgrdConfig {
    #[serde(default = "default_socket_path")]
    pub socket_path: String,
    #[serde(default = "default_log_dir")]
    pub log_dir: String,
}

fn default_socket_path() -> String {
    "/run/nova/procmgr.sock".to_string()
}
fn default_log_dir() -> String {
    nova_fsmgr::paths::LOG.to_string()
}

impl Default for ProcmgrdConfig {
    fn default() -> Self {
        ProcmgrdConfig { socket_path: default_socket_path(), log_dir: default_log_dir() }
    }
}

/// Loads nova-procmgrd's config from its standard path. Returns a
/// clear `ConfigError` (never a panic, never a silent default) if the
/// file exists but is malformed — the caller (`main`) is expected to
/// print the error and exit, per Day 8's DoD wording: "rejected with
/// a clear error rather than crashing the service or silently
/// misconfiguring it."
pub fn load_procmgrd_config() -> Result<ProcmgrdConfig, ConfigError> {
    let path: PathBuf = config_path_for("nova-procmgrd");
    load_or_default(&path)
}
