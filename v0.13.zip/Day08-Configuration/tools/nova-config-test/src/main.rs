//! Nova Configuration test client — the literal Day 8 Definition of
//! Done, run as a standalone, visible process: "A service reads its
//! config from the standard directory; an intentionally malformed
//! config file is rejected with a clear error rather than crashing
//! the service or silently misconfiguring it."

use nova_config::{load, load_or_default};
use serde::Deserialize;
use std::env;
use std::fs;
use std::process;

#[derive(Debug, Deserialize, Default, PartialEq)]
struct DemoServiceConfig {
    #[serde(default = "default_max_connections")]
    max_connections: u32,
    #[serde(default = "default_log_level")]
    log_level: String,
}
fn default_max_connections() -> u32 {
    64
}
fn default_log_level() -> String {
    "INFO".to_string()
}

fn fail(msg: &str) -> ! {
    eprintln!("nova-config-test: FAIL -- {msg}");
    process::exit(1);
}

fn main() {
    println!("nova-config-test: starting");
    let dir = env::temp_dir().join(format!("nova-config-test-live-{}", process::id()));
    let _ = fs::remove_dir_all(&dir);
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(&format!("could not create test dir: {e}")));

    // --- Step 1: a service reads its config from a standard-shaped path ---
    let valid_path = dir.join("demo-service.toml");
    fs::write(&valid_path, "max_connections = 200\nlog_level = \"DEBUG\"\n")
        .unwrap_or_else(|e| fail(&format!("could not write test config: {e}")));

    println!("nova-config-test: reading a valid config from {valid_path:?}");
    let cfg: DemoServiceConfig = load(&valid_path).unwrap_or_else(|e| fail(&format!("valid config load failed: {e}")));
    println!("  max_connections={} log_level={}", cfg.max_connections, cfg.log_level);
    if cfg.max_connections != 200 || cfg.log_level != "DEBUG" {
        fail("loaded config values did not match what was written");
    }
    println!("nova-config-test: step 1 (valid config load) verified");
    println!();

    // --- Step 2: missing config uses safe defaults, not an error ---
    let missing_path = dir.join("never-created.toml");
    println!("nova-config-test: loading from a missing path {missing_path:?} (should use defaults)");
    let defaulted: DemoServiceConfig =
        load_or_default(&missing_path).unwrap_or_else(|e| fail(&format!("missing-file load should not error: {e}")));
    if defaulted != DemoServiceConfig::default() {
        fail("missing config should have produced exactly the default values");
    }
    println!("  got defaults: max_connections={} log_level={}", defaulted.max_connections, defaulted.log_level);
    println!("nova-config-test: step 2 (missing file -> safe defaults) verified");
    println!();

    // --- Step 3: an intentionally malformed config is rejected loudly ---
    let malformed_path = dir.join("malformed.toml");
    fs::write(&malformed_path, "max_connections = 200\nlog_level = \"unterminated string\n")
        .unwrap_or_else(|e| fail(&format!("could not write malformed test config: {e}")));

    println!("nova-config-test: loading an intentionally malformed config from {malformed_path:?}");
    let result: Result<DemoServiceConfig, _> = load(&malformed_path);
    match result {
        Ok(_) => fail("malformed config was accepted -- this must be rejected, not silently parsed"),
        Err(e) => {
            println!("  rejected with a clear error, as required:");
            println!("  {e}");
        }
    }

    // Also confirm load_or_default doesn't quietly paper over the
    // malformed case with defaults -- only a *missing* file should
    // ever produce defaults.
    let result2: Result<DemoServiceConfig, _> = load_or_default(&malformed_path);
    if result2.is_ok() {
        fail("load_or_default silently replaced a malformed config with defaults -- this must still error");
    }
    println!("nova-config-test: confirmed load_or_default does NOT silently default a malformed (vs missing) file");

    let _ = fs::remove_dir_all(&dir);

    println!();
    println!("nova-config-test: PASS -- Day 8 Definition of Done satisfied end-to-end");
    println!("nova-config-test: valid config loads correctly, missing config uses safe");
    println!("nova-config-test: defaults, and a malformed config is rejected with a clear,");
    println!("nova-config-test: named error -- never a crash, never silent misconfiguration.");
}
