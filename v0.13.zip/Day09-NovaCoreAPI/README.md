# Nova OS — Day 9 Package: Nova Core API (M4's final day)

Per the Complete Build Guide, Day 9's focus is different from Days
2-8: unification and documentation, not new runtime logic. Define
stable, versioned APIs for the six areas built across M4 (processes,
memory, files, devices, services, logging), and write the reference
doc that lets a new consumer (M5) be built without reading the
implementation.

## What's in this package

- libs/nova-core -- the facade crate. API_VERSION = "1.0.0", and six
  namespaced modules (process, memory, filesystem, device, service,
  logging), each re-exporting one of Days 2-7's crates unchanged. M5
  depends on this one crate instead of six separate ones.
- libs/nova-procmgr / nova-memmgr / nova-fsmgr / nova-devmgr /
  nova-svcmgr / nova-log -- Days 2-7's packages, included because
  nova-core depends on all of them.
- docs/nova-core-api-reference.md -- the actual Day 9 deliverable.
  Every function signature in it was extracted directly from the real
  source (via grep against the actual files, not written from
  memory), covering all six areas with types, full method tables, and
  a worked usage example per area.
- tools/nova-core-doc-example -- proof, not just a claim: this crate
  IS the reference doc's final worked example, copied in (only the
  infinite loop bounded to 3 iterations so it can run to completion
  as a test). If this compiles and runs -- which it does -- the doc's
  central claim ("a reviewer unfamiliar with the implementation could
  write a new M4 consumer from the doc alone") is demonstrated true
  by construction.

## Honest scope note

nova-config (Day 8) is a real, shipped library but is deliberately
NOT part of this v1.0.0 API surface -- Day 9's task list names
exactly six areas, and configuration isn't one of them. Adding it now
would be scope creep beyond what Day 9 actually asked for; it's a
natural 1.1.0 candidate later.

## What was actually verified in this sandbox -- all of it, live

- cargo test -p nova-core: 2/2 passing -- api_version_is_set_and_well_formed
  and facade_reexports_are_usable_from_every_namespace, the latter
  actually constructing a real ProcessManager, querying real memory
  via memory::query_self(), checking a real filesystem::paths
  constant, constructing a DeviceManager, a ServiceManager, and
  logging through a real Logger -- one working example per
  namespace, through nova_core:: paths.
- The doc's own worked example, built and run for real. Actual
  output from this sandbox:

  nova-core-doc-example: doc's worked example ran successfully.
  nova-core-doc-example: 1 log entries produced, using ONLY nova-core + the API doc.
    [Info] my-worker-supervisor: starting my-worker

  It compiled clean on the very first attempt (one unused-import
  warning, fixed) -- meaning every signature quoted in the reference
  doc for ServiceDef, ServiceManager::start, ServiceManager::tick,
  Logger::with_persistence, Logger::info/warning, and RestartPolicy
  matched the real code exactly, with no drift between what's
  documented and what's implemented.

## Nothing left unverified

Same as Days 2-7: no "test it on your machine" caveat. Run
nova-day9-build_and_run.sh yourself to reproduce this exact result.

## M4 status

Days 2-9 of M4 (Core OS) are now complete: Process, Memory,
Filesystem, Device, Service, Logging, Configuration, and the unifying
Core API -- each with a real, independently-verified package. Per
Table 0, M4 spans Days 2-10 (9 days); Day 10 (not yet built) is
presumably M4's own overall acceptance/integration pass across all
eight subsystems together, per the Guide's structure.
