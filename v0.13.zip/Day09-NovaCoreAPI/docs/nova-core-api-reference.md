# Nova Core API Reference

**Version: 1.0.0** (see `nova_core::API_VERSION`)

This document is the stable, versioned contract for Nova's Core OS
layer (M4, Days 2–8), unified behind the `nova-core` facade crate
(Day 9). Per Section 9.8, this is the contract **M5 (IPC +
Applications)** is required to consume — M5 should depend on
`nova-core`, not on `nova-procmgr`/`nova-memmgr`/etc. directly.

Per Section 4 ("document APIs before creating many consumers"), this
doc is written now, before M5 exists, specifically so a reviewer
unfamiliar with the implementation can write a new M4 consumer from
this document alone — every signature below is copied verbatim from
the real source, not paraphrased or reconstructed from memory.

## Versioning policy

`nova_core::API_VERSION` follows semver. Consumers should pin against
a major version. Within a major version, changes are additive only
(new functions, new optional struct fields) — any change to an
existing function's signature or an enum's existing variants is a
major version bump, never a patch or minor release.

Six areas are covered in this version, matching Day 9's task list
exactly: **processes, memory, files, devices, services, and
logging**. `nova-config` (Day 8) is a real, shipped library but is
**not** part of this v1.0.0 surface — it wasn't one of Day 9's six
named areas. It's a natural candidate for a future `1.1.0`.

---

## 1. Process — `nova_core::process` (re-exports `nova-procmgr`)

A supervising layer over real Linux processes — reads live state from
`/proc`, never a separate tracked estimate.

### Types

```rust
pub enum ProcessState { Running, Sleeping, DiskSleep, Zombie, Stopped, Terminated, Unknown }
pub enum RestartPolicy { Never, OnFailure, Always }

pub struct ProcessInfo {
    pub pid: u32,
    pub ppid: u32,
    pub command: String,
    pub state: ProcessState,
    pub restart_policy: RestartPolicy,
    pub exit_code: Option<i32>,
}

pub enum ProcessEvent {
    Spawned { pid: u32, command: String },
    StateChanged { pid: u32, old: ProcessState, new: ProcessState },
    Terminated { pid: u32, exit_code: Option<i32> },
}
```

### `ProcessManager`

| Function | Signature | Behavior |
|---|---|---|
| `new` | `fn new() -> Self` | Empty manager, no processes tracked. |
| `spawn` | `fn spawn(&mut self, command: &str, args: &[&str], policy: RestartPolicy) -> io::Result<u32>` | Spawns and tracks a real process; returns its PID. |
| `terminate` | `fn terminate(&mut self, pid: u32) -> io::Result<()>` | SIGTERM, waits up to 500ms, escalates to SIGKILL if needed, reaps. |
| `reap_zombies` | `fn reap_zombies(&mut self) -> Vec<u32>` | Non-blocking reap pass; returns PIDs reaped this call. |
| `get` | `fn get(&self, pid: u32) -> Option<ProcessInfo>` | Live query — reads `/proc` fresh each call. |
| `list` | `fn list(&self) -> Vec<ProcessInfo>` | All tracked processes. |
| `events` | `fn events(&self) -> &[ProcessEvent]` | Append-only event history (supplementary to `get`/`list`, which remain the primary query API). |
| `should_restart` | `fn should_restart(&self, pid: u32) -> bool` | True if `Terminated` and policy says restart is warranted. Does **not** act on it — callers (e.g. `nova-svcmgr`) decide whether/when to actually respawn. |
| `tracked_count` | `fn tracked_count(&self) -> usize` | |
| `uptime` | `fn uptime(&self, pid: u32) -> Option<Duration>` | Time since `spawn` was called for this PID. |

### Minimal usage example

```rust
use nova_core::process::{ProcessManager, RestartPolicy};

let mut pm = ProcessManager::new();
let pid = pm.spawn("sleep", &["5"], RestartPolicy::Never)?;
let info = pm.get(pid).unwrap();
assert_eq!(info.ppid, std::process::id());
pm.terminate(pid)?;
```

---

## 2. Memory — `nova_core::memory` (re-exports `nova-memmgr`)

Real per-process memory accounting from `/proc/<pid>/status`, plus a
deterministic allocation-failure boundary via `RLIMIT_AS` — chosen
specifically so allocation failures are clean and immediate
(`ENOMEM`), not dependent on the Linux OOM killer's system-wide,
non-deterministic behavior.

### Types

```rust
pub struct MemoryInfo {
    pub pid: u32,
    pub vsize_bytes: u64, // virtual memory size (VmSize)
    pub rss_bytes: u64,   // resident set size (VmRSS)
}
```

### Functions

| Function | Signature | Behavior |
|---|---|---|
| `query` | `fn query(pid: u32) -> io::Result<MemoryInfo>` | Reads `/proc/<pid>/status`. |
| `query_self` | `fn query_self() -> io::Result<MemoryInfo>` | `query(std::process::id())`. |
| `spawn_with_memory_limit` | `fn spawn_with_memory_limit(command: &str, args: &[&str], limit_bytes: u64) -> io::Result<Child>` | Spawns with a hard `RLIMIT_AS` ceiling, enforced in the child before exec. |

### Minimal usage example

```rust
use nova_core::memory::{query_self, spawn_with_memory_limit};

let own = query_self()?;
println!("using {} KB resident", own.rss_bytes / 1024);

let mut child = spawn_with_memory_limit("some-tool", &[], 20 * 1024 * 1024)?;
let status = child.wait()?; // ENOMEM on overallocation, not SIGSEGV/OOM-kill
```

---

## 3. Filesystem — `nova_core::filesystem` (re-exports `nova-fsmgr`)

Nova's standard directory layout plus file CRUD and real
`mount(2)`/`umount(2)` wrapping — no custom filesystem, per Section 25.

### Standard paths (`nova_core::filesystem::paths`)

| Constant | Value | Purpose |
|---|---|---|
| `SYSTEM` | `/system` | Read-only OS files |
| `DATA` | `/var/lib/nova` | Writable app/user data |
| `APPS` | `/apps` | Installed `.nova` app bundles |
| `CONFIG` | `/etc/nova` | Nova configuration (see `nova-config`, Day 8) |
| `LOG` | `/var/log/nova` | Service logs |
| `RUN` | `/run/nova` | Sockets, pidfiles |
| `TMP` | `/tmp/nova` | Temporary files |
| `ALL` | `&[&str]` | All seven, for bulk creation |

### Functions

| Function | Signature | Behavior |
|---|---|---|
| `ensure_dirs` | `fn ensure_dirs(dirs: &[&str]) -> io::Result<()>` | `mkdir -p` for each path given. |
| `ensure_standard_dirs` | `fn ensure_standard_dirs() -> io::Result<()>` | `ensure_dirs(paths::ALL)`. |
| `create_file` | `fn create_file(path: &Path, contents: &[u8]) -> io::Result<()>` | Errors if the file already exists. |
| `read_file` | `fn read_file(path: &Path) -> io::Result<Vec<u8>>` | |
| `write_file` | `fn write_file(path: &Path, contents: &[u8]) -> io::Result<()>` | **Overwrites.** |
| `append_file` | `fn append_file(path: &Path, contents: &[u8]) -> io::Result<()>` | Creates if missing, **appends** otherwise. Added Day 7 specifically for logging's needs. |
| `delete_file` | `fn delete_file(path: &Path) -> io::Result<()>` | |
| `rename_file` | `fn rename_file(from: &Path, to: &Path) -> io::Result<()>` | |
| `mount` | `fn mount(source: &str, target: &Path, fstype: &str, flags: c_ulong, data: Option<&str>) -> io::Result<()>` | Real `mount(2)`. Requires root. |
| `unmount` | `fn unmount(target: &Path) -> io::Result<()>` | Real `umount(2)`. |

### Minimal usage example

```rust
use nova_core::filesystem::{paths, create_file, mount, unmount};
use std::path::Path;

create_file(Path::new(paths::DATA).join("example.txt").as_path(), b"hello")?;
mount("myfs", Path::new("/mnt/point"), "tmpfs", 0, Some("size=4m"))?;
unmount(Path::new("/mnt/point"))?;
```

---

## 4. Device — `nova_core::device` (re-exports `nova-devmgr`)

One generic `Device` trait every device type conforms to. Deliberately
hardware-agnostic — this is the seam M9 (Hardware Abstraction) and M12
(ARM64 port) plug real drivers into without this module changing.

### Types

```rust
pub enum DeviceType { Display, Input, Storage }
pub enum DeviceStatus { Online, Offline, Error }

pub trait Device: Send {
    fn id(&self) -> &str;
    fn device_type(&self) -> DeviceType;
    fn name(&self) -> &str;
    fn status(&self) -> DeviceStatus;
}

pub struct DeviceInfo {
    pub id: String,
    pub device_type: DeviceType,
    pub name: String,
    pub status: DeviceStatus,
}

pub enum DeviceError { AlreadyRegistered(String), NotFound(String) }
```

### `DeviceManager`

| Function | Signature | Behavior |
|---|---|---|
| `new` | `fn new() -> Self` | |
| `register` | `fn register(&mut self, device: Box<dyn Device>) -> Result<(), DeviceError>` | Errors on duplicate `id()`. |
| `unregister` | `fn unregister(&mut self, id: &str) -> Result<(), DeviceError>` | |
| `list` | `fn list(&self) -> Vec<DeviceInfo>` | Generic query — never the underlying trait object. |
| `list_by_type` | `fn list_by_type(&self, device_type: DeviceType) -> Vec<DeviceInfo>` | |
| `get` | `fn get(&self, id: &str) -> Option<DeviceInfo>` | |
| `count` | `fn count(&self) -> usize` | |

Test/fake implementations (`nova_core::device::fakes`): `FakeDisplay`,
`FakeInput`, `FakeStorage` — for testing consumers without real
hardware.

### Minimal usage example

```rust
use nova_core::device::{DeviceManager, DeviceType};
use nova_core::device::fakes::FakeDisplay;

let mut mgr = DeviceManager::new();
mgr.register(Box::new(FakeDisplay {
    id: "disp0".into(), name: "Test Display".into(), status: nova_core::device::DeviceStatus::Online,
}))?;
let displays = mgr.list_by_type(DeviceType::Display);
```

---

## 5. Service — `nova_core::service` (re-exports `nova-svcmgr`)

Named services on top of `process`: start/stop/restart, dependency
ordering (cycle-detected), and crash/restart policy enforcement via
`tick()` — the actual consumer of `process::RestartPolicy` and
`should_restart`.

### Types

```rust
pub struct ServiceDef {
    pub name: String,
    pub command: String,
    pub args: Vec<String>,
    pub restart_policy: RestartPolicy, // from nova_core::process
    pub depends_on: Vec<String>,
    pub max_restarts: u32, // safety cap against restart-looping
}

pub enum ServiceStatus { NotStarted, Running, Stopped, Failed }
pub enum ServiceError { NotRegistered(String), NotRunning(String), CircularDependency(String), SpawnFailed(String, String) }
```

### `ServiceManager`

| Function | Signature | Behavior |
|---|---|---|
| `new` | `fn new() -> Self` | |
| `register` | `fn register(&mut self, def: ServiceDef)` | Declares without starting. |
| `start` | `fn start(&mut self, name: &str) -> Result<u32, ServiceError>` | Recursively starts unstarted dependencies first; cycle-safe. |
| `stop` | `fn stop(&mut self, name: &str) -> Result<(), ServiceError>` | |
| `restart` | `fn restart(&mut self, name: &str) -> Result<u32, ServiceError>` | |
| `status` | `fn status(&mut self, name: &str) -> ServiceStatus` | |
| `tick` | `fn tick(&mut self) -> Vec<String>` | **The supervision loop.** Reaps exited processes; for any that should restart per policy and haven't hit `max_restarts`, respawns them. Returns names auto-restarted this call. Call this periodically (e.g. from an event loop or timer) — it does not run itself. |
| `restart_count` | `fn restart_count(&self, name: &str) -> u32` | |

### Minimal usage example

```rust
use nova_core::service::{ServiceManager, ServiceDef};
use nova_core::process::RestartPolicy;

let mut mgr = ServiceManager::new();
mgr.register(ServiceDef {
    name: "my-service".into(), command: "my-binary".into(), args: vec![],
    restart_policy: RestartPolicy::OnFailure, depends_on: vec![], max_restarts: 5,
});
mgr.start("my-service")?;
// ... periodically:
let restarted = mgr.tick();
```

---

## 6. Logging — `nova_core::logging` (re-exports `nova-log`)

Structured (not free-text) log entries, persisted through `filesystem`
(never a bespoke log-writing path), queryable/filterable after the
fact.

### Types

```rust
pub enum LogLevel { Debug, Info, Warning, Error, Critical } // Ord: Debug < ... < Critical
pub struct LogEntry { pub timestamp_secs: u64, pub level: LogLevel, pub source: String, pub message: String }
```

### `Logger`

| Function | Signature | Behavior |
|---|---|---|
| `new` | `fn new() -> Self` | In-memory only. |
| `with_persistence` | `fn with_persistence(path: PathBuf) -> Self` | Every `log()` call also appends (via `filesystem::append_file`) to `path`. |
| `log` / `debug` / `info` / `warning` / `error` / `critical` | `fn log(&mut self, level: LogLevel, source: &str, message: &str)` (+ per-level convenience wrappers) | Best-effort persistence — a write failure never panics the caller. |
| `all` | `fn all(&self) -> &[LogEntry]` | |
| `filter_by_level` | `fn filter_by_level(&self, min_level: LogLevel) -> Vec<&LogEntry>` | Entries at or above `min_level`. |
| `filter_by_source` | `fn filter_by_source(&self, source: &str) -> Vec<&LogEntry>` | |

### Free function

| Function | Signature | Behavior |
|---|---|---|
| `load_from_file` | `fn load_from_file(path: &Path) -> io::Result<Vec<LogEntry>>` | Reads a persisted log back into structured entries. |

### Minimal usage example

```rust
use nova_core::logging::{Logger, LogLevel, load_from_file};
use std::path::PathBuf;

let mut logger = Logger::with_persistence(PathBuf::from("/var/log/nova/my-service.log"));
logger.info("my-service", "started successfully");
logger.warning("my-service", "config value missing, using default");

let warnings = logger.filter_by_level(LogLevel::Warning);
let history = load_from_file(&PathBuf::from("/var/log/nova/my-service.log"))?;
```

---

## Writing a new M4/M5 consumer from this doc alone

A worked example: a hypothetical new service that spawns a worker
process, logs its lifecycle, and is supervised with automatic restart
— using nothing but `nova-core` and the tables above:

```rust
use nova_core::process::RestartPolicy;
use nova_core::service::{ServiceManager, ServiceDef};
use nova_core::logging::Logger;
use nova_core::filesystem::paths;
use std::path::PathBuf;

let mut logger = Logger::with_persistence(PathBuf::from(paths::LOG).join("my-worker.log"));
let mut services = ServiceManager::new();

services.register(ServiceDef {
    name: "my-worker".into(),
    command: "/apps/my-worker/bin/my-worker".into(),
    args: vec![],
    restart_policy: RestartPolicy::OnFailure,
    depends_on: vec![],
    max_restarts: 5,
});

logger.info("my-worker-supervisor", "starting my-worker");
services.start("my-worker").expect("failed to start my-worker");

// In a real event loop, called periodically:
loop {
    let restarted = services.tick();
    for name in restarted {
        logger.warning("my-worker-supervisor", &format!("{name} crashed and was restarted"));
    }
    std::thread::sleep(std::time::Duration::from_secs(1));
}
```

Nothing above required reading `nova-procmgr`, `nova-svcmgr`, or
`nova-log`'s source — every type and function used is documented in
Sections 1, 5, and 6 above.
