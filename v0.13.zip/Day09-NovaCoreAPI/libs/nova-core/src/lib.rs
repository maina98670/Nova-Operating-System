//! Nova Core API — M4 Day 9.
//!
//! The single, stable, version-tagged crate M5 (IPC + Applications)
//! is required to depend on, per Section 9.8 — one dependency instead
//! of six. Each of Day 9's six named areas ("processes, memory,
//! files, devices, services, and logging") gets its own namespaced
//! module here, re-exporting the real implementation crate (Days
//! 2-7) unchanged. This file adds no new logic of its own — Day 9's
//! actual work is the unification and the reference doc
//! (`docs/nova-core-api-reference.md`), not new runtime behavior.
//!
//! **Honest scope note**: `nova-config` (Day 8) is deliberately *not*
//! included in this v1.0.0 surface — Day 9's task list names exactly
//! six areas ("processes, memory, files, devices, services, and
//! logging"), and configuration isn't one of them. Adding it would be
//! scope creep beyond what Day 9 actually asked for; it's a natural
//! candidate for a future minor version (e.g. 1.1.0) instead.
//!
//! # Versioning
//! [`API_VERSION`] follows semver. M5 and any other consumer should
//! pin against a major version and expect additive-only changes
//! (new functions, new optional fields) within it — a breaking change
//! to any signature documented in the reference doc is a major
//! version bump, not a patch.

pub const API_VERSION: &str = "1.0.0";

/// Process management — spawn, track, terminate, and query Linux
/// processes. Re-exports `nova-procmgr` (Day 2) unchanged.
pub mod process {
    pub use nova_procmgr::*;
}

/// Per-process memory accounting and the `RLIMIT_AS`-based allocation
/// isolation boundary. Re-exports `nova-memmgr` (Day 3) unchanged.
pub mod memory {
    pub use nova_memmgr::*;
}

/// Standard directory layout, file CRUD, and real mount/unmount.
/// Re-exports `nova-fsmgr` (Day 4) unchanged.
pub mod filesystem {
    pub use nova_fsmgr::*;
}

/// The generic `Device` trait and registry every display/input/
/// storage device type conforms to. Re-exports `nova-devmgr`
/// (Day 5) unchanged.
pub mod device {
    pub use nova_devmgr::*;
}

/// Named services on top of processes: start/stop/restart,
/// dependency ordering, and crash/restart policy enforcement.
/// Re-exports `nova-svcmgr` (Day 6) unchanged.
pub mod service {
    pub use nova_svcmgr::*;
}

/// Structured, level-filtered, persisted logging. Re-exports
/// `nova-log` (Day 7) unchanged.
pub mod logging {
    pub use nova_log::*;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn api_version_is_set_and_well_formed() {
        assert_eq!(API_VERSION, "1.0.0");
        assert_eq!(API_VERSION.split('.').count(), 3, "API_VERSION should be a three-part semver string");
    }

    /// Not a re-test of Days 2-7's own logic (that's their own test
    /// suites' job) — this just proves the facade's re-exports are
    /// real and usable, one item from each of the six namespaces,
    /// through `nova_core::` paths rather than the underlying crates
    /// directly.
    #[test]
    fn facade_reexports_are_usable_from_every_namespace() {
        let mut proc_mgr = process::ProcessManager::new();
        assert_eq!(proc_mgr.tracked_count(), 0);

        let mem_info = memory::query_self();
        assert!(mem_info.is_ok());

        assert!(filesystem::paths::CONFIG.starts_with('/'));

        let dev_mgr = device::DeviceManager::new();
        assert_eq!(dev_mgr.count(), 0);

        let mut svc_mgr = service::ServiceManager::new();
        // No assertion beyond "this type exists and constructs" --
        // svcmgr's own test suite covers behavior; this just proves
        // the re-export compiles and the type is real.
        let _ = svc_mgr.status("nonexistent");

        let mut logger = logging::Logger::new();
        logger.info("nova-core-test", "facade re-export smoke test");
        assert_eq!(logger.all().len(), 1);

        // Also touch the process manager we created above, so it's
        // not an unused binding.
        let _ = proc_mgr.list();
    }
}
