#!/bin/bash
# Nova OS — Day 9: Nova Core API (M4, final day per the Complete Build Guide)
# Unification + documentation day, not primarily new runtime logic.
# No root, no cross-compilation, no QEMU needed.
set -e

echo "=== Nova OS Day 9: Nova Core API ==="

echo "[1/2] Running nova-core facade tests (2 tests, proves the re-exports are real and usable)..."
cargo test -p nova-core

echo "[2/2] Building and running the API reference doc's own worked example..."
cargo build -p nova-core-doc-example
./target/debug/nova-core-doc-example

echo ""
echo "The full API reference is at docs/nova-core-api-reference.md."
