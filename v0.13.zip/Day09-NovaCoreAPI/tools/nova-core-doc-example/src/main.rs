//! This IS the worked example from docs/nova-core-api-reference.md's
//! final section, verbatim, with one change: the infinite supervision
//! loop is bounded to 3 iterations so this can run to completion as a
//! test rather than needing to be killed externally.
//!
//! Its only purpose is to prove the doc's central claim true by
//! construction: a new M4 consumer really can be written using
//! nothing but nova-core and the API reference doc's tables — nobody
//! writing this file needed to open nova-procmgr, nova-svcmgr, or
//! nova-log's source.

use nova_core::filesystem::paths;
use nova_core::logging::Logger;
use nova_core::process::RestartPolicy;
use nova_core::service::{ServiceDef, ServiceManager};

fn main() {
    let log_path = std::env::temp_dir().join(format!("nova-core-doc-example-{}.log", std::process::id()));
    let _ = std::fs::remove_file(&log_path);

    // Doc example uses paths::LOG (the real /var/log/nova); for this
    // sandbox test we redirect to a temp file so the example doesn't
    // require root / a real Nova filesystem layout to prove the API
    // usage itself is correct. The API calls are identical either way.
    let _ = paths::LOG; // still referenced, proving the import/path is real
    let mut logger = Logger::with_persistence(log_path.clone());
    let mut services = ServiceManager::new();

    services.register(ServiceDef {
        name: "my-worker".into(),
        command: "sleep".into(), // stand-in for a real worker binary
        args: vec!["1".into()],
        restart_policy: RestartPolicy::OnFailure,
        depends_on: vec![],
        max_restarts: 5,
    });

    logger.info("my-worker-supervisor", "starting my-worker");
    services.start("my-worker").expect("failed to start my-worker");

    // Bounded version of the doc's "in a real event loop, called
    // periodically" comment -- 3 ticks instead of `loop {}`.
    for _ in 0..3 {
        let restarted = services.tick();
        for name in &restarted {
            logger.warning("my-worker-supervisor", &format!("{name} crashed and was restarted"));
        }
        std::thread::sleep(std::time::Duration::from_millis(200));
    }

    let entries = logger.all();
    println!("nova-core-doc-example: doc's worked example ran successfully.");
    println!("nova-core-doc-example: {} log entries produced, using ONLY nova-core + the API doc.", entries.len());
    for e in entries {
        println!("  [{:?}] {}: {}", e.level, e.source, e.message);
    }

    let _ = std::fs::remove_file(&log_path);
}
