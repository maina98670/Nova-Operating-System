# Nova OS — Day 10 Package: M4 Integration, Console, Acceptance Tests, Tag

Per the Complete Build Guide, Day 10 is M4's closing day: wire all
seven (really eight, counting Configuration and the Nova API layer)
subsystems together into one boot sequence with the exact Section 9.9
console output, run the full Section 9.10 acceptance list end to end,
write the remaining documentation, and tag the release.

**This package was delivered as files only — nothing was built, run,
or tested in the environment that produced it, per instruction.**
Every signature used in `nova-init` was cross-checked against the real
Day 2-9 source immediately before writing it, but that is not the same
guarantee as a passing `cargo build`. Treat this as a strong first
draft, not a verified milestone.

## What's in this package

- **system/nova-init** — the real integration point. A single Rust
  binary that runs the Section 9.9 boot sequence (`[ OK ]` lines for
  Kernel, Nova Init, Logging, Filesystem, Configuration, Memory
  Manager, Process Manager, Device Manager, Service Manager, Nova
  API) and then drops to an interactive `nova#` console. This
  supersedes M2's original C placeholder init — the mounting
  responsibility that program had is still real and still needed
  first in the real boot chain, but everything after it is now this
  binary, matching Section 1's original intent that Nova Init be
  Rust.
- **libs/** — all eight M4 libraries (`nova-procmgr` through
  `nova-core`), included as dependencies since `nova-init` depends on
  the whole stack.
- **docs/nova-core-api-reference.md** — Day 9's doc, carried forward.
- **docs/nova-m4-boot-runtime-overview.md** — the new Day 10 doc: what
  each boot step does, and a table mapping every `nova#` console
  command directly to one item on Section 9.10's acceptance list.
- **scripts/nova-m4-acceptance-test.sh** — pipes the full Section 9.10
  command sequence into a built `nova-init` binary and checks the
  output against expected strings. **Written, not run** — see below.

## The console *is* the acceptance list

Every command on the `nova#` console maps to exactly one Section 9.10
item — this isn't a coincidence, `nova-init` was designed so the
acceptance list is directly executable, not just satisfiable some
other way:

| Console command | Section 9.10 item |
|---|---|
| reaching `nova#` at all | "boot to `nova#`" |
| `ps` | "list processes" |
| `svc start test-echo` / `svc stop test-echo` | "start/stop a test service" |
| `fs write demo.txt ...` / `fs read demo.txt` | "read/write a test file" |
| `mem` | "show memory statistics" |
| `dev list` / `dev register <id>` | "register a test device" |
| `log` / `log info <msg>` | "produce structured logs" |
| `svc crash-test` | "recover from a deliberately failed test service" |

A real known gap, flagged honestly in the code: **Day 9's `nova-core`
facade deliberately excluded `nova-config`** from its v1.0.0 surface
(it wasn't one of Day 9's six named areas). Day 10's boot sequence
needs a `[ OK ] Configuration` line, so `nova-init` depends on
`nova-config` directly, bypassing the facade for this one case — noted
in `nova-init`'s own source comments as exactly the kind of real
consumer need that would motivate a future `nova-core` 1.1.0.

## What genuinely has NOT been done in this delivery

- `nova-init` has not been compiled. There is a real, non-trivial
  chance it has at least one type error or borrow-checker issue —
  this is meaningfully more code in one file than any single prior
  day produced, and Days 2-9's pattern of "write code, then let
  `cargo check` catch 2-6 real bugs before it's clean" should be
  expected to apply here too.
- The acceptance test script has not been run.
- This has not been wired into the actual M0-M3 kernel boot chain —
  `nova-init` currently only runs as a standalone binary you can test
  directly (`cargo run -p nova-init`), not yet as PID 1 exec'd by the
  kernel after M1's framebuffer stage. That wiring is real, separate
  work.
- The git tag has not been created — the exact command is in
  `docs/nova-m4-boot-runtime-overview.md`'s final section, to run
  yourself once the acceptance script above is confirmed green.

## Recommended next steps, in order

1. `cargo build -p nova-init` in this package's workspace — fix
   whatever `cargo check` finds, the same way every prior day did.
2. `cargo run -p nova-init`, manually try a few console commands,
   confirm the boot sequence and console behave as described.
3. Run `scripts/nova-m4-acceptance-test.sh ./target/debug/nova-init`
   and fix anything it reports.
4. Only once that script reports zero failures, run the `git tag`
   command from the boot/runtime overview doc — per Section 24 ("start
   the next milestone only after acceptance"), this is the actual,
   non-negotiable gate before M5 begins.
