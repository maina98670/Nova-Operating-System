# Nova OS — M4 Boot & Runtime Overview

Companion to docs/nova-core-api-reference.md (Day 9). That document
describes the API surface; this one describes what actually happens
when Nova Init runs, and how to drive it from the console -- the two
together are Day 10's "write M4's documentation" task.

## Boot sequence (Section 9.9)

system/nova-init runs after the kernel (M0/M1) has already booted
successfully. It initializes eight things, in order, printing one
[ OK ] line per step (or [FAIL] and a hard stop, never a silent
partial boot):

1. Kernel -- acknowledged, not re-checked (if the kernel hadn't
   booted, this binary would never be running).
2. Nova Init -- this process itself is now running.
3. Logging -- nova-log's Logger, persisted at
   /var/log/nova/nova-init.log. Initialized early, deliberately,
   so every later step can log through it.
4. Filesystem -- nova-fsmgr::ensure_standard_dirs() creates the
   full standard layout (/system, /var/lib/nova, /apps,
   /etc/nova, /var/log/nova, /run/nova, /tmp/nova).
5. Configuration -- loads /etc/nova/nova-init.toml via
   nova-config. Missing file means defaults (not a failure).
   Malformed file means a hard boot failure, per Day 8's own
   principle applied at the whole-system level.
6. Memory Manager -- a self-check via nova-memmgr::query_self().
7. Process Manager -- nova-procmgr::ProcessManager constructed.
8. Device Manager -- nova-devmgr::DeviceManager constructed, with
   two fake devices pre-registered (an input device and a storage
   device -- matching Day 5's fakes-first approach; real drivers are
   M9/M12's job, not M4's).
9. Service Manager -- nova-svcmgr::ServiceManager constructed,
   with two test services registered but not started:
   test-echo (a harmless sleep 30) and test-crasher (false,
   which always exits with failure -- exists specifically so the
   console can exercise Section 9.10's crash-recovery requirement).
10. Nova API -- confirms nova-core::API_VERSION (currently
    1.0.0) loaded correctly.

Boot then prints the configured MOTD and drops to the nova# console.

## The nova# console

Every command maps directly to one item on Section 9.10's acceptance
list -- the console isn't a separate feature that happens to satisfy
the list, it IS the list, made interactive:

- ps -> "list processes": reaps zombies, then lists every tracked
  process (PID, PPID, state, command).
- svc start <name> -> "start ... a test service": starts a registered
  service (dependencies resolved automatically). Try
  "svc start test-echo".
- svc stop <name> -> "... stop a test service": stops it.
- svc crash-test -> "recover from a deliberately failed test
  service": starts test-crasher, waits briefly, runs one supervision
  tick, and reports whether the crash/restart policy fired.
- svc tick -> (supporting crash-test): manually runs one
  supervision-loop pass, in case a second tick is needed.
- fs write <name> [text] -> "read/write a test file": writes into
  /var/lib/nova/<name>.
- fs read <name> -> "read/write a test file": reads it back.
- mem -> "show memory statistics": prints this process's own live
  VmSize/VmRSS.
- dev list -> "register a test device": lists all registered devices
  (the two boot-time fakes, plus any registered via dev register).
- dev register [id] -> "register a test device": registers a new
  fake storage device with the given ID (or console-device0 by
  default).
- log -> "produce structured logs": prints every log entry recorded
  since boot, structured (timestamp, level, source, message), not
  scrolling free text.
- log info <message> -> "produce structured logs": logs a new entry
  at INFO level, then confirms it.
- help: lists all commands.
- exit / quit: leaves the console.

## Running the full Section 9.10 acceptance pass

scripts/nova-m4-acceptance-test.sh pipes exactly the sequence below
into the console and checks for expected output. Manually, from the
nova# prompt:

    ps
    svc start test-echo
    ps
    svc stop test-echo
    fs write demo.txt hello from the acceptance test
    fs read demo.txt
    mem
    dev list
    dev register acceptance-test-device
    dev list
    log info acceptance test checkpoint
    log
    svc crash-test
    exit

## Tagging the M4 release

Per Day 10's task list, once the acceptance pass above is confirmed
green in a real boot (not yet done in this delivery -- see the
package README), tag the milestone in git:

    git add -A
    git commit -m "M4: Core OS complete (Days 2-10)"
    git tag -a m4-core-complete -m "M4 Core OS: Process, Memory, Filesystem, Device, Service, Logging, Configuration, Nova Core API, integration and acceptance console. Section 9.10 acceptance list implemented as nova# console commands."
    git push --tags

Note on the tag name: this Guide's M0-M17 milestone numbering is a
separate system from the earlier Nova-OS-Guide.docx's Nova-0.x
semantic versioning (Section 15 of that document) -- the two were
never reconciled into one scheme. m4-core-complete is used here as a
milestone-scoped git tag rather than guessing at a Nova-0.x version
number that would conflate the two systems; decide the real product
version string separately, deliberately, rather than let a tag name
default one.
