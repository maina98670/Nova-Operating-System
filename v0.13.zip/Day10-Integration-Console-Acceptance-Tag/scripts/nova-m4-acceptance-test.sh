#!/bin/bash
# Nova OS -- M4 Acceptance Test (Section 9.10), Day 10
#
# Pipes every item on Section 9.10's acceptance list into nova-init's
# nova# console and checks the output for the expected confirmation
# text. This script was WRITTEN but NOT RUN as part of this delivery
# (Day 10 was delivered as files only, per instruction) -- run it
# yourself against a real built nova-init binary before trusting it.
#
# Usage: ./nova-m4-acceptance-test.sh /path/to/nova-init

set -uo pipefail

NOVA_INIT_BIN="${1:-./target/debug/nova-init}"
FAILURES=0

check() {
    local description="$1"
    local expected_substring="$2"
    local output="$3"
    if echo "$output" | grep -qF "$expected_substring"; then
        echo "  [PASS] $description"
    else
        echo "  [FAIL] $description -- expected to find: $expected_substring"
        FAILURES=$((FAILURES + 1))
    fi
}

echo "=== Nova OS M4 Acceptance Test (Section 9.10) ==="
echo "Target binary: $NOVA_INIT_BIN"
echo ""

if [ ! -x "$NOVA_INIT_BIN" ]; then
    echo "FATAL: $NOVA_INIT_BIN not found or not executable."
    echo "Build it first: cargo build -p nova-init"
    exit 1
fi

COMMANDS="ps
svc start test-echo
ps
svc stop test-echo
fs write demo.txt hello from the acceptance test
fs read demo.txt
mem
dev list
dev register acceptance-test-device
dev list
log info acceptance test checkpoint
log
svc crash-test
exit"

OUTPUT=$(echo "$COMMANDS" | "$NOVA_INIT_BIN" 2>&1)

echo "--- Boot sequence (Section 9.9) ---"
for line in "Kernel" "Nova Init" "Logging" "Filesystem" "Configuration" \
            "Memory Manager" "Process Manager" "Device Manager" \
            "Service Manager" "Nova API"; do
    check "[ OK ] $line printed" "[ OK ] $line" "$OUTPUT"
done

echo ""
echo "--- Section 9.10 acceptance items ---"
check "reached nova# prompt"                            "nova#"                          "$OUTPUT"
check "list processes (test-echo appears after start)"  "sleep"                          "$OUTPUT"
check "start a test service"                             "started test-echo"             "$OUTPUT"
check "stop a test service"                               "stopped test-echo"            "$OUTPUT"
check "write a test file"                                 "wrote"                        "$OUTPUT"
check "read a test file back correctly"                   "hello from the acceptance test" "$OUTPUT"
check "show memory statistics"                             "rss="                        "$OUTPUT"
check "register a test device"                             "registered device acceptance-test-device" "$OUTPUT"
check "device list shows registered device"                "acceptance-test-device"      "$OUTPUT"
check "produce structured logs (manual entry)"              "logged: acceptance test checkpoint" "$OUTPUT"
check "structured log query shows entries"                  "nova-init"                  "$OUTPUT"
check "recover from a deliberately failed test service"     "recovered: test-crasher"    "$OUTPUT"

echo ""
if [ "$FAILURES" -eq 0 ]; then
    echo "=== ALL CHECKS PASSED -- Section 9.10 acceptance list satisfied ==="
    exit 0
else
    echo "=== $FAILURES CHECK(S) FAILED -- do not tag the M4 release until these pass ==="
    echo ""
    echo "Full output for debugging:"
    echo "$OUTPUT"
    exit 1
fi
