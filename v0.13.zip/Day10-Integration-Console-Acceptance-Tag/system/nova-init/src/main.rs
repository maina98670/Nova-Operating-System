//! Nova Init — M4 integration (Day 10).
//!
//! Wires all seven M4 subsystems (plus Configuration, plus the Nova
//! Core API layer itself) together behind `nova-core` (Day 9), in the
//! exact order and with the exact `[ OK ]` console output Section 9.9
//! specifies, then drops to an interactive `nova#` console. Every
//! command on that console maps directly to one item on Section
//! 9.10's acceptance list — this file *is* the acceptance list, made
//! runnable, not a separate thing that merely satisfies it.
//!
//! This supersedes M2's original placeholder init (a small C program
//! that mounted `/proc`/`/sys`/`/dev` and drew the boot splash) — that
//! program's core mounting responsibility is still real and still
//! needed at the very start of boot, but everything after it is now
//! this Rust binary, matching Section 1's original architecture intent
//! that Nova Init be Rust, not a permanent C placeholder.
//!
//! # Honest scope
//! This file was written without being compiled or run in the
//! sandbox that produced it (by request — Day 10 was delivered as
//! files only). Every function signature used below was re-confirmed
//! against the real Day 2-9 source immediately before writing this,
//! but that is not the same guarantee as an actual `cargo build`
//! passing. Build and run this yourself before trusting it further —
//! see `scripts/nova-m4-acceptance-test.sh` for the check to run once
//! you do.

use nova_config::{config_path_for, load_or_default, ConfigError};
use nova_core::device::fakes::{FakeInput, FakeStorage};
use nova_core::device::{DeviceManager, DeviceStatus};
use nova_core::filesystem::{self, paths};
use nova_core::logging::{LogLevel, Logger};
use nova_core::process::{ProcessManager, RestartPolicy};
use nova_core::service::{ServiceDef, ServiceManager};
use serde::Deserialize;
use std::io::{self, BufRead, Write};
use std::path::PathBuf;

const SOURCE: &str = "nova-init";

#[derive(Debug, Deserialize, Default)]
struct InitConfig {
    #[serde(default = "default_motd")]
    motd: String,
}
fn default_motd() -> String {
    "Nova OS -- M4 Core complete".to_string()
}

fn ok(line: &str) {
    println!("[ OK ] {line}");
}

fn fail_boot(line: &str, detail: &str) -> ! {
    println!("[FAIL] {line}: {detail}");
    eprintln!("nova-init: boot cannot continue, exiting");
    std::process::exit(1);
}

struct Boot {
    logger: Logger,
    processes: ProcessManager,
    devices: DeviceManager,
    services: ServiceManager,
}

/// Runs the exact Section 9.9 boot sequence. Each subsystem is
/// initialized in order; a hard failure at any step prints `[FAIL]`
/// and stops rather than continuing on a partially-initialized
/// system — the same "fail loudly, never silently misconfigure"
/// principle Day 8 established for configuration specifically now
/// applies to the whole boot sequence.
fn boot_sequence() -> Boot {
    // Kernel: by the time this process is running at all, the kernel
    // (M0/M1) has already succeeded -- this line acknowledges that,
    // it doesn't re-verify it (there is nothing left to check from
    // userspace; a failed kernel boot means this binary never runs).
    ok("Kernel");
    ok("Nova Init");

    // Logging first, deliberately, so every subsequent step can log
    // through it (Day 7's retrofit principle, applied here at the
    // earliest possible point in the whole system's life instead of
    // per-service).
    let log_path = PathBuf::from(paths::LOG).join("nova-init.log");
    if let Err(e) = filesystem::ensure_dirs(&[paths::LOG]) {
        fail_boot("Logging", &format!("could not create {}: {e}", paths::LOG));
    }
    let mut logger = Logger::with_persistence(log_path);
    logger.info(SOURCE, "logging initialized");
    ok("Logging");

    // Filesystem: the full standard layout, not just the log dir.
    match filesystem::ensure_standard_dirs() {
        Ok(()) => {
            logger.info(SOURCE, "standard directory layout ensured");
            ok("Filesystem");
        }
        Err(e) => {
            logger.critical(SOURCE, &format!("could not ensure standard dirs: {e}"));
            fail_boot("Filesystem", &e.to_string());
        }
    }

    // Configuration: missing file -> defaults (not a failure); a
    // malformed file is a hard boot failure, per Day 8's own
    // principle applied here at the system level, not just one
    // service's.
    let cfg_path = config_path_for("nova-init");
    let cfg: InitConfig = match load_or_default(&cfg_path) {
        Ok(cfg) => cfg,
        Err(ConfigError::Parse { path, source }) => {
            logger.critical(SOURCE, &format!("malformed config at {}: {source}", path.display()));
            fail_boot("Configuration", &format!("malformed config at {}", path.display()));
        }
        Err(e) => {
            logger.critical(SOURCE, &format!("config I/O error: {e}"));
            fail_boot("Configuration", &e.to_string());
        }
    };
    logger.info(SOURCE, &format!("configuration loaded (motd={:?})", cfg.motd));
    ok("Configuration");

    // Memory Manager: confirm the query path itself works before
    // declaring the subsystem OK -- an early, cheap self-check.
    match nova_core::memory::query_self() {
        Ok(info) => {
            logger.info(SOURCE, &format!("memory manager online, self rss={}KB", info.rss_bytes / 1024));
            ok("Memory Manager");
        }
        Err(e) => {
            logger.critical(SOURCE, &format!("memory manager self-check failed: {e}"));
            fail_boot("Memory Manager", &e.to_string());
        }
    }

    // Process Manager.
    let processes = ProcessManager::new();
    logger.info(SOURCE, "process manager online");
    ok("Process Manager");

    // Device Manager: register a couple of fake devices so `dev list`
    // has something real to show on the console later -- matching
    // Day 5's own DoD approach (fakes are the correct thing to
    // register at this stage; real drivers are M9/M12's job).
    let mut devices = DeviceManager::new();
    let _ = devices.register(Box::new(FakeInput {
        id: "input0".into(),
        name: "Boot-time Fake Touchscreen".into(),
        status: DeviceStatus::Online,
    }));
    let _ = devices.register(Box::new(FakeStorage {
        id: "storage0".into(),
        name: "Boot-time Fake eMMC".into(),
        status: DeviceStatus::Online,
    }));
    logger.info(SOURCE, &format!("device manager online, {} device(s) registered", devices.count()));
    ok("Device Manager");

    // Service Manager: register (but do not start) a couple of test
    // services the nova# console's `svc` commands can exercise --
    // this is what makes Section 9.10's "start/stop a test service"
    // and "recover from a deliberately failed test service" possible
    // to actually run from the console, not just described.
    let mut services = ServiceManager::new();
    services.register(ServiceDef {
        name: "test-echo".into(),
        command: "sleep".into(),
        args: vec!["30".into()],
        restart_policy: RestartPolicy::Never,
        depends_on: vec![],
        max_restarts: 0,
    });
    services.register(ServiceDef {
        name: "test-crasher".into(),
        command: "false".into(),
        args: vec![],
        restart_policy: RestartPolicy::OnFailure,
        depends_on: vec![],
        max_restarts: 3,
    });
    logger.info(SOURCE, "service manager online, test-echo and test-crasher registered");
    ok("Service Manager");

    // Nova API: this is really just confirming nova-core itself
    // loaded and its version is what's expected -- by the time we're
    // this far into boot it trivially has, but the line exists per
    // Section 9.9's spec regardless.
    logger.info(SOURCE, &format!("nova-core API version {}", nova_core::API_VERSION));
    ok("Nova API");

    println!();
    println!("{}", cfg.motd);
    println!();

    Boot { logger, processes, devices, services }
}

/// The `nova#` console. Every command here is a direct, literal
/// mapping to one item on Section 9.10's acceptance list -- see the
/// comment above each match arm.
fn run_console(mut boot: Boot) {
    let stdin = io::stdin();
    loop {
        print!("nova# ");
        io::stdout().flush().ok();

        let mut line = String::new();
        if stdin.lock().read_line(&mut line).unwrap_or(0) == 0 {
            break; // EOF
        }
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let mut parts = line.split_whitespace();
        let cmd = parts.next().unwrap_or("");

        match cmd {
            // Section 9.10: "list processes"
            "ps" => {
                boot.processes.reap_zombies();
                for info in boot.processes.list() {
                    println!(
                        "{}\t{}\t{:?}\t{}",
                        info.pid, info.ppid, info.state, info.command
                    );
                }
                // Service-managed processes (svc start ...) live inside
                // ServiceManager's own internal ProcessManager, not
                // boot.processes -- list those too so `ps` reflects
                // reality.
                for info in boot.services.processes().list() {
                    println!(
                        "{}\t{}\t{:?}\t{}",
                        info.pid, info.ppid, info.state, info.command
                    );
                }
            }

            // Section 9.10: "start/stop a test service"
            "svc" => match parts.next() {
                Some("start") => {
                    let name = parts.next().unwrap_or("test-echo");
                    match boot.services.start(name) {
                        Ok(pid) => {
                            println!("started {name} (pid {pid})");
                            boot.logger.info(SOURCE, &format!("console: started service {name}"));
                        }
                        Err(e) => println!("error: {e}"),
                    }
                }
                Some("stop") => {
                    let name = parts.next().unwrap_or("test-echo");
                    match boot.services.stop(name) {
                        Ok(()) => {
                            println!("stopped {name}");
                            boot.logger.info(SOURCE, &format!("console: stopped service {name}"));
                        }
                        Err(e) => println!("error: {e}"),
                    }
                }
                // Section 9.10: "recover from a deliberately failed
                // test service" -- starts test-crasher (always exits
                // with failure) and ticks the supervision loop until
                // it observes an auto-restart.
                Some("crash-test") => {
                    println!("starting test-crasher (a service that always fails)...");
                    if let Err(e) = boot.services.start("test-crasher") {
                        println!("error starting test-crasher: {e}");
                        continue;
                    }
                    std::thread::sleep(std::time::Duration::from_millis(200));
                    let restarted = boot.services.tick();
                    if restarted.contains(&"test-crasher".to_string()) {
                        println!("recovered: test-crasher crashed and was auto-restarted by policy");
                        boot.logger.warning(SOURCE, "console: test-crasher crashed and was auto-restarted");
                    } else {
                        println!("no restart observed this tick -- try 'svc crash-test' again or 'svc tick'");
                    }
                }
                Some("tick") => {
                    let restarted = boot.services.tick();
                    println!("tick: restarted {restarted:?}");
                }
                _ => println!("usage: svc start|stop|crash-test|tick <name>"),
            },

            // Section 9.10: "read/write a test file"
            "fs" => match parts.next() {
                Some("write") => {
                    let name = parts.next().unwrap_or("test.txt");
                    let text: String = parts.collect::<Vec<_>>().join(" ");
                    let path = PathBuf::from(paths::DATA).join(name);
                    match filesystem::write_file(&path, text.as_bytes()) {
                        Ok(()) => println!("wrote {} bytes to {}", text.len(), path.display()),
                        Err(e) => println!("error: {e}"),
                    }
                }
                Some("read") => {
                    let name = parts.next().unwrap_or("test.txt");
                    let path = PathBuf::from(paths::DATA).join(name);
                    match filesystem::read_file(&path) {
                        Ok(bytes) => println!("{}", String::from_utf8_lossy(&bytes)),
                        Err(e) => println!("error: {e}"),
                    }
                }
                _ => println!("usage: fs write|read <name> [text...]"),
            },

            // Section 9.10: "show memory statistics"
            "mem" => match nova_core::memory::query_self() {
                Ok(info) => println!(
                    "self: pid={} vsize={}KB rss={}KB",
                    info.pid,
                    info.vsize_bytes / 1024,
                    info.rss_bytes / 1024
                ),
                Err(e) => println!("error: {e}"),
            },

            // Section 9.10: "register a test device"
            "dev" => match parts.next() {
                Some("list") => {
                    for info in boot.devices.list() {
                        println!("{}\t{}\t{}\t{:?}", info.id, info.device_type, info.name, info.status);
                    }
                }
                Some("register") => {
                    let id = parts.next().unwrap_or("console-device0").to_string();
                    let dev = Box::new(FakeStorage {
                        id: id.clone(),
                        name: "Console-registered test device".into(),
                        status: DeviceStatus::Online,
                    });
                    match boot.devices.register(dev) {
                        Ok(()) => println!("registered device {id}"),
                        Err(e) => println!("error: {e}"),
                    }
                }
                _ => println!("usage: dev list|register [id]"),
            },

            // Section 9.10: "produce structured logs" -- both a
            // manual log command and a query/filter over what's
            // already been logged since boot.
            "log" => match parts.next() {
                Some("info") | Some("warn") | Some("error") => {
                    let msg: String = parts.collect::<Vec<_>>().join(" ");
                    boot.logger.info(SOURCE, &format!("console: {msg}"));
                    println!("logged: {msg}");
                }
                _ => {
                    for entry in boot.logger.filter_by_level(LogLevel::Debug) {
                        println!("{}\t{:?}\t{}\t{}", entry.timestamp_secs, entry.level, entry.source, entry.message);
                    }
                }
            },

            "help" => {
                println!("commands: ps | svc start|stop|crash-test|tick <name> | fs write|read <name> [text] | mem | dev list|register [id] | log [info <msg>] | exit");
            }

            "exit" | "quit" => {
                boot.logger.info(SOURCE, "console: exit requested");
                println!("nova-init: shutting down console");
                break;
            }

            other => println!("unknown command: {other} (try 'help')"),
        }
    }
}

fn main() {
    let boot = boot_sequence();
    run_console(boot);
}
