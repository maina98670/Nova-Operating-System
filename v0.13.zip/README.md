# Nova OS — M4 Core OS, Days 2–10 (Complete Build Guide)

One folder per day, each self-contained with its own Cargo workspace,
build script, and README documenting exactly what was verified and
how.

| Day | Folder | Focus | Verified live in sandbox? |
|---|---|---|---|
| 2 | Day02-ProcessManager | Process Manager | Yes — full DoD run live (real spawn/list/terminate) |
| 3 | Day03-MemoryManager | Memory Manager | Yes — full DoD run live (real RLIMIT_AS allocation failure) |
| 4 | Day04-FilesystemManager | Filesystem Manager | Yes — full DoD run live (real tmpfs mount/unmount) |
| 5 | Day05-DeviceManager | Device Manager | Yes — full DoD run live (fake display/input/storage registry) |
| 6 | Day06-ServiceManager | Service Manager | Yes — full DoD run live (real crash/restart policy firing) |
| 7 | Day07-Logging | Logging | Yes — full DoD run live, plus a real retrofit of nova-procmgrd |
| 8 | Day08-Configuration | Configuration | **No** — files only, per instruction; not built or run |
| 9 | Day09-NovaCoreAPI | Nova Core API | Yes — facade tests + the API doc's own worked example, run live |
| 10 | Day10-Integration-Console-Acceptance-Tag | M4 Integration, Console, Acceptance, Tag | **No** — files only, per instruction; nova-init not yet compiled |

## Recommended order to actually build these

Each day's package is self-contained (own `Cargo.toml` workspace), but
Day10's `system/nova-init` depends on the full stack (all eight
libraries) and is the integration point for everything before it.
Practical path:

1. Build/verify Day02 through Day07 individually first (each has its
   own `nova-dayN-build_and_run.sh`) — these are already confirmed
   working.
2. Build Day08 (`cargo build -p nova-config` etc.) — untested, expect
   to fix something, per every prior day's pattern.
3. Build Day09's `nova-core` facade and confirm its doc-example still
   runs.
4. Build Day10's `nova-init` last — it's the largest untested file in
   this whole set and depends on everything above it. Follow
   Day10-Integration-Console-Acceptance-Tag/README.md's "Recommended
   next steps" section exactly: `cargo build` → manual console test →
   run the acceptance script → only then tag the release.

See each day's own README.md for full details, and
Day09-NovaCoreAPI/docs/nova-core-api-reference.md +
Day10-Integration-Console-Acceptance-Tag/docs/nova-m4-boot-runtime-overview.md
for the complete API and boot/console documentation.
