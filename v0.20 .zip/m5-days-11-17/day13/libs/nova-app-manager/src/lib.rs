//! Nova App Manager — M5 Day 13.
//!
//! Per the Complete Build Guide's Day 13 row: rebuild App Manager's
//! lifecycle handling (launch/foreground/background/terminate) on top
//! of M4's Process Manager (`nova-procmgr`) and Service Manager
//! (`nova-svcmgr`), instead of raw `fork`/`exec` — this is the actual
//! integration point the Roadmap's M5 phase exists for.
//!
//! ## What "on top of" means concretely here
//! - **Launch** does not call `Command::spawn` itself. It registers
//!   the app as a `nova_svcmgr::ServiceDef` and calls
//!   `ServiceManager::start`, which spawns through the one
//!   `ProcessManager` instance `ServiceManager` already owns. There is
//!   exactly one process-spawning code path in this crate.
//! - **Terminate** calls `ServiceManager::stop`, which calls
//!   `ProcessManager::terminate` (graceful SIGTERM, escalating to
//!   SIGKILL) — not a raw `kill()` from this crate.
//! - **Foreground/Background** are concepts `ProcessManager` and
//!   `ServiceManager` deliberately don't know about (a backgrounded
//!   app is still a *running* Linux process, not a different process
//!   state) — App Manager tracks that layer itself, in `AppRuntime`,
//!   and pushes a `Lifecycle` IPC event to the app's own connection.
//!   What *is* delegated: whether the process backing an app is still
//!   alive at all is always answered by asking `ProcessManager`
//!   (transitively through `ServiceManager::process_list`/
//!   `process_info`), never guessed from App Manager's own state.
//! - **Cold-start reporting** is computed from
//!   `ServiceManager::process_uptime` (which reads
//!   `ProcessManager`'s own spawn timestamp) the moment `Hello`
//!   arrives — not from the app's self-reported `ColdStartReport`
//!   payload. That message still exists on the wire (an app may still
//!   send it) but this crate treats it as informational only; the
//!   authoritative number is the one this crate measured itself.
//!
//! ## What's deliberately out of scope for Day 13
//! - **App discovery / manifests.** `AppRegistry` here is a minimal,
//!   in-memory stand-in keyed by `app_id` — Day 14 is explicitly where
//!   `nova-app.toml` manifest parsing and validation get built. Day 13
//!   only needs *something* that maps an app id to a command to launch
//!   through the Process/Service Manager; it does not anticipate
//!   Day 14's schema.
//! - **Sandbox enforcement.** Permissions are still granted at the
//!   implicit Display/Input level on `Hello`, exactly as before —
//!   actually *enforcing* declared permissions is Day 15's job.

use nova_ipc::{discover as ipc_discover, LifecycleEvent, Message, Permission, SeqPacketSocket};
pub use nova_ipc::AppListEntry;
pub use nova_procmgr::ProcessInfo;
pub use nova_svcmgr::ServiceStatus;
use nova_svcmgr::{ServiceDef, ServiceManager};

use std::collections::HashMap;
use std::fmt;
use std::io;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

/// A launchable app, as far as Day 13's App Manager needs to know.
/// Stand-in for Day 14's manifest — see module docs.
#[derive(Debug, Clone)]
pub struct AppDef {
    pub id: String,
    pub name: String,
    pub command: String,
    pub args: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AppLifecycleState {
    Foreground,
    Background,
}

#[derive(Debug, Clone)]
struct AppRuntime {
    pid: u32,
    state: AppLifecycleState,
    /// Sourced from `ServiceManager::process_uptime` at the moment
    /// `Hello` was received — see module docs. `None` until the app
    /// has actually connected and said `Hello` (launching a process
    /// and it completing its IPC handshake are two different events).
    cold_start_ms: Option<u32>,
}

#[derive(Debug)]
pub enum AppManagerError {
    UnknownApp(String),
    NotRunning(String),
    Service(nova_svcmgr::ServiceError),
}

impl fmt::Display for AppManagerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            AppManagerError::UnknownApp(id) => write!(f, "unknown app: {id}"),
            AppManagerError::NotRunning(id) => write!(f, "app not running: {id}"),
            AppManagerError::Service(e) => write!(f, "service manager error: {e}"),
        }
    }
}
impl std::error::Error for AppManagerError {}

struct Inner {
    svcmgr: ServiceManager,
    registry: HashMap<String, AppDef>,
    runtime: HashMap<String, AppRuntime>,
    /// One connection per app that has completed the `Hello` IPC
    /// handshake. `Arc` (not a bare `SeqPacketSocket`) because
    /// `send`/`recv` both take `&self` — the accept-loop's reader
    /// thread and whatever thread calls `foreground`/`background`
    /// need to use the *same* live connection concurrently, and this
    /// is the one true handle to it rather than a second parallel one.
    connections: HashMap<String, Arc<SeqPacketSocket>>,
}

/// The App Manager itself. Cheap to clone (an `Arc` internally) — the
/// accept-loop thread and the caller of `launch`/`foreground`/
/// `background`/`terminate` share the same locked state, which is
/// exactly what lets a `Hello` handshake arriving on its own thread
/// update the same `AppRuntime` a concurrent `launch()` call just
/// created.
#[derive(Clone)]
pub struct AppManager {
    inner: Arc<Mutex<Inner>>,
}

impl Default for AppManager {
    fn default() -> Self {
        Self::new()
    }
}

impl AppManager {
    pub fn new() -> Self {
        AppManager {
            inner: Arc::new(Mutex::new(Inner {
                svcmgr: ServiceManager::new(),
                registry: HashMap::new(),
                runtime: HashMap::new(),
                connections: HashMap::new(),
            })),
        }
    }

    /// Declares an app the way Day 14's manifest loader eventually
    /// will — for now, called directly with an `AppDef` built by
    /// whatever's driving this crate (the M5 acceptance test, in this
    /// package).
    pub fn register_app(&self, def: AppDef) {
        let mut inner = self.inner.lock().unwrap();
        inner.registry.insert(def.id.clone(), def);
    }

    pub fn list_apps(&self) -> Vec<AppListEntry> {
        let inner = self.inner.lock().unwrap();
        let mut apps: Vec<AppListEntry> =
            inner.registry.values().map(|d| AppListEntry { id: d.id.clone(), name: d.name.clone() }).collect();
        apps.sort_by(|a, b| a.id.cmp(&b.id));
        apps
    }

    /// Launches `app_id`: registers it with `ServiceManager` (idempotent
    /// — safe to call every launch) and starts it, which spawns through
    /// `ServiceManager`'s single `ProcessManager`. Returns the real PID,
    /// exactly as `ProcessManager::spawn` reported it — never a value
    /// this crate invented. Newly launched apps start `Foreground`
    /// (the shell just launched them; nothing launches straight to
    /// background).
    pub fn launch(&self, app_id: &str) -> Result<u32, AppManagerError> {
        let mut inner = self.inner.lock().unwrap();
        let def = inner.registry.get(app_id).cloned().ok_or_else(|| AppManagerError::UnknownApp(app_id.to_string()))?;

        inner.svcmgr.register(ServiceDef {
            name: def.id.clone(),
            command: def.command.clone(),
            args: def.args.clone(),
            // User-launched apps are not auto-restarted on exit —
            // that behavior belongs to system *services* (Day 6's
            // scope), not something a user closed on purpose. This is
            // a Day 13 design decision, noted rather than left
            // implicit.
            restart_policy: nova_procmgr::RestartPolicy::Never,
            depends_on: Vec::new(),
            max_restarts: 0,
        });

        let pid = inner.svcmgr.start(app_id).map_err(AppManagerError::Service)?;
        inner.runtime.insert(app_id.to_string(), AppRuntime { pid, state: AppLifecycleState::Foreground, cold_start_ms: None });
        Ok(pid)
    }

    /// Pushes a `Lifecycle::Foreground` event (if the app has an open
    /// IPC connection) and records the state change. Does **not**
    /// touch the process itself — foregrounding is not a process-manager
    /// operation, it's purely App Manager's own layer, which is exactly
    /// why the DoD requires cross-checking it doesn't silently start
    /// reporting a state Process Manager would disagree with.
    pub fn foreground(&self, app_id: &str) -> Result<(), AppManagerError> {
        self.set_lifecycle(app_id, AppLifecycleState::Foreground, LifecycleEvent::Foreground)
    }

    pub fn background(&self, app_id: &str) -> Result<(), AppManagerError> {
        self.set_lifecycle(app_id, AppLifecycleState::Background, LifecycleEvent::Background)
    }

    fn set_lifecycle(&self, app_id: &str, state: AppLifecycleState, event: LifecycleEvent) -> Result<(), AppManagerError> {
        let mut inner = self.inner.lock().unwrap();
        if !inner.runtime.contains_key(app_id) {
            return Err(AppManagerError::NotRunning(app_id.to_string()));
        }
        // The process itself must still actually be alive per
        // ProcessManager -- foregrounding/backgrounding a pid Process
        // Manager already considers gone would be exactly the kind of
        // "App Manager's own internal state disagrees with reality"
        // bug the Day 13 DoD is checking for.
        let still_alive = inner
            .svcmgr
            .process_info(app_id)
            .map(|info| !matches!(info.state, nova_procmgr::ProcessState::Terminated | nova_procmgr::ProcessState::Unknown))
            .unwrap_or(false);
        if !still_alive {
            return Err(AppManagerError::NotRunning(app_id.to_string()));
        }
        if let Some(rt) = inner.runtime.get_mut(app_id) {
            rt.state = state;
        }
        if let Some(conn) = inner.connections.get(app_id) {
            // Best-effort: a Lifecycle push failing to send doesn't
            // undo the state change -- Nova's own state must stay the
            // source of truth even if this particular app's socket
            // has gone stale, which the next terminate/relaunch will
            // clean up.
            let _ = conn.send(&Message::Lifecycle { event });
        }
        Ok(())
    }

    /// Sends `Lifecycle::Terminate` (best-effort, so a well-behaved app
    /// gets a chance to see it coming), then stops the app through
    /// `ServiceManager::stop` — which is what actually calls
    /// `ProcessManager::terminate` (graceful SIGTERM, escalating to
    /// SIGKILL). Removes App Manager's own runtime/connection state
    /// only after the real process-level stop succeeds.
    pub fn terminate(&self, app_id: &str) -> Result<(), AppManagerError> {
        let mut inner = self.inner.lock().unwrap();
        if !inner.runtime.contains_key(app_id) {
            return Err(AppManagerError::NotRunning(app_id.to_string()));
        }
        if let Some(conn) = inner.connections.get(app_id) {
            let _ = conn.send(&Message::Lifecycle { event: LifecycleEvent::Terminate });
        }
        inner.svcmgr.stop(app_id).map_err(AppManagerError::Service)?;
        inner.runtime.remove(app_id);
        inner.connections.remove(app_id);
        Ok(())
    }

    /// App Manager's own view of foreground/background. Deliberately
    /// separate from `process_list`/`service_status` below -- the DoD
    /// is specifically about these two views staying consistent with
    /// each other, not about collapsing them into one.
    pub fn lifecycle_state(&self, app_id: &str) -> Option<AppLifecycleState> {
        self.inner.lock().unwrap().runtime.get(app_id).map(|rt| rt.state)
    }

    pub fn cold_start_ms(&self, app_id: &str) -> Option<u32> {
        self.inner.lock().unwrap().runtime.get(app_id).and_then(|rt| rt.cold_start_ms)
    }

    pub fn pid_of(&self, app_id: &str) -> Option<u32> {
        self.inner.lock().unwrap().runtime.get(app_id).map(|rt| rt.pid)
    }

    /// M4 Process Manager's own process list, exactly as
    /// `ServiceManager::process_list` (Day 13's addition to
    /// `nova-svcmgr`) reports it -- the actual cross-check surface the
    /// DoD asks for.
    pub fn process_list(&self) -> Vec<ProcessInfo> {
        self.inner.lock().unwrap().svcmgr.process_list()
    }

    /// M4 Service Manager's own status for `app_id`, exactly as
    /// `ServiceManager::status` reports it -- the other half of the
    /// DoD's cross-check.
    pub fn service_status(&self, app_id: &str) -> ServiceStatus {
        self.inner.lock().unwrap().svcmgr.status(app_id)
    }

    /// Binds the IPC control socket and starts accepting connections,
    /// one thread per connection (the same pattern Day 11/12's live
    /// tools already used for a single connection, generalized here to
    /// however many apps are actually running). Returns immediately;
    /// the returned handle is the accept-loop thread.
    pub fn serve(&self, socket_path: &str) -> io::Result<thread::JoinHandle<()>> {
        let listener = SeqPacketSocket::listen(socket_path)?;
        let inner = self.inner.clone();
        Ok(thread::spawn(move || loop {
            match listener.accept() {
                Ok(conn) => {
                    let inner = inner.clone();
                    thread::spawn(move || handle_connection(inner, conn));
                }
                Err(_) => break, // listener closed / fatal accept error
            }
        }))
    }

    /// Convenience for a client that wants the App Manager's socket by
    /// name rather than importing `nova_ipc::SOCKET_PATH` directly —
    /// exercises Day 12's `discover` from this crate too.
    pub fn discover_self() -> io::Result<std::path::PathBuf> {
        ipc_discover("app-manager")
    }
}

/// Handles one app's connection for its whole lifetime: the `Hello`
/// handshake (computing cold-start from Process Manager's own
/// timestamp, per module docs), then a read loop for whatever else the
/// app sends, until it disconnects.
fn handle_connection(inner: Arc<Mutex<Inner>>, conn: SeqPacketSocket) {
    let conn = Arc::new(conn);

    let hello = match conn.recv() {
        Ok(m) => m,
        Err(_) => return, // connected and went away before saying anything
    };

    let Message::Hello { app_id, pid: claimed_pid } = hello else {
        // Protocol says Hello must be the first message; anything else
        // here is a misbehaving client. Drop the connection rather
        // than guessing what it meant.
        return;
    };

    // SO_PEERCRED is the real auth mechanism per the protocol spec --
    // the app-supplied pid in Hello is informational/logging only.
    let real_pid = conn.peer_credentials().map(|(_, _, pid)| pid as u32).unwrap_or(claimed_pid);

    let accepted = {
        let mut inner = inner.lock().unwrap();
        // Cold start sourced from Service/Process Manager's own spawn
        // timestamp -- the actual Day 13 requirement -- not from
        // anything the app itself might report. Computed before the
        // mutable borrow below so it doesn't overlap with it.
        let elapsed_ms = inner.svcmgr.process_uptime(&app_id).map(|d: Duration| d.as_millis() as u32);
        match inner.runtime.get_mut(&app_id) {
            Some(rt) => {
                rt.cold_start_ms = elapsed_ms;
                rt.pid = real_pid;
                true
            }
            // A connection claiming an app_id App Manager didn't
            // itself launch -- reject rather than silently trusting it.
            None => false,
        }
    };

    let _ = conn.send(&Message::HelloAck { accepted, granted_permissions: Permission::implicit_bitmask() });
    if !accepted {
        return;
    }

    inner.lock().unwrap().connections.insert(app_id.clone(), conn.clone());

    // Read loop: keep the connection open so foreground/background/
    // terminate can push Lifecycle events on it later, and so the app
    // can still send ColdStartReport/PermissionRequest/etc (accepted
    // on the wire, but -- per module docs -- ColdStartReport's payload
    // is not what this crate treats as authoritative).
    loop {
        match conn.recv() {
            Ok(_other) => continue,
            Err(_) => break, // app disconnected / process exited
        }
    }

    let mut inner = inner.lock().unwrap();
    // Only clear the connection if it's still the one we own -- a
    // relaunch under the same app_id may already have installed a
    // newer connection by the time this thread notices the old one
    // closed.
    if let Some(current) = inner.connections.get(&app_id) {
        if Arc::ptr_eq(current, &conn) {
            inner.connections.remove(&app_id);
        }
    }
}
