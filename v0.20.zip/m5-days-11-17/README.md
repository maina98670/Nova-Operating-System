# Nova OS — M5, Days 11–17 (IPC, Applications & Sandboxing)

Each `dayNN/` folder is that day's package exactly as delivered. They
are **cumulative, not independent snapshots**: each day builds
directly on the previous day's files (day12 = day11 + that day's
changes, and so on through day17). If you only want one buildable
tree, use **`day17/`** — it contains everything from days 11–16 plus
Day 17's own additions.

Keeping every day's folder here (rather than collapsing to just
day17) preserves the incremental history — each day's own `README.md`
and `DAYxx_CHANGELOG.md` (from Day 15 onward) explain what changed
that day and why, which is lost if you only keep the final state.

## Day-by-day

| Day | Folder | Focus |
|---|---|---|
| 11 | `day11/` | Versioned IPC protocol (`nova-ipc` formalized, `VersionQuery`/`VersionResponse`) |
| 12 | `day12/` | Service discovery + request/response/event messaging over one transport |
| 13 | `day13/` | App lifecycle rebuilt on M4's Process/Service Manager (not raw fork/exec) |
| 14 | `day14/` | `nova-app.toml` manifest schema + permission declarations, validated via `nova-config` |
| 15 | `day15/` | Sandbox boundaries: capability checks + per-app filesystem scoping become real enforcement |
| 16 | `day16/` | Settings/Contacts/Messages/Dialer/Camera built (functional cores, no UI) — confirmed no pre-existing source existed anywhere in this track before building |
| 17 | `day17/` | `nova-hello` smoke test, the Roadmap's own M5 acceptance test run live, M5 tag (`v0.20`) |

## Status

**None of this has been built or tested in this pass**, per
instruction throughout Days 11–17's assembly. Each `dayNN/` has its
own `nova-dayNN-build_and_run.sh` (or, for Day 17, a script that also
re-runs Day 16's live test) — run the one in `day17/` to build and
verify the full, cumulative result.

See `day17/docs/M5-TAG.md` for the M5 tag write-up and the actual
`git tag` command for your own repository.
