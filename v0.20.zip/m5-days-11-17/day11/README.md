# Nova OS — Day 11 Package: Versioned IPC Protocol (M5 begins)

Per the Complete Build Guide, Day 11 opens M5 (IPC, Applications &
Sandboxing): formalize the existing app-control IPC protocol into a
versioned, documented spec, and decide the versioning/compatibility
policy.

## Starting point: more already existed than Day 11 assumed

The IPC protocol (Hello/HelloAck/PermissionRequest/PermissionResponse/
Lifecycle/ColdStartReport/ListApps/AppList/LaunchApp/LaunchResult) and
a spec document (protocols/nova-ipc-v1.md) were already built and
verified in an earlier session -- PROTOCOL_VERSION already existed as
a pub const u8, and nova-settings/nova-contacts/nova-messages already
speak this protocol's Hello/HelloAck/ColdStartReport subset in
production. Day 11's actual delta work, once that was confirmed, was
two specific gaps:

1. A formal, explicit versioning/compatibility policy -- the prior
   spec had an informal note about version mismatches, not a decided
   policy document.
2. A runtime-queryable version -- PROTOCOL_VERSION was only a
   compile-time constant; nothing let an unlinked client (a
   diagnostic tool, or a build compiled against a different nova-ipc
   version) ask a running server what it actually speaks.

## What's in this package

- libs/nova-ipc -- the existing protocol crate, with two additions:
  - Two new message types, VersionQuery (0x0B) and VersionResponse
    (0x0C).
  - A real, non-trivial fix to decode(): the original version check
    happened before looking at the message type, which would have
    made cross-version VersionQuery impossible -- the whole point of
    a version-query message is asking "what do you speak?" before
    knowing you're compatible, so the check itself couldn't require
    compatibility first. is_version_independent() now exempts exactly
    VersionQuery/VersionResponse from the version-match gate, and
    everything else still enforces it exactly as before.
  - protocols/nova-ipc-v1.md, with a new "Versioning & Compatibility
    Policy" section replacing the old informal note: single
    incrementing version integer (not semver, deliberately -- this is
    a small closed binary protocol, unlike nova-core's public API,
    which does use semver per Day 9), hard failure on mismatch by
    default, and the version-query mechanism as the documented
    exception.
- tools/nova-ipc-version-test -- a real two-thread demonstration: a
  minimal in-process server accepts a connection and answers
  VersionQuery; a real client connects over a real Unix socket and
  queries it -- entirely independent of the Hello handshake.

## What was actually verified in this sandbox -- all of it, live

- cargo test -p nova-ipc: 6/6 passing (up from the prior session's
  4), including two new tests specifically exercising the tricky
  part of this fix:
  - version_query_and_response_survive_a_version_mismatch -- proves
    the exemption actually works.
  - non_version_messages_still_reject_mismatch_even_with_the_new_exemption_present
    -- a guard-rail test proving the fix didn't accidentally weaken
    the version check for every other message type too (a real risk
    with this kind of conditional-exemption change).
- The full live Definition of Done, run for real. Actual output from
  this sandbox:

  nova-ipc-version-test: connecting to /tmp/nova-ipc-version-test-531.sock
  nova-ipc-version-test: sending VersionQuery (before any Hello handshake)
  nova-ipc-version-test: received VersionResponse -- server speaks protocol v1

  nova-ipc-version-test: PASS -- Day 11 Definition of Done satisfied end-to-end

  A real client, a real server, a real socket -- not just
  encode/decode round-tripped in memory (which the unit tests already
  cover separately).

## Nothing left unverified

No "test it on your machine" caveat. Run
nova-day11-build_and_run.sh yourself to reproduce this exact result.

## Next: Day 12

Per the Guide's M5 table, Day 12 continues M5 (IPC, Applications &
Sandboxing) -- likely the actual nova-app-manager service that
nova-ipc's spec has described all along but whose implementation
hasn't yet been directly inspected/verified in this delivery
sequence.
