# Nova App Control IPC — Protocol v1

This is the "app IPC protocol" referenced in Section 1, Section 5 (M5),
and Section 11 of the guide. It is **not** the display protocol — display
and input still go over Wayland, exactly as M3 (compositor) and M4
(shell, as a Wayland client) already built. This protocol is the
*control plane*: how an app talks to nova-app-manager (permissions,
lifecycle, cold-start reporting), and how Nova Shell asks
nova-app-manager what's installed and launches things.

Keeping these separate — rather than growing Wayland's protocol with
Nova-specific extensions — means nova-app-manager never has to link
against libwayland at all, and the control protocol stays legible
without pulling in the Wayland wire format.

## Transport

A `SOCK_SEQPACKET` Unix domain socket at `/run/nova/app-manager.sock`.
`SEQPACKET` (not `STREAM`) is used deliberately: message boundaries are
preserved by the kernel, so there's no length-prefix framing bug class
to get wrong at the transport layer — only the payload itself needs a
length, for messages the payload of which is variable (see below).

Every launched app additionally gets `NOVA_CONTROL_SOCK` in its
environment, pointing at the same path — apps do not need to know it in
advance.

## Wire format

Every message is a single `SOCK_SEQPACKET` datagram, laid out as:

```
byte 0       : protocol version (currently 1)
byte 1       : message type (see table)
bytes 2..6   : payload length, u32 little-endian
bytes 6..    : payload (format depends on message type, see below)
```

A version mismatch or unknown message type is a hard error — the
receiving end drops the connection rather than guessing. There is
deliberately no negotiation handshake beyond this: v1 is v1, and a
breaking change increments the version byte and ships a new
nova-app-manager that can still speak v1 to old apps if that's ever
needed (not required yet — no app predates this protocol).

## Message types

| Value | Name               | Direction          | Purpose |
|-------|--------------------|---------------------|---------|
| 0x01  | Hello              | app -> manager      | First message on the socket. Announces app id + pid. |
| 0x02  | HelloAck           | manager -> app      | Confirms registration, returns the granted-permission bitmask. |
| 0x03  | PermissionRequest  | app -> manager      | Ask for one optional permission at runtime (Section 11's manifest lists required vs. optional). |
| 0x04  | PermissionResponse | manager -> app      | Grant or deny, in response to 0x03. |
| 0x05  | Lifecycle          | manager -> app      | Foreground / Background / Suspend / Terminate. |
| 0x06  | ColdStartReport    | app -> manager      | App's self-measured time-to-first-frame, checked against its tier's budget (Section 5: "cold-start time budgets set per app"). |
| 0x07  | ListApps           | shell -> manager    | Request the current app registry (empty payload). |
| 0x08  | AppList            | manager -> shell    | Response to 0x07: id/name pairs of every discovered app. |
| 0x09  | LaunchApp          | shell -> manager    | Ask the manager to sandbox-launch an app by id. |
| 0x0A  | LaunchResult       | manager -> shell    | Success + pid, or a failure reason string. |
| 0x0B  | VersionQuery       | any -> manager      | Ask the running server what protocol version it speaks. Exempt from the version check (see Versioning & Compatibility Policy below) — usable even by a client of a different version. |
| 0x0C  | VersionResponse    | manager -> any      | Answers 0x0B with the server's real `PROTOCOL_VERSION`. Also exempt from the version check. |

Payload encodings (all multi-byte integers little-endian; strings are
UTF-8, length-prefixed with a `u16`, never null-terminated):

- **Hello**: `u16 app_id_len | app_id bytes | u32 pid`
- **HelloAck**: `u8 accepted (0/1) | u32 granted_permission_bitmask`
- **PermissionRequest**: `u8 permission_id` (see `Permission` enum in
  `libs/nova-ipc`)
- **PermissionResponse**: `u8 permission_id | u8 granted (0/1)`
- **Lifecycle**: `u8 event` (0=Foreground, 1=Background, 2=Suspend,
  3=Terminate)
- **ColdStartReport**: `u32 elapsed_ms`
- **ListApps**: (empty)
- **AppList**: `u16 count | count * (u16 id_len | id bytes | u16 name_len | name bytes)`
- **LaunchApp**: `u16 app_id_len | app_id bytes`
- **LaunchResult**: `u8 ok (0/1) | u32 pid (if ok) | u16 reason_len | reason bytes (if !ok)`
- **VersionQuery**: (empty)
- **VersionResponse**: `u8 protocol_version`

## Versioning & Compatibility Policy

**Formalized Day 11**, per Section 4's "document APIs before creating
many consumers" — this section replaces the earlier informal note
about version mismatches (previously folded into the Wire Format
section above) with an explicit, decided policy.

- **The version byte is a single incrementing integer**, not a
  major.minor pair. This is deliberate: this is a small, closed binary
  wire protocol (not a public library API like `nova-core`, which
  *does* use semver — Day 9), and a single version number is the
  simpler, correct model for "does this datagram's format match what
  I know how to parse." There is exactly one shipped version so far:
  **v1**.
- **On mismatch, the default behavior is a hard failure**: `decode()`
  returns an `Err`, and per this spec, the receiving end drops the
  connection rather than attempting to interpret a payload it can't
  be sure it understands correctly. There is no partial-compatibility
  mode, no best-effort parsing of a newer/older format. A version
  mismatch is treated as a configuration error to be fixed (mismatched
  builds of `nova-app-manager` and an app/shell), not a runtime
  condition to gracefully degrade through.
- **Exactly two message types are exempt from this check**:
  `VersionQuery` (0x0B) and `VersionResponse` (0x0C). Their wire format
  is a **permanent commitment** — it will never change across any
  future protocol version — specifically so a client can discover a
  server's real running version *before* knowing whether they can
  otherwise communicate at all. Without this exemption, version
  discovery would be circular: you'd need to already speak the right
  version to ask what version is spoken.
- **Recommended client pattern**: a client uncertain of the server's
  version (e.g. a diagnostic tool, or during a live system update
  where binary and daemon versions could transiently differ) should
  send `VersionQuery` first and inspect the `VersionResponse` before
  sending `Hello` or anything else. A client that already knows it
  matches (the common case — an app built against the same `nova-ipc`
  version as the running `nova-app-manager`) can skip straight to
  `Hello`, exactly as every app built so far already does.
- **Future breaking changes** increment `PROTOCOL_VERSION`. A future
  `nova-app-manager` *may* choose to speak multiple versions
  simultaneously for backward compatibility, but that is an
  implementation choice for whenever it becomes necessary, not a v1
  commitment — v1 has exactly one version in the field, so there is
  nothing to be backward-compatible with yet.

### Querying the version — two ways

1. **At compile time**, any Rust code linked against this crate can
   read `nova_ipc::PROTOCOL_VERSION` directly — a `pub const u8`,
   always available, zero runtime cost.
2. **At runtime**, any client — including one *not* compiled against
   this exact crate version, or a non-Rust diagnostic tool speaking
   the wire format directly — can connect and send `VersionQuery`
   (type `0x0B`, empty payload) and receive back `VersionResponse`
   (type `0x0C`, one payload byte: the server's `PROTOCOL_VERSION`).
   This is the mechanism added Day 11 specifically to satisfy "a
   version number a client can query" as a live, runtime property of
   the running server — not only a property of whatever the client
   happened to be built against.

## Permission model

Permissions are a fixed, small `u32` bitmask — not an open string
namespace — so a manifest can be validated at install time without
trusting arbitrary permission names from an app bundle. The full list
lives in `libs/nova-ipc/src/lib.rs` (`Permission` enum) and currently
covers: Display, Input, Network, Location, Contacts, Camera,
Microphone, Sms, HealthData, Storage.

`Display` and `Input` are implicitly granted to every app the shell
launches (an app that can't draw or receive touch input isn't
meaningfully sandboxed, it's just broken) and are not requestable —
every other permission must be listed in the manifest's
`permissions.required` or requested at runtime via 0x03 if listed under
`permissions.optional`. nova-app-manager is the sole grant authority;
there is no way for an app to self-grant.

## What's deliberately out of scope for v1

- **No bidirectional streaming / large payloads.** `SOCK_SEQPACKET`
  datagrams have a kernel-enforced size ceiling (`SO_SNDBUF`, ~200KB by
  default); this protocol's messages are all well under 1KB by design.
  Anything resembling a data channel (health records syncing, camera
  frames) is explicitly a job for a separate, per-service IPC
  mechanism — not this control protocol — the same separation of
  concerns that keeps Wayland out of this file.
- **No encryption/auth beyond `SO_PEERCRED`.** The socket is
  filesystem-permissioned (`0660`, owned by a `nova-system` group) and
  the manager reads the connecting process's real uid/gid/pid via
  `SO_PEERCRED` rather than trusting the app-supplied pid in `Hello` —
  that field is informational/logging only, never used for auth
  decisions.
