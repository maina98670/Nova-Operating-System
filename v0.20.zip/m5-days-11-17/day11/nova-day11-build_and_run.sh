#!/bin/bash
# Nova OS -- Day 11: Versioned IPC Protocol (M5 begins)
# No root, no cross-compilation, no QEMU needed.
set -e

echo "=== Nova OS Day 11: Versioned IPC Protocol ==="

echo "[1/2] Running nova-ipc's full test suite (6 tests, including the new"
echo "      version-exemption logic and a guard-rail test against a sloppy fix)..."
cargo test -p nova-ipc

echo "[2/2] Building and running the live Definition of Done test..."
cargo build -p nova-ipc-version-test
./target/debug/nova-ipc-version-test

echo ""
echo "Full protocol spec: libs/nova-ipc/protocols/nova-ipc-v1.md"
