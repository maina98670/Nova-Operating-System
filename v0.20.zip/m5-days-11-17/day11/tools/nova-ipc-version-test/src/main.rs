//! Day 11's literal DoD, run live: a real client connects over a real
//! Unix `SOCK_SEQPACKET` socket and queries a real server's protocol
//! version at runtime — proving `VersionQuery`/`VersionResponse`
//! actually work end-to-end, not just round-trip through `encode`/
//! `decode` in memory (which the library's own unit tests already
//! cover separately).

use nova_ipc::{Message, SeqPacketSocket, PROTOCOL_VERSION};
use std::process;
use std::thread;
use std::time::Duration;

fn fail(msg: &str) -> ! {
    eprintln!("nova-ipc-version-test: FAIL -- {msg}");
    process::exit(1);
}

fn main() {
    let sock_path = format!("/tmp/nova-ipc-version-test-{}.sock", process::id());
    let _ = std::fs::remove_file(&sock_path);

    // Minimal server: accept one connection, expect exactly a
    // VersionQuery, reply with this build's real PROTOCOL_VERSION.
    let server_path = sock_path.clone();
    let server = thread::spawn(move || {
        let listener = SeqPacketSocket::listen(&server_path).expect("server: listen failed");
        let conn = listener.accept().expect("server: accept failed");
        match conn.recv() {
            Ok(Message::VersionQuery) => {
                conn.send(&Message::VersionResponse { protocol_version: PROTOCOL_VERSION })
                    .expect("server: send VersionResponse failed");
            }
            other => panic!("server: expected VersionQuery, got {other:?}"),
        }
    });

    thread::sleep(Duration::from_millis(100));

    println!("nova-ipc-version-test: connecting to {sock_path}");
    let client = SeqPacketSocket::connect(&sock_path).unwrap_or_else(|e| fail(&format!("connect failed: {e}")));

    println!("nova-ipc-version-test: sending VersionQuery (before any Hello handshake)");
    client.send(&Message::VersionQuery).unwrap_or_else(|e| fail(&format!("send failed: {e}")));

    let response = client.recv().unwrap_or_else(|e| fail(&format!("recv failed: {e}")));
    match response {
        Message::VersionResponse { protocol_version } => {
            println!("nova-ipc-version-test: received VersionResponse -- server speaks protocol v{protocol_version}");
            if protocol_version != PROTOCOL_VERSION {
                fail(&format!("expected v{PROTOCOL_VERSION}, got v{protocol_version}"));
            }
        }
        other => fail(&format!("expected VersionResponse, got {other:?}")),
    }

    server.join().expect("server thread panicked");
    let _ = std::fs::remove_file(&sock_path);

    println!();
    println!("nova-ipc-version-test: PASS -- Day 11 Definition of Done satisfied end-to-end");
    println!("nova-ipc-version-test: a real client queried a real server's protocol version");
    println!("nova-ipc-version-test: over a real socket, entirely independent of any Hello");
    println!("nova-ipc-version-test: handshake or compile-time constant sharing.");
}
