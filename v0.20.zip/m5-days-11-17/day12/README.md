# Nova OS — Day 12 Package: Service Discovery + Request/Response/Event Messaging

Per the Complete Build Guide, Day 12 continues M5: give clients a way
to discover services without hardcoded socket paths, and confirm
request/response and one-way event messaging both work over the same
transport.

**This package was assembled without running any tests or builds** —
per instruction, this is files only. Nothing below has been verified
in this pass the way Days 2-7, 9, and 11 were; run
nova-day12-build_and_run.sh yourself to actually confirm it.

## What's in this package

- libs/nova-ipc -- the existing protocol crate (now depending on
  nova-fsmgr, a new dependency added this day), plus a new
  src/discovery.rs module:
  - discover(name: &str) -> io::Result<PathBuf> -- resolves a service
    name to {nova_fsmgr::paths::RUN}/<name>.sock if it currently
    exists.
  - list_services() -> io::Result<Vec<String>> -- lists every
    currently-listening service by scanning that directory, zero
    hardcoded names anywhere.
  - 3 unit tests covering the suffix-stripping logic, the NotFound
    path for an unknown service, and the missing-directory-means-empty
    behavior.
- libs/nova-fsmgr -- Day 4's package, included as a dependency (this
  is the first time nova-ipc has needed anything outside its own
  previously-declared "no OS-layer dependency" scope -- noted
  explicitly in the updated Cargo.toml description rather than
  silently added).
- libs/nova-ipc/protocols/nova-ipc-v1.md -- updated with two new
  sections: "Service Discovery" (documenting discover/list_services
  and the {RUN}/<name>.sock convention) and "Request/Response and
  Event Messaging Over One Transport" (documenting, not just
  assuming, that both patterns already coexist correctly on one
  SOCK_SEQPACKET connection).
- tools/nova-ipc-discovery-test -- the literal Day 12 DoD as a live
  demonstration (server thread + client, the same pattern Day 11's
  nova-ipc-version-test used): the client calls list_services() and
  discover() with zero hardcoded paths, completes a real
  ListApps -> AppList request/response exchange, and then --
  separately, without sending anything else -- receives an
  unsolicited Lifecycle event the server pushed on its own.

## A real design point worth understanding before running this

SOCKET_PATH (/run/nova/app-manager.sock) already matched the
{RUN}/<name>.sock convention by construction, purely by coincidence of
how it was originally named. discover("app-manager") resolves to the
exact same path -- nothing about the App Manager's own listening
behavior needs to change. What's new is only that OTHER clients no
longer need to import a path constant per service; they can ask by
name, or enumerate what's running with no prior knowledge at all.

## What genuinely has NOT been done in this delivery

- nova-ipc has not been rebuilt with the new nova-fsmgr dependency --
  there is a real chance of a dependency-resolution or type error
  here that a clean build would catch immediately.
- discovery.rs's tests have not been run.
- nova-ipc-discovery-test has not been compiled or run. It requires
  root (writes a real socket into /run/nova, same requirement Day 4's
  mount test already established as accepted in this project) -- if
  you don't run it as root, expect ensure_dirs to fail loudly with a
  permissions error, which is itself the correct, honest behavior
  (not a bug to route around).
- No existing app (nova-settings, nova-contacts, nova-messages) has
  been migrated to use discover("app-manager") instead of whatever
  path-resolution they currently use -- that's real, identifiable
  follow-up work, not something silently skipped.

## Recommended next steps, in order

1. cargo build -p nova-ipc -- confirm the new nova-fsmgr dependency
   resolves and everything still compiles.
2. cargo test -p nova-ipc -- confirm all 9 tests (6 prior + 3 new)
   pass.
3. cargo build -p nova-ipc-discovery-test, then run it (as root, or
   via sudo) -- confirm the live discovery + request/response +
   unsolicited-event sequence actually works end to end.
4. Only after all three pass, consider Day 12 actually complete --
   per the same discipline Day 10's package established: don't treat
   a days-files-only delivery as verified until you've verified it
   yourself.

## Next: Day 13

Per the Guide's M5 table, Day 13 continues M5 -- likely process
sandboxing/isolation for launched apps, building on nova-procmgr
(Day 2) and the App Manager's existing permission-request machinery.
