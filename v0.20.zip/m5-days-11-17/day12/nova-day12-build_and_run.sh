#!/bin/bash
# Nova OS -- Day 12: Service Discovery + Request/Response/Event Messaging (M5)
# Requires root (writes into the real /run/nova, same requirement as
# Day 4's mount test). No cross-compilation, no QEMU needed.
# NOTE: this package was assembled without running any tests or
# builds in the environment that created it -- run this script
# yourself to verify everything below actually works.
set -e

echo "=== Nova OS Day 12: Service Discovery + Messaging ==="

echo "[1/2] Running nova-ipc's full test suite (9 tests: 6 from before + 3 new"
echo "      discovery-logic tests)..."
cargo test -p nova-ipc

echo "[2/2] Building and running the live Definition of Done test..."
echo "NOTE: this writes a real socket into /run/nova and needs root."
cargo build -p nova-ipc-discovery-test
sudo ./target/debug/nova-ipc-discovery-test || ./target/debug/nova-ipc-discovery-test

echo ""
echo "Full protocol spec (now including the Service Discovery section):"
echo "  libs/nova-ipc/protocols/nova-ipc-v1.md"
