//! Day 12's literal Definition of Done, as a live demonstration:
//! "A test client discovers the App Manager without a hardcoded path,
//! sends a request and gets a matching response, and separately
//! receives an unsolicited event."
//!
//! Structured as one process with a server thread and a client
//! (main thread), the same pattern Day 11's `nova-ipc-version-test`
//! used — a real `SOCK_SEQPACKET` socket, not an in-memory simulation.
//!
//! # Honest scope
//! This file was written but **not compiled or run** in the sandbox
//! that produced it, per instruction (Day 12 delivered as files only).
//! It requires root (to write into the real `/run/nova`, matching Day
//! 4's `mount`/`unmount` test's same requirement) — build and run this
//! yourself before trusting it; see the package README for exact
//! commands.

use nova_fsmgr::paths;
use nova_ipc::{discover, list_services, AppListEntry, LifecycleEvent, Message, SeqPacketSocket};
use std::process;
use std::thread;
use std::time::Duration;

const SERVICE_NAME: &str = "nova-day12-demo-service";

fn fail(msg: &str) -> ! {
    eprintln!("nova-ipc-discovery-test: FAIL -- {msg}");
    process::exit(1);
}

fn main() {
    // Ensure /run/nova exists at all -- same real, root-requiring
    // filesystem operation Day 4's mount test already established as
    // an accepted pattern in this project.
    if let Err(e) = nova_fsmgr::ensure_dirs(&[paths::RUN]) {
        fail(&format!("could not ensure {} exists: {e} (are you running as root?)", paths::RUN));
    }

    let socket_path = format!("{}/{SERVICE_NAME}.sock", paths::RUN);
    let _ = std::fs::remove_file(&socket_path); // stale socket from a prior run

    // --- Server thread: listens under the discoverable name,
    //     answers one request, then proactively pushes an event the
    //     client never asked for. ---
    let server_socket_path = socket_path.clone();
    let server = thread::spawn(move || {
        let listener = SeqPacketSocket::listen(&server_socket_path).expect("server: listen failed");
        let conn = listener.accept().expect("server: accept failed");

        // Request/response: answer whatever the client asks first.
        match conn.recv().expect("server: recv request failed") {
            Message::ListApps => {
                conn.send(&Message::AppList {
                    apps: vec![AppListEntry { id: "org.nova.demo".into(), name: "Demo App".into() }],
                })
                .expect("server: send AppList failed");
            }
            other => panic!("server: expected ListApps, got {other:?}"),
        }

        // One-way event: nothing prompted this from the client side --
        // this is the "separately receives an unsolicited event" half
        // of the DoD, sent over the SAME connection the
        // request/response just happened on, proving both patterns
        // share one transport.
        thread::sleep(Duration::from_millis(50));
        conn.send(&Message::Lifecycle { event: LifecycleEvent::Background })
            .expect("server: send unsolicited Lifecycle event failed");
    });

    thread::sleep(Duration::from_millis(100));

    // --- Client: discovers first, by name, with no hardcoded path
    //     anywhere in this file. ---
    println!("nova-ipc-discovery-test: listing all discoverable services (no names hardcoded)...");
    let services = list_services().unwrap_or_else(|e| fail(&format!("list_services failed: {e}")));
    println!("  found: {services:?}");
    if !services.contains(&SERVICE_NAME.to_string()) {
        fail(&format!("expected '{SERVICE_NAME}' in the discovered service list"));
    }

    println!("nova-ipc-discovery-test: discovering '{SERVICE_NAME}' by name...");
    let discovered_path = discover(SERVICE_NAME).unwrap_or_else(|e| fail(&format!("discover failed: {e}")));
    println!("  resolved to: {}", discovered_path.display());

    let client = SeqPacketSocket::connect(discovered_path.to_str().unwrap())
        .unwrap_or_else(|e| fail(&format!("connect (via discovered path) failed: {e}")));

    // --- Request/response ---
    println!("nova-ipc-discovery-test: sending ListApps request...");
    client.send(&Message::ListApps).unwrap_or_else(|e| fail(&format!("send failed: {e}")));
    let response = client.recv().unwrap_or_else(|e| fail(&format!("recv (response) failed: {e}")));
    match response {
        Message::AppList { apps } => {
            println!("  received matching AppList response: {apps:?}");
            if apps.len() != 1 || apps[0].id != "org.nova.demo" {
                fail("AppList response didn't match what the server sent");
            }
        }
        other => fail(&format!("expected AppList, got {other:?}")),
    }

    // --- Unsolicited event, received without the client having sent
    //     a second request -- the actual point of this test. ---
    println!("nova-ipc-discovery-test: waiting for an unsolicited event (no request sent)...");
    let event = client.recv().unwrap_or_else(|e| fail(&format!("recv (event) failed: {e}")));
    match event {
        Message::Lifecycle { event: LifecycleEvent::Background } => {
            println!("  received unsolicited Lifecycle::Background event, as expected");
        }
        other => fail(&format!("expected an unsolicited Lifecycle event, got {other:?}")),
    }

    server.join().expect("server thread panicked");
    let _ = std::fs::remove_file(&socket_path);

    println!();
    println!("nova-ipc-discovery-test: PASS -- Day 12 Definition of Done satisfied end-to-end");
    println!("nova-ipc-discovery-test: discovered a service with zero hardcoded paths, completed");
    println!("nova-ipc-discovery-test: a request/response exchange, and separately received an");
    println!("nova-ipc-discovery-test: unsolicited event -- all over the same transport.");
}
