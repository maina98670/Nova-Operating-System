# Nova OS — Day 13 Package: Application Lifecycle via M4's Process/Service Manager

Per the Complete Build Guide, Day 13 continues M5: rebuild App
Manager's lifecycle handling (launch/foreground/background/terminate)
on top of M4's Process Manager and Service Manager, rather than raw
`fork`/`exec` — the actual integration point the Roadmap's M5 phase
exists for.

**This package was assembled without running any tests or builds** —
no `cargo` was available in the environment that produced it. Nothing
below has been verified in this pass the way Days 2–7, 9, and 11 were;
run `nova-day13-build_and_run.sh` yourself to actually confirm it.

## Starting point: no App Manager existed yet

Unlike Day 11 (which formalized an existing IPC protocol) and Day 12
(which added discovery to an existing crate), **no App Manager
implementation was present in any prior package** — `nova-app.toml`,
the five apps, and `nova-ipc`'s spec all *refer to* `nova-app-manager`
as the thing they talk to, but its own source was never delivered.
Day 13 could not be "rebuild the existing App Manager against M4" in
the literal sense; it's built here for the first time, directly
against M4's real `nova-procmgr`/`nova-svcmgr` (from `v0_13.zip`) and
M5's real `nova-ipc` (from the Day 12 package), rather than against
raw `fork`/`exec` or an imagined API.

## What's in this package

- **`libs/nova-app-manager`** (new) — the App Manager itself:
  - `launch(app_id)` registers a `nova_svcmgr::ServiceDef` and calls
    `ServiceManager::start`, which spawns through `ServiceManager`'s
    own `ProcessManager` — there is exactly one process-spawning path
    in this crate, not a second one reimplemented here.
  - `terminate(app_id)` calls `ServiceManager::stop`, which calls
    `ProcessManager::terminate` (graceful SIGTERM, escalating to
    SIGKILL) — not a raw `kill()`.
  - `foreground`/`background` are tracked as App Manager's own layer
    (Process/Service Manager deliberately don't model this — a
    backgrounded app is still a running process), but every state
    change is cross-checked against `ProcessManager`'s real view
    before it's accepted.
  - Cold-start is computed from `ServiceManager::process_uptime`
    (Process Manager's own spawn timestamp) the moment `Hello`
    arrives, not from the app's self-reported `ColdStartReport`
    payload — the literal Day 13 requirement.
  - A real accept-loop (`serve()`), one thread per connected app,
    doing the actual `Hello`/`HelloAck` handshake and holding the
    connection open so `Lifecycle` events can be pushed to it later.
- **`libs/nova-svcmgr`** — Day 6's crate, unchanged except for three
  new read-only accessor methods (`process_list`, `process_info`,
  `process_uptime`) that expose the `ProcessManager` instance
  `ServiceManager` already owns. Added because the Day 13 DoD
  specifically requires cross-checking Process Manager's view, not
  just Service Manager's — without these, `nova-app-manager` would
  have had to keep a second, parallel `ProcessManager`, which is
  exactly the kind of disconnected-state bug this whole integration
  phase is trying to eliminate.
- **`libs/nova-procmgr`, `libs/nova-fsmgr`, `libs/nova-ipc`** — carried
  forward unchanged from Day 10 (M4) and Day 12 respectively.
- **`tools/nova-day13-test-app`** — a minimal *real* app: discovers
  the App Manager (Day 12's `discover`), does the actual `Hello`
  handshake, then reports whatever `Lifecycle` events it receives
  until `Terminate`, exiting cleanly on its own. Standing in for one
  of the five real apps, deliberately simpler — same rationale Day
  17's own hello-world app documents.
- **`tools/nova-day13-lifecycle-test`** — the literal Day 13 DoD as a
  live demonstration: launches the test app through App Manager,
  waits for its real `Hello` handshake, then backgrounds, foregrounds,
  and terminates it — checking `ProcessManager`'s process list *and*
  `ServiceManager`'s status at every step, not just App Manager's own
  bookkeeping.

## A real design point worth understanding before running this

After `terminate()`, `ServiceManager::stop` removes the service's
`running` entry entirely — so `service_status()` reports
`NotStarted`, not `Stopped` (that variant exists for other cases in
`nova-svcmgr`, but `stop()`'s own cleanup bypasses it). Meanwhile
`ProcessManager::list()` **does** still show the pid, now with state
`Terminated`, because Day 2's `ProcessManager` deliberately never
forgets a process it tracked. Both are correct, honest views —
they just represent "the app is gone" from two different layers'
perspectives — but it's worth knowing going in, so it doesn't read as
a bug when `service_status()` and `process_list()` don't say the
exact same word.

## What genuinely has NOT been done in this delivery

- Nothing has been compiled. There is a real chance of a
  dependency-resolution, borrow-checker, or type error here that a
  clean `cargo build --workspace` would catch immediately — this
  crate does real thread-sharing (`Arc<Mutex<Inner>>`,
  `Arc<SeqPacketSocket>` shared between the accept-loop reader and
  the launch/foreground/background/terminate callers), which is
  exactly the kind of code most likely to have a mistake that only
  shows up at compile time or under real concurrency.
- `nova-day13-test-app`'s connection has not been exercised.
- No existing app (nova-settings, nova-contacts, nova-messages) has
  been migrated to launch through this App Manager — that's Day 16's
  explicit job ("reconcile the existing Wayland apps against the new
  stack"), not skipped here by omission.
- **Env-injection gap surfaced, not silently worked around forever**:
  the IPC spec says every launched app gets `NOVA_CONTROL_SOCK` in its
  environment; `nova-procmgr::spawn` doesn't currently set per-child
  env vars at all. `nova-day13-test-app` sidesteps this by calling
  `discover("app-manager")` itself instead of reading an env var. This
  works today because there's exactly one App Manager socket
  system-wide, but real per-child env injection into
  `nova-procmgr::spawn` is real, identifiable follow-up work, not
  something this package pretends is already solved.

## Recommended next steps, in order

1. `cargo build --workspace` — confirm everything above actually
   compiles, including the new `nova-app-manager` crate's
   `Arc<Mutex<..>>`/`Arc<SeqPacketSocket>` sharing.
2. `cargo test -p nova-svcmgr` — confirm Day 6's existing tests still
   pass unchanged (the Day 13 additions are read-only and shouldn't
   affect any of them).
3. `sudo ./target/debug/nova-day13-lifecycle-test` (or via
   `nova-day13-build_and_run.sh`, which does both of the above first)
   — confirm the live launch → background → foreground → terminate
   sequence actually works end to end, cross-checked against real
   Process/Service Manager state at each step.
4. Only after all three pass, consider Day 13 actually complete — per
   the same discipline Day 10 and Day 12's packages established.

## Next: Day 14

Per the Guide's M5 table, Day 14 continues M5 — formalizing the
`nova-app.toml` manifest schema (id, name, version, entry point,
permissions) as a documented spec, and validating manifests through
M4's Configuration subsystem's validation path (Day 8) instead of ad
hoc per-app parsing. Day 13's `AppRegistry` (currently a bare
in-memory `HashMap<String, AppDef>` built by whatever's driving this
crate) is the exact seam Day 14's manifest loader should replace.
