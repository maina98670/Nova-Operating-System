#!/bin/bash
# Nova OS -- Day 13: Application lifecycle via M4's Process/Service Manager (M5)
# Requires root (writes a real socket into /run/nova, same requirement
# as Days 4/11/12's live tests). No cross-compilation, no QEMU needed.
# NOTE: this package was assembled without running any tests or builds
# in the environment that created it -- run this script yourself to
# verify everything below actually works.
set -e

echo "=== Nova OS Day 13: Application lifecycle via M4's Process/Service Manager ==="

echo "[1/3] Building the whole workspace first (the lifecycle test needs its"
echo "      sibling nova-day13-test-app binary to already exist alongside it)..."
cargo build --workspace

echo "[2/3] Running nova-svcmgr's test suite (existing Day 6 tests, unchanged --"
echo "      the Day 13 additions are read-only accessor methods with no new"
echo "      state, so no new svcmgr unit tests were required or added)..."
cargo test -p nova-svcmgr

echo "[3/3] Running the live Day 13 Definition of Done test..."
echo "NOTE: this writes a real socket into /run/nova and needs root."
sudo ./target/debug/nova-day13-lifecycle-test || ./target/debug/nova-day13-lifecycle-test

echo ""
echo "App Manager library: libs/nova-app-manager (see its module docs for what"
echo "'on top of Process/Service Manager' means concretely)."
