//! Day 13's Definition of Done, run for real -- no mocks, no
//! in-memory simulation of Process/Service Manager:
//!
//! "Launching, backgrounding, and terminating a test app all show up
//!  correctly in M4's Process Manager process list and Service
//!  Manager status, not just in App Manager's own internal state."
//!
//! Structure mirrors Day 11/12's live tools: one process, a real
//! `SOCK_SEQPACKET` socket, a real spawned child process (this time
//! via nova-app-manager -> nova-svcmgr -> nova-procmgr, not raw
//! fork/exec) -- and this time, the child is itself a real IPC client
//! (`nova-day13-test-app`) completing a real `Hello` handshake, not
//! just a `sleep` standing in for "some process."
//!
//! Requires root (writes a real socket into /run/nova, same
//! requirement Day 4/11/12's live tests already established).

use nova_app_manager::{AppDef, AppManager};
use nova_procmgr::ProcessState;
use nova_svcmgr::ServiceStatus;
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const APP_ID: &str = "org.nova.day13test";

fn fail(msg: &str) -> ! {
    eprintln!("nova-day13-lifecycle-test: FAIL -- {msg}");
    process::exit(1);
}

/// Locates the sibling `nova-day13-test-app` binary cargo already
/// built into the same `target/debug` directory as this binary --
/// same "spawn a real sibling process" approach as spawning `sleep`/
/// `true` in Days 2-10's own tests, just pointed at a real Nova app
/// instead of a coreutils binary.
fn find_test_app_binary() -> std::path::PathBuf {
    let mut path = std::env::current_exe().unwrap_or_else(|e| fail(&format!("current_exe failed: {e}")));
    path.pop(); // drop this binary's own filename
    path.push("nova-day13-test-app");
    if !path.exists() {
        fail(&format!(
            "expected sibling binary at {} -- build the whole workspace first (cargo build), not just this crate",
            path.display()
        ));
    }
    path
}

fn process_state_for(app_manager: &AppManager, pid: u32) -> Option<ProcessState> {
    app_manager.process_list().into_iter().find(|p| p.pid == pid).map(|p| p.state)
}

fn main() {
    println!("=== Nova OS Day 13: Application lifecycle via M4's Process/Service Manager ===");

    if let Err(e) = nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN]) {
        fail(&format!("could not ensure {} exists: {e} (are you running as root?)", nova_fsmgr::paths::RUN));
    }

    let app_manager = AppManager::new();
    app_manager.register_app(AppDef {
        id: APP_ID.to_string(),
        name: "Day 13 Test App".to_string(),
        command: find_test_app_binary().to_string_lossy().to_string(),
        args: vec![APP_ID.to_string()],
    });

    println!("[1/6] Starting App Manager's IPC listener on {}...", nova_ipc::SOCKET_PATH);
    let _server = app_manager.serve(nova_ipc::SOCKET_PATH).unwrap_or_else(|e| fail(&format!("serve() failed: {e}")));
    thread::sleep(Duration::from_millis(100));

    println!("[2/6] Launching '{APP_ID}' through ServiceManager::start (not raw fork/exec)...");
    let pid = app_manager.launch(APP_ID).unwrap_or_else(|e| fail(&format!("launch failed: {e}")));
    println!("      -> real PID from ProcessManager::spawn: {pid}");

    // Wait for the real Hello handshake to complete (the app process
    // has to actually start and connect -- not instantaneous).
    println!("[3/6] Waiting for the test app's real Hello handshake to complete...");
    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        if app_manager.cold_start_ms(APP_ID).is_some() {
            break;
        }
        if Instant::now() >= deadline {
            fail("test app never completed its Hello handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    let cold_start = app_manager.cold_start_ms(APP_ID).unwrap();
    println!("      -> cold start: {cold_start}ms, sourced from ServiceManager::process_uptime (Process Manager's own spawn timestamp), not the app's self-report");

    // --- Cross-check #1: launch ---
    println!("[4/6] Cross-checking launch against M4's Process Manager and Service Manager...");
    match process_state_for(&app_manager, pid) {
        Some(ProcessState::Running) | Some(ProcessState::Sleeping) => {
            println!("      -> Process Manager process list: pid {pid} is Running/Sleeping (correct)");
        }
        other => fail(&format!("expected pid {pid} Running/Sleeping in Process Manager's list, got {other:?}")),
    }
    match app_manager.service_status(APP_ID) {
        ServiceStatus::Running => println!("      -> Service Manager status: Running (correct)"),
        other => fail(&format!("expected Service Manager status Running, got {other:?}")),
    }
    match app_manager.lifecycle_state(APP_ID) {
        Some(nova_app_manager::AppLifecycleState::Foreground) => {
            println!("      -> App Manager's own state: Foreground (correct, newly launched)")
        }
        other => fail(&format!("expected App Manager state Foreground, got {other:?}")),
    }

    // --- Cross-check #2: background ---
    println!("[5/6] Backgrounding '{APP_ID}' and cross-checking the process was NOT touched...");
    app_manager.background(APP_ID).unwrap_or_else(|e| fail(&format!("background() failed: {e}")));
    thread::sleep(Duration::from_millis(150));
    match app_manager.lifecycle_state(APP_ID) {
        Some(nova_app_manager::AppLifecycleState::Background) => println!("      -> App Manager's own state: Background (correct)"),
        other => fail(&format!("expected App Manager state Background, got {other:?}")),
    }
    match process_state_for(&app_manager, pid) {
        Some(ProcessState::Running) | Some(ProcessState::Sleeping) => {
            println!("      -> Process Manager process list: pid {pid} still Running/Sleeping (backgrounding did not kill it -- correct)")
        }
        other => fail(&format!("backgrounding should not change Process Manager state, got {other:?}")),
    }
    match app_manager.service_status(APP_ID) {
        ServiceStatus::Running => println!("      -> Service Manager status: still Running (correct)"),
        other => fail(&format!("expected Service Manager status still Running after backgrounding, got {other:?}")),
    }

    println!("      Foregrounding back...");
    app_manager.foreground(APP_ID).unwrap_or_else(|e| fail(&format!("foreground() failed: {e}")));
    thread::sleep(Duration::from_millis(100));
    match app_manager.lifecycle_state(APP_ID) {
        Some(nova_app_manager::AppLifecycleState::Foreground) => println!("      -> App Manager's own state: Foreground again (correct)"),
        other => fail(&format!("expected App Manager state Foreground after foregrounding, got {other:?}")),
    }

    // --- Cross-check #3: terminate ---
    println!("[6/6] Terminating '{APP_ID}' via ServiceManager::stop (-> ProcessManager::terminate)...");
    app_manager.terminate(APP_ID).unwrap_or_else(|e| fail(&format!("terminate() failed: {e}")));
    thread::sleep(Duration::from_millis(200));
    match process_state_for(&app_manager, pid) {
        Some(ProcessState::Terminated) => {
            println!("      -> Process Manager process list: pid {pid} is Terminated (correct -- still queryable, not silently forgotten)")
        }
        other => fail(&format!("expected pid {pid} Terminated in Process Manager's list after terminate, got {other:?}")),
    }
    match app_manager.service_status(APP_ID) {
        ServiceStatus::NotStarted => {
            println!("      -> Service Manager status: NotStarted (correct -- stop() removes the running entry, so it's not lingering as Running)")
        }
        other => fail(&format!("expected Service Manager status NotStarted after terminate, got {other:?}")),
    }
    if app_manager.lifecycle_state(APP_ID).is_some() {
        fail("App Manager's own runtime state should have been cleared after terminate");
    }
    println!("      -> App Manager's own state: cleared (correct)");

    let _ = std::fs::remove_file(nova_ipc::SOCKET_PATH);

    println!();
    println!("nova-day13-lifecycle-test: PASS -- Day 13 Definition of Done satisfied end-to-end");
    println!("nova-day13-lifecycle-test: launch/background/foreground/terminate all went through");
    println!("nova-day13-lifecycle-test: M4's real Process Manager and Service Manager, and every");
    println!("nova-day13-lifecycle-test: state change was cross-checked against both, not just");
    println!("nova-day13-lifecycle-test: App Manager's own internal bookkeeping.");
}
