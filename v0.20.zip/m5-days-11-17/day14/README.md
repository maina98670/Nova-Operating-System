# Nova OS — Day 14 Package: Package Manifest + Permission Declarations

Per the Complete Build Guide, Day 14 formalizes the `nova-app.toml`
manifest schema (id, name, version, entry point, permissions) as a
documented spec, and validates manifests through M4's Configuration
subsystem's validation path (`nova-config`, Day 8) rather than a
second, ad hoc parser living in App Manager.

**This package was assembled without running any tests or builds**,
per instruction — nothing below has been compiled or verified in this
pass. Run `nova-day14-build_and_run.sh` yourself to actually confirm
it.

## Starting point: Day 13's `AppDef` was a manifest-free stand-in

Day 13 explicitly deferred manifests: `AppRegistry` was a minimal
in-memory map from `app_id` to a hand-built `AppDef`, populated by
calling `register_app` directly — there was no manifest file on disk
anywhere, and no parsing/validation of one. Day 14 is where that
stand-in gets replaced with the real thing.

## What's in this package

- **`libs/nova-app-manager/src/manifest.rs`** (new) — the
  `nova-app.toml` schema as an `AppManifest` struct, and
  `load_manifest()`:
  - Required fields (`id`, `name`, `version`, `entry_point`) have no
    `#[serde(default)]`, so a manifest missing any of them fails to
    deserialize — caught by `nova_config::load`, the exact same
    malformed-file error Day 8 already built and tested, not a new
    one.
  - `required_permissions`/`optional_permissions` are permission
    *names* (strings), checked against `nova_ipc::Permission`'s fixed,
    closed set via `validate_permissions()` — a second pass this crate
    runs after the parse succeeds, since a bad permission name is
    syntactically valid TOML and `serde` alone can't catch it.
  - `load_manifest()` runs both passes and is the single function both
    `install()` and `launch()` call — one validation path, not two
    that could drift apart.
- **`libs/nova-app-manager/src/lib.rs`** (modified from Day 13):
  - `install(app_id)`: loads+validates
    `<APPS>/<app_id>/nova-app.toml`, converts the manifest to an
    `AppDef`, and registers it. Only registers on full success.
  - `launch(app_id)` now calls `install()` itself first if the app
    isn't already registered *and* a manifest exists on disk for it —
    an app_id with no manifest and no prior registration still fails
    with the plain Day 13 `UnknownApp`, so that error stays legible
    for "this app doesn't exist" rather than being replaced by a
    manifest I/O error.
  - `register_app` (Day 13's manifest-free path) is unchanged, kept
    for tests/tools that want to hand-build an `AppDef`.
- **`libs/nova-config`** — Day 8's crate, carried forward unchanged
  from `v0_13`. This package's whole point is reusing it, not
  reimplementing it.
- **`libs/nova-fsmgr`, `libs/nova-ipc`, `libs/nova-procmgr`,
  `libs/nova-svcmgr`** — carried forward unchanged from Day 13.
- **`docs/nova-app-toml-v1.md`** — the documented package-format spec,
  Section 23's first draft: full schema table, the permission-name
  list, an example manifest, and an explicit list of what Day 14 does
  *not* yet validate (entry-point existence, signatures, id/directory
  mismatches — later days' jobs, named so they don't get assumed done).
- **`tools/nova-day13-test-app`** — Day 13's minimal real app, carried
  forward unchanged, reused here as the thing a well-formed manifest's
  `entry_point` actually launches.
- **`tools/nova-day14-manifest-test`** — the live Day 14 DoD: writes
  three real manifests under `/apps/` (well-formed, missing
  `entry_point`, unknown permission `"bluetooth"`), then checks all
  three at **both** `install()` and `launch()` — proving the same
  validation path fires at both call sites the DoD names — and
  launches the well-formed one end-to-end through a real `Hello`/
  `HelloAck` handshake, so "installs" means "genuinely launchable,"
  not just "parsed."

## What genuinely has NOT been done in this delivery

- Nothing has been compiled. `manifest.rs`'s `serde` derive, the new
  `AppManagerError::Manifest` variant and its `From<ManifestError>`
  impl, and the borrow/lock pattern in `launch()`'s lazy-install check
  are exactly the kind of thing a clean `cargo build --workspace`
  would catch immediately if there's a mistake.
- `nova-day14-manifest-test` has not been run. It needs root (real
  `/apps` and `/run/nova` writes) exactly like Day 13's live test did.
- `entry_point` existence/executability is not checked at manifest
  load time — an app with a manifest pointing at a nonexistent binary
  will still pass `install()` and only fail later, at
  `ServiceManager::start`, same as Day 13's behavior for a bad
  `AppDef.command`. Noted in `docs/nova-app-toml-v1.md` as an open
  item, not silently assumed handled.
- No sandbox enforcement of declared permissions — Day 15's job.
- Settings/Contacts/Messages/Dialer/Camera do not yet have
  `nova-app.toml` bundles produced by this delivery — Day 16's job.
