#!/bin/bash
# Nova OS -- Day 14: Package manifest + permission declarations (M5)
# Requires root (writes real manifests into /apps and a real socket
# into /run/nova, same requirement as Days 4/11/12/13's live tests).
# No cross-compilation, no QEMU needed.
# NOTE: this package was assembled and NOT built or tested in the
# environment that produced it -- run this script yourself to verify
# everything below actually works.
set -e

echo "=== Nova OS Day 14: Package manifest + permission declarations ==="

echo "[1/3] Building the whole workspace first (the manifest test needs its"
echo "      sibling nova-day13-test-app binary to already exist alongside it)..."
cargo build --workspace

echo "[2/3] Running nova-app-manager's test suite (Day 13's existing lifecycle"
echo "      tests, plus Day 14's new manifest-parsing/validation unit tests)..."
cargo test -p nova-app-manager

echo "[3/3] Running the live Day 14 Definition of Done test..."
echo "NOTE: this writes real manifests into /apps and a real socket into"
echo "/run/nova, and needs root."
sudo ./target/debug/nova-day14-manifest-test || ./target/debug/nova-day14-manifest-test

echo ""
echo "Manifest schema + loader: libs/nova-app-manager/src/manifest.rs"
echo "Documented spec (first draft): docs/nova-app-toml-v1.md"
