# Day 15 Change Log

Base: `nova-day14-package.zip`

1. Added `nova-sandbox` capability and scoped-storage crate.
2. Extended `AppDef` with required/optional permission sets.
3. Extended app runtime state with a `SandboxPolicy`.
4. Required permissions are granted at launch; optional permissions require
   a runtime request.
5. `PermissionRequest` is now enforced instead of ignored.
6. Added `AppManager::check_permission()` and `granted_permissions()`.
7. Added security-denial logging through `nova-fsmgr`.
8. Added Day 15 live acceptance tool and build script.
9. Added the Day 15 sandbox specification.

M10 security hardening remains intentionally separate.
