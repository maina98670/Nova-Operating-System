# Nova OS — Day 15 Package: Sandbox Boundaries

This package continues directly from the Day 14 package.

## Day 15 goal

The Complete Build Guide requires Day 15 to turn manifest-declared permissions
into actual runtime enforcement, define a concrete sandbox boundary, and prove
that an app requesting an undeclared permission is blocked and the attempt is
logged.

The guide explicitly leaves full namespace/seccomp hardening to M10. This
package therefore implements the Day 15 minimum boundary rather than claiming
to have completed M10 security.

## What's new

- `libs/nova-sandbox/`
  - `PermissionSet`
  - `SandboxPolicy`
  - runtime required/optional permission handling
  - protected-resource gates including camera
  - per-app scoped filesystem paths under `/var/lib/nova/apps/<app-id>/`
  - traversal/absolute-path rejection
- `nova-app-manager`
  - carries required/optional permissions from the validated manifest
  - grants required permissions at launch
  - keeps optional permissions ungranted until a valid runtime request
  - answers resource permission checks through the sandbox policy
  - handles `PermissionRequest` instead of ignoring it
  - logs denied permission attempts to `/var/log/nova/security.log`
  - returns granted permissions in `HelloAck`
- `docs/nova-sandbox-v1.md`
  - Day 15 sandbox/permission specification
- `tools/nova-day15-sandbox-test`
  - live acceptance test for permission denial/grant and filesystem scoping
- `nova-day15-build_and_run.sh`
  - workspace build followed by Day 15 acceptance

## Important boundary

This is **not** the final security system. M10 is still responsible for
kernel-level namespace/seccomp isolation, stronger process identity, secure IPC,
package signing, and the full security audit.

## Run

```bash
./nova-day15-build_and_run.sh
```

The live test uses Nova's standard `/apps`, `/run/nova`, and `/var/log/nova`
paths, so it needs the same root-capable Linux environment used by the earlier
live tests.

## Status

This delivery contains the Day 15 implementation and tests. The package should
still be treated as **unverified until `cargo build --workspace` and the live
acceptance script actually pass** on the target Linux environment.
