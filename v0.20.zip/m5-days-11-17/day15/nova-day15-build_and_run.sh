#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 15: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 15: live acceptance ==="
echo "The live acceptance uses /apps, /run/nova and /var/log/nova and therefore"
echo "needs the same root-capable Linux environment used by earlier live tests."
cargo run -p nova-day15-sandbox-test

echo
echo "Day 15 build + acceptance completed."
