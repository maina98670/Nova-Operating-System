# Day 16 Change Log

Base: `nova-day15-package.zip`

Confirmed against every upload in this track (Days 11–15, `v0_13.zip`,
`V0_07.zip`, and `nova-os-m5-package.zip`) that no source exists for
Settings/Contacts/Messages/Dialer/Camera. Built for real instead of
reconciled, scoped to functional core only (no UI — that's M7).

1. Added `libs/nova-app-storage` — `ScopedStorage` trait over
   `nova-sandbox`'s per-app filesystem scoping, with `SandboxStorage`
   (production) and `MemStorage` (unit tests) backends.
2. Added `libs/nova-contacts-core` — contact CRUD + search.
3. Added `libs/nova-messages-core` — SMS send/receive, threading,
   read/unread, `SmsTransport` seam (`StubTransport` — no SMS HAL yet,
   M9).
4. Added `libs/nova-dialer-core` — call log, recent/missed/history,
   `TelephonyBackend` seam (`StubTelephony` — no cellular HAL yet, M9).
5. Added `libs/nova-camera-core` — photo library metadata + capture,
   `CameraBackend` seam (`StubBackend` — `nova-v4l2` untested against
   real hardware, HAL work is M9).
6. Added `libs/nova-settings-core` — typed, validated key-value store
   over a fixed setting registry.
7. Refactored `libs/nova-app-runtime`: split `run_minimal_app` into
   `connect_and_handshake` + `idle_until_terminate` so each app can run
   real domain logic between the handshake and the idle loop.
8. Rewrote `apps/org.nova.{settings,contacts,messages,dialer,camera}`'s
   `main.rs` to build a local `SandboxPolicy`, load the matching core
   store, run a real demo of that app's logic each launch, then idle.
9. Updated the workspace `Cargo.toml` with the new lib/app members.
10. `tools/nova-day16-reconciliation-test` unchanged — still exercises
    install → launch → handshake → permission check → M4 cross-check →
    terminate against these now-real apps.

Each core crate carries its own unit test suite against
`nova-app-storage::MemStorage`, runnable without root or a real
filesystem:

```
cargo test -p nova-contacts-core -p nova-messages-core -p nova-dialer-core -p nova-camera-core -p nova-settings-core
```

Known gaps: no UI (M7), no real hardware backends (M9), no
delete-scoped storage API (photo deletion orphans the frame file),
and the apps' local `SandboxPolicy` checks are defense-in-depth only —
real sandbox enforcement is still M10's job. See README for detail.

Day 17 (full M5 acceptance across everything built Days 11–16, tag) is
next.
