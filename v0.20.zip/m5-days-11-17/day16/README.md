# Nova OS — Day 16 Package: Reconcile the Existing Wayland Apps Against the New Stack

This package continues directly from the Day 15 package.

**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day16-build_and_run.sh` yourself to actually confirm it.

## Where this landed, honestly

Every upload available across this whole track (Days 11–15, `v0_13.zip`/
`V0_07.zip`, and the separate `nova-os-m5-package.zip`) was checked, and
none of them contain Settings/Contacts/Messages/Dialer/Camera. Per the
Complete Build Guide, those five apps were built in an earlier session,
before M4 existed — that session's source was never uploaded to this
track. So there is nothing to reconcile against; this package **builds
the five apps for real**, as a first implementation, not a reconciliation
of pre-existing code.

Scope agreed for this pass: **functional core only** — real data
models, CRUD, and domain logic for each app, persisted through Day 15's
per-app sandbox-scoped storage. No Wayland UI (that's M7's job). Folded
directly into Day 16, replacing the earlier protocol-only stand-ins.

## What each app actually does now

- **Contacts** (`nova-contacts-core`) — add/remove/search contacts,
  favorites, case-insensitive search by name or number. Persists to
  `contacts.json` under this app's scoped storage.
- **Messages** (`nova-messages-core`) — send/receive SMS, threaded by
  peer number, read/unread tracking. Sending goes through an
  `SmsTransport` trait; `StubTransport` is used because no cellular/SMS
  HAL exists yet (that's M9's job per the guide) — this is the real
  seam a modem HAL plugs into later, not a fake success path dressed up.
- **Dialer** (`nova-dialer-core`) — call log (outgoing/incoming/missed),
  recent calls, per-number history. Placing a call goes through a
  `TelephonyBackend` trait; `StubTelephony` stands in for the same
  reason (no cellular HAL yet). `nova_ipc::Permission`'s fixed set has
  no telephony permission, so Dialer is scoped to `contacts` only for
  now.
- **Camera** (`nova-camera-core`) — photo library metadata, capture
  through a `CameraBackend` trait. `StubBackend` returns a deterministic
  placeholder frame because `nova-v4l2` has never been compiled or
  tested against real hardware (the guide's own note) — Camera HAL
  integration is M9's job.
- **Settings** (`nova-settings-core`) — a typed, validated key-value
  store over a fixed registry (`display_brightness`, `ringer_volume`,
  `language`, `wifi_enabled`, `do_not_disturb`). Rejects unknown keys
  and out-of-range/wrong-type values.

Each core crate is unit-tested on its own (`cargo test -p nova-*-core`),
against an in-memory storage backend (`nova-app-storage::MemStorage`) —
no root or real filesystem needed for that.

## What's new

- `libs/nova-app-storage` — a `ScopedStorage` trait wrapping
  `nova-sandbox`'s per-app filesystem scoping, plus `SandboxStorage`
  (production) and `MemStorage` (unit tests) backends.
- `libs/nova-contacts-core`, `nova-messages-core`, `nova-dialer-core`,
  `nova-camera-core`, `nova-settings-core` — the five functional cores
  above, each with its own unit test suite.
- `libs/nova-app-runtime` — refactored: `connect_and_handshake` (Hello/
  HelloAck/PermissionRequest) and `idle_until_terminate` (Lifecycle
  loop) are now separate calls, so each app can run its own domain
  logic in between instead of the handshake owning the whole lifecycle.
- `apps/org.nova.{settings,contacts,messages,dialer,camera}` — each
  app's `main.rs` now: does the handshake, builds a local
  `SandboxPolicy` matching its manifest (defense-in-depth permission
  check before touching its store), loads its core store against
  sandbox-scoped storage, runs a real demo of its own logic each
  launch (seed/search contacts, send+receive a message, place+log a
  call, capture a photo, read/validate/reset a setting), then idles
  until told to terminate.
- `tools/nova-day16-reconciliation-test/` — unchanged in behavior:
  installs manifests, launches all five apps through App Manager,
  checks the IPC handshake + permission grants, cross-checks against
  M4's Process Manager, terminates and confirms cleanup. Still passes
  the exact same acceptance criteria against these now-real apps.
- `nova-day16-build_and_run.sh`, workspace `Cargo.toml` updated with
  eleven new members (six libs + five apps already existed as crates,
  now with real implementations).

## Permission sets (unchanged from the earlier stand-in pass)

| App | Required | Optional |
|---|---|---|
| Settings (`org.nova.settings`) | `storage` | `network` |
| Contacts (`org.nova.contacts`) | `contacts`, `storage` | — |
| Messages (`org.nova.messages`) | `sms`, `contacts`, `storage` | `network` |
| Dialer (`org.nova.dialer`) | `contacts` | — |
| Camera (`org.nova.camera`) | `camera`, `storage` | — |

## Known gaps, stated plainly

- **No UI.** These are functional cores only, per the agreed scope.
  Wayland rendering is M7.
- **No real hardware backends.** Messages/Dialer/Camera each define a
  trait seam (`SmsTransport`/`TelephonyBackend`/`CameraBackend`) with
  only a stub implementation, because the cellular and camera HALs
  don't exist yet (M9). Swapping in a real implementation later should
  not require touching the core crates' public API.
- **No delete-scoped storage API.** `nova-sandbox`'s Day 15 scope was
  read/write only; `PhotoLibrary::delete` removes the index entry but
  leaves the underlying frame file orphaned. Worth a real
  delete-scoped API in a later day.
- **Local `SandboxPolicy` checks in each app are defense-in-depth, not
  the enforcement point.** App Manager already grants required
  permissions before spawning the process; the app rebuilding the same
  policy client-side and checking it again doesn't add real security
  (a malicious app could just skip the check) — that's still M10's
  kernel-level hardening to close, same caveat Day 15 already states.

## Run

```bash
./nova-day16-build_and_run.sh
```

Builds the workspace, then runs the Day 16 live acceptance test. Needs
the same root-capable Linux environment as the Days 11–15 live tests
(`/apps`, `/run/nova`, `/var/log/nova`).

To run just the new apps' own unit tests without the live/root-needing
parts:

```bash
cargo test -p nova-contacts-core -p nova-messages-core -p nova-dialer-core -p nova-camera-core -p nova-settings-core
```

## Status

Unverified until `cargo build --workspace`, the unit tests above, and
the live acceptance script actually pass — none of that was run in
this pass, per instruction.
