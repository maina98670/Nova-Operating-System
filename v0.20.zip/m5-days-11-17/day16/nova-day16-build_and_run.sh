#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 16: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 16: reconciliation acceptance ==="
echo "Installs and launches Settings/Contacts/Messages/Dialer/Camera through the"
echo "integrated App Manager. Uses Nova's standard /apps, /run/nova and"
echo "/var/log/nova paths, so it needs the same root-capable Linux environment"
echo "used by the Day 11-15 live tests."
cargo run -p nova-day16-reconciliation-test

echo
echo "Day 16 build + reconciliation acceptance completed."
