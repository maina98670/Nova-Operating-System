# Day 17 Change Log

Base: `nova-day16-package.zip`

1. Added `apps/org.nova.hello` — the Day 17 canonical M5 smoke test
   (Hello/HelloAck, a declared-optional permission grant, an
   undeclared-permission denial, all in one run). Checked
   `nova-os-m5-package.zip`'s existing `apps/nova-hello` for reuse;
   incompatible sandbox/manifest conventions (see README), so built
   fresh against this lineage's actual stack instead.
2. Added `tools/nova-day17-m5-acceptance-test` — the Roadmap's own M5
   acceptance test ("a packaged test application can launch,
   communicate through IPC and operate within its permissions") run
   live against `nova-hello`.
3. Appended an addendum to `libs/nova-ipc/protocols/nova-ipc-v1.md`:
   documents the undeclared-`PermissionRequest` behavior (Day 15
   enforcement, Day 17 live proof) and closes with an M5 acceptance
   summary.
4. Appended an addendum to `docs/nova-app-toml-v1.md`: documents the
   `<APPS>/<id>/bin/<binary>` convention now being exercised for real
   by the Day 16/17 live tests, plus its own M5 acceptance note.
5. Added `docs/M5-TAG.md` — the M5 (`v0.20`) tag writeup: what Days
   11–17 covered, the acceptance criterion, and the `git tag` command
   for Zeen's actual repo.
6. Added `nova-day17-build_and_run.sh` — builds the workspace, runs
   Day 16's reconciliation test and Day 17's own M5 acceptance test.
7. Updated the workspace `Cargo.toml` with the two new members.
8. Dropped `nova-day15-build_and_run.sh` from this delivery (per the
   established one-prior-day-script convention); kept
   `nova-day16-build_and_run.sh`.

M5 (Days 11–17) is complete pending the actual `cargo build --workspace`
and both live acceptance runs, which were not executed in this pass
per instruction. M6 (Nova SDK & Application Framework, Days 18–22) is
next.
