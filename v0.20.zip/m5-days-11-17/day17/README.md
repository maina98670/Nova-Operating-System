# Nova OS — Day 17 Package: Hello-World App, Full M5 Acceptance, Tag

This package continues directly from the Day 16 package. **Assembled
without running any tests or builds** — files only. Nothing below has
been compiled or verified in this pass. Run `nova-day17-build_and_run.sh`
yourself to actually confirm it.

## Day 17 goal

Per the Complete Build Guide:
1. Build (or reuse, if one already exists) a minimal Hello-world app —
   deliberately simpler than the five real apps, so failures point at
   the platform, not app-specific code.
2. Run the Roadmap's own M5 acceptance test: "a packaged test
   application can launch, communicate through IPC and operate within
   its permissions."
3. Document the IPC spec and package format properly, tag M5.

DoD: the Hello-world app installs from a package, launches through the
App Manager, exchanges at least one real IPC request/response, and is
blocked from an action outside its declared permissions — all in one
run.

## "Reuse, if one already exists" — checked, not reused

`nova-os-m5-package.zip` (the separate, earlier, parallel-track M5
package flagged in the Day 16 package) already contains
`apps/nova-hello`. It was not reused: it expects a
`NOVA_CONTROL_SOCK`/`NOVA_APP_ID` environment pair from a
namespace/chroot-based launcher, and a different manifest schema
(`[app]`/`[permissions]` sections, `entry` instead of `entry_point`) —
neither matches this lineage's `SOCKET_PATH` constant,
`SandboxPolicy`-based launch, or the `nova-app.toml` schema this track
actually built. `apps/org.nova.hello` here is fresh, built directly
against this lineage's real, current stack.

## What's new

- **`apps/org.nova.hello`** — the Day 17 smoke test. No core data
  model, no persistent storage (deliberately simpler than Day 16's
  five apps). One run: `Hello`/`HelloAck`, its own declared optional
  permission (`network`) requested and granted, then an *undeclared*
  permission (`camera` — not in its manifest at all) requested and
  denied by the real running App Manager. That sequence is the literal
  DoD: real IPC + blocked-outside-permissions, in one run.
- **`tools/nova-day17-m5-acceptance-test`** — the Roadmap's own M5
  acceptance test, live: installs `nova-hello`'s manifest, launches it
  through App Manager, waits for the handshake, checks App Manager's
  own granted-permissions bitmask (not the app's stdout) for both the
  granted and the denied case, cross-checks against M4's Process
  Manager, terminates, confirms cleanup.
- **Docs updated, not rewritten**: `libs/nova-ipc/protocols/nova-ipc-v1.md`
  gets a short addendum documenting the undeclared-`PermissionRequest`
  behavior (implemented Day 15, proven live Day 17) and an "M5
  acceptance" closing section. `docs/nova-app-toml-v1.md` gets a
  similar addendum on the `<APPS>/<id>/bin/<binary>` convention now
  being exercised for real by the Day 16/17 live tests, plus its own
  M5 acceptance note.
- **`docs/M5-TAG.md`** — the M5 tag (`v0.20`) writeup: what M5 covered
  Days 11–17, the acceptance criterion and how it's satisfied, and the
  literal `git tag` command for Zeen to run in his actual repo (this
  package is files only, not a git checkout).
- **`nova-day17-build_and_run.sh`** — builds the workspace, then runs
  Day 16's five-app reconciliation test *and* Day 17's own M5
  acceptance test, so "full M5 acceptance" covers both the minimal
  smoke test and the real application set.

## Run

```bash
./nova-day17-build_and_run.sh
```

Needs the same root-capable Linux environment as the Days 11–16 live
tests (`/apps`, `/run/nova`, `/var/log/nova`).

## Status

Unverified until the build and both live acceptance tests actually
pass — none of that was run in this pass, per instruction. If they
pass, `docs/M5-TAG.md` has the tag command to run in the real repo.
