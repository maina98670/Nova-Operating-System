# Nova OS — M6, Days 18–22 (Nova SDK & Application Framework, v0.27)

Each `dayNN/` folder is that day's package exactly as delivered. They
are **cumulative, not independent snapshots** — each day builds
directly on the previous day's files. If you only want one buildable
tree, use **`day22/`** — it contains everything from Days 11–21 plus
Day 22's own additions (the full M5 + M6 build).

Earlier days' folders are kept for the incremental history — each
day's own `README.md`/`DAYxx_CHANGELOG.md` explains what changed that
day and why, which is lost if you only keep the final state.

## Day-by-day

| Day | Folder | Focus |
|---|---|---|
| 18 | `day18/` | SDK scaffolding + project template (`nova create`/`nova build`, build folded install in at the time) |
| 19 | `day19/` | Window API (real, stubbed backend) + Input API (honest `NotYetAvailable`) |
| 20 | `day20/` | Storage API (real, sandboxed) + Networking API stub (honest `NotImplemented`) |
| 21 | `day21/` | Notifications API (real, local-only) + lifecycle callbacks (app-side layer over Day 13's already-real push mechanism) + runtime Permission API |
| 22 | `day22/` | Full toolchain split apart (`build`/`package`/`install`/`run`), developer guide, M6 tag (`v0.27`) |

## Status

**None of this has been built or tested in this pass**, per
instruction throughout Days 18–22's assembly. Each `dayNN/` has its
own `nova-dayNN-build_and_run.sh` — run the one in `day22/` to build
and verify the full, cumulative result, including the live
`create → build → package → install → run` acceptance test.

See `day22/docs/M6-TAG.md` for the M6 tag write-up and the actual
`git tag` command for your own repository, and
`day22/docs/application-developer-guide-v1.md` for the application
developer guide this milestone produced.
