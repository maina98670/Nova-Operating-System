# Day 18 Change Log

Base: `nova-day17-package.zip` (M5, tagged `v0.20`). First day of M6.

1. Added `tools/nova-cli` (`nova` binary) — `create.rs` (scaffolding +
   auto-detected/`--libs-path` relative-path computation),
   `build.rs` (cargo build + copy to `<apps-dir>/<id>/`),
   `template.rs` (the four generated files' content).
2. Added `tools/nova-day18-scaffold-acceptance-test` — real
   subprocess-driven `nova create` + `nova build`, then install/launch
   through App Manager, matching Day 16/17's live-test pattern.
3. Added `docs/nova-sdk-template-v1.md` — template structure
   reference, including two named limitations (fragile path
   dependency; untested Cargo workspace-resolution risk).
4. Updated the workspace `Cargo.toml` with the two new tool members.

Checked and flagged rather than glossed over: the generated app's
`Cargo.toml` path-depends on `nova-app-runtime`/`nova-ipc`, both
explicit members of this repo's own workspace — a known class of
Cargo workspace-resolution conflict that hasn't been exercised against
a real `cargo build` in this pass. See README/doc for detail; test
this first if picking the work back up.

Day 19 (Window API + Input API) is next.
