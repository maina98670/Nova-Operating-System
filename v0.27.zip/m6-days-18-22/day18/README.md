# Nova OS — Day 18 Package: SDK Scaffolding + Project Template

This package continues directly from the Day 17 package (M5, tagged
`v0.20`). This is the first day of **M6 — Nova SDK & Application
Framework (v0.27)**.

**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day18-build_and_run.sh` yourself to actually confirm it.

## Day 18 goal

Per the Complete Build Guide:
1. `nova create my_app` — generates a working, buildable skeleton app
   (manifest, entry point, minimal window) from one command.
2. Document the template's structure so a third-party developer (even
   a future you) doesn't have to read App Manager source to understand
   it.

DoD: `nova create test_app` followed by `nova build` (stubbed if
needed) produces a package that installs and launches, with zero
manual edits to generated files.

## What's new

- **`tools/nova-cli`** — the `nova` binary. Two subcommands:
  - `nova create <name>` — generates `Cargo.toml` (standalone crate,
    empty `[workspace]`, path deps on `nova-app-runtime`/`nova-ipc`),
    `nova-app.toml` (required `storage`, matching the manifest schema
    from Day 14), `src/main.rs` (handshake + idle loop, with an
    explicit, honest "no window yet" print instead of a fake one —
    see below), and a per-app `README.md`.
  - `nova build <path>` — `cargo build`s the generated crate, then
    copies the binary + manifest to `<apps-dir>/<id>/`, matching the
    layout Days 16–17 already established. Folds build+install
    together; `nova package`/`install`/`run` as separate commands are
    Day 22's job — this is the "stubbed if needed" the DoD explicitly
    allows.
- **`tools/nova-day18-scaffold-acceptance-test`** — runs `nova create
  test_app` and `nova build test_app` as real subprocesses (not
  reimplemented in-process), touches nothing in between, then
  installs and launches the result through App Manager exactly as
  Day 16/17's tools do for the real apps — the literal DoD, live.
- **`docs/nova-sdk-template-v1.md`** — the template reference doc:
  what each generated file contains and why, plus two named
  limitations (see below).

## "Minimal window" — what's actually there

The Window API doesn't exist until Day 19, and real Wayland rendering
is M7's job. A generated app today has nothing to draw. Rather than
fake a window, the generated `main.rs` prints an explicit line saying
so. This is the same honesty-first pattern the five real apps and
`nova-hello` already use for their own missing pieces (no cellular
HAL, no camera HAL, etc.).

## Known limitations — read before relying on `nova build`

1. **The `path = "..."` dependency is fragile.** `nova-app-runtime`/
   `nova-ipc` aren't published anywhere; a generated app depends on
   them via a relative path computed at `create` time. Move the
   generated folder afterward and the path breaks — fix the two
   `path = "..."` lines by hand.
2. **Untested Cargo workspace-resolution risk.** `nova-app-runtime`
   and `nova-ipc` are explicit members of this repo's own root
   workspace. Cargo has a known "current package believes it's in a
   workspace when it's not" error that *can* trigger when an external
   crate path-depends on a crate that's already a member of another
   workspace, depending on Cargo version and layout. The generated
   `Cargo.toml`'s empty `[workspace]` table addresses the more common
   failure mode (accidental absorption into an ancestor workspace) but
   does **not** provably rule this one out — it hasn't been checked
   against a real `cargo build`, per the "no testing" instruction this
   whole day was built under. Run `nova-day18-build_and_run.sh` for
   real before trusting this; `docs/nova-sdk-template-v1.md` has the
   full writeup.

## Run

```bash
./nova-day18-build_and_run.sh
```

Needs the same root-capable Linux environment as the Days 11–17 live
tests (`/apps`, `/run/nova`, `/var/log/nova`).

Try it directly once built:

```bash
./target/debug/nova create my_app
./target/debug/nova build my_app
```

## Status

Unverified until the build and the live acceptance test actually
pass — none of that was run in this pass, per instruction. The Cargo
workspace-resolution risk above is the most likely thing to surface
first if it doesn't.
