//! Camera — Day 16 reconciliation.
//!
//! Connects through App Manager's Hello/HelloAck/PermissionRequest
//! handshake (`nova-app-runtime`), then runs `nova-camera-core`'s real
//! functional core against this app's own sandbox-scoped storage. No
//! real camera HAL exists yet -- `nova-v4l2` has never been compiled
//! or tested against real hardware, and Camera HAL integration is
//! M9's job -- so capture goes through `StubBackend` -- see
//! `nova-camera-core`'s module docs. See `libs/nova-app-runtime`'s
//! module docs for what this binary is (a from-scratch,
//! protocol-correct client) and is not (a preserved copy of any
//! pre-existing Camera implementation, whose source was not part of
//! this Day 16 upload).

use nova_app_storage::SandboxStorage;
use nova_camera_core::{PhotoLibrary, StubBackend};
use nova_ipc::Permission;
use nova_sandbox::{PermissionSet, SandboxPolicy};
use std::time::{SystemTime, UNIX_EPOCH};

const APP_ID: &str = "org.nova.camera";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }

    // Matches this app's nova-app.toml (required = camera, storage).
    let policy = SandboxPolicy::new(
        APP_ID,
        PermissionSet::from_permissions([Permission::Camera, Permission::Storage]),
        PermissionSet::empty(),
    )
    .expect("APP_ID is a valid app id");

    if let Err(e) = policy.authorize_camera() {
        eprintln!("[{APP_ID}] camera permission check failed locally: {e}");
        std::process::exit(1);
    }
    if let Err(e) = policy.check(Permission::Storage) {
        eprintln!("[{APP_ID}] storage permission check failed locally: {e}");
        std::process::exit(1);
    }

    let mut library = match PhotoLibrary::load(SandboxStorage(policy)) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("[{APP_ID}] failed to load photo library: {e}");
            std::process::exit(1);
        }
    };

    // No UI here (M7's job) and no real hardware capture yet (M9's
    // job) -- this is the functional core's own demo of itself, run
    // each launch: capture one synthetic frame through StubBackend,
    // then print the library.
    let mut backend = StubBackend;
    match library.capture(&mut backend, 1280, 720, now_unix()) {
        Ok(id) => println!("[{APP_ID}] captured photo #{id} (1280x720, synthetic placeholder frame)"),
        Err(e) => eprintln!("[{APP_ID}] capture failed: {e}"),
    }

    println!("[{APP_ID}] photo library ({} photo(s)):", library.list().len());
    for p in library.list() {
        println!("[{APP_ID}]   #{} {} {}x{}", p.id, p.file_name, p.width, p.height);
    }

    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}

fn now_unix() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}
