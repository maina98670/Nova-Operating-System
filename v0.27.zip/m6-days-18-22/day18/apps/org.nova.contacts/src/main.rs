//! Contacts — Day 16 reconciliation.
//!
//! Connects through App Manager's Hello/HelloAck/PermissionRequest
//! handshake (`nova-app-runtime`), then runs `nova-contacts-core`'s
//! real functional core against this app's own sandbox-scoped
//! storage. See `libs/nova-app-runtime`'s module docs for what this
//! binary is (a from-scratch, protocol-correct client) and is not (a
//! preserved copy of any pre-existing Contacts implementation, whose
//! source was not part of this Day 16 upload).

use nova_app_storage::SandboxStorage;
use nova_contacts_core::ContactStore;
use nova_ipc::Permission;
use nova_sandbox::{PermissionSet, SandboxPolicy};

const APP_ID: &str = "org.nova.contacts";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }

    // Matches this app's nova-app.toml (required = contacts, storage).
    // App Manager already granted these before spawning this process;
    // building the same policy here and checking it locally is
    // defense-in-depth, not the primary enforcement point.
    let policy = SandboxPolicy::new(
        APP_ID,
        PermissionSet::from_permissions([Permission::Contacts, Permission::Storage]),
        PermissionSet::empty(),
    )
    .expect("APP_ID is a valid app id");

    if let Err(e) = policy.authorize_contacts() {
        eprintln!("[{APP_ID}] contacts permission check failed locally: {e}");
        std::process::exit(1);
    }
    if let Err(e) = policy.check(Permission::Storage) {
        eprintln!("[{APP_ID}] storage permission check failed locally: {e}");
        std::process::exit(1);
    }

    let mut store = match ContactStore::load(SandboxStorage(policy)) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[{APP_ID}] failed to load contact store: {e}");
            std::process::exit(1);
        }
    };

    // No UI yet (M7's job) -- this is the functional core's own demo
    // of itself, run each launch so the reconciliation test has real
    // behavior to observe, not just a silent process.
    if store.list().is_empty() {
        let _ = store.add("Faith Onyangore", vec!["+254700000001".to_string()], None);
        let _ = store.add("NovaMed Support", vec!["+254700000099".to_string()], Some("support@novamed.example".into()));
        println!("[{APP_ID}] seeded {} contact(s) on first run", store.list().len());
    }

    println!("[{APP_ID}] contacts on file: {}", store.list().len());
    for c in store.list() {
        println!("[{APP_ID}]   #{} {} {:?}", c.id, c.name, c.phone_numbers);
    }

    let query = "faith";
    let matches = store.search(query);
    println!("[{APP_ID}] search({query:?}) -> {} match(es)", matches.len());

    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}
