//! Dialer — Day 16 reconciliation.
//!
//! Connects through App Manager's Hello/HelloAck/PermissionRequest
//! handshake (`nova-app-runtime`), then runs `nova-dialer-core`'s real
//! functional core against this app's own sandbox-scoped storage. No
//! cellular HAL exists yet (M9's job), so placing a call goes through
//! `StubTelephony` -- see `nova-dialer-core`'s module docs.
//! `nova_ipc::Permission`'s fixed set has no dedicated telephony
//! permission yet, so this app is scoped to `contacts` (caller-ID
//! lookup) for now. See `libs/nova-app-runtime`'s module docs for what
//! this binary is (a from-scratch, protocol-correct client) and is
//! not (a preserved copy of any pre-existing Dialer implementation,
//! whose source was not part of this Day 16 upload).

use nova_app_storage::SandboxStorage;
use nova_dialer_core::{CallLog, StubTelephony};
use nova_ipc::Permission;
use nova_sandbox::{PermissionSet, SandboxPolicy};
use std::time::{SystemTime, UNIX_EPOCH};

const APP_ID: &str = "org.nova.dialer";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }

    // Matches this app's nova-app.toml (required = contacts).
    let policy = SandboxPolicy::new(APP_ID, PermissionSet::from_permissions([Permission::Contacts]), PermissionSet::empty())
        .expect("APP_ID is a valid app id");

    if let Err(e) = policy.authorize_contacts() {
        eprintln!("[{APP_ID}] contacts permission check failed locally: {e}");
        std::process::exit(1);
    }

    let mut log = match CallLog::load(SandboxStorage(policy)) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("[{APP_ID}] failed to load call log: {e}");
            std::process::exit(1);
        }
    };

    // No UI yet (M7's job) -- this is the functional core's own demo
    // of itself, run each launch: place one call (through the
    // no-op-but-real StubTelephony), log one missed call, then print
    // recent history.
    let mut telephony = StubTelephony;
    let now = now_unix();

    if let Err(e) = log.place_call(&mut telephony, "+254700000001", now) {
        eprintln!("[{APP_ID}] place_call failed: {e}");
    }
    if let Err(e) = log.log_missed("+254700000099", now + 10) {
        eprintln!("[{APP_ID}] log_missed failed: {e}");
    }

    println!("[{APP_ID}] missed calls: {}", log.missed().len());
    println!("[{APP_ID}] recent calls:");
    for c in log.recent(10) {
        println!("[{APP_ID}]   [{:?}] {} ({}s)", c.direction, c.number, c.duration_secs);
    }

    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}

fn now_unix() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}
