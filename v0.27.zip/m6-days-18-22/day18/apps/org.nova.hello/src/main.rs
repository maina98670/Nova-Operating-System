//! nova-hello — Day 17's canonical M5 smoke test.
//!
//! Per the Complete Build Guide's Day 17 row: "Build (or reuse, if one
//! already exists) a minimal Hello-world app as the canonical 'does
//! the whole stack work' smoke test — deliberately simpler than the
//! five real apps, so failures here point at the platform, not
//! app-specific code."
//!
//! ## On "reuse, if one already exists"
//! `nova-os-m5-package.zip` (a separate, earlier, parallel-track M5
//! package — see the Day 16 package's README) already contains an
//! `apps/nova-hello`. It was not reused here: it expects a
//! `NOVA_CONTROL_SOCK`/`NOVA_APP_ID` environment pair from a
//! namespace/chroot-based launcher and a different manifest schema
//! (`[app]`/`[permissions]` sections, `entry` instead of
//! `entry_point`) — neither matches this lineage's `SOCKET_PATH`
//! constant, `SandboxPolicy`-based launch, or `nova-app.toml` schema
//! (`docs/nova-app-toml-v1.md`). Porting it would mean rewriting
//! nearly all of it anyway, so this is a fresh, from-scratch app
//! built directly against *this* lineage's actual, current stack.
//!
//! ## What this proves, all in one run
//! 1. **Launch through the App Manager**, not standalone (same as
//!    Day 16's five apps) — proven by `nova-day17-m5-acceptance-test`
//!    driving this app via `AppManager::install`/`launch`.
//! 2. **Real IPC request/response #1**: `Hello` -> `HelloAck`.
//! 3. **Real IPC request/response #2**: this app's own declared
//!    optional permission (`network`, see `nova-app.toml`) requested
//!    via `PermissionRequest` and granted via `PermissionResponse`.
//! 4. **Real IPC request/response #3, and the DoD's "blocked from an
//!    action outside its declared permissions"**: this app then asks
//!    for `camera` — not declared anywhere in its manifest — and gets
//!    back `PermissionResponse { granted: false }` from the *real*
//!    running App Manager (Day 15's server-side enforcement in
//!    `nova-app-manager::handle_connection`), not a locally-simulated
//!    check.

use nova_ipc::{Message, Permission};
use std::process;

const APP_ID: &str = "org.nova.hello";
const DECLARED_OPTIONAL: &[Permission] = &[Permission::Network];
/// Deliberately *not* in this app's manifest at all — proves the
/// "blocked from an undeclared permission" half of the Day 17 DoD.
const UNDECLARED: Permission = Permission::Camera;

fn main() {
    println!("[{APP_ID}] starting");

    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, DECLARED_OPTIONAL) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck round trip complete -- IPC request/response #1");

    let network_granted = outcome.optional_grants.iter().any(|(p, granted)| *p == Permission::Network && *granted);
    if network_granted {
        println!("[{APP_ID}] declared optional permission 'network' granted -- IPC request/response #2");
    } else {
        eprintln!("[{APP_ID}] UNEXPECTED: declared optional permission 'network' was not granted");
        process::exit(1);
    }

    // The actual "operate within its permissions" proof: ask for
    // something this app's manifest never declared, and confirm the
    // real running App Manager says no over the wire.
    if let Err(e) = conn.send(&Message::PermissionRequest { permission: UNDECLARED }) {
        eprintln!("[{APP_ID}] failed to send undeclared PermissionRequest: {e}");
        process::exit(1);
    }
    match conn.recv() {
        Ok(Message::PermissionResponse { permission, granted }) if permission == UNDECLARED => {
            println!("[{APP_ID}] IPC request/response #3: PermissionRequest({}) -> granted={granted}", permission.name());
            if granted {
                eprintln!("[{APP_ID}] SECURITY REGRESSION: an undeclared permission was granted -- this should never happen");
                process::exit(1);
            }
            println!("[{APP_ID}] correctly blocked from '{}' -- not declared in nova-app.toml", permission.name());
        }
        Ok(other) => {
            eprintln!("[{APP_ID}] expected matching PermissionResponse for the undeclared request, got {other:?}");
            process::exit(1);
        }
        Err(e) => {
            eprintln!("[{APP_ID}] failed to receive PermissionResponse: {e}");
            process::exit(1);
        }
    }

    println!("[{APP_ID}] M5 smoke test complete: launched, exchanged real IPC, operated within its declared permissions");
    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}
