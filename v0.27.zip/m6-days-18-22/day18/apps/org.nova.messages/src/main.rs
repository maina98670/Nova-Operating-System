//! Messages — Day 16 reconciliation.
//!
//! Connects through App Manager's Hello/HelloAck/PermissionRequest
//! handshake (`nova-app-runtime`), then runs `nova-messages-core`'s
//! real functional core against this app's own sandbox-scoped
//! storage. No cellular/SMS HAL exists yet (M9's job), so sending goes
//! through `StubTransport` -- see `nova-messages-core`'s module docs.
//! See `libs/nova-app-runtime`'s module docs for what this binary is
//! (a from-scratch, protocol-correct client) and is not (a preserved
//! copy of any pre-existing Messages implementation, whose source was
//! not part of this Day 16 upload).

use nova_app_storage::SandboxStorage;
use nova_ipc::Permission;
use nova_messages_core::{MessageStore, StubTransport};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use std::time::{SystemTime, UNIX_EPOCH};

const APP_ID: &str = "org.nova.messages";
const OPTIONAL_PERMISSIONS: &[Permission] = &[Permission::Network];

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }

    // Matches this app's nova-app.toml (required = sms, contacts,
    // storage; optional = network -- e.g. MMS/RCS fallback later).
    let mut policy = SandboxPolicy::new(
        APP_ID,
        PermissionSet::from_permissions([Permission::Sms, Permission::Contacts, Permission::Storage]),
        PermissionSet::from_permissions([Permission::Network]),
    )
    .expect("APP_ID is a valid app id");

    if let Err(e) = policy.authorize_sms() {
        eprintln!("[{APP_ID}] sms permission check failed locally: {e}");
        std::process::exit(1);
    }
    if let Err(e) = policy.check(Permission::Storage) {
        eprintln!("[{APP_ID}] storage permission check failed locally: {e}");
        std::process::exit(1);
    }
    if outcome.optional_grants.iter().any(|(p, granted)| *p == Permission::Network && *granted) {
        let _ = policy.request(Permission::Network);
    }

    let mut store = match MessageStore::load(SandboxStorage(policy)) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[{APP_ID}] failed to load message store: {e}");
            std::process::exit(1);
        }
    };

    // No UI yet (M7's job) -- this is the functional core's own demo
    // of itself, run each launch: send one message (through the
    // no-op-but-real StubTransport), simulate one inbound reply, then
    // print the resulting thread.
    let mut transport = StubTransport;
    let now = now_unix();
    let peer = "+254700000001";

    if let Err(e) = store.send(&mut transport, peer, "Reconciled against the integrated App Manager.", now) {
        eprintln!("[{APP_ID}] send failed: {e}");
    }
    if let Err(e) = store.receive(peer, "Got it.", now + 5) {
        eprintln!("[{APP_ID}] receive failed: {e}");
    }

    println!("[{APP_ID}] unread: {}", store.unread_count());
    for thread in store.threads() {
        println!("[{APP_ID}] thread with {}: {} message(s)", thread.peer_number, thread.messages.len());
        for m in &thread.messages {
            println!("[{APP_ID}]   [{:?}/{:?}] {}", m.direction, m.status, m.body);
        }
    }

    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}

fn now_unix() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}
