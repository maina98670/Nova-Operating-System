//! Settings — Day 16 reconciliation.
//!
//! Connects through App Manager's Hello/HelloAck/PermissionRequest
//! handshake (`nova-app-runtime`), then runs `nova-settings-core`'s
//! real functional core against this app's own sandbox-scoped
//! storage. See `libs/nova-app-runtime`'s module docs for what this
//! binary is (a from-scratch, protocol-correct client) and is not (a
//! preserved copy of any pre-existing Settings implementation, whose
//! source was not part of this Day 16 upload).

use nova_app_storage::SandboxStorage;
use nova_ipc::Permission;
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_settings_core::{SettingValue, SettingsStore};

const APP_ID: &str = "org.nova.settings";
const OPTIONAL_PERMISSIONS: &[Permission] = &[Permission::Network];

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }

    // Matches this app's nova-app.toml (required = storage, optional
    // = network -- e.g. checking for a system update).
    let mut policy = SandboxPolicy::new(
        APP_ID,
        PermissionSet::from_permissions([Permission::Storage]),
        PermissionSet::from_permissions([Permission::Network]),
    )
    .expect("APP_ID is a valid app id");

    if let Err(e) = policy.check(Permission::Storage) {
        eprintln!("[{APP_ID}] storage permission check failed locally: {e}");
        std::process::exit(1);
    }
    // Mirror App Manager's own grant of the network permission we just
    // requested during the handshake, so the local policy used for
    // future protected-resource checks agrees with what App Manager
    // actually granted.
    if outcome.optional_grants.iter().any(|(p, granted)| *p == Permission::Network && *granted) {
        let _ = policy.request(Permission::Network);
    }

    let mut store = match SettingsStore::load(SandboxStorage(policy)) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[{APP_ID}] failed to load settings store: {e}");
            std::process::exit(1);
        }
    };

    // No UI yet (M7's job) -- this is the functional core's own demo
    // of itself: read every known setting, then exercise a validated
    // set + an intentionally-rejected out-of-range set, so both the
    // happy path and the validation path are visibly real.
    println!("[{APP_ID}] known settings:");
    for (key, value) in store.list() {
        println!("[{APP_ID}]   {key} = {value:?}");
    }

    match store.set("display_brightness", SettingValue::Int(55)) {
        Ok(()) => println!("[{APP_ID}] display_brightness -> 55 (accepted)"),
        Err(e) => println!("[{APP_ID}] display_brightness -> 55 unexpectedly rejected: {e}"),
    }

    match store.set("display_brightness", SettingValue::Int(500)) {
        Ok(()) => println!("[{APP_ID}] display_brightness -> 500 unexpectedly accepted"),
        Err(e) => println!("[{APP_ID}] display_brightness -> 500 correctly rejected: {e}"),
    }

    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}
