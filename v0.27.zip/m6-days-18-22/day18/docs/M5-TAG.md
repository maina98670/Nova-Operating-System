# Tag: M5 — IPC, Applications & Sandboxing (integrate with M4)

**Version**: `v0.20`, per the Complete Build Guide's milestone table
(`M5 — IPC, Applications & Sandboxing (integrate with M4) (v0.20),
Days 11-17`).

This file documents the intended tag; it does not create one. The
package deliveries in this track are files only, not a git checkout of
Zeen's actual repository, so the literal tagging command below is for
Zeen to run in his own repo once this package's contents are merged
in:

```bash
git tag -a v0.20 -m "M5: IPC, Applications & Sandboxing (integrate with M4)"
git push origin v0.20
```

## What M5 covers (Days 11-17)

| Day | Focus | Delivered |
|---|---|---|
| 11 | Versioned IPC protocol | `nova-ipc` formalized as `protocols/nova-ipc-v1.md`; version byte + `VersionQuery`/`VersionResponse` |
| 12 | Service discovery + request/response/event messaging | `discover()`/`list_services()`; confirmed both messaging patterns share one transport |
| 13 | App lifecycle via M4's Process/Service Manager | `nova-app-manager` launch/terminate rebuilt on `nova-procmgr`/`nova-svcmgr`, not raw fork/exec; cold-start sourced from M4 |
| 14 | Package manifest + permission declarations | `nova-app.toml` schema (`docs/nova-app-toml-v1.md`), validated through `nova-config` |
| 15 | Sandbox boundaries | `nova-sandbox`: capability checks + per-app filesystem scoping; declared permissions become real runtime enforcement |
| 16 | Reconcile the five apps against the new stack | Settings/Contacts/Messages/Dialer/Camera built for real (functional cores — no UI, that's M7) after confirming no pre-existing source existed anywhere in this track; each installs, launches, and completes its IPC handshake through the integrated App Manager |
| 17 | Hello-world app, full M5 acceptance, tag | `nova-hello` — the canonical, deliberately-simpler smoke test; the Roadmap's own M5 acceptance test run live; this tag |

## M5 acceptance, satisfied

> "A packaged test application can launch, communicate through IPC and
> operate within its permissions."

Proven live by `tools/nova-day17-m5-acceptance-test` against
`nova-hello`:

1. **Packaged** — installs via `AppManager::install` (Day 14's real
   manifest-validation path).
2. **Launch** — via the integrated App Manager (Day 13), not a raw
   fork/exec.
3. **Communicate through IPC** — `Hello`/`HelloAck` handshake,
   recorded by App Manager itself.
4. **Operate within its permissions** — required (`storage`) and
   declared-optional (`network`) permissions granted; an undeclared
   permission (`camera`) requested and correctly denied, checked
   against App Manager's own bitmask.

The same platform also carries Day 16's five real apps' functional
cores through this exact pipeline (`tools/nova-day16-reconciliation-test`),
so M5 acceptance holds for both the minimal smoke test and the actual
application set, not just the simplest possible case.

## Known gaps carried forward past M5 (named, not hidden)

- **No UI.** Every app built in M5 is IPC/data-model only. Wayland
  rendering is M7's job.
- **No real hardware backends.** Messages/Dialer/Camera each define a
  trait seam with only a stub behind it; the cellular and camera HALs
  don't exist yet (M9).
- **Sandbox enforcement is user-space discipline, not kernel-level.**
  `nova-sandbox` (Day 15) is explicit about this: no
  namespace/seccomp/chroot hardening yet — that's M10.
- **No package signing/verification.** Anything can currently write a
  `nova-app.toml` + binary to `<APPS>/<id>/`; that's M11 (Day 43).
- **`PhotoLibrary::delete` orphans its frame file** — `nova-sandbox`
  has no delete-scoped storage API yet (Day 16's own note).

None of these block M5's own acceptance criterion above; they're
listed here so M6 onward doesn't have to rediscover them.
