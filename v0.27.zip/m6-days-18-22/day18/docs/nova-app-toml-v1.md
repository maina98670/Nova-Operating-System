# Nova App Manifest — `nova-app.toml`, v1 (first draft)

This is the "package-format specification" referenced in Section 5
(M5) and Section 23 of the guide — the schema for the manifest every
Nova app ships as `nova-app.toml`, formalized here per Day 14. It
covers the manifest file itself only; the surrounding `.nova` package
bundle format (signing, install-time verification) is M11's job
(Day 43), and sandbox *enforcement* of the permissions declared here
is Day 15's, not this document's.

This draft will be finalized (not re-designed) at Day 49's repository
metadata pass and again in Day 83's documentation completion pass, per
the guide's own schedule for Section 23's documents.

## Location

Every installed app has its manifest at:

```
<APPS>/<app_id>/nova-app.toml
```

`<APPS>` is `nova_fsmgr::paths::APPS` (`/apps` by default) — Section
11's package-bundle location, the same one-location convention Day 4
established for `nova-fsmgr`'s other standard directories and Day 8
extended to `nova-config`'s service configs.

## Format

TOML, parsed and validated through `nova-config` (M4 Day 8) — not a
second, app-manager-specific parser. This matters for more than code
reuse: it means a manifest gets the exact same "malformed file is a
loud, immediate error, never a silent fallback" guarantee Day 8
already built and tested for every other Nova service's config.

## Schema

| Field                   | Type             | Required | Meaning |
|--------------------------|------------------|----------|---------|
| `id`                     | string           | yes      | Unique app identifier (e.g. `org.nova.settings`). Matches the directory name under `<APPS>/`. |
| `name`                   | string           | yes      | Human-readable display name (app launcher, notifications). |
| `version`                | string           | yes      | App's own version string. Not currently parsed/compared — recorded for the package ecosystem work in M11. |
| `entry_point`            | string           | yes      | Absolute path to the binary App Manager launches (becomes `AppDef.command`). |
| `args`                   | array of strings | no       | Extra arguments passed to `entry_point` on launch. Defaults to empty. |
| `required_permissions`   | array of strings | no       | Permission names (see below) the app cannot run without. Defaults to empty. |
| `optional_permissions`   | array of strings | no       | Permission names the app may request at runtime via `PermissionRequest`, but doesn't need to launch. Defaults to empty. |

A manifest missing `id`, `name`, `version`, or `entry_point` fails to
parse at all — `nova-config`'s existing malformed-file error, naming
the manifest's path, not a partially-built `AppManifest` with blanks
filled in.

## Permission names

Permission names are strings, but the set they're drawn from is fixed
and closed — `nova-ipc`'s `Permission` enum — not an open namespace a
manifest can invent entries for. The current set (see
`nova-ipc-v1.md` for the wire-level detail): `display`, `input`,
`network`, `location`, `contacts`, `camera`, `microphone`, `sms`,
`health_data`, `storage`.

`display` and `input` are implicitly granted to every launched app
(per the IPC spec's `HelloAck`) and do not need to be listed in either
permission array — listing them is harmless (they'll validate
successfully, since they are real names) but redundant.

A name in `required_permissions` or `optional_permissions` that isn't
one of the names above is rejected at load time with a clear error
naming both the manifest path and the offending string — this is the
literal Day 14 DoD's second case, alongside the missing-required-field
case above.

## Example

```toml
id = "org.nova.settings"
name = "Settings"
version = "0.1.0"
entry_point = "/apps/org.nova.settings/bin/nova-settings"
required_permissions = ["storage"]
optional_permissions = ["network"]
```

## What Day 14 validates vs. what it doesn't yet

Day 14's validation is entirely static — parse the TOML, check every
declared permission name is real. It does **not** yet:

- Enforce that a running process actually has the permissions it
  declared (Day 15).
- Verify `entry_point` exists or is executable before `launch` tries
  to spawn it (still surfaces as a normal `ServiceManager::start`
  failure today, same as Day 13).
- Check for an `id`/directory-name mismatch, or duplicate `id`s across
  installed apps.
- Verify a package signature (M11, Day 43) — anything can currently
  write a `nova-app.toml` to `<APPS>/`, which is fine for this stage
  of M5 but is explicitly not the final security posture.

None of the above is silently assumed to work; they're just not this
day's job, and are named here so a later day's DoD doesn't have to
rediscover that they're still open.

## Day 16/17: the `<APPS>/<id>/bin/<binary>` convention, live

`entry_point` (e.g. `/apps/org.nova.settings/bin/nova-settings`) is
not just documentation — Day 16 and 17's live acceptance tools
(`tools/nova-day16-reconciliation-test`,
`tools/nova-day17-m5-acceptance-test`) actually write each app's built
binary to exactly that path (`<APPS>/<id>/bin/<binary>`, mode `0o755`)
before calling `AppManager::install`/`launch`, so `entry_point` in the
manifest and the binary `launch` actually spawns are the same file for
real, not just by convention on paper. This is still user-space
discipline, not a verified/signed install (see "package signature"
above, still M11) — anything that writes both the manifest and a
binary to `<APPS>/<id>/` today is trusted.

## M5 acceptance (Day 17)

Day 17 is the first time this schema is exercised against a
deliberately minimal app (`nova-hello`, `apps/org.nova.hello`) rather
than only the five real apps — proving the manifest schema, install
validation, and permission model together satisfy the Roadmap's own M5
acceptance test: "a packaged test application can launch, communicate
through IPC and operate within its permissions." See
`libs/nova-ipc/protocols/nova-ipc-v1.md`'s own M5 acceptance section
for the IPC half of that proof.

Tag: **M5** (`v0.20` per the guide's milestone-version table) — see
`docs/M5-TAG.md`.

