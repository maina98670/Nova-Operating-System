# Nova Sandbox v1 — Day 15

## Purpose

Day 14 made `nova-app.toml` permission declarations syntactically and semantically
valid. Day 15 turns those declarations into runtime enforcement.

This milestone intentionally implements the minimum sandbox boundary. Full Linux
namespace/seccomp hardening remains M10.

## Permission model

- `display` and `input` are implicit.
- `required_permissions` are granted when an app is launched.
- `optional_permissions` are not granted at launch.
- A runtime `PermissionRequest` succeeds only for an optional permission declared
  by the app.
- A permission not present in either list is denied.
- Denials are written to `/var/log/nova/security.log`.

## Filesystem boundary

Apps receive an app-specific storage root:

`/var/lib/nova/apps/<app-id>/`

`SandboxPolicy::scoped_path()` accepts only relative paths and rejects `..`,
absolute paths, and other components that could escape the root.

Apps must use the scoped storage API rather than raw host filesystem paths.

## Protected resources

The resource gate exposes explicit checks for:

- camera
- microphone
- network
- contacts
- SMS
- health data
- location

The camera HAL's contract is to call `authorize_camera()` before opening a
`/dev/video*` device. The same pattern applies to the other protected resources.

## What is deliberately not claimed

Day 15 does **not** claim that a hostile process can bypass the Linux kernel and
still be contained. Kernel-level namespaces/seccomp and stronger identity
isolation are M10 work. Day 15 establishes the stable permission/resource-broker
seam and proves that an app without `camera` cannot pass Nova's camera resource
gate.

## Definition of Done

A deliberately misbehaving app/resource request without a declared permission
is rejected, the denial is logged, and app filesystem access cannot escape its
own scoped root. A camera-declaring app receives the camera capability.
