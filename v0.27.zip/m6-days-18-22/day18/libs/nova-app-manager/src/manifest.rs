//! `nova-app.toml` manifest schema — M5 Day 14.
//!
//! Per the Complete Build Guide's Day 14 row: formalize the manifest
//! schema (id, name, version, entry point, permissions) as a
//! documented spec (`docs/nova-app-toml-v1.md`, Section 23's
//! "package-format specification", first draft), and validate
//! manifests **through M4's Configuration subsystem's validation
//! path** — `nova_config::load` — rather than a second, ad hoc TOML
//! parser living in this crate.
//!
//! ## Two different validation failures, on purpose
//! The Day 14 DoD names two distinct rejection cases, and they are
//! deliberately handled by two different layers rather than one
//! catch-all:
//!   - **A missing required field** (`id`, `name`, `version`, or
//!     `entry_point` absent from the TOML table) is a *parse*
//!     failure — `serde` fails to build an `AppManifest` from the
//!     document at all, because those four fields have no
//!     `#[serde(default)]`. `nova_config::load` reports this exactly
//!     as it reports any other malformed config: a loud
//!     `ConfigError::Parse` naming the file, never a silent
//!     fallback. This crate does not re-implement that check; it
//!     reuses Day 8's.
//!   - **An unknown permission name** (present in
//!     `required_permissions`/`optional_permissions`, but not one of
//!     `nova_ipc::Permission`'s fixed, closed set) parses as valid
//!     TOML — it's just a string in an array, as far as `serde` is
//!     concerned — so `nova_config::load` alone cannot catch it.
//!     `validate_permissions` below is the second, explicit pass this
//!     crate runs immediately after a successful parse, checking
//!     every declared name against `Permission::from_name`. Same
//!     "reject loudly, never silently drop or ignore" discipline as
//!     Day 8's own malformed-file case, just for a check TOML syntax
//!     alone can't express.
//!
//! `load_manifest` runs both passes in sequence and is the single
//! entry point `AppManager::install`/`launch` (see `lib.rs`) call —
//! one validation path, used at both install and launch time, per the
//! DoD's own wording.

use nova_ipc::Permission;
use serde::Deserialize;
use std::fmt;
use std::path::{Path, PathBuf};

/// The `nova-app.toml` schema, first draft. See
/// `docs/nova-app-toml-v1.md` for the documented spec this struct is
/// the implementation of — keep the two in sync.
///
/// `id`/`name`/`version`/`entry_point` are required: no
/// `#[serde(default)]`, so a manifest missing any of them fails to
/// deserialize at all (Day 14's "missing required field" case).
/// `args` and the two permission lists are optional and default to
/// empty — most apps declare zero extra launch args and Display/Input
/// (already implicit, per the IPC spec) cover plenty of apps with no
/// further permissions at all.
#[derive(Debug, Clone, Deserialize)]
pub struct AppManifest {
    pub id: String,
    pub name: String,
    pub version: String,
    pub entry_point: String,
    #[serde(default)]
    pub args: Vec<String>,
    /// Permission names (`Permission::name()` strings, e.g.
    /// `"camera"`) the app cannot function at all without — App
    /// Manager should refuse to launch it if one of these can't be
    /// granted, once Day 15 adds enforcement. Day 14 itself only
    /// validates that every name here is a real permission; granting
    /// or refusing is out of scope until then.
    #[serde(default)]
    pub required_permissions: Vec<String>,
    /// Permission names the app can request at runtime
    /// (`PermissionRequest` on the wire) but can run without —
    /// distinguished from `required_permissions` per the IPC spec's
    /// "Section 11's manifest lists required vs. optional".
    #[serde(default)]
    pub optional_permissions: Vec<String>,
}

#[derive(Debug)]
pub enum ManifestError {
    /// Missing manifest, or present-but-malformed TOML (including a
    /// missing required field) — passed straight through from
    /// `nova_config`, unchanged, since that's the validation path
    /// this crate is required to reuse rather than duplicate.
    Config(nova_config::ConfigError),
    /// Parsed fine as TOML, but `required_permissions` or
    /// `optional_permissions` names a permission that isn't in
    /// `nova_ipc::Permission`'s fixed set. Names the offending
    /// manifest path and the bad string verbatim, the same
    /// "clear error" bar Day 8 set for malformed config.
    UnknownPermission { path: PathBuf, name: String },
}

impl fmt::Display for ManifestError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ManifestError::Config(e) => write!(f, "{e}"),
            ManifestError::UnknownPermission { path, name } => write!(
                f,
                "manifest at {} declares unknown permission \"{name}\" (not one of nova-ipc's fixed permission set)",
                path.display()
            ),
        }
    }
}

impl std::error::Error for ManifestError {}

/// Checks every name in `manifest.required_permissions` and
/// `optional_permissions` against `Permission::from_name`, in
/// declaration order, failing on the first unrecognized one. `path`
/// is only used to build a clear error message — the check itself is
/// against the already-parsed struct.
pub fn validate_permissions(manifest: &AppManifest, path: &Path) -> Result<(), ManifestError> {
    for name in manifest.required_permissions.iter().chain(manifest.optional_permissions.iter()) {
        if Permission::from_name(name).is_none() {
            return Err(ManifestError::UnknownPermission { path: path.to_path_buf(), name: name.clone() });
        }
    }
    Ok(())
}

/// The Day 14 entry point: load `path` through `nova_config::load`
/// (Day 8's validation path — malformed TOML, including a missing
/// required field, is rejected here with a clear error naming the
/// file), then run `validate_permissions` on the result. A manifest
/// is only ever returned if both passes succeed.
///
/// Deliberately uses `nova_config::load`, not `load_or_default`: an
/// app with no manifest at all is not "use defaults" the way a
/// missing service config is (Day 8's case) — it's an app that isn't
/// installed, which should be a clear error at whichever call site
/// (install or launch) went looking for it.
pub fn load_manifest(path: &Path) -> Result<AppManifest, ManifestError> {
    let manifest: AppManifest = nova_config::load(path).map_err(ManifestError::Config)?;
    validate_permissions(&manifest, path)?;
    Ok(manifest)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;
    use std::fs;

    fn temp_manifest_path(name: &str) -> PathBuf {
        env::temp_dir().join(format!("nova-app-manager-manifest-test-{}-{}", std::process::id(), name))
    }

    fn write(path: &Path, contents: &str) {
        fs::write(path, contents).unwrap();
    }

    /// The literal Day 14 DoD, first half: a valid manifest loads
    /// correctly through the same path a malformed one is rejected
    /// through.
    #[test]
    fn day14_definition_of_done_valid_manifest_loads() {
        let path = temp_manifest_path("valid.toml");
        write(
            &path,
            r#"
                id = "org.nova.settings"
                name = "Settings"
                version = "0.1.0"
                entry_point = "/apps/org.nova.settings/bin/nova-settings"
                required_permissions = ["storage"]
                optional_permissions = ["network"]
            "#,
        );

        let manifest = load_manifest(&path).expect("a well-formed manifest should load");
        assert_eq!(manifest.id, "org.nova.settings");
        assert_eq!(manifest.required_permissions, vec!["storage".to_string()]);
        assert_eq!(manifest.optional_permissions, vec!["network".to_string()]);

        let _ = fs::remove_file(&path);
    }

    /// Day 14 DoD, second half, case 1: a manifest missing a required
    /// field (here, `entry_point`) is rejected with a clear error —
    /// via `nova_config`'s existing malformed-file path, not a new
    /// one.
    #[test]
    fn day14_definition_of_done_missing_required_field_rejected() {
        let path = temp_manifest_path("missing-field.toml");
        write(
            &path,
            r#"
                id = "org.nova.broken"
                name = "Broken"
                version = "0.1.0"
            "#, // entry_point deliberately omitted
        );

        let result = load_manifest(&path);
        assert!(result.is_err(), "a manifest missing entry_point must be rejected, not defaulted");
        match result.unwrap_err() {
            ManifestError::Config(nova_config::ConfigError::Parse { .. }) => {}
            other => panic!("expected Config(Parse) for a missing required field, got {other:?}"),
        }

        let _ = fs::remove_file(&path);
    }

    /// Day 14 DoD, second half, case 2: a manifest that parses fine
    /// but names a permission outside nova-ipc's fixed set is
    /// rejected with a clear, specific error.
    #[test]
    fn day14_definition_of_done_unknown_permission_rejected() {
        let path = temp_manifest_path("unknown-permission.toml");
        write(
            &path,
            r#"
                id = "org.nova.sketchy"
                name = "Sketchy"
                version = "0.1.0"
                entry_point = "/apps/org.nova.sketchy/bin/sketchy"
                required_permissions = ["bluetooth"]
            "#, // "bluetooth" is not in Permission::ALL
        );

        let result = load_manifest(&path);
        assert!(result.is_err(), "an unknown permission name must be rejected");
        match result.unwrap_err() {
            ManifestError::UnknownPermission { name, .. } => assert_eq!(name, "bluetooth"),
            other => panic!("expected UnknownPermission, got {other:?}"),
        }

        let _ = fs::remove_file(&path);
    }

    /// A missing manifest file is also an error (not defaults) --
    /// distinct from Day 8's own `load_or_default` services, per this
    /// module's doc comment.
    #[test]
    fn missing_manifest_file_is_an_error_not_defaults() {
        let path = temp_manifest_path("does-not-exist.toml");
        let _ = fs::remove_file(&path);

        let result = load_manifest(&path);
        assert!(result.is_err(), "a missing manifest should be an error -- an app that isn't installed, not defaults");
        assert!(matches!(result.unwrap_err(), ManifestError::Config(nova_config::ConfigError::Io(_))));
    }

    /// Optional-only permissions are validated too, not just required
    /// ones -- both lists go through the same check.
    #[test]
    fn unknown_optional_permission_is_also_rejected() {
        let path = temp_manifest_path("unknown-optional.toml");
        write(
            &path,
            r#"
                id = "org.nova.sketchy2"
                name = "Sketchy Two"
                version = "0.1.0"
                entry_point = "/apps/org.nova.sketchy2/bin/sketchy2"
                optional_permissions = ["nfc"]
            "#,
        );

        let result = load_manifest(&path);
        match result.unwrap_err() {
            ManifestError::UnknownPermission { name, .. } => assert_eq!(name, "nfc"),
            other => panic!("expected UnknownPermission, got {other:?}"),
        }

        let _ = fs::remove_file(&path);
    }

    /// A manifest with no permissions declared at all is valid --
    /// both lists default to empty, matching apps that only need the
    /// implicit Display/Input permissions.
    #[test]
    fn manifest_with_no_permissions_declared_is_valid() {
        let path = temp_manifest_path("no-permissions.toml");
        write(
            &path,
            r#"
                id = "org.nova.minimal"
                name = "Minimal"
                version = "0.1.0"
                entry_point = "/apps/org.nova.minimal/bin/minimal"
            "#,
        );

        let manifest = load_manifest(&path).expect("a manifest with no permissions section should still be valid");
        assert!(manifest.required_permissions.is_empty());
        assert!(manifest.optional_permissions.is_empty());

        let _ = fs::remove_file(&path);
    }
}
