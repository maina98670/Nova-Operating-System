//! Nova App Runtime — M5 Day 16.
//!
//! Per the Complete Build Guide's Day 16 row: rebuild Settings,
//! Contacts, Messages, Dialer, and Camera against the integrated App
//! Manager/IPC/permission stack from Days 13-15, replacing any
//! standalone/direct-launch assumptions those apps currently make.
//!
//! ## Honest starting point for this package
//! Days 11-15's own READMEs and `nova-app-manager`'s module docs
//! (`libs/nova-app-manager/src/lib.rs`, "What's still deliberately out
//! of scope for Day 14") state that Settings/Contacts/Messages/Dialer/
//! Camera already existed and already spoke the Hello/HelloAck/
//! ColdStartReport subset of this protocol "in production", built in
//! an earlier session. That earlier session's source was **not**
//! included in any package uploaded for this Day 16 pass -- only the
//! M4 core (Days 1-10, `v0_13.zip`/`V0_07.zip`) and the M5 Days 11-15
//! packages were available here.
//!
//! Rather than guess at unseen implementation details and call it a
//! "rebuild", this crate is a genuine, from-scratch, protocol-correct
//! implementation of exactly the client-side subset the existing
//! `nova-app-manager` server actually requires and enforces as of Day
//! 15: connect, `Hello`, wait for `HelloAck`, request every optional
//! permission the app's manifest declares, then react to `Lifecycle`
//! events until told to terminate.
//!
//! Split into two pieces on purpose:
//!   * [`connect_and_handshake`] — everything up through the optional
//!     `PermissionRequest` round trips. Each of the five apps in
//!     `apps/` calls this, then does its own real domain-logic setup
//!     (opening its `nova-*-core` store against this app's scoped
//!     storage) before...
//!   * [`idle_until_terminate`] — the long-running "stay connected,
//!     react to Lifecycle" loop every app shares, run after that
//!     domain setup.
//!
//! `run_minimal_app`/`main_for` remain as a convenience composition of
//! both, for anything that genuinely has no domain logic of its own.
//!
//! If Zeen's actual pre-existing five apps differ from this
//! reconstruction (different socket handling, extra messages, real UI
//! code, etc.), swapping this crate's client loop for their real
//! entry points -- while keeping the manifests and the Day 16
//! acceptance tool as-is -- is the natural next step; this package
//! does not claim to have seen or preserved their original code.

use nova_ipc::{LifecycleEvent, Message, Permission, SeqPacketSocket, SOCKET_PATH};
use std::io;
use std::time::{Duration, Instant};

#[derive(Debug, Clone)]
pub struct HandshakeOutcome {
    pub accepted: bool,
    pub initial_granted_permissions: u32,
    pub optional_grants: Vec<(Permission, bool)>,
}

/// Connects to App Manager, performs `Hello`/`HelloAck`, sends one
/// (informational-only — see module docs) `ColdStartReport`, then
/// requests each declared optional permission in turn.
///
/// Returns the open connection (for [`idle_until_terminate`] and,
/// where useful, further protocol messages) plus the outcome, so a
/// caller can decide what to do next: an app whose `HelloAck` was
/// rejected, or whose domain-setup fails, should not proceed to the
/// idle loop.
pub fn connect_and_handshake(app_id: &str, optional_permissions: &[Permission]) -> io::Result<(SeqPacketSocket, HandshakeOutcome)> {
    let start = Instant::now();
    let conn = SeqPacketSocket::connect(SOCKET_PATH)?;

    conn.send(&Message::Hello { app_id: app_id.to_string(), pid: std::process::id() })?;
    let ack = conn.recv()?;
    let Message::HelloAck { accepted, granted_permissions } = ack else {
        return Err(protocol_err("expected HelloAck as the first reply to Hello"));
    };
    println!("[{app_id}] Hello -> HelloAck(accepted={accepted}, granted=0b{granted_permissions:b})");

    if !accepted {
        return Ok((
            conn,
            HandshakeOutcome { accepted: false, initial_granted_permissions: granted_permissions, optional_grants: Vec::new() },
        ));
    }

    let elapsed_ms = start.elapsed().as_millis() as u32;
    // Informational only -- see module docs. App Manager's own
    // Service-Manager-sourced measurement is what Day 16's acceptance
    // check actually asserts on.
    let _ = conn.send(&Message::ColdStartReport { elapsed_ms });

    let mut optional_grants = Vec::new();
    for permission in optional_permissions {
        conn.send(&Message::PermissionRequest { permission: *permission })?;
        match conn.recv()? {
            Message::PermissionResponse { permission: p, granted } if p == *permission => {
                println!("[{app_id}] PermissionRequest({}) -> granted={granted}", p.name());
                optional_grants.push((p, granted));
            }
            other => return Err(protocol_err(&format!("expected matching PermissionResponse, got {other:?}"))),
        }
    }

    Ok((conn, HandshakeOutcome { accepted: true, initial_granted_permissions: granted_permissions, optional_grants }))
}

/// Stays connected and reacts to `Lifecycle` pushes, the same as a
/// real long-running app would, until App Manager tells this app to
/// terminate or the connection goes away (App Manager restarted, or
/// `terminate()` was called and the socket was torn down). Runs after
/// an app has finished its own domain-logic setup/demo.
pub fn idle_until_terminate(app_id: &str, conn: &SeqPacketSocket) {
    loop {
        match conn.recv() {
            Ok(Message::Lifecycle { event: LifecycleEvent::Terminate }) => {
                println!("[{app_id}] received Lifecycle::Terminate, exiting cleanly");
                break;
            }
            Ok(Message::Lifecycle { event }) => {
                println!("[{app_id}] Lifecycle::{event:?}");
            }
            Ok(other) => {
                println!("[{app_id}] unexpected message while idle: {other:?}");
            }
            Err(_) => break, // App Manager side closed the connection
        }
    }
}

/// Composition of [`connect_and_handshake`] + [`idle_until_terminate`]
/// for anything with no domain logic of its own.
pub fn run_minimal_app(app_id: &str, optional_permissions: &[Permission]) -> io::Result<HandshakeOutcome> {
    let (conn, outcome) = connect_and_handshake(app_id, optional_permissions)?;
    if outcome.accepted {
        idle_until_terminate(app_id, &conn);
    }
    Ok(outcome)
}

fn protocol_err(msg: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, msg.to_string())
}

/// Small helper for a `main.rs` with no domain logic to just call
/// `nova_app_runtime::main_for("org.nova.x", &[...])` and exit with a
/// sane process status.
pub fn main_for(app_id: &str, optional_permissions: &[Permission]) {
    match run_minimal_app(app_id, optional_permissions) {
        Ok(outcome) if outcome.accepted => std::process::exit(0),
        Ok(_) => {
            eprintln!("[{app_id}] App Manager rejected Hello (HelloAck.accepted=false)");
            std::process::exit(1);
        }
        Err(e) => {
            eprintln!("[{app_id}] failed: {e}");
            std::process::exit(1);
        }
    }
}

// A short, deliberately unused helper kept here (rather than in every
// app's main.rs) for anything wanting a human-readable pause between
// reconnect attempts -- not currently called anywhere in this crate,
// which fails fast per the Day 16 DoD's "note any regressions
// honestly" rather than silently retrying.
#[allow(dead_code)]
fn backoff(_attempt: u32) -> Duration {
    Duration::from_millis(200)
}
