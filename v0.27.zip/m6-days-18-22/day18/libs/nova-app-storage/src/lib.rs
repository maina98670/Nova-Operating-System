//! Nova OS Day 16 — shared scoped-storage abstraction for app cores.
//!
//! Wraps `nova_sandbox::SandboxPolicy`'s per-app filesystem scoping
//! (`scoped_path`/`read_scoped`/`write_scoped`, Day 15) behind a small
//! trait so each app's core data-model crate can be unit-tested
//! against an in-memory backend, instead of needing a real,
//! root-writable `/var/lib/nova/apps/<id>` filesystem the way the
//! actual sandboxed process needs at runtime.
//!
//! This is deliberately just a storage seam, not a second permission
//! system: the production backend (`SandboxStorage`) still goes
//! through `SandboxPolicy::scoped_path`'s traversal/absolute-path
//! rejection, so an app core built against this trait gets Day 15's
//! filesystem boundary for free, in tests and at runtime alike.

use std::collections::HashMap;
use std::io;
use std::sync::{Arc, Mutex};

pub trait ScopedStorage: Send + Sync {
    /// Returns `Ok(None)` for a key that has never been written —
    /// distinct from an I/O error, so callers can tell "no data yet"
    /// (a fresh app on first run) from "storage is broken".
    fn read(&self, relative: &str) -> io::Result<Option<Vec<u8>>>;
    fn write(&self, relative: &str, data: &[u8]) -> io::Result<()>;
}

/// Production backend: nova-sandbox's own per-app scoped storage under
/// `/var/lib/nova/apps/<app-id>/`.
pub struct SandboxStorage(pub nova_sandbox::SandboxPolicy);

impl ScopedStorage for SandboxStorage {
    fn read(&self, relative: &str) -> io::Result<Option<Vec<u8>>> {
        match self.0.read_scoped(relative) {
            Ok(bytes) => Ok(Some(bytes)),
            Err(e) => match e.downcast_ref::<io::Error>() {
                Some(io_err) if io_err.kind() == io::ErrorKind::NotFound => Ok(None),
                _ => Err(io::Error::new(io::ErrorKind::Other, e.to_string())),
            },
        }
    }

    fn write(&self, relative: &str, data: &[u8]) -> io::Result<()> {
        self.0
            .write_scoped(relative, data)
            .map_err(|e| io::Error::new(io::ErrorKind::Other, e.to_string()))
    }
}

/// Test/dev backend: an in-memory map behind a `Mutex`. Every core
/// crate's unit tests exercise real CRUD + persistence round-trip
/// logic against this, without touching disk or needing root. Wrap in
/// `Arc` (see the blanket impl below) to share one backing store
/// across two `*Store::load` calls, e.g. to test that data survives a
/// simulated "app restart".
#[derive(Default)]
pub struct MemStorage(Mutex<HashMap<String, Vec<u8>>>);

impl MemStorage {
    pub fn new() -> Self {
        Self::default()
    }
}

impl ScopedStorage for MemStorage {
    fn read(&self, relative: &str) -> io::Result<Option<Vec<u8>>> {
        Ok(self.0.lock().unwrap().get(relative).cloned())
    }

    fn write(&self, relative: &str, data: &[u8]) -> io::Result<()> {
        self.0.lock().unwrap().insert(relative.to_string(), data.to_vec());
        Ok(())
    }
}

impl<T: ScopedStorage + ?Sized> ScopedStorage for Arc<T> {
    fn read(&self, relative: &str) -> io::Result<Option<Vec<u8>>> {
        (**self).read(relative)
    }

    fn write(&self, relative: &str, data: &[u8]) -> io::Result<()> {
        (**self).write(relative, data)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mem_storage_round_trips() {
        let s = MemStorage::new();
        assert_eq!(s.read("x.json").unwrap(), None);
        s.write("x.json", b"hello").unwrap();
        assert_eq!(s.read("x.json").unwrap(), Some(b"hello".to_vec()));
    }

    #[test]
    fn arc_mem_storage_is_shared_across_handles() {
        let s = Arc::new(MemStorage::new());
        let s2 = s.clone();
        s.write("k", b"v").unwrap();
        assert_eq!(s2.read("k").unwrap(), Some(b"v".to_vec()));
    }
}
