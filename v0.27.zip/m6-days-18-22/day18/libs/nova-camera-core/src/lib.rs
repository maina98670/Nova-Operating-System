//! Camera app — Day 16 functional core.
//!
//! Owns the photo library metadata and capture logic. No UI here
//! (M7's job). No real camera HAL exists yet: per the build guide,
//! `nova-v4l2` was written without a Rust toolchain to test against
//! and has never been compiled or run against real hardware -- that
//! only happens on M9's Camera HAL day. `CameraBackend` is the seam a
//! real, M9-formalized `nova-v4l2` integration plugs into later;
//! `StubBackend` used here returns a deterministic synthetic frame,
//! so the rest of this pipeline (library metadata, per-photo scoped
//! storage) is real and testable now without pretending capture
//! works today.

use nova_app_storage::ScopedStorage;
use serde::{Deserialize, Serialize};

pub const INDEX_FILE: &str = "photos_index.json";

/// The seam a real, M9-formalized `nova-v4l2` integration plugs into.
/// Returns raw pixel bytes for a `width`x`height` capture.
pub trait CameraBackend {
    fn capture(&mut self, width: u32, height: u32) -> Result<Vec<u8>, String>;
}

/// No real camera HAL exists yet -- returns a deterministic,
/// zero-filled RGB buffer of the requested size. Explicitly a
/// placeholder, not a simulated "realistic" photo.
pub struct StubBackend;
impl CameraBackend for StubBackend {
    fn capture(&mut self, width: u32, height: u32) -> Result<Vec<u8>, String> {
        Ok(vec![0u8; (width as usize) * (height as usize) * 3])
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PhotoMeta {
    pub id: u32,
    pub file_name: String,
    pub width: u32,
    pub height: u32,
    pub timestamp_unix: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct OnDisk {
    next_id: u32,
    photos: Vec<PhotoMeta>,
}

#[derive(Debug)]
pub enum CameraError {
    NotFound(u32),
    Backend(String),
    Storage(String),
    Serialization(String),
}

impl std::fmt::Display for CameraError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CameraError::NotFound(id) => write!(f, "no photo with id {id}"),
            CameraError::Backend(e) => write!(f, "camera backend error: {e}"),
            CameraError::Storage(e) => write!(f, "storage error: {e}"),
            CameraError::Serialization(e) => write!(f, "serialization error: {e}"),
        }
    }
}
impl std::error::Error for CameraError {}

pub struct PhotoLibrary<S: ScopedStorage> {
    storage: S,
    photos: Vec<PhotoMeta>,
    next_id: u32,
}

impl<S: ScopedStorage> PhotoLibrary<S> {
    pub fn load(storage: S) -> Result<Self, CameraError> {
        let on_disk: OnDisk = match storage.read(INDEX_FILE).map_err(|e| CameraError::Storage(e.to_string()))? {
            Some(bytes) => serde_json::from_slice(&bytes).map_err(|e| CameraError::Serialization(e.to_string()))?,
            None => OnDisk::default(),
        };
        let next_id = if on_disk.next_id == 0 { 1 } else { on_disk.next_id };
        Ok(Self { storage, photos: on_disk.photos, next_id })
    }

    /// Captures via `backend`, writes the raw frame to this app's own
    /// scoped storage under `photos/`, and records it in the index.
    /// A backend error is propagated -- no metadata entry is created
    /// for a capture that didn't actually happen.
    pub fn capture(&mut self, backend: &mut impl CameraBackend, width: u32, height: u32, now_unix: u64) -> Result<u32, CameraError> {
        let bytes = backend.capture(width, height).map_err(CameraError::Backend)?;

        let id = self.next_id;
        self.next_id += 1;
        let file_name = format!("photo_{id}.raw");
        self.storage
            .write(&format!("photos/{file_name}"), &bytes)
            .map_err(|e| CameraError::Storage(e.to_string()))?;

        self.photos.push(PhotoMeta { id, file_name, width, height, timestamp_unix: now_unix });
        self.persist_index()?;
        Ok(id)
    }

    pub fn list(&self) -> &[PhotoMeta] {
        &self.photos
    }

    pub fn get(&self, id: u32) -> Option<&PhotoMeta> {
        self.photos.iter().find(|p| p.id == id)
    }

    /// Reads the raw frame bytes for a photo back from scoped storage.
    pub fn read_bytes(&self, id: u32) -> Result<Vec<u8>, CameraError> {
        let meta = self.get(id).ok_or(CameraError::NotFound(id))?;
        self.storage
            .read(&format!("photos/{}", meta.file_name))
            .map_err(|e| CameraError::Storage(e.to_string()))?
            .ok_or(CameraError::NotFound(id))
    }

    /// Removes the index entry. Note: `ScopedStorage` has no delete
    /// operation yet (`nova-sandbox`'s Day 15 scope was read/write
    /// only), so the underlying frame file is orphaned rather than
    /// actually deleted -- worth a real delete-scoped API in a later
    /// day rather than working around it here.
    pub fn delete(&mut self, id: u32) -> Result<(), CameraError> {
        let before = self.photos.len();
        self.photos.retain(|p| p.id != id);
        if self.photos.len() == before {
            return Err(CameraError::NotFound(id));
        }
        self.persist_index()
    }

    fn persist_index(&self) -> Result<(), CameraError> {
        let on_disk = OnDisk { next_id: self.next_id, photos: self.photos.clone() };
        let bytes = serde_json::to_vec_pretty(&on_disk).map_err(|e| CameraError::Serialization(e.to_string()))?;
        self.storage.write(INDEX_FILE, &bytes).map_err(|e| CameraError::Storage(e.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_app_storage::MemStorage;

    struct FailingBackend;
    impl CameraBackend for FailingBackend {
        fn capture(&mut self, _w: u32, _h: u32) -> Result<Vec<u8>, String> {
            Err("no camera hardware".into())
        }
    }

    #[test]
    fn capture_writes_frame_and_index_entry() {
        let mut lib = PhotoLibrary::load(MemStorage::new()).unwrap();
        let mut backend = StubBackend;
        let id = lib.capture(&mut backend, 640, 480, 1000).unwrap();

        let meta = lib.get(id).unwrap();
        assert_eq!((meta.width, meta.height), (640, 480));

        let bytes = lib.read_bytes(id).unwrap();
        assert_eq!(bytes.len(), 640 * 480 * 3);
    }

    #[test]
    fn backend_failure_creates_no_entry() {
        let mut lib = PhotoLibrary::load(MemStorage::new()).unwrap();
        let mut backend = FailingBackend;
        let result = lib.capture(&mut backend, 640, 480, 1000);
        assert!(matches!(result, Err(CameraError::Backend(_))));
        assert!(lib.list().is_empty());
    }

    #[test]
    fn delete_removes_index_entry() {
        let mut lib = PhotoLibrary::load(MemStorage::new()).unwrap();
        let mut backend = StubBackend;
        let id = lib.capture(&mut backend, 100, 100, 1000).unwrap();
        lib.delete(id).unwrap();
        assert!(lib.get(id).is_none());
        assert!(matches!(lib.delete(id), Err(CameraError::NotFound(_))));
    }
}
