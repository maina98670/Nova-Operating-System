//! Contacts app — Day 16 functional core.
//!
//! Owns the contact data model and CRUD/search logic. No UI here —
//! that's M7's (GUI & Window System's) job; this crate is what a
//! future Wayland front-end, or the IPC-driven shell, would call into.
//! Persists through `nova_app_storage::ScopedStorage`, so in
//! production this lives at `<APPS_DATA>/org.nova.contacts/contacts.json`
//! (Day 15's per-app filesystem scoping), and in tests it's an
//! in-memory `MemStorage` with no filesystem/root dependency at all.

use nova_app_storage::ScopedStorage;
use serde::{Deserialize, Serialize};

pub const STORAGE_FILE: &str = "contacts.json";

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Contact {
    pub id: u32,
    pub name: String,
    pub phone_numbers: Vec<String>,
    pub email: Option<String>,
    pub favorite: bool,
}

/// On-disk shape. `next_id` is persisted explicitly (not derived from
/// `contacts`'s current max) so an id is never reused after its
/// contact is removed and the app restarts -- deriving it from the
/// current list would let a deleted contact's id come back.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct OnDisk {
    next_id: u32,
    contacts: Vec<Contact>,
}

#[derive(Debug)]
pub enum ContactsError {
    NotFound(u32),
    Storage(String),
    Serialization(String),
}

impl std::fmt::Display for ContactsError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ContactsError::NotFound(id) => write!(f, "no contact with id {id}"),
            ContactsError::Storage(e) => write!(f, "storage error: {e}"),
            ContactsError::Serialization(e) => write!(f, "serialization error: {e}"),
        }
    }
}
impl std::error::Error for ContactsError {}

pub struct ContactStore<S: ScopedStorage> {
    storage: S,
    contacts: Vec<Contact>,
    next_id: u32,
}

impl<S: ScopedStorage> ContactStore<S> {
    /// Loads the store from `storage`, or starts empty if nothing has
    /// been saved yet (a fresh install, not an error).
    pub fn load(storage: S) -> Result<Self, ContactsError> {
        let on_disk: OnDisk = match storage.read(STORAGE_FILE).map_err(|e| ContactsError::Storage(e.to_string()))? {
            Some(bytes) => serde_json::from_slice(&bytes).map_err(|e| ContactsError::Serialization(e.to_string()))?,
            None => OnDisk::default(),
        };
        let next_id = if on_disk.next_id == 0 { 1 } else { on_disk.next_id };
        Ok(Self { storage, contacts: on_disk.contacts, next_id })
    }

    pub fn add(&mut self, name: impl Into<String>, phone_numbers: Vec<String>, email: Option<String>) -> Result<u32, ContactsError> {
        let id = self.next_id;
        self.next_id += 1;
        self.contacts.push(Contact { id, name: name.into(), phone_numbers, email, favorite: false });
        self.persist()?;
        Ok(id)
    }

    pub fn remove(&mut self, id: u32) -> Result<(), ContactsError> {
        let before = self.contacts.len();
        self.contacts.retain(|c| c.id != id);
        if self.contacts.len() == before {
            return Err(ContactsError::NotFound(id));
        }
        self.persist()
    }

    pub fn set_favorite(&mut self, id: u32, favorite: bool) -> Result<(), ContactsError> {
        let contact = self.contacts.iter_mut().find(|c| c.id == id).ok_or(ContactsError::NotFound(id))?;
        contact.favorite = favorite;
        self.persist()
    }

    pub fn get(&self, id: u32) -> Option<&Contact> {
        self.contacts.iter().find(|c| c.id == id)
    }

    pub fn list(&self) -> &[Contact] {
        &self.contacts
    }

    pub fn favorites(&self) -> Vec<&Contact> {
        self.contacts.iter().filter(|c| c.favorite).collect()
    }

    /// Case-insensitive substring match against name or any phone
    /// number. Good enough for a functional core; ranking/fuzzy match
    /// is a UI-layer concern for later.
    pub fn search(&self, query: &str) -> Vec<&Contact> {
        let q = query.to_lowercase();
        self.contacts
            .iter()
            .filter(|c| c.name.to_lowercase().contains(&q) || c.phone_numbers.iter().any(|p| p.contains(&q)))
            .collect()
    }

    fn persist(&self) -> Result<(), ContactsError> {
        let on_disk = OnDisk { next_id: self.next_id, contacts: self.contacts.clone() };
        let bytes = serde_json::to_vec_pretty(&on_disk).map_err(|e| ContactsError::Serialization(e.to_string()))?;
        self.storage.write(STORAGE_FILE, &bytes).map_err(|e| ContactsError::Storage(e.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_app_storage::MemStorage;
    use std::sync::Arc;

    #[test]
    fn add_and_get() {
        let mut store = ContactStore::load(MemStorage::new()).unwrap();
        let id = store.add("Faith Onyangore", vec!["+254700000001".into()], None).unwrap();
        let c = store.get(id).unwrap();
        assert_eq!(c.name, "Faith Onyangore");
        assert_eq!(c.phone_numbers, vec!["+254700000001".to_string()]);
    }

    #[test]
    fn search_is_case_insensitive_and_matches_numbers() {
        let mut store = ContactStore::load(MemStorage::new()).unwrap();
        store.add("Pauline Omaiyo", vec!["+254711111111".into()], None).unwrap();
        store.add("Faith Onyangore", vec!["+254722222222".into()], None).unwrap();

        assert_eq!(store.search("pauline").len(), 1);
        assert_eq!(store.search("ONYANGORE").len(), 1);
        assert_eq!(store.search("722222").len(), 1);
        assert_eq!(store.search("nonexistent").len(), 0);
    }

    #[test]
    fn remove_missing_contact_is_an_error() {
        let mut store = ContactStore::load(MemStorage::new()).unwrap();
        assert!(matches!(store.remove(999), Err(ContactsError::NotFound(999))));
    }

    #[test]
    fn favorite_toggle_round_trips() {
        let mut store = ContactStore::load(MemStorage::new()).unwrap();
        let id = store.add("Zeen", vec![], None).unwrap();
        assert!(store.favorites().is_empty());
        store.set_favorite(id, true).unwrap();
        assert_eq!(store.favorites().len(), 1);
    }

    /// The actual point of `ScopedStorage`: data written by one store
    /// instance is visible to a second one loaded against the same
    /// backing storage -- simulating the app restarting.
    #[test]
    fn persists_across_a_simulated_restart() {
        let backing = Arc::new(MemStorage::new());

        let id = {
            let mut store = ContactStore::load(backing.clone()).unwrap();
            store.add("Isaac Maina", vec!["+254733333333".into()], Some("isaac@example.com".into())).unwrap()
        };

        let store2 = ContactStore::load(backing).unwrap();
        let reloaded = store2.get(id).expect("contact should survive a reload");
        assert_eq!(reloaded.name, "Isaac Maina");
        assert_eq!(reloaded.email.as_deref(), Some("isaac@example.com"));
    }

    #[test]
    fn ids_never_reused_after_reload() {
        let backing = Arc::new(MemStorage::new());
        {
            let mut store = ContactStore::load(backing.clone()).unwrap();
            store.add("A", vec![], None).unwrap();
            let id_b = store.add("B", vec![], None).unwrap();
            store.remove(id_b).unwrap();
        }
        let mut store2 = ContactStore::load(backing).unwrap();
        let id_c = store2.add("C", vec![], None).unwrap();
        assert_eq!(id_c, 3, "next_id must resume from the highest id ever issued, not from list length");
    }
}
