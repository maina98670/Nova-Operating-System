//! Dialer app — Day 16 functional core.
//!
//! Owns the call-log data model and placing/logging calls. No UI here
//! (M7's job) and no real cellular HAL exists yet (M9's job, same
//! honesty as Messages and Camera). `TelephonyBackend` is the seam a
//! real modem HAL plugs into later; `StubTelephony` used here just
//! simulates an immediately-connected, zero-duration call, so the rest
//! of this pipeline (call log, history-by-number, missed-call
//! tracking) is real and testable now.

use nova_app_storage::ScopedStorage;
use serde::{Deserialize, Serialize};

pub const STORAGE_FILE: &str = "call_log.json";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CallDirection {
    Outgoing,
    Incoming,
    Missed,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct CallRecord {
    pub id: u32,
    pub number: String,
    pub direction: CallDirection,
    pub timestamp_unix: u64,
    pub duration_secs: u32,
}

/// The seam a real cellular/telephony HAL (M9) plugs into.
/// `place_call` returns the call's final duration in seconds once it
/// ends, or an error if the call couldn't be placed at all.
pub trait TelephonyBackend {
    fn place_call(&mut self, number: &str) -> Result<u32, String>;
}

/// No real cellular HAL exists yet -- this always "connects"
/// immediately with zero duration. Explicitly not pretending to be a
/// real modem.
pub struct StubTelephony;
impl TelephonyBackend for StubTelephony {
    fn place_call(&mut self, _number: &str) -> Result<u32, String> {
        Ok(0)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct OnDisk {
    next_id: u32,
    calls: Vec<CallRecord>,
}

#[derive(Debug)]
pub enum DialerError {
    Backend(String),
    Storage(String),
    Serialization(String),
}

impl std::fmt::Display for DialerError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DialerError::Backend(e) => write!(f, "telephony backend error: {e}"),
            DialerError::Storage(e) => write!(f, "storage error: {e}"),
            DialerError::Serialization(e) => write!(f, "serialization error: {e}"),
        }
    }
}
impl std::error::Error for DialerError {}

pub struct CallLog<S: ScopedStorage> {
    storage: S,
    calls: Vec<CallRecord>,
    next_id: u32,
}

impl<S: ScopedStorage> CallLog<S> {
    pub fn load(storage: S) -> Result<Self, DialerError> {
        let on_disk: OnDisk = match storage.read(STORAGE_FILE).map_err(|e| DialerError::Storage(e.to_string()))? {
            Some(bytes) => serde_json::from_slice(&bytes).map_err(|e| DialerError::Serialization(e.to_string()))?,
            None => OnDisk::default(),
        };
        let next_id = if on_disk.next_id == 0 { 1 } else { on_disk.next_id };
        Ok(Self { storage, calls: on_disk.calls, next_id })
    }

    /// Places a call via `backend` and logs it as `Outgoing` with the
    /// duration the backend reports. A backend error is propagated,
    /// not silently logged as a call that never happened.
    pub fn place_call(&mut self, backend: &mut impl TelephonyBackend, number: impl Into<String>, now_unix: u64) -> Result<u32, DialerError> {
        let number = number.into();
        let duration = backend.place_call(&number).map_err(DialerError::Backend)?;
        self.log(number, CallDirection::Outgoing, now_unix, duration)
    }

    pub fn log_incoming(&mut self, number: impl Into<String>, now_unix: u64, duration_secs: u32) -> Result<u32, DialerError> {
        self.log(number, CallDirection::Incoming, now_unix, duration_secs)
    }

    pub fn log_missed(&mut self, number: impl Into<String>, now_unix: u64) -> Result<u32, DialerError> {
        self.log(number, CallDirection::Missed, now_unix, 0)
    }

    fn log(&mut self, number: impl Into<String>, direction: CallDirection, timestamp_unix: u64, duration_secs: u32) -> Result<u32, DialerError> {
        let id = self.next_id;
        self.next_id += 1;
        self.calls.push(CallRecord { id, number: number.into(), direction, timestamp_unix, duration_secs });
        self.persist()?;
        Ok(id)
    }

    /// Most recent calls first, capped at `limit`.
    pub fn recent(&self, limit: usize) -> Vec<&CallRecord> {
        let mut calls: Vec<&CallRecord> = self.calls.iter().collect();
        calls.sort_by(|a, b| b.timestamp_unix.cmp(&a.timestamp_unix));
        calls.truncate(limit);
        calls
    }

    pub fn missed(&self) -> Vec<&CallRecord> {
        self.calls.iter().filter(|c| c.direction == CallDirection::Missed).collect()
    }

    pub fn history_for(&self, number: &str) -> Vec<&CallRecord> {
        let mut calls: Vec<&CallRecord> = self.calls.iter().filter(|c| c.number == number).collect();
        calls.sort_by_key(|c| c.timestamp_unix);
        calls
    }

    fn persist(&self) -> Result<(), DialerError> {
        let on_disk = OnDisk { next_id: self.next_id, calls: self.calls.clone() };
        let bytes = serde_json::to_vec_pretty(&on_disk).map_err(|e| DialerError::Serialization(e.to_string()))?;
        self.storage.write(STORAGE_FILE, &bytes).map_err(|e| DialerError::Storage(e.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_app_storage::MemStorage;

    struct FailingTelephony;
    impl TelephonyBackend for FailingTelephony {
        fn place_call(&mut self, _number: &str) -> Result<u32, String> {
            Err("no signal".into())
        }
    }

    #[test]
    fn place_call_logs_outgoing_with_backend_duration() {
        let mut log = CallLog::load(MemStorage::new()).unwrap();
        let mut backend = StubTelephony;
        log.place_call(&mut backend, "+254700000001", 1000).unwrap();
        let recent = log.recent(10);
        assert_eq!(recent.len(), 1);
        assert_eq!(recent[0].direction, CallDirection::Outgoing);
    }

    #[test]
    fn backend_failure_is_propagated_not_logged() {
        let mut log = CallLog::load(MemStorage::new()).unwrap();
        let mut backend = FailingTelephony;
        let result = log.place_call(&mut backend, "+254700000001", 1000);
        assert!(matches!(result, Err(DialerError::Backend(_))));
        assert!(log.recent(10).is_empty());
    }

    #[test]
    fn missed_calls_filtered_correctly() {
        let mut log = CallLog::load(MemStorage::new()).unwrap();
        log.log_missed("+254700000002", 1000).unwrap();
        log.log_incoming("+254700000003", 1100, 42).unwrap();
        assert_eq!(log.missed().len(), 1);
        assert_eq!(log.missed()[0].number, "+254700000002");
    }

    #[test]
    fn recent_is_ordered_newest_first_and_respects_limit() {
        let mut log = CallLog::load(MemStorage::new()).unwrap();
        log.log_incoming("a", 1000, 10).unwrap();
        log.log_incoming("b", 3000, 10).unwrap();
        log.log_incoming("c", 2000, 10).unwrap();
        let recent = log.recent(2);
        assert_eq!(recent.len(), 2);
        assert_eq!(recent[0].number, "b");
        assert_eq!(recent[1].number, "c");
    }

    #[test]
    fn history_for_number_is_chronological() {
        let mut log = CallLog::load(MemStorage::new()).unwrap();
        log.log_incoming("+254700000001", 2000, 10).unwrap();
        log.log_incoming("+254700000001", 1000, 5).unwrap();
        log.log_incoming("+254700000002", 1500, 5).unwrap();
        let history = log.history_for("+254700000001");
        assert_eq!(history.len(), 2);
        assert!(history[0].timestamp_unix < history[1].timestamp_unix);
    }
}
