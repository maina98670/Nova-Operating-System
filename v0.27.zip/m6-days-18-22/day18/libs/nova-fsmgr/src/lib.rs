//! Nova Filesystem Manager — M4 Day 4.
//!
//! Same discipline as Days 2-3: a supervising layer over what Linux
//! already does correctly. File I/O here is `std::fs` underneath —
//! Nova does not reimplement read/write/open/close, and per Section
//! 25, Nova does not build a custom filesystem at this stage either;
//! `mount`/`unmount` wrap the kernel's real `mount(2)`/`umount(2)`
//! syscalls against ext4 (or another mature filesystem) for the real
//! OS build. What this module actually adds is Nova's own standard
//! directory layout (an FHS-equivalent) and a single, consistent API
//! surface for file and mount operations, rather than every app or
//! service inventing its own paths and error handling.
//!
//! **Reconciliation note**: `nova-settings` (built before this
//! milestone existed) reads `/etc/nova-version` and
//! `/etc/nova-device-name` directly as flat files. This module's
//! `paths::CONFIG` formalizes `/etc/nova/` as the real config
//! directory going forward. That's a deliberate, visible inconsistency
//! rather than a silent one — migrating Settings to the new layout is
//! separate follow-up work, not done here, so as not to change a
//! previously-shipped, verified app's behavior as a side effect of an
//! unrelated milestone. `paths::RUN` (`/run/nova`) already matches
//! what `nova-procmgrd` (Day 2) uses for its socket by convention, so
//! at least that path was already consistent by accident.

use libc::c_ulong;
use std::ffi::CString;
use std::fs;
use std::io;
use std::path::Path;
use std::ptr;

/// Nova's standard directory layout — the FHS-equivalent Day 4 asks
/// for. This becomes the input to Section 21's repo/deploy structure.
pub mod paths {
    /// Read-only OS/system files.
    pub const SYSTEM: &str = "/system";
    /// Writable application/user data. Already in real use by
    /// nova-contacts and nova-messages (Section 16's `libs/` pattern)
    /// as `/var/lib/nova/*.tsv` — this constant formalizes that
    /// existing convention rather than replacing it.
    pub const DATA: &str = "/var/lib/nova";
    /// Installed app bundles, per Section 11's `.nova` package format.
    pub const APPS: &str = "/apps";
    /// Nova-specific configuration.
    pub const CONFIG: &str = "/etc/nova";
    /// Nova service logs.
    pub const LOG: &str = "/var/log/nova";
    /// Runtime state: sockets, pidfiles. Matches nova-procmgrd's
    /// existing `/run/nova/procmgr.sock` default (Day 2).
    pub const RUN: &str = "/run/nova";
    /// Nova-specific temporary files.
    pub const TMP: &str = "/tmp/nova";

    pub const ALL: &[&str] = &[SYSTEM, DATA, APPS, CONFIG, LOG, RUN, TMP];
}

/// Creates every directory in `dirs` (like `mkdir -p` for each).
/// Generic over the path list specifically so tests can pass a
/// temp-dir-prefixed fake layout instead of touching the real
/// system's `/etc`, `/var`, etc. — see `ensure_standard_dirs` for the
/// real-paths wrapper.
pub fn ensure_dirs(dirs: &[&str]) -> io::Result<()> {
    for dir in dirs {
        fs::create_dir_all(dir)?;
    }
    Ok(())
}

/// Creates Nova's real standard directory layout (`paths::ALL`) on
/// the actual system — what Nova Init (M2) would call during boot.
pub fn ensure_standard_dirs() -> io::Result<()> {
    ensure_dirs(paths::ALL)
}

// --- File CRUD: thin, consistent wrappers over std::fs ---

pub fn create_file(path: &Path, contents: &[u8]) -> io::Result<()> {
    if path.exists() {
        return Err(io::Error::new(io::ErrorKind::AlreadyExists, "file already exists"));
    }
    fs::write(path, contents)
}

pub fn read_file(path: &Path) -> io::Result<Vec<u8>> {
    fs::read(path)
}

pub fn write_file(path: &Path, contents: &[u8]) -> io::Result<()> {
    fs::write(path, contents)
}

/// Appends to a file, creating it if it doesn't exist. Added on Day 7
/// specifically because logging needs append semantics — `write_file`
/// above overwrites, which is correct for config/data files but wrong
/// for a log, which must never clobber prior entries. This is a
/// genuine, honest extension to Day 4's module, not a silent change
/// to what `write_file` does.
pub fn append_file(path: &Path, contents: &[u8]) -> io::Result<()> {
    use std::io::Write;
    let mut file = fs::OpenOptions::new().create(true).append(true).open(path)?;
    file.write_all(contents)
}

pub fn delete_file(path: &Path) -> io::Result<()> {
    fs::remove_file(path)
}

pub fn rename_file(from: &Path, to: &Path) -> io::Result<()> {
    fs::rename(from, to)
}

// --- Mounting: real mount(2)/umount(2), the same syscalls Nova Init
//     (M2) already uses for /proc, /sys, /dev, generalized here into
//     a reusable, independently-testable library function. ---

pub fn mount(source: &str, target: &Path, fstype: &str, flags: c_ulong, data: Option<&str>) -> io::Result<()> {
    let c_source = CString::new(source).map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "nul byte in source"))?;
    let c_target = CString::new(target.to_string_lossy().as_bytes())
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "nul byte in target"))?;
    let c_fstype = CString::new(fstype).map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "nul byte in fstype"))?;
    let c_data = match data {
        Some(d) => Some(CString::new(d).map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "nul byte in data"))?),
        None => None,
    };

    let ret = unsafe {
        libc::mount(
            c_source.as_ptr(),
            c_target.as_ptr(),
            c_fstype.as_ptr(),
            flags,
            c_data.as_ref().map(|d| d.as_ptr() as *const libc::c_void).unwrap_or(ptr::null()),
        )
    };

    if ret == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

pub fn unmount(target: &Path) -> io::Result<()> {
    let c_target = CString::new(target.to_string_lossy().as_bytes())
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "nul byte in target"))?;
    let ret = unsafe { libc::umount(c_target.as_ptr()) };
    if ret == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;

    fn temp_path(name: &str) -> std::path::PathBuf {
        env::temp_dir().join(format!("nova-fsmgr-test-{}-{}", std::process::id(), name))
    }

    /// The literal Day 4 DoD: create, write, read back correctly,
    /// rename, delete -- through Nova's Filesystem Manager API.
    #[test]
    fn day4_definition_of_done_file_crud_cycle() {
        let path = temp_path("crud.txt");
        let renamed = temp_path("crud-renamed.txt");
        let _ = fs::remove_file(&path);
        let _ = fs::remove_file(&renamed);

        create_file(&path, b"hello nova").expect("create should succeed");
        let read_back = read_file(&path).expect("read should succeed");
        assert_eq!(read_back, b"hello nova", "read-back content must match what was written");

        write_file(&path, b"updated content").expect("write (overwrite) should succeed");
        assert_eq!(read_file(&path).unwrap(), b"updated content");

        rename_file(&path, &renamed).expect("rename should succeed");
        assert!(!path.exists(), "original path should no longer exist after rename");
        assert!(renamed.exists(), "renamed path should exist");

        delete_file(&renamed).expect("delete should succeed");
        assert!(!renamed.exists(), "file should be gone after delete");
    }

    #[test]
    fn append_file_preserves_prior_content_and_creates_if_missing() {
        let path = temp_path("append.log");
        let _ = fs::remove_file(&path);

        append_file(&path, b"line one\n").expect("append should create the file if missing");
        append_file(&path, b"line two\n").expect("append should succeed on an existing file");

        let contents = read_file(&path).unwrap();
        assert_eq!(contents, b"line one\nline two\n", "append must preserve prior content, never overwrite it");

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn create_file_fails_if_already_exists() {
        let path = temp_path("exists.txt");
        let _ = fs::remove_file(&path);
        create_file(&path, b"first").unwrap();
        let result = create_file(&path, b"second");
        assert!(result.is_err(), "create_file should refuse to clobber an existing file");
        assert_eq!(read_file(&path).unwrap(), b"first", "original content should be untouched");
        let _ = fs::remove_file(&path);
    }

    #[test]
    fn read_nonexistent_file_errors_cleanly() {
        let path = temp_path("does-not-exist.txt");
        let _ = fs::remove_file(&path);
        assert!(read_file(&path).is_err());
    }

    /// Second half of the Day 4 DoD: "a second filesystem/mount point
    /// can be mounted and unmounted cleanly." tmpfs is a real, mature
    /// Linux filesystem (Section 25 permits "another mature
    /// filesystem" -- this test exercises the mount/unmount mechanism
    /// itself, not Nova's eventual root-filesystem choice).
    #[test]
    fn day4_definition_of_done_mount_unmount_tmpfs() {
        let mountpoint = temp_path("mnt");
        let _ = fs::remove_dir_all(&mountpoint);
        fs::create_dir_all(&mountpoint).expect("create mountpoint dir");

        mount("nova-test-tmpfs", &mountpoint, "tmpfs", 0, Some("size=4m"))
            .expect("mount should succeed (needs root -- this sandbox runs as root)");

        // Prove it's a real, distinct mount: write a file inside it,
        // unmount, and confirm the file is gone (it lived in tmpfs's
        // own memory-backed storage, not the underlying directory).
        let file_in_mount = mountpoint.join("proof.txt");
        create_file(&file_in_mount, b"this only exists inside the mount").expect("write inside mount");
        assert!(file_in_mount.exists());

        unmount(&mountpoint).expect("unmount should succeed cleanly");

        assert!(
            !file_in_mount.exists(),
            "file should be gone after unmount -- proves this was a real separate mount, not just a directory"
        );

        let _ = fs::remove_dir_all(&mountpoint);
    }

    #[test]
    fn unmount_non_mountpoint_errors_cleanly_not_panic() {
        let path = temp_path("not-a-mountpoint");
        fs::create_dir_all(&path).unwrap();
        let result = unmount(&path);
        assert!(result.is_err(), "unmounting a plain directory should error, not panic");
        let _ = fs::remove_dir_all(&path);
    }

    #[test]
    fn ensure_dirs_creates_nested_directories() {
        let base = temp_path("ensure-dirs-root");
        let _ = fs::remove_dir_all(&base);
        let nested = base.join("a/b/c");
        let nested_str = nested.to_string_lossy().to_string();

        ensure_dirs(&[&nested_str]).expect("ensure_dirs should succeed");
        assert!(nested.is_dir());

        let _ = fs::remove_dir_all(&base);
    }

    #[test]
    fn standard_paths_are_absolute_and_distinct() {
        use std::collections::HashSet;
        let set: HashSet<&str> = paths::ALL.iter().copied().collect();
        assert_eq!(set.len(), paths::ALL.len(), "standard paths should all be distinct");
        for p in paths::ALL {
            assert!(p.starts_with('/'), "{p} should be an absolute path");
        }
    }
}
