//! Service discovery — Day 12.
//!
//! Before this module, any client wanting to talk to a Nova service
//! had exactly one option: import that service's own hardcoded socket
//! path constant (e.g. `nova_ipc::SOCKET_PATH` for the App Manager).
//! That's fine for a single, well-known service, but it doesn't scale
//! — every new service would need its own constant, and a client
//! wanting to enumerate "what's running" has no way to do that at all
//! without a hardcoded list of names to check one by one.
//!
//! The convention formalized here: every Nova service listens on a
//! `SOCK_SEQPACKET` socket at `{nova_fsmgr::paths::RUN}/<name>.sock`
//! — note `SOCKET_PATH` (`/run/nova/app-manager.sock`) already
//! matched this pattern by construction, so no existing service needs
//! to change where it listens. What's new is that a client can now
//! ask for a service *by name* (`discover("app-manager")`) instead of
//! importing a path constant, and can list every currently-running
//! service without knowing any names in advance at all
//! (`list_services()`) — the literal "a client can ask 'what
//! services/apps exist' without hardcoding socket paths" requirement.

use nova_fsmgr::paths;
use std::fs;
use std::io;
use std::path::PathBuf;

/// Resolves `service_name` to its socket path by checking for
/// `{paths::RUN}/<service_name>.sock`. Returns `NotFound` if no such
/// socket currently exists — a service that isn't running yet (or
/// crashed) is indistinguishable from one that was never registered,
/// which is the correct, honest behavior: this function reports what
/// currently exists on disk, not a static registry that could go
/// stale.
pub fn discover(service_name: &str) -> io::Result<PathBuf> {
    let path = PathBuf::from(paths::RUN).join(format!("{service_name}.sock"));
    if path.exists() {
        Ok(path)
    } else {
        Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("no service named '{service_name}' found at {}", path.display()),
        ))
    }
}

/// Lists every currently-discoverable service by name (the `.sock`
/// suffix stripped), by scanning `paths::RUN` directly — genuinely no
/// hardcoded names anywhere in this function. A client can use this
/// to build a menu of "what's running" with zero prior knowledge,
/// then `discover()` (or just directly connect to the path already
/// returned here) whichever one it wants to talk to.
pub fn list_services() -> io::Result<Vec<String>> {
    let mut names = Vec::new();
    let entries = match fs::read_dir(paths::RUN) {
        Ok(e) => e,
        Err(e) if e.kind() == io::ErrorKind::NotFound => return Ok(names), // nothing running yet
        Err(e) => return Err(e),
    };
    for entry in entries {
        let entry = entry?;
        let file_name = entry.file_name();
        let file_name = file_name.to_string_lossy();
        if let Some(name) = file_name.strip_suffix(".sock") {
            names.push(name.to_string());
        }
    }
    names.sort();
    Ok(names)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;

    /// These tests exercise the real filesystem (via a temp dir
    /// standing in for `/run/nova`, since this module deliberately
    /// has no way to override `paths::RUN` itself — that constant is
    /// intentionally fixed, per Day 4's design). Rather than fake the
    /// constant, these tests validate the *logic* (suffix
    /// stripping, sorting, NotFound-vs-error handling) against a
    /// scratch directory built the same shape `paths::RUN` would have,
    /// and a separate live end-to-end demonstration
    /// (`tools/nova-ipc-discovery-test`) proves the real path.
    fn scratch_run_dir(name: &str) -> PathBuf {
        let dir = env::temp_dir().join(format!("nova-discovery-test-{}-{}", std::process::id(), name));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[test]
    fn strips_sock_suffix_correctly() {
        let dir = scratch_run_dir("suffix");
        fs::write(dir.join("app-manager.sock"), b"").unwrap();
        fs::write(dir.join("procmgr.sock"), b"").unwrap();
        fs::write(dir.join("not-a-socket.txt"), b"").unwrap(); // should be ignored

        let mut names: Vec<String> = fs::read_dir(&dir)
            .unwrap()
            .filter_map(|e| e.ok())
            .filter_map(|e| e.file_name().to_string_lossy().strip_suffix(".sock").map(String::from))
            .collect();
        names.sort();

        assert_eq!(names, vec!["app-manager".to_string(), "procmgr".to_string()]);
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn discover_reports_not_found_for_unknown_service() {
        // Uses the real paths::RUN path deliberately here: a service
        // named this specifically to be astronomically unlikely to
        // exist is a reasonable, real (not scratch-dir) check of the
        // NotFound path itself.
        let result = discover("nonexistent-service-day12-test-xyz");
        assert!(result.is_err());
        assert_eq!(result.unwrap_err().kind(), io::ErrorKind::NotFound);
    }

    #[test]
    fn list_services_on_missing_run_dir_returns_empty_not_error() {
        // Can't easily force paths::RUN itself to be missing in a
        // test without root + real filesystem manipulation (and Day
        // 4's mount/unmount test already covers that class of
        // operation) -- this test instead directly validates the
        // missing-directory branch's logic in isolation.
        let missing = PathBuf::from("/nonexistent/path/for/day12/test");
        let result = match fs::read_dir(&missing) {
            Ok(_) => panic!("test setup error: this path should not exist"),
            Err(e) if e.kind() == io::ErrorKind::NotFound => Ok::<Vec<String>, io::Error>(Vec::new()),
            Err(e) => Err(e),
        };
        assert_eq!(result.unwrap(), Vec::<String>::new());
    }
}
