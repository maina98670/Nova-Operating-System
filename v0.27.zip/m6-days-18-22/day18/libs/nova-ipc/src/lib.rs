//! Nova App Control IPC — protocol v1.
//!
//! Implements the wire format specified in `protocols/nova-ipc-v1.md`.
//! This crate has no OS-layer dependency beyond `libc` for the
//! `SOCK_SEQPACKET` socket calls themselves (Section 16 of the guide:
//! "libs/ holds logic with no OS-layer dependency ... so it can be
//! unit-tested in isolation, without booting QEMU") — encode/decode is
//! pure, and the `tests` module below round-trips every message type
//! without touching a real socket.
//!
//! Used by: nova-app-manager (system service), nova-shell (M4, as a
//! client asking "what apps exist" / "launch this one"), and every
//! sandboxed app (to say Hello, request permissions, report cold-start
//! time).

use std::io;
use std::mem;
use std::os::unix::io::{AsRawFd, FromRawFd, RawFd};

pub const PROTOCOL_VERSION: u8 = 1;

pub const SOCKET_PATH: &str = "/run/nova/app-manager.sock";

mod discovery;
pub use discovery::{discover, list_services};

/// Fixed, closed permission set (protocol spec: "not an open string
/// namespace"). Display/Input are implicitly granted and not
/// requestable — everything else must appear in the manifest or be
/// requested at runtime.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum Permission {
    Display = 0,
    Input = 1,
    Network = 2,
    Location = 3,
    Contacts = 4,
    Camera = 5,
    Microphone = 6,
    Sms = 7,
    HealthData = 8,
    Storage = 9,
}

impl Permission {
    pub const ALL: [Permission; 10] = [
        Permission::Display,
        Permission::Input,
        Permission::Network,
        Permission::Location,
        Permission::Contacts,
        Permission::Camera,
        Permission::Microphone,
        Permission::Sms,
        Permission::HealthData,
        Permission::Storage,
    ];

    pub fn bit(self) -> u32 {
        1u32 << (self as u8)
    }

    pub fn from_id(id: u8) -> Option<Permission> {
        Permission::ALL.into_iter().find(|p| *p as u8 == id)
    }

    pub fn name(self) -> &'static str {
        match self {
            Permission::Display => "display",
            Permission::Input => "input",
            Permission::Network => "network",
            Permission::Location => "location",
            Permission::Contacts => "contacts",
            Permission::Camera => "camera",
            Permission::Microphone => "microphone",
            Permission::Sms => "sms",
            Permission::HealthData => "health_data",
            Permission::Storage => "storage",
        }
    }

    pub fn from_name(s: &str) -> Option<Permission> {
        Permission::ALL.into_iter().find(|p| p.name() == s)
    }

    /// Permissions every launched app gets without asking — see
    /// "Permission model" in the protocol spec.
    pub fn implicit_bitmask() -> u32 {
        Permission::Display.bit() | Permission::Input.bit()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum LifecycleEvent {
    Foreground = 0,
    Background = 1,
    Suspend = 2,
    Terminate = 3,
}

impl LifecycleEvent {
    fn from_u8(v: u8) -> Option<Self> {
        Some(match v {
            0 => LifecycleEvent::Foreground,
            1 => LifecycleEvent::Background,
            2 => LifecycleEvent::Suspend,
            3 => LifecycleEvent::Terminate,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AppListEntry {
    pub id: String,
    pub name: String,
}

/// One decoded protocol message. Encoding/decoding lives entirely in
/// this file so the wire format has exactly one implementation shared
/// by every crate that speaks it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Message {
    Hello { app_id: String, pid: u32 },
    HelloAck { accepted: bool, granted_permissions: u32 },
    PermissionRequest { permission: Permission },
    PermissionResponse { permission: Permission, granted: bool },
    Lifecycle { event: LifecycleEvent },
    ColdStartReport { elapsed_ms: u32 },
    ListApps,
    AppList { apps: Vec<AppListEntry> },
    LaunchApp { app_id: String },
    LaunchResult { ok: bool, pid: u32, reason: String },
    /// Day 11: lets any client — not just one that's already completed
    /// the Hello handshake — ask the running server what protocol
    /// version it actually speaks, before committing to a session.
    /// This is the runtime-queryable version the Day 11 DoD asks for,
    /// distinct from `PROTOCOL_VERSION` being a compile-time constant
    /// a *linked* client can read: a diagnostic tool, a version of
    /// nova-shell built against a different nova-ipc release, or
    /// anything else not compiled against this exact crate version
    /// can still ask a running nova-app-manager directly.
    VersionQuery,
    VersionResponse { protocol_version: u8 },
}

impl Message {
    fn type_byte(&self) -> u8 {
        match self {
            Message::Hello { .. } => 0x01,
            Message::HelloAck { .. } => 0x02,
            Message::PermissionRequest { .. } => 0x03,
            Message::PermissionResponse { .. } => 0x04,
            Message::Lifecycle { .. } => 0x05,
            Message::ColdStartReport { .. } => 0x06,
            Message::ListApps => 0x07,
            Message::AppList { .. } => 0x08,
            Message::LaunchApp { .. } => 0x09,
            Message::LaunchResult { .. } => 0x0A,
            Message::VersionQuery => 0x0B,
            Message::VersionResponse { .. } => 0x0C,
        }
    }

    /// Whether this message type is exempt from the protocol-version
    /// check in `decode` — see the "Version-independent messages"
    /// section of the protocol spec. Only `VersionQuery` and
    /// `VersionResponse` qualify: their wire format is a permanent,
    /// stable commitment (one byte, or nothing) specifically so a
    /// client can ask "what version are you?" *before* knowing
    /// whether it can speak the server's version at all — the whole
    /// mechanism is useless if it itself requires a version match
    /// first.
    fn is_version_independent(msg_type: u8) -> bool {
        matches!(msg_type, 0x0B | 0x0C)
    }

    /// Encode to the wire format: version | type | u32 len | payload.
    /// Callers send the result as a single SOCK_SEQPACKET datagram —
    /// message boundaries come from the kernel, not from this framing.
    pub fn encode(&self) -> Vec<u8> {
        let mut payload = Vec::new();
        match self {
            Message::Hello { app_id, pid } => {
                put_str(&mut payload, app_id);
                payload.extend_from_slice(&pid.to_le_bytes());
            }
            Message::HelloAck { accepted, granted_permissions } => {
                payload.push(*accepted as u8);
                payload.extend_from_slice(&granted_permissions.to_le_bytes());
            }
            Message::PermissionRequest { permission } => {
                payload.push(*permission as u8);
            }
            Message::PermissionResponse { permission, granted } => {
                payload.push(*permission as u8);
                payload.push(*granted as u8);
            }
            Message::Lifecycle { event } => {
                payload.push(*event as u8);
            }
            Message::ColdStartReport { elapsed_ms } => {
                payload.extend_from_slice(&elapsed_ms.to_le_bytes());
            }
            Message::ListApps => {}
            Message::AppList { apps } => {
                payload.extend_from_slice(&(apps.len() as u16).to_le_bytes());
                for entry in apps {
                    put_str(&mut payload, &entry.id);
                    put_str(&mut payload, &entry.name);
                }
            }
            Message::LaunchApp { app_id } => {
                put_str(&mut payload, app_id);
            }
            Message::LaunchResult { ok, pid, reason } => {
                payload.push(*ok as u8);
                payload.extend_from_slice(&pid.to_le_bytes());
                put_str(&mut payload, reason);
            }
            Message::VersionQuery => {}
            Message::VersionResponse { protocol_version } => {
                payload.push(*protocol_version);
            }
        }

        let mut out = Vec::with_capacity(6 + payload.len());
        out.push(PROTOCOL_VERSION);
        out.push(self.type_byte());
        out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        out.extend_from_slice(&payload);
        out
    }

    /// Decode a single received datagram. Returns an error on version
    /// mismatch, unknown type, or truncated payload — per the spec,
    /// none of these are recoverable; the caller drops the connection.
    pub fn decode(buf: &[u8]) -> io::Result<Message> {
        if buf.len() < 6 {
            return Err(err("message shorter than the 6-byte header"));
        }
        let version = buf[0];
        let msg_type = buf[1];

        // VersionQuery/VersionResponse are exempt from the version
        // check by design — see `is_version_independent`. Every other
        // message type still enforces an exact match, unchanged.
        if version != PROTOCOL_VERSION && !Message::is_version_independent(msg_type) {
            return Err(err(&format!(
                "protocol version mismatch: got {version}, speak {PROTOCOL_VERSION}"
            )));
        }
        let len = u32::from_le_bytes([buf[2], buf[3], buf[4], buf[5]]) as usize;
        let payload = &buf[6..];
        if payload.len() != len {
            return Err(err("payload length header doesn't match datagram size"));
        }

        let mut r = Reader::new(payload);
        Ok(match msg_type {
            0x01 => Message::Hello { app_id: r.str()?, pid: r.u32()? },
            0x02 => Message::HelloAck {
                accepted: r.u8()? != 0,
                granted_permissions: r.u32()?,
            },
            0x03 => Message::PermissionRequest {
                permission: Permission::from_id(r.u8()?)
                    .ok_or_else(|| err("unknown permission id"))?,
            },
            0x04 => Message::PermissionResponse {
                permission: Permission::from_id(r.u8()?)
                    .ok_or_else(|| err("unknown permission id"))?,
                granted: r.u8()? != 0,
            },
            0x05 => Message::Lifecycle {
                event: LifecycleEvent::from_u8(r.u8()?)
                    .ok_or_else(|| err("unknown lifecycle event"))?,
            },
            0x06 => Message::ColdStartReport { elapsed_ms: r.u32()? },
            0x07 => Message::ListApps,
            0x08 => {
                let count = r.u16()?;
                let mut apps = Vec::with_capacity(count as usize);
                for _ in 0..count {
                    let id = r.str()?;
                    let name = r.str()?;
                    apps.push(AppListEntry { id, name });
                }
                Message::AppList { apps }
            }
            0x09 => Message::LaunchApp { app_id: r.str()? },
            0x0A => Message::LaunchResult {
                ok: r.u8()? != 0,
                pid: r.u32()?,
                reason: r.str()?,
            },
            0x0B => Message::VersionQuery,
            0x0C => Message::VersionResponse { protocol_version: r.u8()? },
            other => return Err(err(&format!("unknown message type 0x{other:02X}"))),
        })
    }
}

fn put_str(out: &mut Vec<u8>, s: &str) {
    out.extend_from_slice(&(s.len() as u16).to_le_bytes());
    out.extend_from_slice(s.as_bytes());
}

fn err(msg: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, msg.to_string())
}

struct Reader<'a> {
    buf: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    fn new(buf: &'a [u8]) -> Self {
        Reader { buf, pos: 0 }
    }

    fn take(&mut self, n: usize) -> io::Result<&'a [u8]> {
        if self.pos + n > self.buf.len() {
            return Err(err("truncated message payload"));
        }
        let s = &self.buf[self.pos..self.pos + n];
        self.pos += n;
        Ok(s)
    }

    fn u8(&mut self) -> io::Result<u8> {
        Ok(self.take(1)?[0])
    }

    fn u16(&mut self) -> io::Result<u16> {
        let b = self.take(2)?;
        Ok(u16::from_le_bytes([b[0], b[1]]))
    }

    fn u32(&mut self) -> io::Result<u32> {
        let b = self.take(4)?;
        Ok(u32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }

    fn str(&mut self) -> io::Result<String> {
        let len = self.u16()? as usize;
        let bytes = self.take(len)?;
        String::from_utf8(bytes.to_vec()).map_err(|_| err("non-UTF-8 string field"))
    }
}

/// Thin wrapper around a `SOCK_SEQPACKET` Unix socket. `std` has no
/// stable `SeqPacket` type (only `UnixStream`/`UnixDatagram`), so this
/// goes straight to `libc` for `socket()`/`bind()`/`connect()` — the
/// same reason nova-init (M2) already depends on `libc` rather than a
/// heavier abstraction crate.
pub struct SeqPacketSocket {
    fd: RawFd,
}

impl SeqPacketSocket {
    /// Connect as a client (used by apps and by nova-shell).
    pub fn connect(path: &str) -> io::Result<Self> {
        let fd = unsafe { libc::socket(libc::AF_UNIX, libc::SOCK_SEQPACKET, 0) };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        let addr = unix_sockaddr(path)?;
        let ret = unsafe {
            libc::connect(
                fd,
                &addr as *const _ as *const libc::sockaddr,
                mem::size_of::<libc::sockaddr_un>() as libc::socklen_t,
            )
        };
        if ret < 0 {
            let e = io::Error::last_os_error();
            unsafe { libc::close(fd) };
            return Err(e);
        }
        Ok(SeqPacketSocket { fd })
    }

    /// Bind + listen as the server (used by nova-app-manager). Returns
    /// a listening socket; `accept()` yields per-connection
    /// `SeqPacketSocket`s.
    pub fn listen(path: &str) -> io::Result<Self> {
        let _ = std::fs::remove_file(path); // stale socket from a previous run
        let fd = unsafe { libc::socket(libc::AF_UNIX, libc::SOCK_SEQPACKET, 0) };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        let addr = unix_sockaddr(path)?;
        let ret = unsafe {
            libc::bind(
                fd,
                &addr as *const _ as *const libc::sockaddr,
                mem::size_of::<libc::sockaddr_un>() as libc::socklen_t,
            )
        };
        if ret < 0 {
            let e = io::Error::last_os_error();
            unsafe { libc::close(fd) };
            return Err(e);
        }
        // 0660, nova-system group — see "What's deliberately out of
        // scope" in the protocol spec re: filesystem-permission auth.
        unsafe {
            let cpath = std::ffi::CString::new(path).unwrap();
            libc::chmod(cpath.as_ptr(), 0o660);
        }
        if unsafe { libc::listen(fd, 16) } < 0 {
            let e = io::Error::last_os_error();
            unsafe { libc::close(fd) };
            return Err(e);
        }
        Ok(SeqPacketSocket { fd })
    }

    pub fn accept(&self) -> io::Result<SeqPacketSocket> {
        let fd = unsafe { libc::accept(self.fd, std::ptr::null_mut(), std::ptr::null_mut()) };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(SeqPacketSocket { fd })
    }

    /// Read the connecting process's real uid/gid/pid via
    /// `SO_PEERCRED` — the actual auth mechanism per the protocol
    /// spec, independent of anything the app claims in `Hello`.
    pub fn peer_credentials(&self) -> io::Result<(u32, u32, i32)> {
        let mut cred: libc::ucred = unsafe { mem::zeroed() };
        let mut len = mem::size_of::<libc::ucred>() as libc::socklen_t;
        let ret = unsafe {
            libc::getsockopt(
                self.fd,
                libc::SOL_SOCKET,
                libc::SO_PEERCRED,
                &mut cred as *mut _ as *mut libc::c_void,
                &mut len,
            )
        };
        if ret < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok((cred.uid, cred.gid, cred.pid))
    }

    pub fn send(&self, msg: &Message) -> io::Result<()> {
        let bytes = msg.encode();
        let ret = unsafe { libc::send(self.fd, bytes.as_ptr() as *const _, bytes.len(), 0) };
        if ret < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(())
    }

    /// Blocking receive of exactly one datagram (one message).
    pub fn recv(&self) -> io::Result<Message> {
        // Generously sized for this protocol's small messages (spec:
        // "all well under 1KB by design") with headroom for an
        // AppList response listing a realistic number of installed
        // apps.
        let mut buf = vec![0u8; 8192];
        let n = unsafe { libc::recv(self.fd, buf.as_mut_ptr() as *mut _, buf.len(), 0) };
        if n < 0 {
            return Err(io::Error::last_os_error());
        }
        if n == 0 {
            return Err(err("peer closed the connection"));
        }
        buf.truncate(n as usize);
        Message::decode(&buf)
    }
}

impl Drop for SeqPacketSocket {
    fn drop(&mut self) {
        unsafe { libc::close(self.fd) };
    }
}

impl AsRawFd for SeqPacketSocket {
    fn as_raw_fd(&self) -> RawFd {
        self.fd
    }
}

impl FromRawFd for SeqPacketSocket {
    unsafe fn from_raw_fd(fd: RawFd) -> Self {
        SeqPacketSocket { fd }
    }
}

fn unix_sockaddr(path: &str) -> io::Result<libc::sockaddr_un> {
    if path.len() >= 108 {
        // sun_path is 108 bytes on Linux, including the NUL terminator.
        return Err(err("socket path too long for sockaddr_un"));
    }
    let mut addr: libc::sockaddr_un = unsafe { mem::zeroed() };
    addr.sun_family = libc::AF_UNIX as libc::sa_family_t;
    for (i, b) in path.as_bytes().iter().enumerate() {
        addr.sun_path[i] = *b as libc::c_char;
    }
    Ok(addr)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn roundtrip(m: Message) {
        let encoded = m.encode();
        let decoded = Message::decode(&encoded).expect("decode failed");
        assert_eq!(m, decoded);
    }

    #[test]
    fn roundtrip_all_message_types() {
        roundtrip(Message::Hello { app_id: "org.nova.hello".into(), pid: 4242 });
        roundtrip(Message::HelloAck {
            accepted: true,
            granted_permissions: Permission::implicit_bitmask(),
        });
        roundtrip(Message::PermissionRequest { permission: Permission::Network });
        roundtrip(Message::PermissionResponse {
            permission: Permission::Network,
            granted: false,
        });
        roundtrip(Message::Lifecycle { event: LifecycleEvent::Background });
        roundtrip(Message::ColdStartReport { elapsed_ms: 187 });
        roundtrip(Message::ListApps);
        roundtrip(Message::AppList {
            apps: vec![
                AppListEntry { id: "org.nova.phone".into(), name: "Phone".into() },
                AppListEntry { id: "org.nova.hello".into(), name: "Hello".into() },
            ],
        });
        roundtrip(Message::LaunchApp { app_id: "org.nova.hello".into() });
        roundtrip(Message::LaunchResult { ok: true, pid: 4242, reason: String::new() });
        roundtrip(Message::LaunchResult {
            ok: false,
            pid: 0,
            reason: "manifest missing entry binary".into(),
        });
        roundtrip(Message::VersionQuery);
        roundtrip(Message::VersionResponse { protocol_version: PROTOCOL_VERSION });
    }

    #[test]
    fn rejects_wrong_version() {
        let mut bytes = Message::ListApps.encode();
        bytes[0] = 99;
        assert!(Message::decode(&bytes).is_err());
    }

    /// Day 11's actual point: VersionQuery/VersionResponse must
    /// decode successfully even when the version byte doesn't match
    /// what this build speaks — that's the entire mechanism a client
    /// would use to discover a mismatch *before* attempting a real
    /// session, per the protocol spec's Versioning & Compatibility
    /// Policy section.
    #[test]
    fn version_query_and_response_survive_a_version_mismatch() {
        let mut query_bytes = Message::VersionQuery.encode();
        query_bytes[0] = 99; // simulate a client claiming to speak v99
        let decoded = Message::decode(&query_bytes).expect("VersionQuery must decode despite version mismatch");
        assert_eq!(decoded, Message::VersionQuery);

        let mut response_bytes = Message::VersionResponse { protocol_version: 1 }.encode();
        response_bytes[0] = 99; // simulate a server claiming to speak v99 in the header
        let decoded = Message::decode(&response_bytes).expect("VersionResponse must decode despite header mismatch");
        assert_eq!(decoded, Message::VersionResponse { protocol_version: 1 });
    }

    #[test]
    fn non_version_messages_still_reject_mismatch_even_with_the_new_exemption_present() {
        // Guards against a sloppy is_version_independent implementation
        // accidentally exempting everything instead of just 0x0B/0x0C.
        let mut bytes = Message::Hello { app_id: "x".into(), pid: 1 }.encode();
        bytes[0] = 99;
        assert!(Message::decode(&bytes).is_err());
    }

    #[test]
    fn rejects_truncated_payload() {
        let mut bytes = Message::Hello { app_id: "x".into(), pid: 1 }.encode();
        bytes.truncate(bytes.len() - 2);
        assert!(Message::decode(&bytes).is_err());
    }

    #[test]
    fn implicit_permissions_dont_need_a_grant() {
        let mask = Permission::implicit_bitmask();
        assert_eq!(mask & Permission::Display.bit(), Permission::Display.bit());
        assert_eq!(mask & Permission::Input.bit(), Permission::Input.bit());
        assert_eq!(mask & Permission::Camera.bit(), 0);
    }
}
