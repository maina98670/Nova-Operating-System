//! Messages app — Day 16 functional core.
//!
//! Owns the SMS data model, threading-by-peer-number, and send/receive
//! logic. No UI here (M7's job) and no real cellular/SMS HAL exists yet
//! — the guide schedules HAL work for M9, the same honesty it already
//! applies to the `nova-v4l2` camera driver. `SmsTransport` is the seam
//! a real modem HAL implementation plugs into later; `StubTransport`
//! used here just marks outgoing messages `Sent` immediately, so the
//! rest of this pipeline (storage, threading, status tracking) is real
//! and testable now without pretending a modem exists today.

use nova_app_storage::ScopedStorage;
use serde::{Deserialize, Serialize};

pub const STORAGE_FILE: &str = "messages.json";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Direction {
    Incoming,
    Outgoing,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MessageStatus {
    Queued,
    Sent,
    Failed,
    Received,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Message {
    pub id: u32,
    /// The other party's number. Threads are grouped by this, not by
    /// a separate thread-id concept -- one peer, one thread, matching
    /// how SMS actually works.
    pub peer_number: String,
    pub direction: Direction,
    pub body: String,
    pub timestamp_unix: u64,
    pub status: MessageStatus,
    pub read: bool,
}

#[derive(Debug, Clone)]
pub struct Thread<'a> {
    pub peer_number: String,
    pub messages: Vec<&'a Message>,
}

/// The seam a real cellular/SMS HAL (M9) plugs into. `send` returns
/// `Ok(())` if the transport accepted the message for sending —
/// delivery confirmation is a later concern this trait doesn't model
/// yet.
pub trait SmsTransport {
    fn send(&mut self, to: &str, body: &str) -> Result<(), String>;
}

/// No real modem HAL exists yet -- this always succeeds and does
/// nothing else. Explicitly not pretending to be a real transport.
pub struct StubTransport;
impl SmsTransport for StubTransport {
    fn send(&mut self, _to: &str, _body: &str) -> Result<(), String> {
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct OnDisk {
    next_id: u32,
    messages: Vec<Message>,
}

#[derive(Debug)]
pub enum MessagesError {
    NotFound(u32),
    Transport(String),
    Storage(String),
    Serialization(String),
}

impl std::fmt::Display for MessagesError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            MessagesError::NotFound(id) => write!(f, "no message with id {id}"),
            MessagesError::Transport(e) => write!(f, "transport error: {e}"),
            MessagesError::Storage(e) => write!(f, "storage error: {e}"),
            MessagesError::Serialization(e) => write!(f, "serialization error: {e}"),
        }
    }
}
impl std::error::Error for MessagesError {}

pub struct MessageStore<S: ScopedStorage> {
    storage: S,
    messages: Vec<Message>,
    next_id: u32,
}

impl<S: ScopedStorage> MessageStore<S> {
    pub fn load(storage: S) -> Result<Self, MessagesError> {
        let on_disk: OnDisk = match storage.read(STORAGE_FILE).map_err(|e| MessagesError::Storage(e.to_string()))? {
            Some(bytes) => serde_json::from_slice(&bytes).map_err(|e| MessagesError::Serialization(e.to_string()))?,
            None => OnDisk::default(),
        };
        let next_id = if on_disk.next_id == 0 { 1 } else { on_disk.next_id };
        Ok(Self { storage, messages: on_disk.messages, next_id })
    }

    /// Sends via `transport`, recording `Sent` on success or `Failed`
    /// (still persisted, still visible in the thread) on transport
    /// error -- a failed send is not silently dropped.
    pub fn send(&mut self, transport: &mut impl SmsTransport, peer_number: impl Into<String>, body: impl Into<String>, now_unix: u64) -> Result<u32, MessagesError> {
        let peer_number = peer_number.into();
        let body = body.into();
        let status = match transport.send(&peer_number, &body) {
            Ok(()) => MessageStatus::Sent,
            Err(_) => MessageStatus::Failed,
        };
        let id = self.next_id;
        self.next_id += 1;
        self.messages.push(Message {
            id,
            peer_number,
            direction: Direction::Outgoing,
            body,
            timestamp_unix: now_unix,
            status,
            read: true, // outgoing messages don't need an unread badge
        });
        self.persist()?;
        Ok(id)
    }

    /// Records an inbound message (delivered here by whatever inbound
    /// path the real HAL eventually uses -- polling, an interrupt
    /// callback, etc; out of scope for this functional core).
    pub fn receive(&mut self, peer_number: impl Into<String>, body: impl Into<String>, now_unix: u64) -> Result<u32, MessagesError> {
        let id = self.next_id;
        self.next_id += 1;
        self.messages.push(Message {
            id,
            peer_number: peer_number.into(),
            direction: Direction::Incoming,
            body: body.into(),
            timestamp_unix: now_unix,
            status: MessageStatus::Received,
            read: false,
        });
        self.persist()?;
        Ok(id)
    }

    pub fn mark_thread_read(&mut self, peer_number: &str) -> Result<(), MessagesError> {
        for m in self.messages.iter_mut().filter(|m| m.peer_number == peer_number) {
            m.read = true;
        }
        self.persist()
    }

    pub fn unread_count(&self) -> usize {
        self.messages.iter().filter(|m| !m.read).count()
    }

    /// One thread per distinct peer number, each thread's messages in
    /// chronological order, threads themselves ordered by most-recent
    /// message first (the natural "message list" order).
    pub fn threads(&self) -> Vec<Thread<'_>> {
        let mut peers: Vec<&str> = Vec::new();
        for m in &self.messages {
            if !peers.contains(&m.peer_number.as_str()) {
                peers.push(&m.peer_number);
            }
        }

        let mut threads: Vec<Thread> = peers
            .into_iter()
            .map(|peer| {
                let mut msgs: Vec<&Message> = self.messages.iter().filter(|m| m.peer_number == peer).collect();
                msgs.sort_by_key(|m| m.timestamp_unix);
                Thread { peer_number: peer.to_string(), messages: msgs }
            })
            .collect();

        threads.sort_by(|a, b| {
            let a_latest = a.messages.last().map(|m| m.timestamp_unix).unwrap_or(0);
            let b_latest = b.messages.last().map(|m| m.timestamp_unix).unwrap_or(0);
            b_latest.cmp(&a_latest)
        });
        threads
    }

    fn persist(&self) -> Result<(), MessagesError> {
        let on_disk = OnDisk { next_id: self.next_id, messages: self.messages.clone() };
        let bytes = serde_json::to_vec_pretty(&on_disk).map_err(|e| MessagesError::Serialization(e.to_string()))?;
        self.storage.write(STORAGE_FILE, &bytes).map_err(|e| MessagesError::Storage(e.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_app_storage::MemStorage;

    struct FailingTransport;
    impl SmsTransport for FailingTransport {
        fn send(&mut self, _to: &str, _body: &str) -> Result<(), String> {
            Err("no signal".into())
        }
    }

    #[test]
    fn send_records_sent_on_success() {
        let mut store = MessageStore::load(MemStorage::new()).unwrap();
        let mut transport = StubTransport;
        let id = store.send(&mut transport, "+254700000001", "hi", 1000).unwrap();
        assert_eq!(store.threads()[0].messages[0].status, MessageStatus::Sent);
        assert!(store.threads()[0].messages.iter().any(|m| m.id == id));
    }

    #[test]
    fn send_records_failed_on_transport_error_but_still_persists() {
        let mut store = MessageStore::load(MemStorage::new()).unwrap();
        let mut transport = FailingTransport;
        store.send(&mut transport, "+254700000001", "hi", 1000).unwrap();
        assert_eq!(store.threads()[0].messages[0].status, MessageStatus::Failed);
    }

    #[test]
    fn receive_marks_unread_and_increments_unread_count() {
        let mut store = MessageStore::load(MemStorage::new()).unwrap();
        store.receive("+254700000002", "hey", 2000).unwrap();
        assert_eq!(store.unread_count(), 1);
        store.mark_thread_read("+254700000002").unwrap();
        assert_eq!(store.unread_count(), 0);
    }

    #[test]
    fn threads_group_by_peer_and_order_newest_first() {
        let mut store = MessageStore::load(MemStorage::new()).unwrap();
        let mut transport = StubTransport;
        store.send(&mut transport, "+254700000001", "first thread, old", 1000).unwrap();
        store.send(&mut transport, "+254700000002", "second thread, new", 5000).unwrap();
        store.receive("+254700000001", "reply in first thread", 2000).unwrap();

        let threads = store.threads();
        assert_eq!(threads.len(), 2);
        // Thread 2 (peer ...002) has the newest message overall (5000), so it's first.
        assert_eq!(threads[0].peer_number, "+254700000002");
        // Thread 1 (peer ...001) has two messages, in chronological order.
        assert_eq!(threads[1].peer_number, "+254700000001");
        assert_eq!(threads[1].messages.len(), 2);
        assert!(threads[1].messages[0].timestamp_unix < threads[1].messages[1].timestamp_unix);
    }
}
