//! Nova Process Manager — M4 Day 2.
//!
//! Per the Complete Build Guide: "Nova's Process Manager is a
//! supervising layer over Linux processes, not a new scheduler."
//! This library does not reimplement scheduling, memory isolation, or
//! any of what the Linux kernel already does correctly — it wraps
//! `std::process::Command` for spawn/terminate and reads real process
//! state from `/proc`, so what Nova reports is never out of sync with
//! what the kernel actually thinks (an easy bug class to introduce if
//! you tried to track state yourself instead of reading it from the
//! kernel's own source of truth).
//!
//! Unlike M0-M3, this is genuinely testable on any Linux machine,
//! including a sandbox with no display or cross-compilation toolchain
//! — every unit test below spawns and manages *real* processes.
//!
//! Design maps directly to Day 2's five task bullets:
//! - Process IDs, creation/termination -> `spawn`, `terminate`
//! - Process states -> `ProcessState`, read from `/proc/<pid>/stat`
//! - Parent/child relationships -> `ProcessInfo::ppid`, verified
//!   against `/proc/<pid>/status` rather than just recorded at spawn
//!   time (a process's parent can only change via reparenting to
//!   init, which is itself useful state to observe correctly)
//! - Monitoring hooks -> `get`/`list` are the live, queryable source
//!   of truth (the Guide's DoD is explicit that this must be a real
//!   API, not `ps`/`kill` or "visible in logs")
//! - Service supervision hook -> `RestartPolicy`, attached per
//!   process at spawn time. Day 2 defines this seam only — actually
//!   *acting* on a restart policy (relaunching a crashed service) is
//!   M4.5 (Service Manager)'s job, not this milestone's.

use libc::{c_int, SIGKILL, SIGTERM};
use std::collections::HashMap;
use std::fs;
use std::io;
use std::process::{Child, Command};
use std::time::{Duration, Instant};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProcessState {
    Running,
    Sleeping,
    DiskSleep,
    Zombie,
    Stopped,
    /// Nova-tracked process has been reaped (exited and waited on) —
    /// distinct from `Zombie`, which is "exited but not yet reaped."
    /// A well-behaved process manager should rarely let anything sit
    /// in `Zombie` for long; `reap_zombies` exists specifically so it
    /// doesn't.
    Terminated,
    Unknown,
}

impl ProcessState {
    fn from_proc_stat_char(c: char) -> ProcessState {
        match c {
            'R' => ProcessState::Running,
            'S' => ProcessState::Sleeping,
            'D' => ProcessState::DiskSleep,
            'Z' => ProcessState::Zombie,
            'T' | 't' => ProcessState::Stopped,
            _ => ProcessState::Unknown,
        }
    }
}

/// The M4.5 seam: how a crashed/exited service should be handled.
/// Day 2 only *defines* this — nothing in this file acts on it yet.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RestartPolicy {
    Never,
    OnFailure,
    Always,
}

#[derive(Debug, Clone)]
pub struct ProcessInfo {
    pub pid: u32,
    pub ppid: u32,
    pub command: String,
    pub state: ProcessState,
    pub restart_policy: RestartPolicy,
    pub exit_code: Option<i32>,
}

struct Tracked {
    child: Option<Child>, // None once reaped
    command: String,
    restart_policy: RestartPolicy,
    last_state: ProcessState,
    exit_code: Option<i32>,
    spawned_at: Instant,
}

#[derive(Debug)]
pub enum ProcessEvent {
    Spawned { pid: u32, command: String },
    StateChanged { pid: u32, old: ProcessState, new: ProcessState },
    Terminated { pid: u32, exit_code: Option<i32> },
}

#[derive(Default)]
pub struct ProcessManager {
    processes: HashMap<u32, Tracked>,
    /// Queryable event history — supplementary to `get`/`list`, which
    /// remain the primary "must be queryable, not just in logs" API
    /// the Guide's DoD asks for. Kept bounded in a real system; a
    /// plain Vec is fine for M4 Day 2's scope.
    events: Vec<ProcessEvent>,
}

impl ProcessManager {
    pub fn new() -> Self {
        ProcessManager::default()
    }

    /// Spawns `command` with `args`, tracked under the given restart
    /// policy (the M4.5 seam — unused by this function beyond storing
    /// it). Returns the real Linux PID.
    pub fn spawn(&mut self, command: &str, args: &[&str], policy: RestartPolicy) -> io::Result<u32> {
        let child = Command::new(command).args(args).spawn()?;
        let pid = child.id();
        let full_command = if args.is_empty() {
            command.to_string()
        } else {
            format!("{command} {}", args.join(" "))
        };
        self.processes.insert(
            pid,
            Tracked {
                child: Some(child),
                command: full_command.clone(),
                restart_policy: policy,
                last_state: ProcessState::Running,
                exit_code: None,
                spawned_at: Instant::now(),
            },
        );
        self.events.push(ProcessEvent::Spawned { pid, command: full_command });
        Ok(pid)
    }

    /// Reads live state from `/proc/<pid>/stat` — never Nova's own
    /// guess, always the kernel's actual view, per this module's
    /// central design principle.
    fn read_proc_state(pid: u32) -> ProcessState {
        let stat = match fs::read_to_string(format!("/proc/{pid}/stat")) {
            Ok(s) => s,
            Err(_) => return ProcessState::Unknown, // already reaped / never existed
        };
        // Format: "pid (comm) STATE ppid ...". comm can contain
        // spaces/parens, so state is the first token after the last
        // ')', not a fixed split index.
        if let Some(idx) = stat.rfind(')') {
            let rest = stat[idx + 1..].trim_start();
            if let Some(state_char) = rest.chars().next() {
                return ProcessState::from_proc_stat_char(state_char);
            }
        }
        ProcessState::Unknown
    }

    /// Real parent PID from `/proc/<pid>/status`, not just whatever
    /// Nova recorded at spawn time — catches reparenting (e.g. to
    /// PID 1) correctly rather than reporting stale data.
    fn read_proc_ppid(pid: u32) -> Option<u32> {
        let status = fs::read_to_string(format!("/proc/{pid}/status")).ok()?;
        for line in status.lines() {
            if let Some(rest) = line.strip_prefix("PPid:") {
                return rest.trim().parse().ok();
            }
        }
        None
    }

    /// Non-blocking reap pass — the same PID-1-style duty Nova Init
    /// (M2) has, scoped here to processes this manager itself spawned.
    /// Returns the PIDs that were reaped this call.
    pub fn reap_zombies(&mut self) -> Vec<u32> {
        let mut reaped = Vec::new();
        for (&pid, tracked) in self.processes.iter_mut() {
            if let Some(child) = tracked.child.as_mut() {
                match child.try_wait() {
                    Ok(Some(status)) => {
                        let old = tracked.last_state;
                        tracked.exit_code = status.code();
                        tracked.last_state = ProcessState::Terminated;
                        tracked.child = None; // reaped
                        reaped.push(pid);
                        self.events.push(ProcessEvent::StateChanged {
                            pid,
                            old,
                            new: ProcessState::Terminated,
                        });
                        self.events.push(ProcessEvent::Terminated { pid, exit_code: status.code() });
                    }
                    Ok(None) => { /* still running */ }
                    Err(_) => { /* already reaped elsewhere; leave as-is */ }
                }
            }
        }
        reaped
    }

    /// Terminates `pid`: SIGTERM first, waits briefly, escalates to
    /// SIGKILL if it hasn't exited, then reaps it. This is the
    /// "graceful, then forceful" shutdown pattern every real init/
    /// process-manager needs — a bare SIGKILL-only implementation
    /// would be simpler to write but wrong for anything that should
    /// get a chance to clean up.
    pub fn terminate(&mut self, pid: u32) -> io::Result<()> {
        let tracked = self
            .processes
            .get_mut(&pid)
            .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "pid not tracked by this manager"))?;

        let old_state = tracked.last_state;
        unsafe {
            libc::kill(pid as c_int, SIGTERM);
        }

        // Give it a real chance to exit cleanly before escalating —
        // short in this implementation since tests need to run fast,
        // but the pattern (wait, then escalate) is what matters here,
        // not the exact duration.
        let deadline = Instant::now() + Duration::from_millis(500);
        loop {
            if let Some(child) = tracked.child.as_mut() {
                if let Ok(Some(status)) = child.try_wait() {
                    tracked.exit_code = status.code();
                    tracked.last_state = ProcessState::Terminated;
                    tracked.child = None;
                    self.events.push(ProcessEvent::StateChanged {
                        pid,
                        old: old_state,
                        new: ProcessState::Terminated,
                    });
                    self.events.push(ProcessEvent::Terminated { pid, exit_code: status.code() });
                    return Ok(());
                }
            } else {
                return Ok(()); // already reaped by a prior reap_zombies() call
            }
            if Instant::now() >= deadline {
                break;
            }
            std::thread::sleep(Duration::from_millis(20));
        }

        // Didn't exit gracefully in time — escalate.
        unsafe {
            libc::kill(pid as c_int, SIGKILL);
        }
        if let Some(child) = tracked.child.as_mut() {
            let status = child.wait()?; // blocking now; SIGKILL is not ignorable
            tracked.exit_code = status.code();
            tracked.last_state = ProcessState::Terminated;
            tracked.child = None;
            self.events.push(ProcessEvent::StateChanged {
                pid,
                old: old_state,
                new: ProcessState::Terminated,
            });
            self.events.push(ProcessEvent::Terminated { pid, exit_code: status.code() });
        }
        Ok(())
    }

    /// Live-queries a single tracked process. This, along with
    /// `list()`, is the actual "monitoring hook" the Guide's DoD asks
    /// for: state is queryable through Nova's own API, not by
    /// shelling out to `ps`.
    pub fn get(&self, pid: u32) -> Option<ProcessInfo> {
        let tracked = self.processes.get(&pid)?;
        let state = if tracked.child.is_none() {
            ProcessState::Terminated
        } else {
            Self::read_proc_state(pid)
        };
        let ppid = Self::read_proc_ppid(pid).unwrap_or(0);
        Some(ProcessInfo {
            pid,
            ppid,
            command: tracked.command.clone(),
            state,
            restart_policy: tracked.restart_policy,
            exit_code: tracked.exit_code,
        })
    }

    pub fn list(&self) -> Vec<ProcessInfo> {
        self.processes.keys().filter_map(|&pid| self.get(pid)).collect()
    }

    pub fn events(&self) -> &[ProcessEvent] {
        &self.events
    }

    /// Whether M4.5's Service Manager *should* restart this process,
    /// given its policy and current state — the seam itself. Actually
    /// performing the restart (calling `spawn` again) is explicitly
    /// out of scope for Day 2 / this file.
    pub fn should_restart(&self, pid: u32) -> bool {
        match self.get(pid) {
            Some(info) if info.state == ProcessState::Terminated => match info.restart_policy {
                RestartPolicy::Always => true,
                RestartPolicy::OnFailure => info.exit_code.map(|c| c != 0).unwrap_or(true),
                RestartPolicy::Never => false,
            },
            _ => false,
        }
    }

    pub fn tracked_count(&self) -> usize {
        self.processes.len()
    }

    /// How long ago this process was spawned — genuinely useful for
    /// M4.5's Service Manager (e.g. "don't restart-loop a service
    /// that's crashed 5 times in 10 seconds"), so this is real,
    /// forward-looking API surface rather than an unused field.
    pub fn uptime(&self, pid: u32) -> Option<Duration> {
        self.processes.get(&pid).map(|t| t.spawned_at.elapsed())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    /// The Guide's literal Day 2 DoD: create a process, list it with
    /// correct PID/state/parent, terminate it, observe the state
    /// transition — through this API, not `ps`/`kill`.
    #[test]
    fn day2_definition_of_done_end_to_end() {
        let mut pm = ProcessManager::new();
        let pid = pm.spawn("sleep", &["2"], RestartPolicy::Never).expect("spawn should succeed");

        // Give it a moment to actually be running.
        thread::sleep(Duration::from_millis(100));

        let info = pm.get(pid).expect("spawned process should be listed");
        assert_eq!(info.pid, pid);
        assert_eq!(info.ppid, std::process::id(), "parent should be this test process");
        assert!(
            matches!(info.state, ProcessState::Running | ProcessState::Sleeping),
            "expected Running or Sleeping, got {:?}",
            info.state
        );

        pm.terminate(pid).expect("terminate should succeed");
        let after = pm.get(pid).expect("terminated process should still be queryable");
        assert_eq!(after.state, ProcessState::Terminated, "state should transition to Terminated");
    }

    #[test]
    fn list_reflects_multiple_tracked_processes() {
        let mut pm = ProcessManager::new();
        let p1 = pm.spawn("sleep", &["1"], RestartPolicy::Never).unwrap();
        let p2 = pm.spawn("sleep", &["1"], RestartPolicy::Never).unwrap();

        let all = pm.list();
        let pids: Vec<u32> = all.iter().map(|p| p.pid).collect();
        assert!(pids.contains(&p1));
        assert!(pids.contains(&p2));
        assert_eq!(pm.tracked_count(), 2);

        pm.terminate(p1).unwrap();
        pm.terminate(p2).unwrap();
    }

    #[test]
    fn get_nonexistent_pid_returns_none() {
        let pm = ProcessManager::new();
        assert!(pm.get(999_999).is_none());
    }

    #[test]
    fn short_lived_process_gets_reaped() {
        let mut pm = ProcessManager::new();
        let pid = pm.spawn("true", &[], RestartPolicy::Never).unwrap();

        // `true` exits almost immediately; give it a moment, then reap.
        thread::sleep(Duration::from_millis(150));
        let reaped = pm.reap_zombies();
        assert!(reaped.contains(&pid));

        let info = pm.get(pid).unwrap();
        assert_eq!(info.state, ProcessState::Terminated);
        assert_eq!(info.exit_code, Some(0));
    }

    #[test]
    fn failed_process_restart_policy_on_failure() {
        let mut pm = ProcessManager::new();
        // `false` always exits with status 1.
        let pid = pm.spawn("false", &[], RestartPolicy::OnFailure).unwrap();
        thread::sleep(Duration::from_millis(150));
        pm.reap_zombies();

        assert!(pm.should_restart(pid), "OnFailure + nonzero exit should signal restart");
    }

    #[test]
    fn successful_process_restart_policy_on_failure_does_not_restart() {
        let mut pm = ProcessManager::new();
        let pid = pm.spawn("true", &[], RestartPolicy::OnFailure).unwrap();
        thread::sleep(Duration::from_millis(150));
        pm.reap_zombies();

        assert!(!pm.should_restart(pid), "OnFailure + zero exit should NOT signal restart");
    }

    #[test]
    fn never_policy_never_restarts_even_on_failure() {
        let mut pm = ProcessManager::new();
        let pid = pm.spawn("false", &[], RestartPolicy::Never).unwrap();
        thread::sleep(Duration::from_millis(150));
        pm.reap_zombies();

        assert!(!pm.should_restart(pid));
    }

    #[test]
    fn events_log_captures_lifecycle() {
        let mut pm = ProcessManager::new();
        let pid = pm.spawn("true", &[], RestartPolicy::Never).unwrap();
        thread::sleep(Duration::from_millis(150));
        pm.reap_zombies();

        let has_spawned = pm.events().iter().any(|e| matches!(e, ProcessEvent::Spawned { pid: p, .. } if *p == pid));
        let has_terminated =
            pm.events().iter().any(|e| matches!(e, ProcessEvent::Terminated { pid: p, .. } if *p == pid));
        assert!(has_spawned);
        assert!(has_terminated);
    }

    #[test]
    fn terminate_unknown_pid_returns_error_not_panic() {
        let mut pm = ProcessManager::new();
        let result = pm.terminate(999_999);
        assert!(result.is_err());
    }

    #[test]
    fn uptime_increases_while_tracked() {
        let mut pm = ProcessManager::new();
        let pid = pm.spawn("sleep", &["1"], RestartPolicy::Never).unwrap();
        thread::sleep(Duration::from_millis(50));
        let uptime = pm.uptime(pid).expect("tracked process should have an uptime");
        assert!(uptime.as_millis() >= 50);
        pm.terminate(pid).unwrap();
    }
}
