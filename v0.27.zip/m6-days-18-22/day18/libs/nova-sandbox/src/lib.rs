//! Nova OS M5 Day 15 — sandbox boundaries.
//!
//! Day 15 is deliberately a minimum enforcement layer, not the full
//! namespace/seccomp hardening scheduled for M10. The important change
//! from Day 14 is that manifest declarations are now converted into a
//! runtime capability set and every protected-resource operation must
//! pass through that set.
//!
//! The sandbox provides two concrete boundaries:
//!   * capability checks for protected resources (camera, microphone,
//!     network, contacts, SMS, health data, location);
//!   * per-app filesystem scoping under `/var/lib/nova/apps/<app-id>`.
//!
//! M10 remains responsible for kernel-level namespace/seccomp hardening.
//! Day 15 does not claim that a malicious process can never bypass these
//! user-space APIs; it makes the platform's resource broker enforce the
//! permission boundary and gives later HAL/security work one stable seam.

use nova_ipc::Permission;
use std::fs;
use std::io;
use std::path::{Component, Path, PathBuf};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SandboxError {
    PermissionDenied(Permission),
    PathOutsideSandbox,
    InvalidAppId,
}

impl std::fmt::Display for SandboxError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SandboxError::PermissionDenied(p) => {
                write!(f, "permission denied: {}", p.name())
            }
            SandboxError::PathOutsideSandbox => write!(f, "path is outside the app sandbox"),
            SandboxError::InvalidAppId => write!(f, "invalid app id"),
        }
    }
}

impl std::error::Error for SandboxError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PermissionSet {
    bits: u32,
}

impl PermissionSet {
    pub fn empty() -> Self { Self { bits: 0 } }

    pub fn from_permissions(perms: impl IntoIterator<Item = Permission>) -> Self {
        let mut set = Self::empty();
        for p in perms { set.grant(p); }
        set
    }

    pub fn grant(&mut self, permission: Permission) {
        self.bits |= permission.bit();
    }

    pub fn contains(&self, permission: Permission) -> bool {
        self.bits & permission.bit() != 0
    }

    pub fn bits(&self) -> u32 { self.bits }
}

#[derive(Debug, Clone)]
pub struct SandboxPolicy {
    pub app_id: String,
    pub required: PermissionSet,
    pub optional: PermissionSet,
    granted: PermissionSet,
}

impl SandboxPolicy {
    pub fn new(app_id: impl Into<String>, required: PermissionSet, optional: PermissionSet) -> Result<Self, SandboxError> {
        let app_id = app_id.into();
        if !valid_app_id(&app_id) {
            return Err(SandboxError::InvalidAppId);
        }

        // Display/Input are implicit, matching the IPC protocol.
        let mut granted = PermissionSet::from_permissions([Permission::Display, Permission::Input]);
        for p in Permission::ALL {
            if required.contains(p) {
                granted.grant(p);
            }
        }

        Ok(Self { app_id, required, optional, granted })
    }

    pub fn granted(&self) -> PermissionSet { self.granted }

    /// Returns whether the app may use a protected resource now.
    pub fn check(&self, permission: Permission) -> Result<(), SandboxError> {
        if self.granted.contains(permission) {
            Ok(())
        } else {
            Err(SandboxError::PermissionDenied(permission))
        }
    }

    /// Optional permissions are runtime-grantable only when declared.
    pub fn request(&mut self, permission: Permission) -> Result<bool, SandboxError> {
        if !self.optional.contains(permission) {
            return Err(SandboxError::PermissionDenied(permission));
        }
        self.granted.grant(permission);
        Ok(true)
    }

    pub fn app_data_root(&self) -> PathBuf {
        PathBuf::from("/var/lib/nova/apps").join(&self.app_id)
    }

    /// Converts a relative app-data path to an absolute path inside the
    /// app's own storage root. Absolute paths and `..` traversal are
    /// rejected before any filesystem call is made.
    pub fn scoped_path(&self, relative: impl AsRef<Path>) -> Result<PathBuf, SandboxError> {
        let relative = relative.as_ref();
        if relative.is_absolute() {
            return Err(SandboxError::PathOutsideSandbox);
        }

        for component in relative.components() {
            match component {
                Component::Normal(_) | Component::CurDir => {}
                Component::ParentDir | Component::RootDir | Component::Prefix(_) => {
                    return Err(SandboxError::PathOutsideSandbox)
                }
            }
        }

        Ok(self.app_data_root().join(relative))
    }

    pub fn read_scoped(&self, relative: impl AsRef<Path>) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        let path = self.scoped_path(relative)?;
        Ok(fs::read(path)?)
    }

    pub fn write_scoped(&self, relative: impl AsRef<Path>, data: &[u8]) -> Result<(), Box<dyn std::error::Error>> {
        let path = self.scoped_path(relative)?;
        if let Some(parent) = path.parent() { fs::create_dir_all(parent)?; }
        fs::write(path, data)?;
        Ok(())
    }

    /// Camera access is deliberately a capability check at the resource
    /// boundary. The Camera HAL should call this before opening `/dev/video*`.
    pub fn authorize_camera(&self) -> Result<(), SandboxError> {
        self.check(Permission::Camera)
    }

    pub fn authorize_microphone(&self) -> Result<(), SandboxError> {
        self.check(Permission::Microphone)
    }

    pub fn authorize_network(&self) -> Result<(), SandboxError> {
        self.check(Permission::Network)
    }

    pub fn authorize_contacts(&self) -> Result<(), SandboxError> {
        self.check(Permission::Contacts)
    }

    pub fn authorize_sms(&self) -> Result<(), SandboxError> {
        self.check(Permission::Sms)
    }

    pub fn authorize_health_data(&self) -> Result<(), SandboxError> {
        self.check(Permission::HealthData)
    }

    pub fn authorize_location(&self) -> Result<(), SandboxError> {
        self.check(Permission::Location)
    }
}

fn valid_app_id(id: &str) -> bool {
    !id.is_empty()
        && id.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_'))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn day15_undeclared_camera_is_blocked() {
        let policy = SandboxPolicy::new(
            "org.nova.test",
            PermissionSet::from_permissions([Permission::Storage]),
            PermissionSet::empty(),
        ).unwrap();

        assert_eq!(
            policy.authorize_camera(),
            Err(SandboxError::PermissionDenied(Permission::Camera))
        );
    }

    #[test]
    fn day15_declared_camera_is_allowed() {
        let policy = SandboxPolicy::new(
            "org.nova.camera",
            PermissionSet::from_permissions([Permission::Camera]),
            PermissionSet::empty(),
        ).unwrap();

        assert!(policy.authorize_camera().is_ok());
    }

    #[test]
    fn optional_permission_is_not_granted_until_requested() {
        let mut policy = SandboxPolicy::new(
            "org.nova.test",
            PermissionSet::empty(),
            PermissionSet::from_permissions([Permission::Network]),
        ).unwrap();

        assert!(policy.authorize_network().is_err());
        assert!(policy.request(Permission::Network).unwrap());
        assert!(policy.authorize_network().is_ok());
    }

    #[test]
    fn non_declared_optional_permission_cannot_be_requested() {
        let mut policy = SandboxPolicy::new(
            "org.nova.test",
            PermissionSet::empty(),
            PermissionSet::from_permissions([Permission::Network]),
        ).unwrap();

        assert_eq!(
            policy.request(Permission::Camera),
            Err(SandboxError::PermissionDenied(Permission::Camera))
        );
    }

    #[test]
    fn traversal_is_rejected() {
        let policy = SandboxPolicy::new("org.nova.test", PermissionSet::empty(), PermissionSet::empty()).unwrap();
        assert_eq!(
            policy.scoped_path("../other-app/data"),
            Err(SandboxError::PathOutsideSandbox)
        );
        assert_eq!(
            policy.scoped_path("/var/lib/nova/apps/other-app/data"),
            Err(SandboxError::PathOutsideSandbox)
        );
    }

    #[test]
    fn own_storage_is_scoped() {
        let policy = SandboxPolicy::new("org.nova.test", PermissionSet::empty(), PermissionSet::empty()).unwrap();
        assert_eq!(
            policy.scoped_path("notes/test.txt").unwrap(),
            PathBuf::from("/var/lib/nova/apps/org.nova.test/notes/test.txt")
        );
    }

    #[test]
    fn app_id_cannot_escape_path_root() {
        assert!(SandboxPolicy::new("../escape", PermissionSet::empty(), PermissionSet::empty()).is_err());
        assert!(SandboxPolicy::new("org/nova", PermissionSet::empty(), PermissionSet::empty()).is_err());
    }
}
