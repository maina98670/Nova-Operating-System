//! Settings app — Day 16 functional core.
//!
//! A typed, validated key-value store over a fixed registry of known
//! settings (`KNOWN_SETTINGS`). No UI here (M7's job); a future
//! front-end, or the IPC-driven shell, reads/writes through this. Only
//! keys in the registry can be set, and each key's value is validated
//! against that key's rule before being accepted — an app can't wedge
//! `display_brightness` to `9999` or `wifi_enabled` to a string.

use nova_app_storage::ScopedStorage;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

pub const STORAGE_FILE: &str = "settings.json";

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(untagged)]
pub enum SettingValue {
    Bool(bool),
    Int(i64),
    Text(String),
}

/// A `const`-friendly default (plain `&'static str` instead of
/// `String`, so `KNOWN_SETTINGS` can be a plain static array).
#[derive(Debug, Clone, Copy)]
enum DefaultValue {
    Bool(bool),
    Int(i64),
    Text(&'static str),
}

impl DefaultValue {
    fn to_value(self) -> SettingValue {
        match self {
            DefaultValue::Bool(b) => SettingValue::Bool(b),
            DefaultValue::Int(i) => SettingValue::Int(i),
            DefaultValue::Text(s) => SettingValue::Text(s.to_string()),
        }
    }
}

pub struct SettingSpec {
    pub key: &'static str,
    default: DefaultValue,
    validate: fn(&SettingValue) -> bool,
}

impl SettingSpec {
    pub fn default_value(&self) -> SettingValue {
        self.default.to_value()
    }
}

/// The fixed set of settings this milestone knows about. Extending
/// this list is how a later day adds a new setting — the store itself
/// doesn't need to change.
pub static KNOWN_SETTINGS: &[SettingSpec] = &[
    SettingSpec {
        key: "display_brightness",
        default: DefaultValue::Int(70),
        validate: |v| matches!(v, SettingValue::Int(n) if (0..=100).contains(n)),
    },
    SettingSpec {
        key: "ringer_volume",
        default: DefaultValue::Int(60),
        validate: |v| matches!(v, SettingValue::Int(n) if (0..=100).contains(n)),
    },
    SettingSpec {
        key: "language",
        default: DefaultValue::Text("en"),
        validate: |v| matches!(v, SettingValue::Text(s) if s == "en" || s == "sw"),
    },
    SettingSpec {
        key: "wifi_enabled",
        default: DefaultValue::Bool(false),
        validate: |v| matches!(v, SettingValue::Bool(_)),
    },
    SettingSpec {
        key: "do_not_disturb",
        default: DefaultValue::Bool(false),
        validate: |v| matches!(v, SettingValue::Bool(_)),
    },
];

fn spec_for(key: &str) -> Option<&'static SettingSpec> {
    KNOWN_SETTINGS.iter().find(|s| s.key == key)
}

#[derive(Debug)]
pub enum SettingsError {
    UnknownKey(String),
    InvalidValue { key: String, value: SettingValue },
    Storage(String),
    Serialization(String),
}

impl std::fmt::Display for SettingsError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SettingsError::UnknownKey(k) => write!(f, "unknown setting key: {k}"),
            SettingsError::InvalidValue { key, value } => write!(f, "invalid value for {key}: {value:?}"),
            SettingsError::Storage(e) => write!(f, "storage error: {e}"),
            SettingsError::Serialization(e) => write!(f, "serialization error: {e}"),
        }
    }
}
impl std::error::Error for SettingsError {}

pub struct SettingsStore<S: ScopedStorage> {
    storage: S,
    values: HashMap<String, SettingValue>,
}

impl<S: ScopedStorage> SettingsStore<S> {
    pub fn load(storage: S) -> Result<Self, SettingsError> {
        let values: HashMap<String, SettingValue> = match storage.read(STORAGE_FILE).map_err(|e| SettingsError::Storage(e.to_string()))? {
            Some(bytes) => serde_json::from_slice(&bytes).map_err(|e| SettingsError::Serialization(e.to_string()))?,
            None => HashMap::new(),
        };
        Ok(Self { storage, values })
    }

    /// The key's stored value, or its registry default if never set.
    /// `None` only for a key that isn't in `KNOWN_SETTINGS` at all.
    pub fn get(&self, key: &str) -> Option<SettingValue> {
        if let Some(v) = self.values.get(key) {
            return Some(v.clone());
        }
        spec_for(key).map(|s| s.default_value())
    }

    pub fn set(&mut self, key: &str, value: SettingValue) -> Result<(), SettingsError> {
        let spec = spec_for(key).ok_or_else(|| SettingsError::UnknownKey(key.to_string()))?;
        if !(spec.validate)(&value) {
            return Err(SettingsError::InvalidValue { key: key.to_string(), value });
        }
        self.values.insert(key.to_string(), value);
        self.persist()
    }

    /// Removes any override, so `get` falls back to the registry
    /// default again.
    pub fn reset(&mut self, key: &str) -> Result<(), SettingsError> {
        spec_for(key).ok_or_else(|| SettingsError::UnknownKey(key.to_string()))?;
        self.values.remove(key);
        self.persist()
    }

    pub fn reset_all(&mut self) -> Result<(), SettingsError> {
        self.values.clear();
        self.persist()
    }

    /// Every known setting with its current effective value (override
    /// or default).
    pub fn list(&self) -> Vec<(&'static str, SettingValue)> {
        KNOWN_SETTINGS.iter().map(|s| (s.key, self.get(s.key).unwrap())).collect()
    }

    fn persist(&self) -> Result<(), SettingsError> {
        let bytes = serde_json::to_vec_pretty(&self.values).map_err(|e| SettingsError::Serialization(e.to_string()))?;
        self.storage.write(STORAGE_FILE, &bytes).map_err(|e| SettingsError::Storage(e.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_app_storage::MemStorage;
    use std::sync::Arc;

    #[test]
    fn unset_key_returns_registry_default() {
        let store = SettingsStore::load(MemStorage::new()).unwrap();
        assert_eq!(store.get("display_brightness"), Some(SettingValue::Int(70)));
    }

    #[test]
    fn unknown_key_returns_none() {
        let store = SettingsStore::load(MemStorage::new()).unwrap();
        assert_eq!(store.get("not_a_real_setting"), None);
    }

    #[test]
    fn set_out_of_range_is_rejected() {
        let mut store = SettingsStore::load(MemStorage::new()).unwrap();
        let result = store.set("display_brightness", SettingValue::Int(9999));
        assert!(matches!(result, Err(SettingsError::InvalidValue { .. })));
        // rejected -- still the default
        assert_eq!(store.get("display_brightness"), Some(SettingValue::Int(70)));
    }

    #[test]
    fn set_wrong_type_is_rejected() {
        let mut store = SettingsStore::load(MemStorage::new()).unwrap();
        let result = store.set("wifi_enabled", SettingValue::Text("yes".into()));
        assert!(matches!(result, Err(SettingsError::InvalidValue { .. })));
    }

    #[test]
    fn set_unknown_key_is_rejected() {
        let mut store = SettingsStore::load(MemStorage::new()).unwrap();
        let result = store.set("not_a_real_setting", SettingValue::Bool(true));
        assert!(matches!(result, Err(SettingsError::UnknownKey(_))));
    }

    #[test]
    fn valid_set_and_reset_round_trip() {
        let mut store = SettingsStore::load(MemStorage::new()).unwrap();
        store.set("display_brightness", SettingValue::Int(30)).unwrap();
        assert_eq!(store.get("display_brightness"), Some(SettingValue::Int(30)));
        store.reset("display_brightness").unwrap();
        assert_eq!(store.get("display_brightness"), Some(SettingValue::Int(70)));
    }

    #[test]
    fn persists_across_a_simulated_restart() {
        let backing = Arc::new(MemStorage::new());
        {
            let mut store = SettingsStore::load(backing.clone()).unwrap();
            store.set("language", SettingValue::Text("sw".into())).unwrap();
        }
        let store2 = SettingsStore::load(backing).unwrap();
        assert_eq!(store2.get("language"), Some(SettingValue::Text("sw".into())));
    }

    #[test]
    fn list_covers_every_known_key() {
        let store = SettingsStore::load(MemStorage::new()).unwrap();
        assert_eq!(store.list().len(), KNOWN_SETTINGS.len());
    }
}
