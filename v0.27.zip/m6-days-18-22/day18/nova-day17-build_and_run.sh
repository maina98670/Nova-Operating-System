#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 17: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 17: full M5 acceptance ==="
echo "Runs Day 16's five-app reconciliation test, then Day 17's own M5"
echo "acceptance test against nova-hello. Uses Nova's standard /apps,"
echo "/run/nova and /var/log/nova paths -- needs the same root-capable"
echo "Linux environment as the Day 11-16 live tests."
echo
echo "--- Day 16: five real apps through the integrated App Manager ---"
cargo run -p nova-day16-reconciliation-test
echo
echo "--- Day 17: nova-hello, the Roadmap's own M5 acceptance test ---"
cargo run -p nova-day17-m5-acceptance-test

echo
echo "Day 17 build + full M5 acceptance completed."
echo
echo "If both passed, tag the repo (see docs/M5-TAG.md):"
echo "  git tag -a v0.20 -m \"M5: IPC, Applications & Sandboxing (integrate with M4)\""
echo "  git push origin v0.20"
