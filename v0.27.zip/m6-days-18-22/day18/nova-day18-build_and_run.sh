#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 18: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 18: scaffold acceptance ==="
echo "Runs \`nova create test_app\` then \`nova build\` as real subprocesses,"
echo "then installs and launches the result through App Manager. Uses Nova's"
echo "standard /apps, /run/nova and /var/log/nova paths -- needs the same"
echo "root-capable Linux environment as the Day 11-17 live tests."
cargo run -p nova-day18-scaffold-acceptance-test

echo
echo "Day 18 build + scaffold acceptance completed."
echo
echo "Try it yourself:"
echo "  ./target/debug/nova create my_app"
echo "  ./target/debug/nova build my_app"
