//! `nova build <path>` — compiles the generated crate, then copies
//! the resulting binary + manifest to `<apps-dir>/<id>/`, matching
//! the layout Days 16-17 already established
//! (`<APPS>/<id>/nova-app.toml`, `<APPS>/<id>/bin/<binary>`).
//!
//! This folds "build" and "install" into one step. `nova package`/
//! `nova install`/`nova run` as their own separate commands are
//! Day 22's job ("the full toolchain, one command per step") — Day 18
//! only needs to prove that what `create` generates can, with zero
//! manual edits, end up somewhere App Manager can `install()`/
//! `launch()` it from. That's what this does, stubbed down to exactly
//! that.

use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode};

const DEFAULT_APPS_DIR: &str = "/apps"; // mirrors nova_fsmgr::paths::APPS

pub fn run(args: &[String]) -> ExitCode {
    let mut app_path: Option<PathBuf> = None;
    let mut apps_dir = std::env::var("NOVA_APPS_DIR").unwrap_or_else(|_| DEFAULT_APPS_DIR.to_string());

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--apps-dir" => {
                i += 1;
                if let Some(v) = args.get(i) {
                    apps_dir = v.clone();
                }
            }
            other if !other.starts_with('-') && app_path.is_none() => {
                app_path = Some(PathBuf::from(other));
            }
            other => {
                eprintln!("nova build: unrecognized argument '{other}'");
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    let Some(app_path) = app_path else {
        eprintln!("nova build: missing <path>\nusage: nova build <path-to-app-dir> [--apps-dir <dir>]");
        return ExitCode::FAILURE;
    };

    let manifest_toml = app_path.join("nova-app.toml");
    let cargo_toml = app_path.join("Cargo.toml");
    if !manifest_toml.is_file() || !cargo_toml.is_file() {
        eprintln!(
            "nova build: {} doesn't look like a `nova create`-generated app (missing nova-app.toml or Cargo.toml)",
            app_path.display()
        );
        return ExitCode::FAILURE;
    }

    let manifest_text = match fs::read_to_string(&manifest_toml) {
        Ok(t) => t,
        Err(e) => {
            eprintln!("nova build: couldn't read {}: {e}", manifest_toml.display());
            return ExitCode::FAILURE;
        }
    };
    let Some(id) = extract_toml_string(&manifest_text, "id") else {
        eprintln!("nova build: {} has no `id` field", manifest_toml.display());
        return ExitCode::FAILURE;
    };
    let Some(entry_point) = extract_toml_string(&manifest_text, "entry_point") else {
        eprintln!("nova build: {} has no `entry_point` field", manifest_toml.display());
        return ExitCode::FAILURE;
    };
    let bin_name = match Path::new(&entry_point).file_name() {
        Some(n) => n.to_string_lossy().to_string(),
        None => {
            eprintln!("nova build: couldn't extract a binary name from entry_point '{entry_point}'");
            return ExitCode::FAILURE;
        }
    };

    println!("Building {} (id={id}, bin={bin_name})...", app_path.display());
    let status = Command::new("cargo")
        .arg("build")
        .arg("--manifest-path")
        .arg(&cargo_toml)
        .status();
    match status {
        Ok(s) if s.success() => {}
        Ok(s) => {
            eprintln!("nova build: cargo build failed ({s})");
            return ExitCode::FAILURE;
        }
        Err(e) => {
            eprintln!("nova build: couldn't run cargo: {e}");
            return ExitCode::FAILURE;
        }
    }

    let built_bin = app_path.join("target").join("debug").join(&bin_name);
    if !built_bin.is_file() {
        eprintln!(
            "nova build: cargo build succeeded but {} wasn't produced -- \
             does the [[bin]] name in Cargo.toml match entry_point's file name?",
            built_bin.display()
        );
        return ExitCode::FAILURE;
    }

    let dest_dir = Path::new(&apps_dir).join(&id);
    let dest_bin_dir = dest_dir.join("bin");
    if let Err(e) = fs::create_dir_all(&dest_bin_dir) {
        eprintln!("nova build: couldn't create {}: {e}", dest_bin_dir.display());
        return ExitCode::FAILURE;
    }

    let dest_manifest = dest_dir.join("nova-app.toml");
    if let Err(e) = fs::copy(&manifest_toml, &dest_manifest) {
        eprintln!("nova build: couldn't copy manifest to {}: {e}", dest_manifest.display());
        return ExitCode::FAILURE;
    }

    let dest_bin = dest_bin_dir.join(&bin_name);
    if let Err(e) = fs::copy(&built_bin, &dest_bin) {
        eprintln!("nova build: couldn't copy binary to {}: {e}", dest_bin.display());
        return ExitCode::FAILURE;
    }
    if let Ok(meta) = fs::metadata(&dest_bin) {
        let mut perms = meta.permissions();
        perms.set_mode(0o755);
        let _ = fs::set_permissions(&dest_bin, perms);
    }

    println!("Installed to {}", dest_dir.display());
    println!("  {}", dest_manifest.display());
    println!("  {}", dest_bin.display());
    println!();
    println!("Ready for App Manager to install()/launch() '{id}' -- no manual edits made to any generated file.");
    ExitCode::SUCCESS
}

/// Deliberately minimal: this CLI doesn't depend on `nova-config`
/// (kept standalone, see `main.rs`'s module doc), so it can't reuse
/// that crate's real TOML parser. Just enough to pull a
/// `key = "value"` string field out of the small, known-shape
/// manifests `nova create` itself generates -- not a general TOML
/// parser, and not meant to be one.
fn extract_toml_string(text: &str, key: &str) -> Option<String> {
    for line in text.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix(key) {
            let rest = rest.trim_start();
            if let Some(rest) = rest.strip_prefix('=') {
                let rest = rest.trim();
                if let Some(inner) = rest.strip_prefix('"').and_then(|s| s.strip_suffix('"')) {
                    return Some(inner.to_string());
                }
            }
        }
    }
    None
}
