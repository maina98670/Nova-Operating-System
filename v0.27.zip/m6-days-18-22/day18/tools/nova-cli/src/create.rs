//! `nova create <name>` — generates a working, buildable skeleton app.
//!
//! ## Known limitation, stated plainly
//! Nova's own libs (`nova-app-runtime`, `nova-ipc`) aren't published
//! anywhere yet — no crates.io, no offline registry, no `.nova`
//! package for a *library* (M11 is packages for *apps*, not shared
//! Rust crates). So a generated app's `Cargo.toml` can only depend on
//! them via a relative `path = "..."`, which means the generated app
//! has to live at a known depth relative to this repo's `libs/`
//! directory, and moving it elsewhere breaks the build until that's
//! fixed by hand. `--libs-path` makes this explicit rather than
//! papering over it; auto-detection (below) covers the common case
//! (running `nova create` from inside this repo) without needing the
//! flag at all.

use crate::template;
use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

pub fn run(args: &[String]) -> ExitCode {
    let mut name: Option<String> = None;
    let mut id_override: Option<String> = None;
    let mut out_override: Option<PathBuf> = None;
    let mut libs_path_override: Option<PathBuf> = None;

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--id" => {
                i += 1;
                id_override = args.get(i).cloned();
            }
            "--out" => {
                i += 1;
                out_override = args.get(i).map(PathBuf::from);
            }
            "--libs-path" => {
                i += 1;
                libs_path_override = args.get(i).map(PathBuf::from);
            }
            other if !other.starts_with('-') && name.is_none() => {
                name = Some(other.to_string());
            }
            other => {
                eprintln!("nova create: unrecognized argument '{other}'");
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    let Some(name) = name else {
        eprintln!("nova create: missing <name>\nusage: nova create <name> [--id <app-id>] [--out <dir>] [--libs-path <path>]");
        return ExitCode::FAILURE;
    };
    if !is_valid_crate_name(&name) {
        eprintln!("nova create: '{name}' isn't a valid app name -- use lowercase letters, digits, and underscores, starting with a letter");
        return ExitCode::FAILURE;
    }

    let id = id_override.unwrap_or_else(|| format!("org.nova.{name}"));
    let out_dir = out_override.unwrap_or_else(|| PathBuf::from(&name));
    let bin_name = name.replace('_', "-");
    let display_name = title_case(&name);

    if out_dir.exists() {
        eprintln!("nova create: '{}' already exists -- refusing to overwrite", out_dir.display());
        return ExitCode::FAILURE;
    }

    let libs_path = match libs_path_override {
        Some(p) => p,
        None => match find_libs_dir(&env::current_dir().unwrap_or_default()) {
            Some(p) => p,
            None => {
                eprintln!(
                    "nova create: couldn't auto-detect this repo's libs/ directory from {}\n\
                     pass it explicitly: nova create {name} --libs-path <path-to-libs>",
                    env::current_dir().map(|p| p.display().to_string()).unwrap_or_else(|_| "<cwd>".into())
                );
                return ExitCode::FAILURE;
            }
        },
    };

    let libs_path_from_app_dir = match relative_path(&out_dir, &libs_path) {
        Ok(p) => p,
        Err(e) => {
            eprintln!("nova create: couldn't compute a relative path from {} to {}: {e}", out_dir.display(), libs_path.display());
            return ExitCode::FAILURE;
        }
    };

    if let Err(e) = scaffold(&out_dir, &id, &display_name, &bin_name, &libs_path_from_app_dir) {
        eprintln!("nova create: failed: {e}");
        return ExitCode::FAILURE;
    }

    println!("Created {} ({id})", out_dir.display());
    println!("  {}/Cargo.toml", out_dir.display());
    println!("  {}/nova-app.toml", out_dir.display());
    println!("  {}/src/main.rs", out_dir.display());
    println!("  {}/README.md", out_dir.display());
    println!();
    println!("Next: nova build {}", out_dir.display());
    ExitCode::SUCCESS
}

fn scaffold(out_dir: &Path, id: &str, display_name: &str, bin_name: &str, libs_path_from_app_dir: &str) -> std::io::Result<()> {
    fs::create_dir_all(out_dir.join("src"))?;
    fs::write(out_dir.join("nova-app.toml"), template::manifest(id, display_name, bin_name))?;
    fs::write(out_dir.join("Cargo.toml"), template::cargo_toml(bin_name, libs_path_from_app_dir))?;
    fs::write(out_dir.join("src/main.rs"), template::main_rs(id))?;
    fs::write(out_dir.join("README.md"), template::app_readme(display_name, id, bin_name, libs_path_from_app_dir))?;
    Ok(())
}

fn is_valid_crate_name(name: &str) -> bool {
    let mut chars = name.chars();
    match chars.next() {
        Some(c) if c.is_ascii_lowercase() => {}
        _ => return false,
    }
    chars.all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_')
}

fn title_case(name: &str) -> String {
    name.split('_')
        .map(|word| {
            let mut c = word.chars();
            match c.next() {
                Some(first) => first.to_uppercase().collect::<String>() + c.as_str(),
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

/// Walks up from `start` looking for a `libs/nova-app-runtime`
/// directory -- the marker that `start` (or an ancestor of it) is
/// inside this repo. Stops after a bounded number of levels rather
/// than walking to filesystem root indefinitely.
fn find_libs_dir(start: &Path) -> Option<PathBuf> {
    let mut dir = start.to_path_buf();
    for _ in 0..8 {
        let candidate = dir.join("libs");
        if candidate.join("nova-app-runtime").is_dir() {
            return Some(candidate);
        }
        if !dir.pop() {
            break;
        }
    }
    None
}

/// Computes a relative path from `from` to `to`, walking up from
/// `from` and back down into `to` component by component. Both paths
/// are resolved as given (not canonicalized) since `from` (the
/// about-to-be-created app directory) doesn't exist on disk yet.
fn relative_path(from: &Path, to: &Path) -> Result<String, String> {
    let from_abs = absolute(from)?;
    let to_abs = absolute(to)?;

    let from_components: Vec<_> = from_abs.components().collect();
    let to_components: Vec<_> = to_abs.components().collect();

    let common = from_components.iter().zip(to_components.iter()).take_while(|(a, b)| a == b).count();

    let mut result = PathBuf::new();
    for _ in common..from_components.len() {
        result.push("..");
    }
    for component in &to_components[common..] {
        result.push(component.as_os_str());
    }

    Ok(result.to_string_lossy().replace('\\', "/"))
}

/// `Path::canonicalize` requires the path to exist; `from` (the
/// not-yet-created app directory) doesn't. This just resolves against
/// the current directory without touching the filesystem.
fn absolute(path: &Path) -> Result<PathBuf, String> {
    if path.is_absolute() {
        Ok(path.to_path_buf())
    } else {
        let cwd = env::current_dir().map_err(|e| e.to_string())?;
        Ok(cwd.join(path))
    }
}
