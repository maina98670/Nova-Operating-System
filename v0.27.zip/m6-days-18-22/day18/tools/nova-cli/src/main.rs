//! `nova` — the Day 18 SDK command-line tool.
//!
//! Deliberately standalone: this crate does not depend on
//! `nova-ipc`/`nova-app-manager`/`nova-fsmgr` at compile time, the
//! same way a real third-party app developer's toolchain wouldn't
//! link against the platform's own internal crates just to scaffold
//! and build an app. `--apps-dir` mirrors `nova_fsmgr::paths::APPS`'s
//! value (`/apps`) as a plain string default rather than a shared
//! dependency, for that reason.
//!
//! Subcommands:
//!   - `nova create <name>` — see `create.rs`.
//!   - `nova build <path>`  — see `build.rs`.
//!
//! `nova package`/`nova install`/`nova run` as their own separate
//! steps are Day 22's job ("the full toolchain, acceptance, tag").
//! Day 18's DoD only asks that `nova create` followed by `nova build`
//! (stubbed if needed) produces something that installs and launches
//! — so this day's `build` folds build+install together rather than
//! pretending the other three subcommands already exist.

mod build;
mod create;
mod template;

use std::env;
use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = env::args().collect();

    match args.get(1).map(String::as_str) {
        Some("create") => create::run(&args[2..]),
        Some("build") => build::run(&args[2..]),
        Some("-h") | Some("--help") | None => {
            print_usage();
            ExitCode::SUCCESS
        }
        Some(other) => {
            eprintln!("nova: unknown subcommand '{other}'");
            print_usage();
            ExitCode::FAILURE
        }
    }
}

fn print_usage() {
    eprintln!(
        "nova — Nova OS SDK CLI (Day 18: scaffolding + build/install)

USAGE:
    nova create <name> [--id <app-id>] [--out <dir>] [--libs-path <path>]
    nova build <path-to-app-dir> [--apps-dir <dir>]

    nova create test_app
        Generates ./test_app: a buildable Cargo crate + nova-app.toml,
        with sensible defaults for --id (org.nova.test_app) and --out
        (./test_app). --libs-path is auto-detected by walking up from
        the current directory looking for libs/nova-app-runtime; pass
        it explicitly if create is run somewhere that detection can't
        find (see docs/nova-sdk-template-v1.md).

    nova build test_app
        cargo build's the generated crate, then copies the resulting
        binary and manifest to <apps-dir>/<id>/ (default /apps,
        matching nova_fsmgr::paths::APPS), matching the install layout
        Days 16-17 already established -- ready for App Manager to
        install() and launch() with zero manual edits.
"
    );
}
