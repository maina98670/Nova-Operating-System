//! A deliberately minimal real app, used by Day 13's live acceptance
//! test. It is launched by nova-app-manager (through M4's Process/
//! Service Manager -- it has no idea how it was started, which is the
//! point: from an app's point of view, launch mechanics are entirely
//! App Manager's concern), discovers the App Manager's socket itself
//! (Day 12's `discover`, so it has zero hardcoded path), completes the
//! `Hello` handshake, and then just reports whatever `Lifecycle`
//! events arrive on stdout until it sees `Terminate`, at which point it
//! exits on its own -- proving Lifecycle delivery works, without
//! requiring App Manager to SIGKILL it to prove termination.
//!
//! Usage: nova-day13-test-app <app_id>

use nova_ipc::{discover, Message, SeqPacketSocket};
use std::process;

fn main() {
    let app_id = std::env::args().nth(1).unwrap_or_else(|| {
        eprintln!("nova-day13-test-app: usage: nova-day13-test-app <app_id>");
        process::exit(2);
    });

    let socket_path = discover("app-manager").unwrap_or_else(|e| {
        eprintln!("nova-day13-test-app: could not discover app-manager: {e}");
        process::exit(1);
    });

    let conn = SeqPacketSocket::connect(&socket_path.to_string_lossy()).unwrap_or_else(|e| {
        eprintln!("nova-day13-test-app: connect failed: {e}");
        process::exit(1);
    });

    conn.send(&Message::Hello { app_id: app_id.clone(), pid: process::id() })
        .unwrap_or_else(|e| {
            eprintln!("nova-day13-test-app: sending Hello failed: {e}");
            process::exit(1);
        });

    match conn.recv() {
        Ok(Message::HelloAck { accepted: true, granted_permissions }) => {
            println!("nova-day13-test-app[{app_id}]: HelloAck accepted, granted_permissions={granted_permissions:#x}");
        }
        Ok(Message::HelloAck { accepted: false, .. }) => {
            eprintln!("nova-day13-test-app[{app_id}]: HelloAck rejected by app-manager");
            process::exit(1);
        }
        Ok(other) => {
            eprintln!("nova-day13-test-app[{app_id}]: expected HelloAck, got {other:?}");
            process::exit(1);
        }
        Err(e) => {
            eprintln!("nova-day13-test-app[{app_id}]: recv HelloAck failed: {e}");
            process::exit(1);
        }
    }

    // Sit and report Lifecycle events until Terminate, exactly what a
    // real app's event loop would do -- this is the part of the DoD
    // that proves Lifecycle delivery, not just that the process is
    // still alive.
    loop {
        match conn.recv() {
            Ok(Message::Lifecycle { event }) => {
                println!("nova-day13-test-app[{app_id}]: received Lifecycle::{event:?}");
                if matches!(event, nova_ipc::LifecycleEvent::Terminate) {
                    println!("nova-day13-test-app[{app_id}]: exiting cleanly on Terminate");
                    break;
                }
            }
            Ok(other) => {
                println!("nova-day13-test-app[{app_id}]: received {other:?} (ignoring)");
            }
            Err(e) => {
                println!("nova-day13-test-app[{app_id}]: connection closed ({e}), exiting");
                break;
            }
        }
    }
}
