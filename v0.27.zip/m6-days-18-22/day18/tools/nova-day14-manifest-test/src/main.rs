//! Day 14's Definition of Done, run for real -- no mocks:
//!
//! "A manifest with a missing required field or an unknown permission
//!  name is rejected with a clear error at install/launch time, using
//!  the same validation path M4's Configuration subsystem already
//!  has."
//!
//! Writes three real `nova-app.toml` files under `<APPS>/`
//! (`nova_fsmgr::paths::APPS`, real `/apps` -- this needs root, same
//! requirement as Days 4/11/12/13's live tests) and checks all three
//! failure/success shapes, at both call sites Day 14 wires manifest
//! loading into:
//!   1. A well-formed manifest: `install()` succeeds, and the app it
//!      registers actually launches and completes a real `Hello`
//!      handshake (proving the manifest -> AppDef conversion produces
//!      something genuinely launchable, not just something that
//!      parses).
//!   2. A manifest missing a required field (`entry_point`):
//!      rejected by both `install()` and, on a fresh AppManager that
//!      never called `install()` at all, by `launch()`'s own lazy
//!      install path -- same error variant either way.
//!   3. A manifest naming an unknown permission: same two-call-site
//!      check.

use nova_app_manager::{AppManager, AppManagerError, ManifestError};
use nova_config::ConfigError;
use std::fs;
use std::path::PathBuf;
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const VALID_ID: &str = "org.nova.day14test";
const BROKEN_ID: &str = "org.nova.day14broken";
const SKETCHY_ID: &str = "org.nova.day14sketchy";

fn fail(msg: &str) -> ! {
    eprintln!("nova-day14-manifest-test: FAIL -- {msg}");
    process::exit(1);
}

fn app_dir(app_id: &str) -> PathBuf {
    std::path::Path::new(nova_fsmgr::paths::APPS).join(app_id)
}

fn write_manifest(app_id: &str, contents: &str) {
    let dir = app_dir(app_id);
    fs::create_dir_all(&dir)
        .unwrap_or_else(|e| fail(&format!("could not create {} (are you running as root?): {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), contents)
        .unwrap_or_else(|e| fail(&format!("could not write manifest for {app_id}: {e}")));
}

fn find_test_app_binary() -> PathBuf {
    let mut path = std::env::current_exe().unwrap_or_else(|e| fail(&format!("current_exe failed: {e}")));
    path.pop();
    path.push("nova-day13-test-app");
    if !path.exists() {
        fail(&format!(
            "expected sibling binary at {} -- build the whole workspace first (cargo build), not just this crate",
            path.display()
        ));
    }
    path
}

/// Asserts `result` is an `AppManagerError::Manifest(ManifestError::Config(ConfigError::Parse { .. }))`
/// -- the missing-required-field case, routed through nova-config's
/// own malformed-file error, per module docs.
fn expect_missing_field_error<T: std::fmt::Debug>(result: Result<T, AppManagerError>, context: &str) {
    match result {
        Err(AppManagerError::Manifest(ManifestError::Config(ConfigError::Parse { path, .. }))) => {
            println!("      -> {context}: rejected as malformed config (missing required field), naming {}", path.display());
        }
        other => fail(&format!("{context}: expected Manifest(Config(Parse)) for a missing required field, got {other:?}")),
    }
}

/// Asserts `result` is an `AppManagerError::Manifest(ManifestError::UnknownPermission { .. })`
/// naming the specific bad permission string.
fn expect_unknown_permission_error<T: std::fmt::Debug>(result: Result<T, AppManagerError>, context: &str, expected_name: &str) {
    match result {
        Err(AppManagerError::Manifest(ManifestError::UnknownPermission { name, path })) => {
            if name != expected_name {
                fail(&format!("{context}: expected unknown permission \"{expected_name}\", got \"{name}\""));
            }
            println!("      -> {context}: rejected \"{name}\" as an unknown permission, naming {}", path.display());
        }
        other => fail(&format!("{context}: expected Manifest(UnknownPermission), got {other:?}")),
    }
}

fn main() {
    println!("=== Nova OS Day 14: Package manifest + permission declarations ===");

    if let Err(e) = nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS]) {
        fail(&format!("could not ensure standard directories exist (are you running as root?): {e}"));
    }

    println!("[1/5] Writing three real nova-app.toml manifests under {}...", nova_fsmgr::paths::APPS);
    write_manifest(
        VALID_ID,
        &format!(
            "id = \"{VALID_ID}\"\nname = \"Day 14 Test App\"\nversion = \"0.1.0\"\nentry_point = \"{}\"\nargs = [\"{VALID_ID}\"]\nrequired_permissions = [\"storage\"]\noptional_permissions = [\"network\"]\n",
            find_test_app_binary().to_string_lossy()
        ),
    );
    write_manifest(
        BROKEN_ID,
        &format!("id = \"{BROKEN_ID}\"\nname = \"Missing entry_point\"\nversion = \"0.1.0\"\n"),
    );
    write_manifest(
        SKETCHY_ID,
        &format!("id = \"{SKETCHY_ID}\"\nname = \"Unknown permission\"\nversion = \"0.1.0\"\nentry_point = \"/bin/true\"\nrequired_permissions = [\"bluetooth\"]\n"),
    );
    println!("      -> {VALID_ID}: well-formed, real entry_point");
    println!("      -> {BROKEN_ID}: missing entry_point (required field)");
    println!("      -> {SKETCHY_ID}: entry_point set, but \"bluetooth\" is not a real permission");

    // --- Case 1: install() on all three ---
    println!("[2/5] install() -- validating at install time...");
    let installer = AppManager::new();
    installer.install(VALID_ID).unwrap_or_else(|e| fail(&format!("install({VALID_ID}) should have succeeded: {e}")));
    println!("      -> {VALID_ID}: installed successfully");
    expect_missing_field_error(installer.install(BROKEN_ID), &format!("install({BROKEN_ID})"));
    expect_unknown_permission_error(installer.install(SKETCHY_ID), &format!("install({SKETCHY_ID})"), "bluetooth");

    // --- Case 2: launch() on a FRESH AppManager that never called
    // install() -- proves the same validation path fires at launch
    // time too, not just when install() is called explicitly first.
    println!("[3/5] launch() on a fresh AppManager -- validating at launch time...");
    let launcher = AppManager::new();
    expect_missing_field_error(launcher.launch(BROKEN_ID), &format!("launch({BROKEN_ID})"));
    expect_unknown_permission_error(launcher.launch(SKETCHY_ID), &format!("launch({SKETCHY_ID})"), "bluetooth");

    // --- Case 3: the well-formed manifest, launched end-to-end,
    // proving install/launch produced something genuinely runnable,
    // not just something that parsed.
    println!("[4/5] Launching the well-formed manifest end-to-end...");
    let _server = launcher.serve(nova_ipc::SOCKET_PATH).unwrap_or_else(|e| fail(&format!("serve() failed: {e}")));
    thread::sleep(Duration::from_millis(100));
    let pid = launcher.launch(VALID_ID).unwrap_or_else(|e| fail(&format!("launch({VALID_ID}) should have succeeded via lazy install: {e}")));
    println!("      -> launched via lazy install-at-launch, real PID {pid}");

    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        if launcher.cold_start_ms(VALID_ID).is_some() {
            break;
        }
        if Instant::now() >= deadline {
            fail("test app never completed its Hello handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    println!("      -> real Hello/HelloAck handshake completed -- manifest-derived AppDef is genuinely launchable");

    println!("[5/5] Cleaning up...");
    launcher.terminate(VALID_ID).unwrap_or_else(|e| fail(&format!("terminate({VALID_ID}) failed: {e}")));
    let _ = fs::remove_file(nova_ipc::SOCKET_PATH);
    for id in [VALID_ID, BROKEN_ID, SKETCHY_ID] {
        let _ = fs::remove_dir_all(app_dir(id));
    }

    println!();
    println!("nova-day14-manifest-test: PASS -- a missing required field and an unknown");
    println!("nova-day14-manifest-test: permission name are both rejected with a clear error");
    println!("nova-day14-manifest-test: at install() and at launch() time, through the same");
    println!("nova-day14-manifest-test: manifest::load_manifest() path -- and a well-formed");
    println!("nova-day14-manifest-test: manifest installs and launches a real app end-to-end.");
}
