//! Nova OS Day 16 live acceptance: "Reconcile the existing Wayland
//! apps against the new stack".
//!
//! Per the Complete Build Guide's Day 16 DoD: all five apps must
//! launch, complete their IPC handshake, and pass their individual
//! acceptance checks (cold-start time, permission grants, IPC
//! handshake) when run through the M4-integrated App Manager -- not
//! standalone.
//!
//! This tool:
//! 1. Installs each app's `nova-app.toml` (embedded from `apps/<id>/`
//!    at compile time, written to `<APPS>/<id>/nova-app.toml` at
//!    runtime) through `AppManager::install`, the real
//!    manifest-validation path.
//! 2. Copies each app's already-built binary next to this tool into
//!    `<APPS>/<id>/bin/<binary>`, matching the manifest's
//!    `entry_point`.
//! 3. Launches each app through `AppManager::launch` (which spawns via
//!    M4's Service/Process Manager, not a raw fork/exec) and waits for
//!    its `Hello`/`HelloAck` handshake to complete.
//! 4. Checks the granted-permission bitmask against what the manifest
//!    declared (required at launch, optional after the app's own
//!    `PermissionRequest`s -- see `nova-app-runtime`).
//! 5. Cross-checks App Manager's own runtime view against M4's
//!    Process/Service Manager (the Day 13 DoD's own cross-check,
//!    re-run here against these five real apps rather than a
//!    synthetic test app).
//! 6. Terminates each app and confirms it actually stops.
//!
//! Regressions are reported honestly (not swallowed) -- an app that
//! fails any step is named explicitly rather than the run being
//! silently marked green.

use nova_app_manager::AppManager;
use nova_ipc::{Permission, SOCKET_PATH};
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

struct AppSpec {
    id: &'static str,
    bin_name: &'static str,
    manifest: &'static str,
    required: &'static [Permission],
    optional: &'static [Permission],
}

const APPS: &[AppSpec] = &[
    AppSpec {
        id: "org.nova.settings",
        bin_name: "nova-settings",
        manifest: include_str!("../../../apps/org.nova.settings/nova-app.toml"),
        required: &[Permission::Storage],
        optional: &[Permission::Network],
    },
    AppSpec {
        id: "org.nova.contacts",
        bin_name: "nova-contacts",
        manifest: include_str!("../../../apps/org.nova.contacts/nova-app.toml"),
        required: &[Permission::Contacts, Permission::Storage],
        optional: &[],
    },
    AppSpec {
        id: "org.nova.messages",
        bin_name: "nova-messages",
        manifest: include_str!("../../../apps/org.nova.messages/nova-app.toml"),
        required: &[Permission::Sms, Permission::Contacts, Permission::Storage],
        optional: &[Permission::Network],
    },
    AppSpec {
        id: "org.nova.dialer",
        bin_name: "nova-dialer",
        manifest: include_str!("../../../apps/org.nova.dialer/nova-app.toml"),
        required: &[Permission::Contacts],
        optional: &[],
    },
    AppSpec {
        id: "org.nova.camera",
        bin_name: "nova-camera",
        manifest: include_str!("../../../apps/org.nova.camera/nova-app.toml"),
        required: &[Permission::Camera, Permission::Storage],
        optional: &[],
    },
];

struct Report {
    failures: Vec<String>,
}

impl Report {
    fn fail(&mut self, app_id: &str, msg: impl AsRef<str>) {
        let line = format!("{app_id}: {}", msg.as_ref());
        eprintln!("      -> REGRESSION: {line}");
        self.failures.push(line);
    }
}

fn app_dir(id: &str) -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(id)
}

fn install_manifest(spec: &AppSpec) {
    let dir = app_dir(spec.id);
    fs::create_dir_all(&dir).unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: mkdir {}: {e}", dir.display());
        process::exit(2);
    });
    fs::write(dir.join("nova-app.toml"), spec.manifest).unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: write manifest for {}: {e}", spec.id);
        process::exit(2);
    });
}

fn install_binary(spec: &AppSpec) {
    let mut src = std::env::current_exe().unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: current_exe: {e}");
        process::exit(2);
    });
    src.pop(); // this tool's own directory -- `cargo build --workspace` puts
               // every binary in the same target/<profile>/ directory, so
               // each app's built binary is a sibling of this one.
    src.push(spec.bin_name);
    if !src.exists() {
        eprintln!(
            "nova-day16-reconciliation-test: expected sibling binary {} \
             (run `cargo build --workspace` first, per the Day 16 build script)",
            src.display()
        );
        process::exit(2);
    }

    let dest_dir = app_dir(spec.id).join("bin");
    fs::create_dir_all(&dest_dir).unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: mkdir {}: {e}", dest_dir.display());
        process::exit(2);
    });
    let dest = dest_dir.join(spec.bin_name);
    fs::copy(&src, &dest).unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: copy {} -> {}: {e}", src.display(), dest.display());
        process::exit(2);
    });
    let mut perms = fs::metadata(&dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&dest, perms).unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: chmod {}: {e}", dest.display());
        process::exit(2);
    });
}

fn bits_of(perms: &[Permission]) -> u32 {
    perms.iter().fold(0u32, |acc, p| acc | p.bit())
}

fn main() {
    println!("=== Nova OS Day 16: reconcile Settings/Contacts/Messages/Dialer/Camera ===");
    println!();
    println!("NOTE: the five apps launched below are Day 16's from-scratch, protocol-");
    println!("correct reconstructions (see libs/nova-app-runtime's module docs), not a");
    println!("preserved copy of any pre-existing implementation -- that source was not");
    println!("part of this Day 16 upload. This run proves the integrated App Manager /");
    println!("IPC / permission stack against apps built to speak it, not a regression");
    println!("diff against original app-specific behavior.");
    println!();

    nova_fsmgr::ensure_dirs(&[
        nova_fsmgr::paths::RUN,
        nova_fsmgr::paths::APPS,
        nova_fsmgr::paths::LOG,
    ]).unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: ensure dirs: {e}");
        process::exit(2);
    });

    let manager = AppManager::new();
    let _server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| {
        eprintln!("nova-day16-reconciliation-test: serve: {e}");
        process::exit(2);
    });

    let mut report = Report { failures: Vec::new() };

    for spec in APPS {
        println!("--- {} ({}) ---", spec.id, spec.bin_name);
        install_manifest(spec);
        install_binary(spec);

        if let Err(e) = manager.install(spec.id) {
            report.fail(spec.id, format!("install (manifest validation) failed: {e}"));
            continue;
        }
        println!("      manifest installed and validated");

        let pid = match manager.launch(spec.id) {
            Ok(pid) => pid,
            Err(e) => {
                report.fail(spec.id, format!("launch failed: {e}"));
                continue;
            }
        };
        println!("      launched, pid={pid} (via M4 Service/Process Manager, not raw fork/exec)");

        // IPC handshake: wait for Hello to land and cold-start to be
        // recorded by App Manager itself (not the app's own claim).
        let deadline = Instant::now() + Duration::from_secs(5);
        while manager.cold_start_ms(spec.id).is_none() {
            if Instant::now() >= deadline {
                report.fail(spec.id, "did not complete the Hello/HelloAck handshake within 5s");
                break;
            }
            thread::sleep(Duration::from_millis(20));
        }
        if manager.cold_start_ms(spec.id).is_none() {
            let _ = manager.terminate(spec.id);
            continue;
        }
        let cold_start = manager.cold_start_ms(spec.id).unwrap();
        println!("      IPC handshake complete, cold-start = {cold_start}ms (measured by App Manager)");

        // Required permissions must be granted at launch, immediately.
        let required_bits = bits_of(spec.required);
        let implicit_bits = Permission::implicit_bitmask();
        let granted = manager.granted_permissions(spec.id).unwrap_or(0);
        if granted & required_bits != required_bits {
            report.fail(
                spec.id,
                format!(
                    "required permissions not fully granted at launch: required=0b{required_bits:b} granted=0b{granted:b}"
                ),
            );
        } else if granted & implicit_bits != implicit_bits {
            report.fail(spec.id, "implicit Display/Input permissions missing from grant");
        } else {
            println!("      required permissions granted at launch: 0b{required_bits:b}");
        }

        // Optional permissions: the app itself requests these right
        // after Hello (see nova-app-runtime::run_minimal_app). Give it
        // a moment, then confirm the grant matches the manifest.
        if !spec.optional.is_empty() {
            thread::sleep(Duration::from_millis(100));
            let optional_bits = bits_of(spec.optional);
            let granted = manager.granted_permissions(spec.id).unwrap_or(0);
            if granted & optional_bits != optional_bits {
                report.fail(
                    spec.id,
                    format!(
                        "declared optional permissions were not granted after runtime request: \
                         optional=0b{optional_bits:b} granted=0b{granted:b}"
                    ),
                );
            } else {
                println!("      declared optional permissions granted after runtime request: 0b{optional_bits:b}");
            }
        }

        // Day 13's own cross-check, re-run here: App Manager's runtime
        // view must agree with M4's Process/Service Manager, not just
        // with itself.
        let process_seen = manager.process_list().iter().any(|p| p.pid == pid);
        if !process_seen {
            report.fail(spec.id, "pid missing from M4 Process Manager's process_list() while App Manager still thinks it's running");
        }
        match manager.check_permission(spec.id, Permission::Display) {
            Ok(()) => {}
            Err(e) => report.fail(spec.id, format!("implicit Display permission check failed: {e}")),
        }

        // Terminate and confirm it actually stops -- not just that App
        // Manager forgot about it.
        if let Err(e) = manager.terminate(spec.id) {
            report.fail(spec.id, format!("terminate failed: {e}"));
            continue;
        }
        thread::sleep(Duration::from_millis(150));
        let still_tracked = manager.pid_of(spec.id).is_some();
        if still_tracked {
            report.fail(spec.id, "still tracked as running after terminate()");
        } else {
            println!("      terminated cleanly, no longer tracked as running");
        }

        println!();
    }

    // Cleanup: remove the manifests/binaries this run installed so a
    // re-run starts clean (doesn't touch anything Day 15's test may
    // also have left, which already cleans up after itself).
    for spec in APPS {
        let _ = fs::remove_dir_all(app_dir(spec.id));
    }
    let _ = fs::remove_file(SOCKET_PATH);

    println!("=== Day 16 result ===");
    if report.failures.is_empty() {
        println!("PASS: all five apps installed, launched, completed their IPC handshake,");
        println!("      received exactly the permissions their manifest declares, agreed with");
        println!("      M4's Process Manager, and terminated cleanly -- through the integrated");
        println!("      App Manager, not standalone.");
    } else {
        println!("FAIL: {} regression(s) found:", report.failures.len());
        for f in &report.failures {
            println!("  - {f}");
        }
        process::exit(1);
    }
}
