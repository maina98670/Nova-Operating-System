//! Nova OS Day 17 — the Roadmap's own M5 acceptance test, run live.
//!
//! Per the Complete Build Guide: "a packaged test application can
//! launch, communicate through IPC and operate within its
//! permissions." This tool proves exactly that against `nova-hello`,
//! the Day 17 canonical smoke test — deliberately simpler than
//! Day 16's five real apps, so a failure here points at the platform
//! (App Manager / nova-ipc / nova-sandbox), not at any one app's own
//! logic.
//!
//! Sequence, all in one run:
//! 1. **Packaged**: install `nova-hello`'s manifest through
//!    `AppManager::install` — the same manifest-validation path
//!    (Day 14) every real app goes through.
//! 2. **Launch**: through the integrated App Manager (Day 13's M4
//!    Process/Service Manager integration), not a raw fork/exec.
//! 3. **Communicate through IPC**: wait for the `Hello`/`HelloAck`
//!    handshake App Manager itself records (`cold_start_ms`).
//! 4. **Operate within its permissions**: confirm the required
//!    permission (`storage`) and the declared optional permission
//!    (`network`, requested by `nova-hello` itself at runtime) are
//!    both granted, *and* confirm the undeclared permission
//!    (`camera`, also requested by `nova-hello` itself) is **not**
//!    granted — App Manager's own bitmask is the source of truth for
//!    both halves, not `nova-hello`'s stdout.
//! 5. Cross-check against M4's Process Manager (the same cross-check
//!    Days 13 and 16 already run), terminate, confirm cleanup.

use nova_app_manager::AppManager;
use nova_ipc::{Permission, SOCKET_PATH};
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const APP_ID: &str = "org.nova.hello";
const BIN_NAME: &str = "nova-hello";
const MANIFEST: &str = include_str!("../../../apps/org.nova.hello/nova-app.toml");
const REQUIRED: &[Permission] = &[Permission::Storage];
const DECLARED_OPTIONAL: &[Permission] = &[Permission::Network];
const UNDECLARED: Permission = Permission::Camera;

fn app_dir() -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(APP_ID)
}

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn main() {
    println!("=== Nova OS Day 17: M5 acceptance -- 'a packaged test application can launch,");
    println!("    communicate through IPC and operate within its permissions' ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));

    let manager = AppManager::new();
    let _server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("serve: {e}")));

    // 1. Packaged: write and install the manifest through the real
    // validation path.
    let dir = app_dir();
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), MANIFEST).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(BIN_NAME);
    if !bin_src.exists() {
        fail(format!(
            "expected sibling binary {} (run `cargo build --workspace` first, per the Day 17 build script)",
            bin_src.display()
        ));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(BIN_NAME);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(APP_ID).unwrap_or_else(|e| fail(format!("install (manifest validation): {e}")));
    println!("1. PACKAGED    -- manifest installed and validated through AppManager::install");

    // 2. Launch through the integrated App Manager.
    let pid = manager.launch(APP_ID).unwrap_or_else(|e| fail(format!("launch: {e}")));
    println!("2. LAUNCH      -- pid={pid}, spawned via M4 Service/Process Manager");

    // 3. Communicate through IPC: wait for the handshake App Manager
    // itself recorded.
    let deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(APP_ID).is_none() {
        if Instant::now() >= deadline {
            fail("did not complete the Hello/HelloAck handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    let cold_start = manager.cold_start_ms(APP_ID).unwrap();
    println!("3. IPC         -- Hello/HelloAck handshake complete, cold-start = {cold_start}ms");

    // Give nova-hello time to run its own PermissionRequest round
    // trips (declared network, then undeclared camera) before
    // checking App Manager's bitmask.
    thread::sleep(Duration::from_millis(200));

    // 4. Operate within its permissions: required + declared-optional
    // granted, undeclared NOT granted -- per App Manager's own
    // bitmask, not nova-hello's stdout.
    let granted = manager.granted_permissions(APP_ID).unwrap_or(0);
    let implicit = Permission::implicit_bitmask();
    let required_bits: u32 = REQUIRED.iter().fold(0, |acc, p| acc | p.bit());
    let optional_bits: u32 = DECLARED_OPTIONAL.iter().fold(0, |acc, p| acc | p.bit());

    if granted & implicit != implicit {
        fail("implicit Display/Input permissions missing from grant");
    }
    if granted & required_bits != required_bits {
        fail(format!("required permission(s) not granted: required=0b{required_bits:b} granted=0b{granted:b}"));
    }
    if granted & optional_bits != optional_bits {
        fail(format!(
            "declared optional permission(s) not granted after nova-hello's own runtime request: \
             optional=0b{optional_bits:b} granted=0b{granted:b}"
        ));
    }
    if granted & UNDECLARED.bit() != 0 {
        fail(format!(
            "SECURITY REGRESSION: undeclared permission '{}' was granted -- granted=0b{granted:b}",
            UNDECLARED.name()
        ));
    }
    println!(
        "4. PERMISSIONS -- required (0b{required_bits:b}) + declared optional (0b{optional_bits:b}) granted; \
         undeclared '{}' correctly blocked (granted=0b{granted:b})",
        UNDECLARED.name()
    );

    // 5. Cross-check against M4's Process Manager, then terminate and
    // confirm cleanup.
    let process_seen = manager.process_list().iter().any(|p| p.pid == pid);
    if !process_seen {
        fail("pid missing from M4 Process Manager's process_list() while App Manager still thinks it's running");
    }
    println!("5. CROSS-CHECK -- pid {pid} confirmed in M4 Process Manager's process_list()");

    manager.terminate(APP_ID).unwrap_or_else(|e| fail(format!("terminate: {e}")));
    thread::sleep(Duration::from_millis(150));
    if manager.pid_of(APP_ID).is_some() {
        fail("still tracked as running after terminate()");
    }
    println!("   TERMINATE   -- terminated cleanly, no longer tracked as running");

    let _ = fs::remove_dir_all(app_dir());
    let _ = fs::remove_file(SOCKET_PATH);

    println!();
    println!("=== M5 ACCEPTANCE: PASS ===");
    println!("A packaged test application launched, communicated through real IPC");
    println!("(3 request/response round trips), and operated within its declared");
    println!("permissions -- including being blocked from an undeclared one -- all");
    println!("through the integrated M4/M5 stack in a single run.");
}
