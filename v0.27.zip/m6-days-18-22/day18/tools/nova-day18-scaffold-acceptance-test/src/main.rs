//! Nova OS Day 18 live acceptance.
//!
//! DoD: "`nova create test_app` followed by `nova build` (stubbed if
//! needed) produces a package that installs and launches, with zero
//! manual edits to generated files."
//!
//! This runs the real `nova` binary as a subprocess for both steps —
//! not a re-implementation of `create`/`build`'s logic in-process —
//! so "zero manual edits" is actually true: nothing in this test ever
//! opens or rewrites a file `nova create` generated. Only after
//! `nova build` has copied its own output to `<APPS>/<id>/` does this
//! test touch anything, and only to install/launch/verify through
//! App Manager, exactly as Day 16/17's tools already do for the real
//! apps and `nova-hello`.

use nova_app_manager::AppManager;
use nova_ipc::{Permission, SOCKET_PATH};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode};
use std::thread;
use std::time::{Duration, Instant};

const APP_NAME: &str = "test_app";
const APP_ID: &str = "org.nova.test_app";
const BIN_NAME: &str = "test-app";

fn fail(msg: impl AsRef<str>) -> ExitCode {
    eprintln!("FAIL: {}", msg.as_ref());
    ExitCode::FAILURE
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 18: `nova create` + `nova build` acceptance ===");
    println!();

    // Locate the `nova` binary and this repo's root the same way
    // Day 16/17's tools locate their sibling app binaries: `cargo
    // build --workspace` puts every workspace binary in one
    // target/<profile>/ directory.
    let mut nova_bin = match std::env::current_exe() {
        Ok(p) => p,
        Err(e) => return fail(format!("current_exe: {e}")),
    };
    nova_bin.pop(); // .../target/debug/
    let target_debug = nova_bin.clone();
    nova_bin.push("nova");
    if !nova_bin.is_file() {
        return fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", nova_bin.display()));
    }

    // target/debug -> target -> repo root
    let repo_root = match target_debug.parent().and_then(Path::parent) {
        Some(p) => p.to_path_buf(),
        None => return fail("couldn't derive repo root from current_exe's path"),
    };
    let libs_path = repo_root.join("libs");
    if !libs_path.join("nova-app-runtime").is_dir() {
        return fail(format!("expected {} to contain nova-app-runtime", libs_path.display()));
    }

    let workdir = PathBuf::from("/tmp").join(format!("nova-day18-test-{}", std::process::id()));
    if workdir.exists() {
        let _ = fs::remove_dir_all(&workdir);
    }
    if let Err(e) = fs::create_dir_all(&workdir) {
        return fail(format!("mkdir {}: {e}", workdir.display()));
    }
    let app_dir = workdir.join(APP_NAME);

    // Step 1: `nova create test_app` -- a real subprocess, exactly
    // what a developer would type.
    println!("--- nova create {APP_NAME} ---");
    let create_status = Command::new(&nova_bin)
        .arg("create")
        .arg(APP_NAME)
        .arg("--out")
        .arg(&app_dir)
        .arg("--libs-path")
        .arg(&libs_path)
        .status();
    match create_status {
        Ok(s) if s.success() => {}
        Ok(s) => return fail(format!("nova create exited with {s}")),
        Err(e) => return fail(format!("couldn't run nova create: {e}")),
    }
    for expected in ["Cargo.toml", "nova-app.toml", "src/main.rs", "README.md"] {
        if !app_dir.join(expected).is_file() {
            return fail(format!("nova create didn't produce {}", app_dir.join(expected).display()));
        }
    }
    println!("nova create produced a working skeleton at {}", app_dir.display());

    // Step 2: `nova build test_app` -- also a real subprocess. Between
    // here and step 1, nothing in this test has opened or modified
    // any file under app_dir -- that's the "zero manual edits" half
    // of the DoD.
    println!();
    println!("--- nova build {} ---", app_dir.display());
    let build_status = Command::new(&nova_bin).arg("build").arg(&app_dir).status();
    match build_status {
        Ok(s) if s.success() => {}
        Ok(s) => return fail(format!("nova build exited with {s}")),
        Err(e) => return fail(format!("couldn't run nova build: {e}")),
    }

    let installed_manifest = Path::new(nova_fsmgr::paths::APPS).join(APP_ID).join("nova-app.toml");
    let installed_bin = Path::new(nova_fsmgr::paths::APPS).join(APP_ID).join("bin").join(BIN_NAME);
    if !installed_manifest.is_file() {
        return fail(format!("nova build didn't install {}", installed_manifest.display()));
    }
    if !installed_bin.is_file() {
        return fail(format!("nova build didn't install {}", installed_bin.display()));
    }
    println!("nova build installed {} + {}", installed_manifest.display(), installed_bin.display());

    // Step 3: the "produces a package that installs and launches"
    // half -- same install()/launch()/handshake sequence Day 16/17's
    // tools already run for the real apps and nova-hello.
    println!();
    println!("--- install + launch through App Manager ---");
    if let Err(e) = nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG]) {
        return fail(format!("ensure dirs: {e}"));
    }
    let manager = AppManager::new();
    let _server = match manager.serve(SOCKET_PATH) {
        Ok(s) => s,
        Err(e) => return fail(format!("serve: {e}")),
    };

    if let Err(e) = manager.install(APP_ID) {
        return fail(format!("install (manifest validation): {e}"));
    }
    println!("installed and validated");

    let pid = match manager.launch(APP_ID) {
        Ok(pid) => pid,
        Err(e) => return fail(format!("launch: {e}")),
    };
    println!("launched, pid={pid}");

    let deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(APP_ID).is_none() {
        if Instant::now() >= deadline {
            return fail("scaffolded app did not complete the Hello/HelloAck handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    let cold_start = manager.cold_start_ms(APP_ID).unwrap();
    println!("IPC handshake complete, cold-start = {cold_start}ms");

    let granted = manager.granted_permissions(APP_ID).unwrap_or(0);
    let implicit = Permission::implicit_bitmask();
    let required = Permission::Storage.bit(); // template's default required_permissions
    if granted & implicit != implicit {
        return fail("implicit Display/Input permissions missing from grant");
    }
    if granted & required != required {
        return fail(format!("required 'storage' permission not granted: granted=0b{granted:b}"));
    }
    println!("required permissions granted as declared in the generated nova-app.toml");

    let process_seen = manager.process_list().iter().any(|p| p.pid == pid);
    if !process_seen {
        return fail("pid missing from M4 Process Manager's process_list()");
    }
    println!("cross-checked against M4's Process Manager");

    if let Err(e) = manager.terminate(APP_ID) {
        return fail(format!("terminate: {e}"));
    }
    thread::sleep(Duration::from_millis(150));
    if manager.pid_of(APP_ID).is_some() {
        return fail("still tracked as running after terminate()");
    }
    println!("terminated cleanly");

    // Cleanup
    let _ = fs::remove_dir_all(workdir);
    let _ = fs::remove_dir_all(Path::new(nova_fsmgr::paths::APPS).join(APP_ID));
    let _ = fs::remove_file(SOCKET_PATH);

    println!();
    println!("=== Day 18 ACCEPTANCE: PASS ===");
    println!("`nova create {APP_NAME}` -> `nova build` produced a package that installed");
    println!("and launched through App Manager, with zero manual edits to any generated file.");
    ExitCode::SUCCESS
}
