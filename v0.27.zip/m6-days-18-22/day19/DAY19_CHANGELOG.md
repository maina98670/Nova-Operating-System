# Day 19 Change Log

Base: `nova-day18-package.zip`

1. Added `libs/nova-window-api` — `Window<B: WaylandBackend>`
   (create/resize/set_title/state/close), `StubBackend` (in-memory,
   no real compositor exists yet -- M7). Unit tests cover create,
   resize+retitle, close-consumes-handle, operating-on-closed-window
   errors, and multi-window independence.
2. Added `libs/nova-input-api` — `TouchEvent`/`KeyEvent`/
   `PointerEvent`/`InputEvent` types, `InputSource` trait,
   `UnavailableSource` (always `Err(NotYetAvailable)`, never `Ok`).
   Unit tests confirm this and that the event types are usable today.
3. Added `apps/org.nova.windowtest` — the DoD's "test app built
   against the new Window API": handshake, then the full Window API
   lifecycle + Input API check, no Wayland protocol type imported
   anywhere in its source. Exits early with a distinct code on the
   first failure.
4. Added `tools/nova-day19-window-acceptance-test` — installs/
   launches `nova-windowtest`, confirms handshake, then confirms the
   process is still alive (not exited early) as the process-level
   proxy for every internal step having succeeded, since window state
   lives in-process and isn't exposed over IPC yet.
5. Added `docs/nova-window-input-api-v1.md` — API reference, honest
   starting point (no compositor exists until M7), and named scope
   boundaries (no IPC exposure of window state, no multi-window/focus
   model).
6. Updated the workspace `Cargo.toml` with the two new libs, one new
   app, and one new tool.

Day 20 (Storage API + Networking API stub) is next.
