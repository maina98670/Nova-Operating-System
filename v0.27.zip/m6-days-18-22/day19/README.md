# Nova OS — Day 19 Package: Window API + Input API

This package continues directly from the Day 18 package (M6).
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day19-build_and_run.sh` yourself to actually confirm it.

## Day 19 goal

Per the Complete Build Guide:
1. Window API: create/resize/close/title, wrapping the xdg-shell-style
   calls the existing apps already hand-roll, so future apps don't
   each reimplement `fb.rs`/protocol boilerplate from scratch.
2. Input API: the touch/keyboard/pointer plumbing every app so far has
   been missing — expose it as a stable API now even though the real
   input pipeline lands in M7.

DoD: a test app built against the new Window API renders a window
without touching Wayland protocol code directly; the Input API
compiles and returns a defined "not yet available" state honestly
rather than pretending input works before M7.

## Honest starting point

The "existing apps already hand-roll" Wayland code is the same
never-uploaded, earlier-session app-level work flagged since Day 16 —
nothing to literally wrap here. More importantly: **Nova's own
compositor doesn't exist yet** — that's M7 (Days 23–28), a later
milestone than this one. Both APIs below are built the way every other
missing-hardware seam in this repo already is (`SmsTransport`,
`CameraBackend`, `TelephonyBackend`): a real trait, a real
caller-facing type, and an honest stub. See `docs/nova-window-input-api-v1.md`
for the full writeup.

## What's new

- **`libs/nova-window-api`** — `Window<B: WaylandBackend>`:
  create/resize/set_title/state/close. `StubBackend` tracks window
  state in an in-memory `HashMap`, zero socket I/O. `close(self)`
  consumes the handle, so use-after-close is a compile error for
  anything holding a `Window` directly. Unit-tested.
- **`libs/nova-input-api`** — `TouchEvent`/`KeyEvent`/`PointerEvent`/
  `InputEvent` types (real, usable today), `InputSource::poll()`, and
  `UnavailableSource` — the only implementation shipped, which always
  returns `Err(InputError::NotYetAvailable)`. Unit-tested.
- **`apps/org.nova.windowtest`** — the literal "test app built against
  the new Window API" from the DoD. Launches through App Manager
  (Hello/HelloAck), then exercises the full Window API lifecycle and
  the Input API's honest unavailable-check. No Wayland protocol type
  appears anywhere in its source.
- **`tools/nova-day19-window-acceptance-test`** — installs/launches
  `nova-windowtest` through App Manager, confirms the IPC handshake,
  then confirms the process is still `Running`/`Sleeping` (not exited
  early) a short delay later — the process-level proxy for "every
  Window/Input step inside it succeeded," since window state lives in
  that process's own memory and isn't exposed over IPC (a named,
  not-hidden scope boundary — see the doc).
- **`docs/nova-window-input-api-v1.md`** — API reference + honest
  starting point + what Day 19 doesn't cover.

## Run

```bash
./nova-day19-build_and_run.sh
```

Builds the workspace, runs both new crates' unit tests, then the live
acceptance test. Needs the same root-capable Linux environment as the
Days 11–18 live tests (`/apps`, `/run/nova`, `/var/log/nova`).

## Status

Unverified until the build, unit tests, and live acceptance test
actually pass — none of that was run in this pass, per instruction.
