# Nova SDK — Window API & Input API, v1 (Day 19, first draft)

Per Day 19's task list: "wrapping the xdg-shell-style calls the
existing apps already hand-roll, so future apps don't each reimplement
`fb.rs`/protocol boilerplate from scratch," and exposing the
touch/keyboard/pointer Input API as a stable surface now, ahead of
M7's real pipeline.

## Honest starting point

The "existing apps [that] already hand-roll" Wayland/`fb.rs` code
refers to the same earlier-session, pre-M4 app-level work already
flagged in the Day 16 package (Settings/Contacts/Messages/Dialer/
Camera, `nova-ipc`) — never uploaded to this track, so there was
nothing to literally unwrap and re-wrap here.

More fundamentally: **Nova's own compositor doesn't exist yet at all**
— that's M7's job (Days 23–28, per the guide's milestone table). Even
with the hand-rolled code in hand, there is nothing running today for
a Window API to connect to. So both APIs below are built the same way
every missing-hardware seam in this repo has been built since Day 16
(`nova-messages-core`'s `SmsTransport`, `nova-camera-core`'s
`CameraBackend`, etc.): a real trait, a real caller-facing type, and a
stub backend that is honest about doing nothing beyond in-memory
bookkeeping.

## Window API (`nova-window-api`)

```rust
let mut window = Window::create(StubBackend::new(), "My App", 640, 480)?;
window.resize(1024, 768)?;
window.set_title("My App (resized)")?;
let state = window.state()?; // WindowState { title, width, height, open }
window.close()?; // consumes the handle -- no use-after-close at compile time
```

- `WaylandBackend` is the trait a real M7 compositor client implements
  later. `StubBackend` is the only implementation today — an in-memory
  `HashMap<WindowId, WindowState>`, zero socket I/O.
- `Window<B: WaylandBackend>` is what an app actually holds. Nothing
  in its public API names a Wayland protocol type (`wl_surface`,
  `xdg_toplevel`, `xdg_surface`, etc.) — that's the literal DoD
  requirement ("without touching Wayland protocol code directly"),
  and it's enforced by this crate simply never importing or
  re-exporting one.
- `close(self)` takes the window by value: once closed, the handle is
  gone, so "operate on a window after closing it" is a compile error
  for code that holds the `Window<B>` itself, not just a runtime
  `Result` — though the underlying backend also rejects it
  (`WindowError::AlreadyClosed`) for callers going through the trait
  directly, e.g. `nova-day19-window-acceptance-test` if it ever needs
  to.

## Input API (`nova-input-api`)

```rust
let mut input = UnavailableSource;
match input.poll() {
    Err(InputError::NotYetAvailable) => { /* the only outcome today */ }
    Ok(_) => unreachable!("no InputSource in this crate ever returns Ok before M7"),
}
```

- Event types (`TouchEvent`, `KeyEvent`, `PointerEvent`, `InputEvent`)
  are defined now so an app can write real match arms against them
  today, and so M7's eventual real backend doesn't have to invent a
  new event shape that every app written in the meantime then has to
  adapt to. `KeyEvent::keycode` deliberately uses the Linux evdev
  keycode convention for this same reason.
- `InputSource::poll()` is the entire trait surface: non-blocking,
  `Ok(Some(event))` / `Ok(None)` / `Err`. `UnavailableSource` is the
  only implementation shipped here, and it always returns
  `Err(InputError::NotYetAvailable)` — never `Ok`, never a panic. This
  *is* Day 19's Input API deliverable, not a stand-in for one that's
  still missing.

## What an app built against these looks like

`apps/org.nova.windowtest` — the literal "test app built against the
new Window API" from the DoD. It launches through App Manager exactly
like every Day 16–18 app (`Hello`/`HelloAck`), then calls
`Window::create`/`resize`/`set_title`/`state`/`close` and
`UnavailableSource::poll()`, printing each result. No Wayland protocol
type appears anywhere in its source — verify by reading it, since
that's a much stronger check than anything a test can assert from
outside the process.

## What Day 19 doesn't cover (named, not hidden)

- **No real rendering, no real input events.** Both are explicitly
  M7's job. Nothing here should be mistaken for a working GUI.
- **No IPC exposure of window/input state.** `nova-windowtest`'s
  window lives entirely in its own process memory; there's no new
  `nova-ipc` message type for querying it from outside (e.g. from
  Nova Shell). That would be real, useful work for a later day, not
  something Day 19 silently assumes already happened.
- **Multi-window/focus/z-order semantics** aren't modeled — `Window`
  is one window at a time, with no concept of which window (if
  several existed) has input focus. Not meaningful to design yet
  without a real compositor to define those semantics against.
