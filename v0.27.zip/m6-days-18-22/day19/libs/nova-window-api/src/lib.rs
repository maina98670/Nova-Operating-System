//! Nova OS Day 19 — Window API.
//!
//! Wraps the xdg-shell-style window lifecycle (create/resize/close/
//! title) so a future app calls `Window::create(...)` instead of
//! hand-rolling Wayland protocol code — the literal Day 19 task:
//! "wrapping the xdg-shell-style calls the existing apps already
//! hand-roll, so future apps don't each reimplement fb.rs/protocol
//! boilerplate from scratch."
//!
//! ## Honest starting point
//! That "existing apps already hand-roll" code refers to the same
//! earlier-session, pre-M4 app-level work referenced throughout Days
//! 16-18 (Settings/Contacts/Messages/Dialer/Camera, `nova-ipc`) —
//! never uploaded to this track, so there's nothing to actually wrap.
//! More fundamentally: **Nova's own compositor doesn't exist yet
//! either** — that's M7's job (Days 23-28, per the guide's own
//! milestone table), so even with that hand-rolled code in hand,
//! there would be nothing running to connect it to today.
//!
//! [`WaylandBackend`] is the seam a real M7 compositor client plugs
//! into. [`StubBackend`] tracks window state (id, title, size,
//! open/closed) purely in memory, with zero socket/network I/O — so
//! `Window::create`/`resize`/`set_title`/`close` are all real,
//! callable, and unit-testable today, exactly the same honesty
//! pattern already used for missing hardware elsewhere in this repo
//! (`nova-messages-core`'s `SmsTransport`, `nova-camera-core`'s
//! `CameraBackend`, etc.) — not a claim that pixels are being drawn
//! anywhere.

use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct WindowId(u32);

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WindowState {
    pub title: String,
    pub width: u32,
    pub height: u32,
    pub open: bool,
}

#[derive(Debug)]
pub enum WindowError {
    NotFound(WindowId),
    AlreadyClosed(WindowId),
    Backend(String),
}

impl std::fmt::Display for WindowError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            WindowError::NotFound(id) => write!(f, "no window with id {id:?}"),
            WindowError::AlreadyClosed(id) => write!(f, "window {id:?} is already closed"),
            WindowError::Backend(e) => write!(f, "backend error: {e}"),
        }
    }
}
impl std::error::Error for WindowError {}

/// The seam a real M7 compositor client (talking actual xdg-shell
/// over a real Wayland socket) plugs into.
pub trait WaylandBackend {
    fn create_window(&mut self, title: &str, width: u32, height: u32) -> Result<WindowId, WindowError>;
    fn resize(&mut self, id: WindowId, width: u32, height: u32) -> Result<(), WindowError>;
    fn set_title(&mut self, id: WindowId, title: &str) -> Result<(), WindowError>;
    fn close(&mut self, id: WindowId) -> Result<(), WindowError>;
    fn state(&self, id: WindowId) -> Result<WindowState, WindowError>;
}

/// No real compositor exists yet — see module docs. Tracks window
/// state in an in-memory map only; never touches a socket. Explicitly
/// a placeholder, not a simulated "realistic" compositor connection.
#[derive(Default)]
pub struct StubBackend {
    windows: HashMap<WindowId, WindowState>,
    next_id: u32,
}

impl StubBackend {
    pub fn new() -> Self {
        Self::default()
    }
}

impl WaylandBackend for StubBackend {
    fn create_window(&mut self, title: &str, width: u32, height: u32) -> Result<WindowId, WindowError> {
        self.next_id += 1;
        let id = WindowId(self.next_id);
        self.windows.insert(id, WindowState { title: title.to_string(), width, height, open: true });
        Ok(id)
    }

    fn resize(&mut self, id: WindowId, width: u32, height: u32) -> Result<(), WindowError> {
        let w = self.windows.get_mut(&id).ok_or(WindowError::NotFound(id))?;
        if !w.open {
            return Err(WindowError::AlreadyClosed(id));
        }
        w.width = width;
        w.height = height;
        Ok(())
    }

    fn set_title(&mut self, id: WindowId, title: &str) -> Result<(), WindowError> {
        let w = self.windows.get_mut(&id).ok_or(WindowError::NotFound(id))?;
        if !w.open {
            return Err(WindowError::AlreadyClosed(id));
        }
        w.title = title.to_string();
        Ok(())
    }

    fn close(&mut self, id: WindowId) -> Result<(), WindowError> {
        let w = self.windows.get_mut(&id).ok_or(WindowError::NotFound(id))?;
        if !w.open {
            return Err(WindowError::AlreadyClosed(id));
        }
        w.open = false;
        Ok(())
    }

    fn state(&self, id: WindowId) -> Result<WindowState, WindowError> {
        self.windows.get(&id).cloned().ok_or(WindowError::NotFound(id))
    }
}

/// A single window, backed by a `WaylandBackend`. This is the type an
/// app actually calls — the backend is otherwise invisible to it,
/// which is the whole point: an app written against `Window` never
/// needs to import a Wayland protocol crate or know an `xdg_surface`
/// exists.
pub struct Window<B: WaylandBackend> {
    backend: B,
    id: WindowId,
}

impl<B: WaylandBackend> Window<B> {
    pub fn create(mut backend: B, title: &str, width: u32, height: u32) -> Result<Self, WindowError> {
        let id = backend.create_window(title, width, height)?;
        Ok(Self { backend, id })
    }

    pub fn id(&self) -> WindowId {
        self.id
    }

    pub fn resize(&mut self, width: u32, height: u32) -> Result<(), WindowError> {
        self.backend.resize(self.id, width, height)
    }

    pub fn set_title(&mut self, title: &str) -> Result<(), WindowError> {
        self.backend.set_title(self.id, title)
    }

    pub fn state(&self) -> Result<WindowState, WindowError> {
        self.backend.state(self.id)
    }

    /// Consumes the window — once closed, there's nothing left to
    /// call methods on, which the type system enforces here rather
    /// than leaving a closed-but-still-usable handle around.
    pub fn close(mut self) -> Result<(), WindowError> {
        self.backend.close(self.id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn create_reports_initial_state() {
        let window = Window::create(StubBackend::new(), "Hello", 640, 480).unwrap();
        let state = window.state().unwrap();
        assert_eq!(state, WindowState { title: "Hello".into(), width: 640, height: 480, open: true });
    }

    #[test]
    fn resize_and_set_title_update_state() {
        let mut window = Window::create(StubBackend::new(), "Hello", 640, 480).unwrap();
        window.resize(1024, 768).unwrap();
        window.set_title("Renamed").unwrap();
        let state = window.state().unwrap();
        assert_eq!(state.width, 1024);
        assert_eq!(state.height, 768);
        assert_eq!(state.title, "Renamed");
    }

    #[test]
    fn close_marks_closed_and_consumes_the_handle() {
        let window = Window::create(StubBackend::new(), "Hello", 640, 480).unwrap();
        // window.close() takes `self` -- a second call is a compile
        // error, not a runtime one, which is the actual guarantee
        // being tested here as much as the resulting state is.
        window.close().unwrap();
    }

    #[test]
    fn operating_on_a_closed_window_is_an_error() {
        let mut backend = StubBackend::new();
        let id = backend.create_window("Hello", 640, 480).unwrap();
        backend.close(id).unwrap();
        assert!(matches!(backend.resize(id, 100, 100), Err(WindowError::AlreadyClosed(_))));
        assert!(matches!(backend.set_title(id, "x"), Err(WindowError::AlreadyClosed(_))));
        assert!(matches!(backend.close(id), Err(WindowError::AlreadyClosed(_))));
    }

    #[test]
    fn multiple_windows_are_independent() {
        let mut backend = StubBackend::new();
        let a = backend.create_window("A", 100, 100).unwrap();
        let b = backend.create_window("B", 200, 200).unwrap();
        assert_ne!(a, b);
        backend.resize(a, 50, 50).unwrap();
        assert_eq!(backend.state(a).unwrap().width, 50);
        assert_eq!(backend.state(b).unwrap().width, 200);
    }
}
