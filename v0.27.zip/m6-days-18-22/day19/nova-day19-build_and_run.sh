#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 19: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 19: Window API + Input API unit tests ==="
cargo test -p nova-window-api -p nova-input-api

echo
echo "=== Nova OS Day 19: live acceptance ==="
echo "Installs and launches nova-windowtest through App Manager. Uses Nova's"
echo "standard /apps, /run/nova and /var/log/nova paths -- needs the same"
echo "root-capable Linux environment as the Day 11-18 live tests."
cargo run -p nova-day19-window-acceptance-test

echo
echo "Day 19 build + tests + live acceptance completed."
