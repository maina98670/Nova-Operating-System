//! Nova OS Day 19 live acceptance.
//!
//! DoD: "A test app built against the new Window API renders a
//! window without touching Wayland protocol code directly; the Input
//! API compiles and returns a defined 'not yet available' state
//! honestly rather than pretending input works before M7."
//!
//! `nova-window-api`'s own unit tests (`cargo test -p nova-window-api`)
//! and `nova-input-api`'s (`cargo test -p nova-input-api`) already
//! prove the API surface works and behaves honestly in isolation.
//! This tool proves the other half live: that a real app
//! (`nova-windowtest`) built against these APIs — never importing a
//! Wayland protocol type — installs and launches through the
//! integrated App Manager (same as every Day 16-18 app) and actually
//! reaches its idle loop, meaning every Window/Input step inside it
//! ran without error.
//!
//! Window state itself lives entirely inside `nova-windowtest`'s own
//! process memory (`StubBackend`'s `HashMap`) — there's no IPC message
//! exposing it externally (out of scope for this day), so this tool
//! can't directly assert "width == 1024" from the outside. What it
//! *can* assert, and does: `nova-windowtest` exits early with a
//! distinct nonzero code on the first Window/Input failure (see its
//! own source), so a process that's still `Running` a short delay
//! after launch — past the point all those calls would already have
//! executed, since none of them do any I/O — is real evidence every
//! step succeeded, not just that the process started.

use nova_app_manager::AppManager;
use nova_ipc::{Permission, SOCKET_PATH};
use nova_procmgr::ProcessState;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const APP_ID: &str = "org.nova.windowtest";
const BIN_NAME: &str = "nova-windowtest";
const MANIFEST: &str = include_str!("../../../apps/org.nova.windowtest/nova-app.toml");
const REQUIRED: &[Permission] = &[Permission::Storage];

fn app_dir() -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(APP_ID)
}

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn main() {
    println!("=== Nova OS Day 19: Window API + Input API acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));

    let manager = AppManager::new();
    let _server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("serve: {e}")));

    let dir = app_dir();
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), MANIFEST).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(BIN_NAME);
    if !bin_src.exists() {
        fail(format!(
            "expected sibling binary {} (run `cargo build --workspace` first, per the Day 19 build script)",
            bin_src.display()
        ));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(BIN_NAME);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(APP_ID).unwrap_or_else(|e| fail(format!("install (manifest validation): {e}")));
    println!("installed and validated");

    let pid = manager.launch(APP_ID).unwrap_or_else(|e| fail(format!("launch: {e}")));
    println!("launched, pid={pid}");

    let deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(APP_ID).is_none() {
        if Instant::now() >= deadline {
            fail("did not complete the Hello/HelloAck handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    let cold_start = manager.cold_start_ms(APP_ID).unwrap();
    println!("IPC handshake complete, cold-start = {cold_start}ms");

    let granted = manager.granted_permissions(APP_ID).unwrap_or(0);
    let required_bits: u32 = REQUIRED.iter().fold(0, |acc, p| acc | p.bit());
    if granted & required_bits != required_bits {
        fail(format!("required permission(s) not granted: required=0b{required_bits:b} granted=0b{granted:b}"));
    }

    // Give every Window/Input step inside nova-windowtest time to run
    // -- all in-memory, no I/O, so this is generous, not tight.
    thread::sleep(Duration::from_millis(300));

    let process = manager
        .process_list()
        .into_iter()
        .find(|p| p.pid == pid)
        .unwrap_or_else(|| fail("pid missing from M4 Process Manager's process_list() entirely"));

    match process.state {
        ProcessState::Running | ProcessState::Sleeping => {
            println!(
                "nova-windowtest is still {:?} after {}ms -- every Window/Input API step it ran completed \
                 without triggering its own early-exit path",
                process.state,
                300
            );
        }
        other => {
            fail(format!(
                "nova-windowtest exited early (state={other:?}, exit_code={:?}) -- see its own stderr for which \
                 Window/Input step failed",
                process.exit_code
            ));
        }
    }

    manager.terminate(APP_ID).unwrap_or_else(|e| fail(format!("terminate: {e}")));
    thread::sleep(Duration::from_millis(150));
    if manager.pid_of(APP_ID).is_some() {
        fail("still tracked as running after terminate()");
    }
    println!("terminated cleanly");

    let _ = fs::remove_dir_all(app_dir());
    let _ = fs::remove_file(SOCKET_PATH);

    println!();
    println!("=== Day 19 ACCEPTANCE: PASS ===");
    println!("nova-windowtest installed, launched, completed the IPC handshake, and ran every");
    println!("Window API step (create/resize/set_title/close) and the Input API's honest");
    println!("NotYetAvailable check without crashing -- all without touching Wayland protocol");
    println!("code directly. See nova-window-api's and nova-input-api's own unit tests for the");
    println!("API-level correctness proof this tool doesn't reach into the process to check.");
}
