# Day 20 Change Log

Base: `nova-day19-package.zip`

1. Added `libs/nova-storage-api` — `StorageApi` (permission-checked at
   `open()`), `read`/`write`/`delete`/`list`, all routed through
   `SandboxPolicy::scoped_path`. `delete`/`list` are new (Day 15's
   `nova-sandbox` only had read/write) -- closes the gap Day 16's
   `nova-camera-core` named. Unit tests include traversal-rejected on
   every operation and two-app-ids-never-collide.
2. Added `libs/nova-network-api` — `Request`/`Response`/`Method`,
   `NetworkClient` trait, `UnavailableClient` (always
   `Err(NotImplemented)`). Same honesty pattern as Day 19's
   `nova-input-api`.
3. Added `apps/org.nova.storagetest` — the DoD's test app: own-storage
   round trip (kept on disk), list+delete, five traversal/absolute-path
   escape attempts (must all fail), one Networking API call (must
   return NotImplemented). Distinct exit codes per failure category
   (3 = own-storage op failed, 4 = security regression, 5 = honesty
   regression on networking).
4. Added `tools/nova-day20-storage-network-acceptance-test` —
   installs/launches, confirms handshake, then verifies Storage API
   results **on the real filesystem** (own file exists with correct
   content, throwaway key actually deleted, no file appeared under
   `org.nova.contacts`'s or `/etc/`'s paths) rather than trusting the
   app's own stdout.
5. Added `docs/nova-storage-network-api-v1.md` — API reference, the
   two-"/apps"-paths clarification, and the honest scope of "blocked
   from another app's data" (real traversal protection; identity
   spoofing across processes is still M10's job, unchanged from prior
   days' caveats).
6. Updated the workspace `Cargo.toml` with the two new libs, one new
   app, and one new tool.

Named but not done in this delivery: wiring `StorageApi::delete` into
`nova-camera-core::PhotoLibrary::delete` (the API to fix that Day 16
gap now exists; the actual wire-up is a follow-up, not part of Day
20's own scope).

Day 21 (Notifications + lifecycle callbacks + permission-request APIs)
is next.
