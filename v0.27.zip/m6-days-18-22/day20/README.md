# Nova OS — Day 20 Package: Storage API + Networking API Stub

This package continues directly from the Day 19 package (M6).
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day20-build_and_run.sh` yourself to actually confirm it.

## Day 20 goal

Per the Complete Build Guide:
1. Storage API: a scoped, permission-checked file/data API for apps,
   built on M4's Filesystem Manager and M5's sandbox boundaries — not
   raw filesystem access.
2. Networking API: define the interface now; the real implementation
   waits for M8, so stub it with a clear "network unavailable"
   response rather than silently failing.

DoD: a test app can read/write its own scoped storage but is blocked
from another app's data (proving M5's sandboxing is actually wired to
the SDK, not bypassed); the Networking API returns an honest "not
implemented" rather than crashing.

## What's new

- **`libs/nova-storage-api`** — `StorageApi::open(policy)`
  (permission-checked at construction) with `read`/`write`/`delete`/
  `list`, every operation routed through `SandboxPolicy::scoped_path`
  (Day 15) — never a raw `std::fs` call on a caller-given path. Adds
  `delete`/`list` on top of Day 15's `read_scoped`/`write_scoped`,
  closing the gap Day 16's `nova-camera-core` named in its own doc
  comment. Unit-tested, including a traversal-rejected-on-every-op
  test and a two-different-app-ids-never-collide test.
- **`libs/nova-network-api`** — `Request`/`Response`/`Method` types,
  `NetworkClient` trait, `UnavailableClient` — always
  `Err(NetworkError::NotImplemented)`, same honesty pattern as Day
  19's Input API stub. Unit-tested.
- **`apps/org.nova.storagetest`** — the DoD's "test app": own-storage
  read/write/list/delete (kept on disk for external verification),
  five distinct traversal/absolute-path escape attempts (each must
  fail or the app exits with a security-regression code), one
  Networking API call (must return `NotImplemented` or the app exits
  with an honesty-regression code).
- **`tools/nova-day20-storage-network-acceptance-test`** — installs/
  launches `nova-storagetest`, confirms the handshake, then verifies
  on the **real filesystem** (not the app's stdout) that its own data
  was written, its throwaway key was actually deleted, and its
  traversal attempt never touched `org.nova.contacts`'s storage root
  or any absolute path outside the sandbox. Stronger than Day 19's
  process-alive proxy, because Storage API's whole point is a real,
  checkable location on disk.
- **`docs/nova-storage-network-api-v1.md`** — API reference, the
  two-different-"`/apps`"-paths clarification, and the honest scope of
  "blocked from another app's data" (real traversal protection;
  identity-spoofing across processes is still M10's job).

## Run

```bash
./nova-day20-build_and_run.sh
```

Builds the workspace, runs both new crates' unit tests, then the live
acceptance test. Needs the same root-capable Linux environment as the
Days 11–19 live tests, plus write access to `/var/lib/nova/apps/`
(Storage API's actual data root, distinct from `nova_fsmgr::paths::APPS`
= `/apps`).

## Status

Unverified until the build, unit tests, and live acceptance test
actually pass — none of that was run in this pass, per instruction.
