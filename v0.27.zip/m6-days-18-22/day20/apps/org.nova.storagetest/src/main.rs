//! nova-storagetest — Day 20's "test app" from the DoD.
//!
//! Launches through App Manager like every other app (Hello/
//! HelloAck), then:
//! 1. Writes and reads its own scoped storage via `nova-storage-api`
//!    (kept on disk after this run, not deleted, so
//!    `tools/nova-day20-storage-network-acceptance-test` can verify
//!    it externally).
//! 2. Exercises `list`/`delete` on a second, throwaway key.
//! 3. Attempts to escape its own sandbox root via `..` and an
//!    absolute path on every Storage API operation — each attempt
//!    must fail, or this app exits with a distinct "security
//!    regression" code rather than continuing as if nothing happened.
//! 4. Calls the Networking API stub and confirms it returns
//!    `NotImplemented` — again exiting with a distinct code if it
//!    ever doesn't, since a networking stub that silently starts
//!    "working" before M8 exists would be a bug, not a feature.

use nova_ipc::Permission;
use nova_network_api::{NetworkClient, NetworkError, Request, UnavailableClient};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_storage_api::{StorageApi, StorageError};
use std::process;

const APP_ID: &str = "org.nova.storagetest";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck complete");

    // Matches this app's nova-app.toml (required = storage).
    let policy = SandboxPolicy::new(APP_ID, PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty())
        .expect("APP_ID is a valid app id");
    let storage = match StorageApi::open(policy) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[{APP_ID}] StorageApi::open failed: {e}");
            process::exit(1);
        }
    };

    // --- 1. Read/write our own scoped storage ---
    // Kept on disk (not deleted) so the acceptance test can check it
    // externally under /var/lib/nova/apps/org.nova.storagetest/.
    let greeting = b"hello from org.nova.storagetest";
    if let Err(e) = storage.write("greeting.txt", greeting) {
        eprintln!("[{APP_ID}] write(greeting.txt) failed: {e}");
        process::exit(3);
    }
    match storage.read("greeting.txt") {
        Ok(bytes) if bytes == greeting => println!("[{APP_ID}] own-storage read/write round trip OK"),
        Ok(_) => {
            eprintln!("[{APP_ID}] read(greeting.txt) returned unexpected content");
            process::exit(3);
        }
        Err(e) => {
            eprintln!("[{APP_ID}] read(greeting.txt) failed: {e}");
            process::exit(3);
        }
    }

    // --- 2. list + delete on a throwaway key ---
    if let Err(e) = storage.write("scratch.txt", b"temp") {
        eprintln!("[{APP_ID}] write(scratch.txt) failed: {e}");
        process::exit(3);
    }
    match storage.list("") {
        Ok(names) if names.contains(&"scratch.txt".to_string()) => println!("[{APP_ID}] list() correctly shows scratch.txt"),
        Ok(names) => {
            eprintln!("[{APP_ID}] list() didn't include scratch.txt: {names:?}");
            process::exit(3);
        }
        Err(e) => {
            eprintln!("[{APP_ID}] list failed: {e}");
            process::exit(3);
        }
    }
    if let Err(e) = storage.delete("scratch.txt") {
        eprintln!("[{APP_ID}] delete(scratch.txt) failed: {e}");
        process::exit(3);
    }
    match storage.read("scratch.txt") {
        Err(StorageError::NotFound(_)) => println!("[{APP_ID}] delete() confirmed -- scratch.txt no longer readable"),
        Ok(_) => {
            eprintln!("[{APP_ID}] scratch.txt still readable after delete()");
            process::exit(3);
        }
        Err(e) => {
            eprintln!("[{APP_ID}] unexpected error re-reading deleted key: {e}");
            process::exit(3);
        }
    }

    // --- 3. Traversal MUST be blocked on every operation ---
    if storage.write("../org.nova.contacts/pwned.txt", b"nope").is_ok() {
        eprintln!("[{APP_ID}] SECURITY REGRESSION: write() escaped the sandbox via ../");
        process::exit(4);
    }
    if storage.read("../org.nova.contacts/contacts.json").is_ok() {
        eprintln!("[{APP_ID}] SECURITY REGRESSION: read() escaped the sandbox via ../");
        process::exit(4);
    }
    if storage.delete("../org.nova.contacts/contacts.json").is_ok() {
        eprintln!("[{APP_ID}] SECURITY REGRESSION: delete() escaped the sandbox via ../");
        process::exit(4);
    }
    if storage.list("../org.nova.contacts").is_ok() {
        eprintln!("[{APP_ID}] SECURITY REGRESSION: list() escaped the sandbox via ../");
        process::exit(4);
    }
    if storage.write("/etc/nova-pwned", b"nope").is_ok() {
        eprintln!("[{APP_ID}] SECURITY REGRESSION: write() accepted an absolute path");
        process::exit(4);
    }
    println!("[{APP_ID}] every traversal/absolute-path attempt was correctly blocked -- M5's sandboxing is wired into the Storage API, not bypassed");

    // --- 4. Networking API: must be honestly unavailable ---
    let mut network = UnavailableClient;
    match network.send(Request::get("https://example.invalid/ping")) {
        Err(NetworkError::NotImplemented) => {
            println!("[{APP_ID}] Networking API correctly reports NotImplemented (real stack lands in M8)");
        }
        Ok(_) => {
            eprintln!("[{APP_ID}] HONESTY REGRESSION: Networking API returned a response before M8 exists");
            process::exit(5);
        }
    }

    println!("[{APP_ID}] Day 20 checks complete: own storage real and usable, sandboxed, network honestly unavailable");
    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}
