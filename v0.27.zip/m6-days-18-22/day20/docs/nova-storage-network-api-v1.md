# Nova SDK — Storage API & Networking API, v1 (Day 20, first draft)

Per Day 20's task list: "a scoped, permission-checked file/data API
for apps, built on M4's Filesystem Manager and M5's sandbox boundaries
— not raw filesystem access," and a Networking API interface defined
now, stubbed honestly until M8.

## Storage API (`nova-storage-api`)

```rust
let policy = SandboxPolicy::new("org.nova.my_app", required, optional)?;
let storage = StorageApi::open(policy)?; // fails if Storage isn't granted
storage.write("greeting.txt", b"hello")?;
let bytes = storage.read("greeting.txt")?;
let keys = storage.list("")?;
storage.delete("greeting.txt")?;
```

- Every operation routes through `SandboxPolicy::scoped_path` (Day
  15) — `nova-storage-api` never calls `std::fs` on a caller-given
  path directly, anywhere. That's the literal proof the DoD asks for:
  "M5's sandboxing is actually wired to the SDK, not bypassed."
- `open()` itself checks `Permission::Storage` before returning a
  handle — a `StorageApi` value existing at all is proof the
  permission was granted, the same type-level guarantee
  `nova-window-api`'s `close(self)` uses for a different property.
- `delete`/`list` are new here — Day 15's `nova-sandbox` only had
  `read_scoped`/`write_scoped`. This closes the gap Day 16's
  `nova-camera-core` named in its own doc comment ("no delete-scoped
  storage API yet"); `PhotoLibrary::delete` can now actually delete
  the frame file instead of only removing its index entry (not
  changed in this delivery — a follow-up wire-up, not done here, since
  Day 20's job was the API itself).

### Two different "`/apps`" paths

`nova_fsmgr::paths::APPS` (`/apps`) is where App Manager installs a
manifest + binary (Days 14/16). `SandboxPolicy::app_data_root`
(`/var/lib/nova/apps/<id>`, Day 15) is where Storage API's
`read`/`write`/`delete`/`list` actually touch disk. They share the
word "apps" and nothing else — worth remembering when reading
`tools/nova-day20-storage-network-acceptance-test`, which touches
both.

### What "blocked from another app's data" means today, honestly

`StorageApi` structurally cannot escape its own `app_data_root()` via
a relative path — `..` and absolute paths are rejected before any
filesystem call, proven by this crate's own unit tests and re-proven
live by `nova-storagetest` (`apps/org.nova.storagetest`) attempting
exactly that and being blocked on every operation
(write/read/delete/list).

What this does **not** defend against: a process constructing a
`SandboxPolicy` for a *different* app id and opening `StorageApi`
against it directly. Nothing today cryptographically ties an app id to
the one process that's allowed to claim it — that's still M10's job
(no per-process OS-level isolation exists yet), the same caveat Day
15/16 already state for their own local permission checks. Traversal
protection is real and structural today; identity-spoofing protection
is not.

## Networking API (`nova-network-api`)

```rust
let mut client = UnavailableClient;
match client.send(Request::get("https://example.com")) {
    Err(NetworkError::NotImplemented) => { /* the only outcome today */ }
    Ok(_) => unreachable!("no NetworkClient in this crate ever returns Ok before M8"),
}
```

- `Request`/`Response`/`Method` are defined now (real, usable types) so
  an app can write real code against them today; `NetworkClient` is
  the trait a real M8 (Networking, v0.40, Days 29–33) implementation
  plugs into later.
- `UnavailableClient` is the only implementation shipped here, and it
  always returns `Err(NetworkError::NotImplemented)` — never `Ok`,
  never a panic, never a hang. Same honesty pattern as Day 19's
  `nova-input-api::UnavailableSource`.

## What an app built against these looks like

`apps/org.nova.storagetest` — the DoD's "test app": handshake, then
own-storage read/write/list/delete (kept on disk afterward so
`tools/nova-day20-storage-network-acceptance-test` can verify it
externally on the real filesystem, not by trusting stdout), then five
distinct traversal/absolute-path attempts (each must fail or the app
exits with a "security regression" code), then one Networking API call
(must return `NotImplemented` or the app exits with an "honesty
regression" code).

## What Day 20 doesn't cover (named, not hidden)

- **Identity-spoofing isn't blocked.** See "What 'blocked from another
  app's data' means today, honestly" above — this is the same M10 gap
  every prior day's sandbox-adjacent work has named.
- **`nova-camera-core`'s `PhotoLibrary::delete` still doesn't delete
  the frame file** — the API to do so now exists (`StorageApi::delete`),
  but wiring it into that specific crate wasn't done in this delivery.
- **No quota/size limits.** An app can write arbitrarily large or
  numerous files to its own scoped storage; nothing here enforces a
  cap.
- **`list` is non-recursive**, file names only, one level deep from
  the given prefix.
