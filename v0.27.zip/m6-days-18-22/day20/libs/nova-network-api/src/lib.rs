//! Nova OS Day 20 — Networking API.
//!
//! "Define the interface now; the real implementation waits for M8,
//! so stub it with a clear 'network unavailable' response rather than
//! silently failing." M8 (Networking, v0.40) is Days 29-33 — a later
//! milestone than this one. Same honesty pattern as
//! `nova-input-api`'s Day 19 stub: the type shape is real and usable
//! today, so an app written against it now doesn't need to change
//! when M8 lands — only which [`NetworkClient`] it's given changes.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Method {
    Get,
    Post,
    Put,
    Delete,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Request {
    pub url: String,
    pub method: Method,
    pub headers: Vec<(String, String)>,
    pub body: Vec<u8>,
}

impl Request {
    pub fn get(url: impl Into<String>) -> Self {
        Self { url: url.into(), method: Method::Get, headers: Vec::new(), body: Vec::new() }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Response {
    pub status: u16,
    pub headers: Vec<(String, String)>,
    pub body: Vec<u8>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NetworkError {
    /// The honest, defined state the Day 20 DoD asks for. Every
    /// `NetworkClient` implementation shipped in this crate returns
    /// this from every call — no "sometimes works" path, and no
    /// silent failure (e.g. hanging, or returning a fabricated
    /// response) either.
    NotImplemented,
}

impl std::fmt::Display for NetworkError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            NetworkError::NotImplemented => write!(f, "networking is not implemented yet -- the real stack lands in M8"),
        }
    }
}
impl std::error::Error for NetworkError {}

/// The seam a real M8 networking stack plugs into.
pub trait NetworkClient {
    fn send(&mut self, request: Request) -> Result<Response, NetworkError>;
}

/// The only `NetworkClient` this crate ships. Always returns
/// `Err(NetworkError::NotImplemented)` — never `Ok`, never a panic,
/// never a hang. This *is* Day 20's Networking API deliverable for
/// the "real implementation" half, not a placeholder pending one
/// elsewhere in this same delivery.
#[derive(Default)]
pub struct UnavailableClient;

impl NetworkClient for UnavailableClient {
    fn send(&mut self, _request: Request) -> Result<Response, NetworkError> {
        Err(NetworkError::NotImplemented)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unavailable_client_always_errs() {
        let mut client = UnavailableClient;
        for _ in 0..5 {
            assert_eq!(client.send(Request::get("https://example.invalid")), Err(NetworkError::NotImplemented));
        }
    }

    #[test]
    fn request_types_are_constructible() {
        let req = Request {
            url: "https://example.invalid/api".into(),
            method: Method::Post,
            headers: vec![("content-type".into(), "application/json".into())],
            body: b"{}".to_vec(),
        };
        assert_eq!(req.method, Method::Post);
        assert_eq!(req.headers.len(), 1);
    }
}
