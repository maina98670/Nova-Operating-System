//! Nova OS Day 20 — Storage API.
//!
//! "A scoped, permission-checked file/data API for apps, built on
//! M4's Filesystem Manager and M5's sandbox boundaries — not raw
//! filesystem access." Every operation here goes through
//! `SandboxPolicy::scoped_path` (Day 15) — this crate never calls
//! `std::fs` on a caller-given path directly. That's the literal
//! proof the DoD asks for: "M5's sandboxing is actually wired to the
//! SDK, not bypassed."
//!
//! Also closes a gap Day 16's `nova-camera-core` named in its own
//! doc comment ("no delete-scoped storage API yet") — `delete` and
//! `list` are added here, on top of Day 15's existing
//! `read_scoped`/`write_scoped`, both still routed through
//! `scoped_path` for the same traversal protection.
//!
//! ## Two different "`/apps`" paths — don't confuse them
//! `nova_fsmgr::paths::APPS` (`/apps`) is where App Manager installs
//! a manifest + binary (Days 14/16). `SandboxPolicy::app_data_root`
//! (`/var/lib/nova/apps/<id>`, Day 15) is where *this* crate's
//! `read`/`write`/`delete`/`list` actually touch disk — an app's own
//! *data*, not its installed package. They happen to share the word
//! "apps" and nothing else.
//!
//! ## What "blocked from another app's data" means today, honestly
//! [`StorageApi`] structurally cannot escape its own
//! `app_data_root()` via a relative path — `..` and absolute paths
//! are rejected before any filesystem call, proven by this crate's
//! own unit tests. What it does **not** defend against: a process
//! constructing a [`SandboxPolicy`] for a *different* app id and
//! opening `StorageApi` against it directly — nothing today ties an
//! app id to the process that's allowed to claim it (no per-process
//! OS-level isolation exists yet; that's still M10's job, the exact
//! same caveat Day 15/16 already state). Traversal protection is real
//! and structural; identity-spoofing protection is not yet.

use nova_ipc::Permission;
use nova_sandbox::{SandboxError, SandboxPolicy};
use std::fs;
use std::io;

#[derive(Debug)]
pub enum StorageError {
    NotFound(String),
    Sandbox(SandboxError),
    Io(String),
}

impl std::fmt::Display for StorageError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            StorageError::NotFound(key) => write!(f, "no such key: {key}"),
            StorageError::Sandbox(e) => write!(f, "sandbox error: {e}"),
            StorageError::Io(e) => write!(f, "storage I/O error: {e}"),
        }
    }
}
impl std::error::Error for StorageError {}

/// A permission-checked handle onto one app's own scoped storage.
/// Cannot be constructed unless `Permission::Storage` is already
/// granted on the given policy — the permission check is part of
/// `open`, not something a caller can forget to do first.
pub struct StorageApi {
    policy: SandboxPolicy,
}

impl StorageApi {
    pub fn open(policy: SandboxPolicy) -> Result<Self, StorageError> {
        policy.check(Permission::Storage).map_err(StorageError::Sandbox)?;
        Ok(Self { policy })
    }

    pub fn read(&self, key: &str) -> Result<Vec<u8>, StorageError> {
        self.policy.read_scoped(key).map_err(|e| classify_read_error(&*e))
    }

    pub fn write(&self, key: &str, data: &[u8]) -> Result<(), StorageError> {
        self.policy.write_scoped(key, data).map_err(|e| classify_write_error(&*e))
    }

    /// Not in `nova-sandbox` itself (Day 15 didn't add it) — still
    /// routed through `scoped_path` for the same traversal
    /// protection every other operation here gets.
    pub fn delete(&self, key: &str) -> Result<(), StorageError> {
        let path = self.policy.scoped_path(key).map_err(StorageError::Sandbox)?;
        fs::remove_file(&path).map_err(|e| {
            if e.kind() == io::ErrorKind::NotFound {
                StorageError::NotFound(key.to_string())
            } else {
                StorageError::Io(e.to_string())
            }
        })
    }

    /// Lists entries directly under `prefix` (relative to this app's
    /// own storage root; `""` for the root itself). Non-recursive,
    /// file names only — enough for the apps built so far
    /// (`nova-camera-core`'s photo index, etc. already keep their own
    /// richer listing in a JSON index file rather than relying on
    /// directory listing).
    pub fn list(&self, prefix: &str) -> Result<Vec<String>, StorageError> {
        let dir = self.policy.scoped_path(prefix).map_err(StorageError::Sandbox)?;
        if !dir.exists() {
            return Ok(Vec::new());
        }
        let mut names: Vec<String> = fs::read_dir(&dir)
            .map_err(|e| StorageError::Io(e.to_string()))?
            .filter_map(|entry| entry.ok())
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .collect();
        names.sort();
        Ok(names)
    }
}

fn classify_read_error(e: &(dyn std::error::Error + 'static)) -> StorageError {
    if let Some(sandbox_err) = e.downcast_ref::<SandboxError>() {
        return StorageError::Sandbox(sandbox_err.clone());
    }
    if let Some(io_err) = e.downcast_ref::<io::Error>() {
        if io_err.kind() == io::ErrorKind::NotFound {
            return StorageError::NotFound(String::new());
        }
    }
    StorageError::Io(e.to_string())
}

fn classify_write_error(e: &(dyn std::error::Error + 'static)) -> StorageError {
    if let Some(sandbox_err) = e.downcast_ref::<SandboxError>() {
        return StorageError::Sandbox(sandbox_err.clone());
    }
    StorageError::Io(e.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_sandbox::PermissionSet;

    fn open_test_policy(app_id: &str) -> StorageApi {
        let policy = SandboxPolicy::new(app_id, PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty()).unwrap();
        StorageApi::open(policy).unwrap()
    }

    #[test]
    fn open_without_storage_permission_is_rejected() {
        let policy = SandboxPolicy::new("org.nova.day20test.noperms", PermissionSet::empty(), PermissionSet::empty()).unwrap();
        assert!(matches!(StorageApi::open(policy), Err(StorageError::Sandbox(_))));
    }

    #[test]
    fn write_read_round_trip() {
        let storage = open_test_policy("org.nova.day20test.roundtrip");
        storage.write("greeting.txt", b"hello").unwrap();
        assert_eq!(storage.read("greeting.txt").unwrap(), b"hello");
        let _ = storage.delete("greeting.txt");
    }

    #[test]
    fn delete_then_read_is_not_found() {
        let storage = open_test_policy("org.nova.day20test.deletecheck");
        storage.write("scratch.txt", b"temp").unwrap();
        storage.delete("scratch.txt").unwrap();
        assert!(matches!(storage.read("scratch.txt"), Err(StorageError::NotFound(_))));
    }

    #[test]
    fn deleting_a_missing_key_is_not_found_not_a_panic() {
        let storage = open_test_policy("org.nova.day20test.deletemissing");
        assert!(matches!(storage.delete("never-existed.txt"), Err(StorageError::NotFound(_))));
    }

    #[test]
    fn list_reflects_written_keys() {
        let storage = open_test_policy("org.nova.day20test.listing");
        storage.write("a.txt", b"1").unwrap();
        storage.write("b.txt", b"2").unwrap();
        let names = storage.list("").unwrap();
        assert!(names.contains(&"a.txt".to_string()));
        assert!(names.contains(&"b.txt".to_string()));
        let _ = storage.delete("a.txt");
        let _ = storage.delete("b.txt");
    }

    /// The actual DoD proof: traversal out of this app's own root is
    /// rejected by the same `scoped_path` call every other operation
    /// here goes through -- not a special case, just the normal path.
    #[test]
    fn traversal_outside_the_sandbox_is_rejected_on_every_operation() {
        let storage = open_test_policy("org.nova.day20test.traversal");
        assert!(matches!(storage.write("../org.nova.other/pwned.txt", b"nope"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.read("../org.nova.other/secret.txt"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.delete("../org.nova.other/secret.txt"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.list("../org.nova.other"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.write("/etc/passwd", b"nope"), Err(StorageError::Sandbox(_))));
    }

    /// Two different app ids resolve to two different, non-overlapping
    /// roots -- real isolation between two apps that each behave
    /// (neither tries to construct a policy for the other's id).
    #[test]
    fn two_different_app_ids_never_see_each_others_writes() {
        let a = open_test_policy("org.nova.day20test.isoA");
        let b = open_test_policy("org.nova.day20test.isoB");
        a.write("shared-key-name.txt", b"from A").unwrap();
        b.write("shared-key-name.txt", b"from B").unwrap();
        assert_eq!(a.read("shared-key-name.txt").unwrap(), b"from A");
        assert_eq!(b.read("shared-key-name.txt").unwrap(), b"from B");
        let _ = a.delete("shared-key-name.txt");
        let _ = b.delete("shared-key-name.txt");
    }
}
