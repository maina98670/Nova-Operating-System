#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 20: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 20: Storage API + Networking API unit tests ==="
cargo test -p nova-storage-api -p nova-network-api

echo
echo "=== Nova OS Day 20: live acceptance ==="
echo "Installs and launches nova-storagetest through App Manager, then verifies its"
echo "Storage API operations on the real filesystem under /var/lib/nova/apps/."
echo "Needs the same root-capable Linux environment as the Day 11-19 live tests"
echo "(/apps, /run/nova, /var/log/nova, /var/lib/nova/apps)."
cargo run -p nova-day20-storage-network-acceptance-test

echo
echo "Day 20 build + tests + live acceptance completed."
