//! Nova OS Day 20 live acceptance.
//!
//! DoD: "A test app can read/write its own scoped storage but is
//! blocked from another app's data (proving M5's sandboxing is
//! actually wired to the SDK, not bypassed); the Networking API
//! returns an honest 'not implemented' rather than crashing."
//!
//! `nova-storage-api`'s and `nova-network-api`'s own unit tests
//! already prove the API surface in isolation. This tool proves it
//! live, and — unlike Day 19's process-alive proxy — can check most
//! of it **externally**, by reading the real filesystem, because
//! Storage API's whole point is writing to a real, checkable
//! location: `/var/lib/nova/apps/org.nova.storagetest/` (distinct
//! from `nova_fsmgr::paths::APPS` = `/apps`, which is only the
//! manifest+binary install location — see `nova-storage-api`'s module
//! docs for that distinction).

use nova_app_manager::AppManager;
use nova_ipc::{Permission, SOCKET_PATH};
use nova_procmgr::ProcessState;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const APP_ID: &str = "org.nova.storagetest";
const BIN_NAME: &str = "nova-storagetest";
const MANIFEST: &str = include_str!("../../../apps/org.nova.storagetest/nova-app.toml");
const REQUIRED: &[Permission] = &[Permission::Storage];

/// `SandboxPolicy::app_data_root` (Day 15): `/var/lib/nova/apps/<id>`.
/// Hardcoded here rather than importing `nova-sandbox` for one
/// constant, matching the same "don't overlink for one value" call
/// Day 18's `nova-cli` made for `nova_fsmgr::paths::APPS`.
const APP_DATA_ROOT: &str = "/var/lib/nova/apps";

fn app_install_dir() -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(APP_ID)
}

fn app_data_dir(id: &str) -> PathBuf {
    Path::new(APP_DATA_ROOT).join(id)
}

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn main() {
    println!("=== Nova OS Day 20: Storage API + Networking API acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));
    fs::create_dir_all(APP_DATA_ROOT).unwrap_or_else(|e| fail(format!("mkdir {APP_DATA_ROOT}: {e}")));

    // Clean slate: remove any leftover data from a previous run so
    // "greeting.txt exists" below is evidence of *this* run, not a
    // stale file.
    let _ = fs::remove_dir_all(app_data_dir(APP_ID));
    let _ = fs::remove_dir_all(app_data_dir("org.nova.contacts"));

    let manager = AppManager::new();
    let _server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("serve: {e}")));

    let dir = app_install_dir();
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), MANIFEST).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(BIN_NAME);
    if !bin_src.exists() {
        fail(format!(
            "expected sibling binary {} (run `cargo build --workspace` first, per the Day 20 build script)",
            bin_src.display()
        ));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(BIN_NAME);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(APP_ID).unwrap_or_else(|e| fail(format!("install (manifest validation): {e}")));
    println!("installed and validated");

    let pid = manager.launch(APP_ID).unwrap_or_else(|e| fail(format!("launch: {e}")));
    println!("launched, pid={pid}");

    let deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(APP_ID).is_none() {
        if Instant::now() >= deadline {
            fail("did not complete the Hello/HelloAck handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    let cold_start = manager.cold_start_ms(APP_ID).unwrap();
    println!("IPC handshake complete, cold-start = {cold_start}ms");

    let granted = manager.granted_permissions(APP_ID).unwrap_or(0);
    let required_bits: u32 = REQUIRED.iter().fold(0, |acc, p| acc | p.bit());
    if granted & required_bits != required_bits {
        fail(format!("required permission(s) not granted: required=0b{required_bits:b} granted=0b{granted:b}"));
    }

    // Give every Storage/Network API step inside nova-storagetest time
    // to run -- disk I/O this time, so a bit more generous than
    // Day 19's in-memory-only wait.
    thread::sleep(Duration::from_millis(500));

    let process = manager
        .process_list()
        .into_iter()
        .find(|p| p.pid == pid)
        .unwrap_or_else(|| fail("pid missing from M4 Process Manager's process_list() entirely"));
    match process.state {
        ProcessState::Running | ProcessState::Sleeping => {
            println!("nova-storagetest is still {:?} -- didn't hit its own early-exit path", process.state);
        }
        other => fail(format!(
            "nova-storagetest exited early (state={other:?}, exit_code={:?}) -- see its own stderr for which step failed \
             (exit 3 = own-storage op failed, 4 = SECURITY REGRESSION, 5 = HONESTY REGRESSION on networking)",
            process.exit_code
        )),
    }

    // --- External, filesystem-level verification (not the app's word for it) ---
    let own_greeting = app_data_dir(APP_ID).join("greeting.txt");
    match fs::read(&own_greeting) {
        Ok(bytes) if bytes == b"hello from org.nova.storagetest" => {
            println!("VERIFIED: {} exists with the expected content", own_greeting.display());
        }
        Ok(_) => fail(format!("{} exists but has unexpected content", own_greeting.display())),
        Err(e) => fail(format!("{} missing or unreadable: {e} -- own-storage write did not actually happen", own_greeting.display())),
    }

    let own_scratch = app_data_dir(APP_ID).join("scratch.txt");
    if own_scratch.exists() {
        fail(format!("{} still exists -- delete() did not actually happen on disk", own_scratch.display()));
    }
    println!("VERIFIED: {} does not exist -- delete() actually removed it", own_scratch.display());

    let pwned = app_data_dir("org.nova.contacts").join("pwned.txt");
    if pwned.exists() {
        fail(format!(
            "SECURITY REGRESSION: {} exists -- nova-storagetest's traversal attempt actually wrote outside its own sandbox",
            pwned.display()
        ));
    }
    println!("VERIFIED: {} does not exist -- traversal never reached another app's storage root", pwned.display());

    if Path::new("/etc/nova-pwned").exists() {
        fail("SECURITY REGRESSION: /etc/nova-pwned exists -- an absolute-path write escaped the sandbox entirely");
    }
    println!("VERIFIED: /etc/nova-pwned does not exist -- absolute-path write was blocked");

    manager.terminate(APP_ID).unwrap_or_else(|e| fail(format!("terminate: {e}")));
    thread::sleep(Duration::from_millis(150));
    if manager.pid_of(APP_ID).is_some() {
        fail("still tracked as running after terminate()");
    }
    println!("terminated cleanly");

    // Cleanup
    let _ = fs::remove_dir_all(app_install_dir());
    let _ = fs::remove_dir_all(app_data_dir(APP_ID));
    let _ = fs::remove_file(SOCKET_PATH);

    println!();
    println!("=== Day 20 ACCEPTANCE: PASS ===");
    println!("nova-storagetest installed, launched, completed the IPC handshake, and its Storage");
    println!("API operations were verified on the real filesystem -- own read/write/delete really");
    println!("happened, and its traversal/absolute-path escape attempts really didn't reach");
    println!("anywhere outside its own sandbox root. The Networking API stub never returned Ok");
    println!("(confirmed by nova-storagetest's own exit code, not re-checked externally here).");
}
