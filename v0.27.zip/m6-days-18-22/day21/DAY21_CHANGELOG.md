# Day 21 Change Log

Base: `nova-day20-package.zip`

1. Extended `libs/nova-ipc`: `Message::NotificationPost { title, body }`
   (0x0D) / `Message::NotificationPosted { id }` (0x0E). Additive —
   `PROTOCOL_VERSION` stays 1. Added to the existing exhaustive
   roundtrip test.
2. Extended `libs/nova-app-manager`: `Notification` struct,
   `Inner::notifications`/`next_notification_id`, the
   `NotificationPost` handling arm in `handle_connection`,
   `AppManager::notifications()`/`notifications_for()`.
3. Added `libs/nova-notification-api` — `post()`, wrapping the new
   message pair. Real and working today, not a stub.
4. Added `libs/nova-lifecycle-api` — `LifecycleHandler` +
   `run_until_terminate`, the app-side reaction layer over
   `nova-app-manager`'s already-real (Day 13)
   `foreground()`/`background()`/`terminate()` pushes. New, opt-in
   loop; `nova_app_runtime::idle_until_terminate` and every app using
   it (Days 16-20) unchanged.
5. Added `libs/nova-permission-api` — `request()`, the same
   PermissionRequest/Response exchange `connect_and_handshake` already
   sends at handshake time, now callable standalone at any later
   point.
6. Added `apps/org.nova.lifecycletest` — DoD test app: notification
   post, runtime permission request (deliberately not during
   handshake), lifecycle callbacks writing marker files.
7. Added `tools/nova-day21-notification-lifecycle-acceptance-test` —
   installs/launches, then verifies notification + permission grant
   via `AppManager`'s own live state, and both lifecycle callbacks via
   real marker files on disk after calling `background()`/
   `foreground()` itself.
8. Added `docs/nova-notification-lifecycle-permission-api-v1.md`;
   appended a Day 21 addendum to `libs/nova-ipc/protocols/nova-ipc-v1.md`.
9. Updated the workspace `Cargo.toml` with three new libs, one new
   app, and one new tool.

Day 22 (full SDK toolchain -- `nova package`/`install`/`run`, M6
acceptance, tag) is next.
