# Nova OS — Day 21 Package: Notifications + Lifecycle Callbacks + Runtime Permission API

This package continues directly from the Day 20 package (M6).
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day21-build_and_run.sh` yourself to actually confirm it.

## Day 21 goal

Per the Complete Build Guide:
1. Notifications API (even a minimal local-only version — no push
   infrastructure needed yet).
2. Lifecycle callbacks (on-foreground/on-background/on-terminate)
   wired to M5's Application lifecycle work.
3. Permission-request APIs so an app can ask for a permission at
   runtime, not just declare it statically in the manifest.

DoD: a test app posts a local notification, correctly receives a
lifecycle callback when backgrounded, and successfully requests a
runtime permission that then shows up as granted in M5's enforcement
layer.

## Honest starting point — the good kind, this time

Unlike most prior days, the hard infrastructure for #2 **already
existed**: `nova-app-manager`'s `foreground()`/`background()`/
`terminate()` have pushed genuine `Lifecycle` IPC events since Day 13,
cross-checked against M4's Process Manager. Day 21's actual new work
for lifecycle callbacks is the **app-side reaction layer**
(`nova-lifecycle-api`) — see `docs/nova-notification-lifecycle-permission-api-v1.md`.

## What's new

- **`libs/nova-ipc`** — extended, additively (`PROTOCOL_VERSION`
  unchanged): `NotificationPost`/`NotificationPosted` message types.
  Roundtrip-tested alongside every other message type.
- **`libs/nova-app-manager`** — `Notification` struct,
  `notifications()`/`notifications_for()`, and the `NotificationPost`
  handling arm in `handle_connection`. Local-only, in-memory, cleared
  on restart.
- **`libs/nova-notification-api`** — `post(conn, title, body) -> Result<u32, _>`.
  Actually works today — no "not yet available" caveat needed, unlike
  Day 19/20's Input/Networking stubs.
- **`libs/nova-lifecycle-api`** — `LifecycleHandler` (builder:
  `on_foreground`/`on_background`/`on_suspend`/`on_terminate`) +
  `run_until_terminate`, a new opt-in loop alongside
  `nova_app_runtime::idle_until_terminate` (existing apps unaffected).
- **`libs/nova-permission-api`** — `request(conn, permission) -> Result<bool, _>`,
  usable at any point in an app's life, not just baked into the
  initial handshake.
- **`apps/org.nova.lifecycletest`** — the DoD's test app: posts a
  notification, requests `Permission::Network` at runtime
  (deliberately *not* during handshake, to prove this specific API),
  and registers callbacks that each write a distinct marker file to
  its own scoped storage.
- **`tools/nova-day21-notification-lifecycle-acceptance-test`** —
  installs/launches, then verifies **externally**: the notification
  via `AppManager::notifications_for()`, the runtime permission grant
  via `AppManager::granted_permissions()`, and both `on_background`/
  `on_foreground` firing by reading the real marker files on disk
  after calling `AppManager::background()`/`foreground()` itself.
- **`docs/nova-notification-lifecycle-permission-api-v1.md`** — API
  reference + what Day 21 doesn't cover.

## Run

```bash
./nova-day21-build_and_run.sh
```

Builds the workspace, runs `nova-ipc`'s protocol tests (covering the
new message types), then the live acceptance test. Needs the same
root-capable Linux environment as the Days 11–20 live tests.

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction.
