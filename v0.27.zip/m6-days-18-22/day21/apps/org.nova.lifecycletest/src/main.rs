//! nova-lifecycletest — Day 21's "test app" from the DoD.
//!
//! Launches through App Manager (Hello/HelloAck), then:
//! 1. Posts a local notification via `nova-notification-api`.
//! 2. Requests `Permission::Network` at runtime via
//!    `nova-permission-api` — deliberately *not* requested during the
//!    initial handshake (see `nova-app.toml`'s own comment), to prove
//!    this is the standalone Day 21 API working, not a re-test of the
//!    handshake-time auto-request Days 16-19 already cover.
//! 3. Registers `nova-lifecycle-api` callbacks for foreground/
//!    background/terminate, each of which writes a distinct marker
//!    file to this app's own scoped storage — real, externally
//!    verifiable evidence (via
//!    `tools/nova-day21-notification-lifecycle-acceptance-test`
//!    reading the filesystem, the same pattern Day 20 established)
//!    that a callback actually ran, not just that this app claims it
//!    did over stdout.
//! 4. Runs `nova_lifecycle_api::run_until_terminate` instead of
//!    `nova_app_runtime::idle_until_terminate` — the new, opt-in loop.

use nova_ipc::Permission;
use nova_lifecycle_api::{run_until_terminate, LifecycleHandler};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_storage_api::StorageApi;
use std::process;
use std::rc::Rc;

const APP_ID: &str = "org.nova.lifecycletest";

fn main() {
    // Deliberately empty: Network is requested later, at runtime, via
    // nova-permission-api -- not auto-requested here.
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, &[]) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck complete");

    let policy = SandboxPolicy::new(APP_ID, PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty())
        .expect("APP_ID is a valid app id");
    let storage = match StorageApi::open(policy) {
        Ok(s) => Rc::new(s),
        Err(e) => {
            eprintln!("[{APP_ID}] StorageApi::open failed: {e}");
            process::exit(1);
        }
    };

    // --- 1. Notifications API ---
    match nova_notification_api::post(&conn, "Day 21", "Local notification test") {
        Ok(id) => println!("[{APP_ID}] posted notification, id={id}"),
        Err(e) => {
            eprintln!("[{APP_ID}] notification post failed: {e}");
            process::exit(3);
        }
    }

    // --- 2. Runtime Permission API ---
    match nova_permission_api::request(&conn, Permission::Network) {
        Ok(true) => println!("[{APP_ID}] runtime request for 'network' granted"),
        Ok(false) => {
            eprintln!("[{APP_ID}] runtime request for 'network' was denied -- expected granted (it's declared optional)");
            process::exit(3);
        }
        Err(e) => {
            eprintln!("[{APP_ID}] runtime permission request failed: {e}");
            process::exit(3);
        }
    }

    // --- 3. Lifecycle callbacks, each writing an externally-checkable marker ---
    let fg_storage = storage.clone();
    let bg_storage = storage.clone();
    let term_storage = storage.clone();

    let handler = LifecycleHandler::new()
        .on_foreground(move || {
            println!("[{APP_ID}] on_foreground fired");
            if let Err(e) = fg_storage.write("foregrounded.marker", b"foreground event received") {
                eprintln!("[{APP_ID}] failed to write foregrounded.marker: {e}");
            }
        })
        .on_background(move || {
            println!("[{APP_ID}] on_background fired");
            if let Err(e) = bg_storage.write("backgrounded.marker", b"background event received") {
                eprintln!("[{APP_ID}] failed to write backgrounded.marker: {e}");
            }
        })
        .on_terminate(move || {
            println!("[{APP_ID}] on_terminate fired");
            let _ = term_storage.write("terminated.marker", b"terminate event received");
        });

    println!("[{APP_ID}] Day 21 setup complete -- entering lifecycle loop");
    // --- 4. New opt-in loop, not nova_app_runtime::idle_until_terminate ---
    run_until_terminate(APP_ID, &conn, handler);
}
