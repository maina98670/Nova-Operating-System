# Nova SDK — Notifications, Lifecycle Callbacks & Runtime Permission API, v1 (Day 21)

Per Day 21's task list: a minimal local-only Notifications API, app-side
lifecycle callbacks wired to M5's already-real Application lifecycle
work, and a permission-request API usable at runtime, not just during
initial handshake or manifest declaration.

## Notifications API (`nova-notification-api`)

```rust
let id = nova_notification_api::post(&conn, "Title", "Body")?;
```

Unlike Day 19/20's Input/Networking stubs, this one **actually works**
today — no "honestly not yet available" caveat needed:

- Extends the wire protocol (additive, `PROTOCOL_VERSION` unchanged —
  see `nova-ipc-v1.md`'s own Day 21 addendum): `NotificationPost` /
  `NotificationPosted`.
- `nova-app-manager` holds every posted notification in memory for the
  life of that run (`AppManager::notifications()`/`notifications_for()`,
  new in this delivery) — local-only, no persistence across restarts,
  no cross-device push, no compositor-rendered visual banner (that's
  still M7's job for the banner). "Local-only... no push infrastructure
  needed yet" is exactly this: real bookkeeping, no delivery mechanism
  beyond in-process memory.
- `id`/timestamp are assigned server-side on receipt, not trusted from
  the app — the same pattern `ColdStartReport` already established.

## Lifecycle callback API (`nova-lifecycle-api`)

```rust
let handler = LifecycleHandler::new()
    .on_foreground(|| { /* ... */ })
    .on_background(|| { /* ... */ })
    .on_terminate(|| { /* ... */ });
nova_lifecycle_api::run_until_terminate(app_id, &conn, handler);
```

**The hard part already existed.** `nova-app-manager`'s
`foreground()`/`background()`/`terminate()` have pushed genuine
`Lifecycle` IPC events since Day 13, cross-checked against M4's Process
Manager before acting. What Day 21 adds is purely the **app-side**
reaction layer: previously, `nova_app_runtime::idle_until_terminate`
just printed `Lifecycle::{event:?}` and moved on. `LifecycleHandler` +
`run_until_terminate` let an app actually *do* something per event
kind. Existing apps (Days 16–20) are unaffected — this is a new,
opt-in loop alongside `idle_until_terminate`, not a replacement for it.

## Runtime Permission API (`nova-permission-api`)

```rust
let granted = nova_permission_api::request(&conn, Permission::Camera)?;
```

`PermissionRequest`/`PermissionResponse` have existed since Day 11 and
been genuinely enforced since Day 15. `nova_app_runtime::connect_and_handshake`
already sends one of these per declared-optional permission, but only
ever at handshake time. This crate is the same exchange, exposed as its
own callable at any later point in an app's life — the literal task:
"so an app can ask for a permission at runtime, not just declare it
statically in the manifest." `Ok(false)` is a normal, honestly-reported
denial, not an error — App Manager's Day 15 enforcement (declared-
optional-only) is what actually decides; this function just relays it.

## What an app built against these looks like

`apps/org.nova.lifecycletest` — the DoD's "test app": posts a
notification, requests `Permission::Network` at runtime (deliberately
*not* pre-requested during handshake, to prove this specific API
rather than re-testing Days 16–19's handshake-time behavior), then
registers callbacks that each write a distinct marker file to its own
scoped storage (`nova-storage-api`, Day 20) — so
`tools/nova-day21-notification-lifecycle-acceptance-test` can verify a
callback actually ran by reading the real filesystem, the same
external-verification standard Day 20 established, rather than by
trusting stdout.

## What Day 21 doesn't cover (named, not hidden)

- **No visual notification banner.** Posting is real; a compositor
  rendering it as a banner is M7's job, same dependency every UI-facing
  API in this repo has on M7 existing at all.
- **No notification persistence, dismissal, or read/unread state.**
  App Manager's list only grows for the life of one run; there's no
  `NotificationDismiss` message or similar yet.
- **`LifecycleHandler` callbacks are `FnMut`, not `Send`.** Fine for
  the single-threaded blocking loop every app here already uses; would
  need rework if an app ever wanted to dispatch from a different
  thread than the one reading the connection.
- **No callback for a permission being revoked later.** `nova-permission-api::request`
  is one-shot; nothing pushes an app a notice if App Manager's grant
  for it ever changes after the fact (no such revocation mechanism
  exists yet either).
