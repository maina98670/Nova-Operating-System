//! Nova App Manager — M5 Days 13-15.
//!
//! Per the Complete Build Guide's Day 13 row: rebuild App Manager's
//! lifecycle handling (launch/foreground/background/terminate) on top
//! of M4's Process Manager (`nova-procmgr`) and Service Manager
//! (`nova-svcmgr`), instead of raw `fork`/`exec` — this is the actual
//! integration point the Roadmap's M5 phase exists for.
//!
//! Day 14 adds the `nova-app.toml` manifest schema (see the
//! `manifest` module and `docs/nova-app-toml-v1.md`) and wires it
//! into `install`/`launch` below, replacing Day 13's `AppDef`-only,
//! manually-registered stand-in with real manifest loading — through
//! M4's Configuration subsystem's validation path, per the Day 14
//! DoD, not a second parser.
//!
//! ## What "on top of" means concretely here
//! - **Launch** does not call `Command::spawn` itself. It registers
//!   the app as a `nova_svcmgr::ServiceDef` and calls
//!   `ServiceManager::start`, which spawns through the one
//!   `ProcessManager` instance `ServiceManager` already owns. There is
//!   exactly one process-spawning code path in this crate.
//! - **Terminate** calls `ServiceManager::stop`, which calls
//!   `ProcessManager::terminate` (graceful SIGTERM, escalating to
//!   SIGKILL) — not a raw `kill()` from this crate.
//! - **Foreground/Background** are concepts `ProcessManager` and
//!   `ServiceManager` deliberately don't know about (a backgrounded
//!   app is still a *running* Linux process, not a different process
//!   state) — App Manager tracks that layer itself, in `AppRuntime`,
//!   and pushes a `Lifecycle` IPC event to the app's own connection.
//!   What *is* delegated: whether the process backing an app is still
//!   alive at all is always answered by asking `ProcessManager`
//!   (transitively through `ServiceManager::process_list`/
//!   `process_info`), never guessed from App Manager's own state.
//! - **Cold-start reporting** is computed from
//!   `ServiceManager::process_uptime` (which reads
//!   `ProcessManager`'s own spawn timestamp) the moment `Hello`
//!   arrives — not from the app's self-reported `ColdStartReport`
//!   payload. That message still exists on the wire (an app may still
//!   send it) but this crate treats it as informational only; the
//!   authoritative number is the one this crate measured itself.
//!
//! ## What Day 14 adds on top of that
//! - **`install(app_id)`**: reads `<APPS>/<app_id>/nova-app.toml`
//!   (`nova_fsmgr::paths::APPS`, Section 11's package-bundle
//!   location) through `manifest::load_manifest` — Day 8's
//!   `nova_config::load` plus the permission-name check — and, only
//!   if that succeeds, converts the manifest into an `AppDef` and
//!   calls `register_app`. A manifest with a missing required field
//!   or an unknown permission name is rejected here with a clear
//!   error, never partially registered.
//! - **`launch(app_id)`** now calls `install` itself first when
//!   `app_id` isn't already registered, instead of immediately
//!   failing `UnknownApp` the way Day 13's version did. This is the
//!   literal Day 14 DoD wording — "rejected... at install/launch
//!   time, using the *same* validation path" — satisfied by having
//!   exactly one code path (`install`) that both call sites share,
//!   not two separate checks that could drift apart.
//! - **`register_app`** (Day 13's direct, manifest-free path) is kept
//!   unchanged, for tests and tools that still want to hand-build an
//!   `AppDef` without a manifest file on disk.
//!
//! ## What's still deliberately out of scope for Day 14
//! - **Sandbox enforcement.** A manifest's declared permissions are
//!   validated (real names, from the fixed set) but not yet enforced
//!   — a process without `camera` can still open camera devices today.
//!   Turning declared permissions into actual enforcement, using M4's
//!   Process/Memory Manager isolation primitives, is Day 15's job.
//! - **Migrating the five real apps.** Settings/Contacts/Messages/
//!   Dialer/Camera still don't have `nova-app.toml` bundles under
//!   `<APPS>/` produced by this delivery — that reconciliation is
//!   Day 16's.

use nova_ipc::{discover as ipc_discover, LifecycleEvent, Message, Permission, SeqPacketSocket};
use nova_sandbox::{PermissionSet, SandboxError, SandboxPolicy};
pub use nova_ipc::AppListEntry;
pub use nova_procmgr::ProcessInfo;
pub use nova_svcmgr::ServiceStatus;
use nova_svcmgr::{ServiceDef, ServiceManager};

use std::collections::HashMap;
use std::fmt;
use std::io;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

pub mod manifest;
pub use manifest::{AppManifest, ManifestError};

/// A launchable app, as far as `ServiceManager`/`ProcessManager` need
/// to know to actually spawn it: an id, a display name, and a
/// command/args pair. Day 13 introduced this as a manifest stand-in;
/// Day 14's `app_def_from_manifest` now builds it from a real,
/// validated `AppManifest` instead — this struct itself is unchanged,
/// since the launch machinery still only needs these four fields.
#[derive(Debug, Clone)]
pub struct AppDef {
    pub id: String,
    pub name: String,
    pub command: String,
    pub args: Vec<String>,
    /// Permissions declared by the manifest and enforced at runtime.
    pub required_permissions: PermissionSet,
    pub optional_permissions: PermissionSet,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AppLifecycleState {
    Foreground,
    Background,
}

/// Day 21: a local-only posted notification. `id` and `posted_at_ms`
/// are assigned server-side, on receipt -- an app's own claims about
/// itself are informational, never authoritative, the same trust
/// boundary `cold_start_ms` already established for `ColdStartReport`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Notification {
    pub id: u32,
    pub app_id: String,
    pub title: String,
    pub body: String,
    pub posted_at_ms: u64,
}

#[derive(Debug, Clone)]
struct AppRuntime {
    pid: u32,
    state: AppLifecycleState,
    /// Sourced from `ServiceManager::process_uptime` at the moment
    /// `Hello` was received — see module docs. `None` until the app
    /// has actually connected and said `Hello` (launching a process
    /// and it completing its IPC handshake are two different events).
    cold_start_ms: Option<u32>,
    sandbox: SandboxPolicy,
}

#[derive(Debug)]
pub enum AppManagerError {
    UnknownApp(String),
    NotRunning(String),
    Service(nova_svcmgr::ServiceError),
    /// A manifest failed to load or validate — Day 14's addition.
    /// Carries the underlying `ManifestError` (missing required
    /// field / malformed TOML, or an unknown permission name)
    /// unchanged, so the caller sees the same clear error
    /// `manifest::load_manifest` produced, not a re-summarized one.
    Manifest(ManifestError),
    Sandbox(SandboxError),
}

impl fmt::Display for AppManagerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            AppManagerError::UnknownApp(id) => write!(f, "unknown app: {id}"),
            AppManagerError::NotRunning(id) => write!(f, "app not running: {id}"),
            AppManagerError::Service(e) => write!(f, "service manager error: {e}"),
            AppManagerError::Manifest(e) => write!(f, "manifest error: {e}"),
            AppManagerError::Sandbox(e) => write!(f, "sandbox error: {e}"),
        }
    }
}
impl std::error::Error for AppManagerError {}

impl From<SandboxError> for AppManagerError {
    fn from(e: SandboxError) -> Self { AppManagerError::Sandbox(e) }
}

impl From<ManifestError> for AppManagerError {
    fn from(e: ManifestError) -> Self {
        AppManagerError::Manifest(e)
    }
}

struct Inner {
    svcmgr: ServiceManager,
    registry: HashMap<String, AppDef>,
    runtime: HashMap<String, AppRuntime>,
    /// One connection per app that has completed the `Hello` IPC
    /// handshake. `Arc` (not a bare `SeqPacketSocket`) because
    /// `send`/`recv` both take `&self` — the accept-loop's reader
    /// thread and whatever thread calls `foreground`/`background`
    /// need to use the *same* live connection concurrently, and this
    /// is the one true handle to it rather than a second parallel one.
    connections: HashMap<String, Arc<SeqPacketSocket>>,
    /// Day 21: every notification posted by any app, in post order.
    /// Local-only, in-memory, cleared on restart -- no push
    /// infrastructure, no persistence, per the Day 20 task list's own
    /// scope for this. `notifications()`/`notifications_for()` below
    /// are the read side; the write side is the `NotificationPost`
    /// arm in `handle_connection`.
    notifications: Vec<Notification>,
    next_notification_id: u32,
}

/// The App Manager itself. Cheap to clone (an `Arc` internally) — the
/// accept-loop thread and the caller of `launch`/`foreground`/
/// `background`/`terminate` share the same locked state, which is
/// exactly what lets a `Hello` handshake arriving on its own thread
/// update the same `AppRuntime` a concurrent `launch()` call just
/// created.
#[derive(Clone)]
pub struct AppManager {
    inner: Arc<Mutex<Inner>>,
}

impl Default for AppManager {
    fn default() -> Self {
        Self::new()
    }
}

impl AppManager {
    pub fn new() -> Self {
        AppManager {
            inner: Arc::new(Mutex::new(Inner {
                svcmgr: ServiceManager::new(),
                registry: HashMap::new(),
                runtime: HashMap::new(),
                connections: HashMap::new(),
                notifications: Vec::new(),
                next_notification_id: 1,
            })),
        }
    }

    /// Registers an app directly from an already-built `AppDef`,
    /// bypassing manifest loading entirely. Kept from Day 13 for
    /// tests/tools that want to hand-construct an app without a
    /// `nova-app.toml` on disk — `install` below is the manifest-
    /// backed path real apps should use.
    pub fn register_app(&self, def: AppDef) {
        let mut inner = self.inner.lock().unwrap();
        inner.registry.insert(def.id.clone(), def);
    }

    /// Day 14's manifest-backed registration path: loads and
    /// validates `<APPS>/<app_id>/nova-app.toml` through
    /// `manifest::load_manifest` (Day 8's `nova_config::load`, plus
    /// the permission-name check), and only registers the app if
    /// that succeeds. This is the "install time" half of the Day 14
    /// DoD; `launch` below calls this same function for the "launch
    /// time" half, rather than a second, separate check.
    pub fn install(&self, app_id: &str) -> Result<(), AppManagerError> {
        let path = manifest_path_for(app_id);
        let manifest = manifest::load_manifest(&path)?;
        self.register_app(app_def_from_manifest(&manifest));
        Ok(())
    }

    /// Loads `<APPS>/<app_id>/nova-app.toml` and validates it (same
    /// path as `install`), without registering it — useful for a
    /// caller that wants to inspect a manifest (e.g. its declared
    /// permissions) before deciding whether to install it at all.
    pub fn inspect_manifest(app_id: &str) -> Result<AppManifest, ManifestError> {
        manifest::load_manifest(&manifest_path_for(app_id))
    }

    pub fn list_apps(&self) -> Vec<AppListEntry> {
        let inner = self.inner.lock().unwrap();
        let mut apps: Vec<AppListEntry> =
            inner.registry.values().map(|d| AppListEntry { id: d.id.clone(), name: d.name.clone() }).collect();
        apps.sort_by(|a, b| a.id.cmp(&b.id));
        apps
    }

    /// Launches `app_id`: registers it with `ServiceManager` (idempotent
    /// — safe to call every launch) and starts it, which spawns through
    /// `ServiceManager`'s single `ProcessManager`. Returns the real PID,
    /// exactly as `ProcessManager::spawn` reported it — never a value
    /// this crate invented. Newly launched apps start `Foreground`
    /// (the shell just launched them; nothing launches straight to
    /// background).
    pub fn launch(&self, app_id: &str) -> Result<u32, AppManagerError> {
        // Day 14: an app that hasn't been registered yet (directly via
        // register_app, or by a prior install() call) gets one chance
        // to install itself from its manifest here, through the exact
        // same install() -> load_manifest() path -- not a second,
        // looser check. Only attempted when a manifest actually exists
        // on disk: an app_id with no manifest at all and no prior
        // registration is still the plain "doesn't exist" case
        // (UnknownApp), same as Day 13 -- it's a manifest *present but
        // invalid* that should surface as the Day 14 Manifest error.
        let already_registered = self.inner.lock().unwrap().registry.contains_key(app_id);
        if !already_registered && manifest_path_for(app_id).exists() {
            self.install(app_id)?;
        }

        let mut inner = self.inner.lock().unwrap();
        let def = inner.registry.get(app_id).cloned().ok_or_else(|| AppManagerError::UnknownApp(app_id.to_string()))?;

        inner.svcmgr.register(ServiceDef {
            name: def.id.clone(),
            command: def.command.clone(),
            args: def.args.clone(),
            // User-launched apps are not auto-restarted on exit —
            // that behavior belongs to system *services* (Day 6's
            // scope), not something a user closed on purpose. This is
            // a Day 13 design decision, noted rather than left
            // implicit.
            restart_policy: nova_procmgr::RestartPolicy::Never,
            depends_on: Vec::new(),
            max_restarts: 0,
        });

        let pid = inner.svcmgr.start(app_id).map_err(AppManagerError::Service)?;
        let sandbox = SandboxPolicy::new(
            def.id.clone(),
            def.required_permissions,
            def.optional_permissions,
        )?;
        inner.runtime.insert(app_id.to_string(), AppRuntime {
            pid,
            state: AppLifecycleState::Foreground,
            cold_start_ms: None,
            sandbox,
        });
        Ok(pid)
    }

    /// Pushes a `Lifecycle::Foreground` event (if the app has an open
    /// IPC connection) and records the state change. Does **not**
    /// touch the process itself — foregrounding is not a process-manager
    /// operation, it's purely App Manager's own layer, which is exactly
    /// why the DoD requires cross-checking it doesn't silently start
    /// reporting a state Process Manager would disagree with.
    pub fn foreground(&self, app_id: &str) -> Result<(), AppManagerError> {
        self.set_lifecycle(app_id, AppLifecycleState::Foreground, LifecycleEvent::Foreground)
    }

    pub fn background(&self, app_id: &str) -> Result<(), AppManagerError> {
        self.set_lifecycle(app_id, AppLifecycleState::Background, LifecycleEvent::Background)
    }

    fn set_lifecycle(&self, app_id: &str, state: AppLifecycleState, event: LifecycleEvent) -> Result<(), AppManagerError> {
        let mut inner = self.inner.lock().unwrap();
        if !inner.runtime.contains_key(app_id) {
            return Err(AppManagerError::NotRunning(app_id.to_string()));
        }
        // The process itself must still actually be alive per
        // ProcessManager -- foregrounding/backgrounding a pid Process
        // Manager already considers gone would be exactly the kind of
        // "App Manager's own internal state disagrees with reality"
        // bug the Day 13 DoD is checking for.
        let still_alive = inner
            .svcmgr
            .process_info(app_id)
            .map(|info| !matches!(info.state, nova_procmgr::ProcessState::Terminated | nova_procmgr::ProcessState::Unknown))
            .unwrap_or(false);
        if !still_alive {
            return Err(AppManagerError::NotRunning(app_id.to_string()));
        }
        if let Some(rt) = inner.runtime.get_mut(app_id) {
            rt.state = state;
        }
        if let Some(conn) = inner.connections.get(app_id) {
            // Best-effort: a Lifecycle push failing to send doesn't
            // undo the state change -- Nova's own state must stay the
            // source of truth even if this particular app's socket
            // has gone stale, which the next terminate/relaunch will
            // clean up.
            let _ = conn.send(&Message::Lifecycle { event });
        }
        Ok(())
    }

    /// Sends `Lifecycle::Terminate` (best-effort, so a well-behaved app
    /// gets a chance to see it coming), then stops the app through
    /// `ServiceManager::stop` — which is what actually calls
    /// `ProcessManager::terminate` (graceful SIGTERM, escalating to
    /// SIGKILL). Removes App Manager's own runtime/connection state
    /// only after the real process-level stop succeeds.
    pub fn terminate(&self, app_id: &str) -> Result<(), AppManagerError> {
        let mut inner = self.inner.lock().unwrap();
        if !inner.runtime.contains_key(app_id) {
            return Err(AppManagerError::NotRunning(app_id.to_string()));
        }
        if let Some(conn) = inner.connections.get(app_id) {
            let _ = conn.send(&Message::Lifecycle { event: LifecycleEvent::Terminate });
        }
        inner.svcmgr.stop(app_id).map_err(AppManagerError::Service)?;
        inner.runtime.remove(app_id);
        inner.connections.remove(app_id);
        Ok(())
    }

    /// App Manager's own view of foreground/background. Deliberately
    /// separate from `process_list`/`service_status` below -- the DoD
    /// is specifically about these two views staying consistent with
    /// each other, not about collapsing them into one.
    pub fn lifecycle_state(&self, app_id: &str) -> Option<AppLifecycleState> {
        self.inner.lock().unwrap().runtime.get(app_id).map(|rt| rt.state)
    }

    /// Day 21: every notification posted by any app so far, oldest
    /// first. Local-only and in-memory — see `Notification`'s and
    /// `Inner::notifications`'s own doc comments for why that's the
    /// deliberate scope, not a gap.
    pub fn notifications(&self) -> Vec<Notification> {
        self.inner.lock().unwrap().notifications.clone()
    }

    pub fn notifications_for(&self, app_id: &str) -> Vec<Notification> {
        self.inner.lock().unwrap().notifications.iter().filter(|n| n.app_id == app_id).cloned().collect()
    }

    /// Day 15 resource gate used by HAL/resource brokers before touching
    /// a protected device or service.
    pub fn check_permission(&self, app_id: &str, permission: Permission) -> Result<(), AppManagerError> {
        let inner = self.inner.lock().unwrap();
        let rt = inner.runtime.get(app_id).ok_or_else(|| AppManagerError::NotRunning(app_id.to_string()))?;
        rt.sandbox.check(permission)?;
        Ok(())
    }

    /// Returns the app's currently granted permission bitmask.
    pub fn granted_permissions(&self, app_id: &str) -> Option<u32> {
        self.inner.lock().unwrap().runtime.get(app_id).map(|rt| rt.sandbox.granted().bits())
    }

    pub fn cold_start_ms(&self, app_id: &str) -> Option<u32> {
        self.inner.lock().unwrap().runtime.get(app_id).and_then(|rt| rt.cold_start_ms)
    }

    pub fn pid_of(&self, app_id: &str) -> Option<u32> {
        self.inner.lock().unwrap().runtime.get(app_id).map(|rt| rt.pid)
    }

    /// M4 Process Manager's own process list, exactly as
    /// `ServiceManager::process_list` (Day 13's addition to
    /// `nova-svcmgr`) reports it -- the actual cross-check surface the
    /// DoD asks for.
    pub fn process_list(&self) -> Vec<ProcessInfo> {
        self.inner.lock().unwrap().svcmgr.process_list()
    }

    /// M4 Service Manager's own status for `app_id`, exactly as
    /// `ServiceManager::status` reports it -- the other half of the
    /// DoD's cross-check.
    pub fn service_status(&self, app_id: &str) -> ServiceStatus {
        self.inner.lock().unwrap().svcmgr.status(app_id)
    }

    /// Binds the IPC control socket and starts accepting connections,
    /// one thread per connection (the same pattern Day 11/12's live
    /// tools already used for a single connection, generalized here to
    /// however many apps are actually running). Returns immediately;
    /// the returned handle is the accept-loop thread.
    pub fn serve(&self, socket_path: &str) -> io::Result<thread::JoinHandle<()>> {
        let listener = SeqPacketSocket::listen(socket_path)?;
        let inner = self.inner.clone();
        Ok(thread::spawn(move || loop {
            match listener.accept() {
                Ok(conn) => {
                    let inner = inner.clone();
                    thread::spawn(move || handle_connection(inner, conn));
                }
                Err(_) => break, // listener closed / fatal accept error
            }
        }))
    }

    /// Convenience for a client that wants the App Manager's socket by
    /// name rather than importing `nova_ipc::SOCKET_PATH` directly —
    /// exercises Day 12's `discover` from this crate too.
    pub fn discover_self() -> io::Result<std::path::PathBuf> {
        ipc_discover("app-manager")
    }
}

/// The standard bundle location for `app_id`'s manifest:
/// `<APPS>/<app_id>/nova-app.toml`, per Section 11's package-bundle
/// layout (`nova_fsmgr::paths::APPS`, "installed app bundles") and
/// `docs/nova-app-toml-v1.md`'s documented default. One convention,
/// not each caller picking its own path — same reasoning Day 8 gave
/// `nova_config::config_path_for` for service configs.
fn manifest_path_for(app_id: &str) -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(app_id).join("nova-app.toml")
}

/// Converts a validated `AppManifest` into the `AppDef` Day 13's
/// launch machinery already knows how to run. Permissions are carried
/// on the manifest itself (available via `AppManager::inspect_manifest`
/// for a caller that needs them) rather than duplicated onto `AppDef`
/// — enforcing them is Day 15's job, not this conversion's.
fn app_def_from_manifest(manifest: &AppManifest) -> AppDef {
    AppDef {
        id: manifest.id.clone(),
        name: manifest.name.clone(),
        command: manifest.entry_point.clone(),
        args: manifest.args.clone(),
        required_permissions: PermissionSet::from_permissions(
            manifest.required_permissions.iter().filter_map(|n| Permission::from_name(n))
        ),
        optional_permissions: PermissionSet::from_permissions(
            manifest.optional_permissions.iter().filter_map(|n| Permission::from_name(n))
        ),
    }
}

/// Day 15 security audit trail. Permission denials are persisted through
/// M4's Filesystem Manager logging path rather than being silently dropped.
fn log_security_event(app_id: &str, permission: Permission, reason: &str) -> io::Result<()> {
    let path = Path::new(nova_fsmgr::paths::LOG).join("security.log");
    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::LOG])?;
    let line = format!(
        "app={app_id} event=permission_denied permission={} reason={reason}\n",
        permission.name()
    );
    nova_fsmgr::append_file(&path, line.as_bytes())
}

/// Handles one app's connection for its whole lifetime: the `Hello`
/// handshake (computing cold-start from Process Manager's own
/// timestamp, per module docs), then a read loop for whatever else the
/// app sends, until it disconnects.
fn handle_connection(inner: Arc<Mutex<Inner>>, conn: SeqPacketSocket) {
    let conn = Arc::new(conn);

    let hello = match conn.recv() {
        Ok(m) => m,
        Err(_) => return, // connected and went away before saying anything
    };

    let Message::Hello { app_id, pid: claimed_pid } = hello else {
        // Protocol says Hello must be the first message; anything else
        // here is a misbehaving client. Drop the connection rather
        // than guessing what it meant.
        return;
    };

    // SO_PEERCRED is the real auth mechanism per the protocol spec --
    // the app-supplied pid in Hello is informational/logging only.
    let real_pid = conn.peer_credentials().map(|(_, _, pid)| pid as u32).unwrap_or(claimed_pid);

    let accepted = {
        let mut inner = inner.lock().unwrap();
        // Cold start sourced from Service/Process Manager's own spawn
        // timestamp -- the actual Day 13 requirement -- not from anything
        // the app itself might report. Computed before the mutable borrow
        // below since `inner` is a MutexGuard: Deref/DerefMut don't allow
        // the compiler to split it into disjoint field borrows.
        let elapsed_ms = inner.svcmgr.process_uptime(&app_id).map(|d: Duration| d.as_millis() as u32);
        match inner.runtime.get_mut(&app_id) {
            Some(rt) => {
                rt.cold_start_ms = elapsed_ms;
                rt.pid = real_pid;
                true
            }
            // A connection claiming an app_id App Manager didn't
            // itself launch -- reject rather than silently trusting it.
            None => false,
        }
    };

    let initial_permissions = {
        let inner = inner.lock().unwrap();
        inner.runtime.get(&app_id)
            .map(|rt| rt.sandbox.granted().bits())
            .unwrap_or_else(Permission::implicit_bitmask)
    };
    let _ = conn.send(&Message::HelloAck { accepted, granted_permissions: initial_permissions });
    if !accepted {
        return;
    }

    inner.lock().unwrap().connections.insert(app_id.clone(), conn.clone());

    // Day 15: PermissionRequest is no longer a no-op. Optional
    // permissions are granted only when they were declared in the
    // manifest. Undeclared requests are rejected and logged.
    loop {
        match conn.recv() {
            Ok(Message::PermissionRequest { permission }) => {
                let (granted, reason) = {
                    let mut inner = inner.lock().unwrap();
                    let result = inner.runtime.get_mut(&app_id)
                        .ok_or(SandboxError::PermissionDenied(permission))
                        .and_then(|rt| rt.sandbox.request(permission));
                    match result {
                        Ok(true) => (true, None),
                        Ok(false) => (false, Some("permission not granted".to_string())),
                        Err(e) => (false, Some(e.to_string())),
                    }
                };

                if !granted {
                    let _ = log_security_event(&app_id, permission, reason.as_deref().unwrap_or("denied"));
                }
                let _ = conn.send(&Message::PermissionResponse { permission, granted });
            }
            Ok(Message::ColdStartReport { .. }) => {}
            Ok(Message::NotificationPost { title, body }) => {
                let id = {
                    let mut inner = inner.lock().unwrap();
                    let id = inner.next_notification_id;
                    inner.next_notification_id += 1;
                    let posted_at_ms = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0);
                    inner.notifications.push(Notification { id, app_id: app_id.clone(), title, body, posted_at_ms });
                    id
                };
                let _ = conn.send(&Message::NotificationPosted { id });
            }
            Ok(_) => {}
            Err(_) => break,
        }
    }

    let mut inner = inner.lock().unwrap();
    // Only clear the connection if it's still the one we own -- a
    // relaunch under the same app_id may already have installed a
    // newer connection by the time this thread notices the old one
    // closed.
    if let Some(current) = inner.connections.get(&app_id) {
        if Arc::ptr_eq(current, &conn) {
            inner.connections.remove(&app_id);
        }
    }
}
