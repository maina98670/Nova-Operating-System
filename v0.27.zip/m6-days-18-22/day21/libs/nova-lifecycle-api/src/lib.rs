//! Nova OS Day 21 — Lifecycle callback API.
//!
//! ## Honest starting point: the hard part already existed
//! `nova-app-manager`'s `foreground()`/`background()`/`terminate()`
//! have been real since Day 13 — they push genuine `Lifecycle`
//! IPC events (`Foreground`/`Background`/`Terminate`) to a running
//! app's live connection, and `terminate()`/`background()`/
//! `foreground()` all cross-check against M4's Process Manager before
//! acting (see that crate's own module docs). What's never existed
//! until now is an **app-side** way to react to those pushes other
//! than `nova_app_runtime::idle_until_terminate`'s bare
//! `println!("Lifecycle::{event:?}")`.
//!
//! [`LifecycleHandler`] is that reaction layer: register a closure
//! per event kind, then run [`run_until_terminate`] instead of
//! `nova_app_runtime::idle_until_terminate` for an app that actually
//! wants to *do* something on background/foreground, not just log it.
//! Existing apps (Days 16-20) are unaffected — this is a new,
//! opt-in loop, not a change to the one they already use.

use nova_ipc::{LifecycleEvent, Message, SeqPacketSocket};

type Callback = Box<dyn FnMut()>;

/// Builder-style registration: `LifecycleHandler::new().on_background(|| {...}).on_terminate(|| {...})`.
/// Any event kind with no registered callback is simply not acted on
/// (still consumed from the connection, so the loop keeps running) —
/// an app doesn't have to handle every kind it might be pushed.
#[derive(Default)]
pub struct LifecycleHandler {
    on_foreground: Option<Callback>,
    on_background: Option<Callback>,
    on_suspend: Option<Callback>,
    on_terminate: Option<Callback>,
}

impl LifecycleHandler {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn on_foreground(mut self, f: impl FnMut() + 'static) -> Self {
        self.on_foreground = Some(Box::new(f));
        self
    }

    pub fn on_background(mut self, f: impl FnMut() + 'static) -> Self {
        self.on_background = Some(Box::new(f));
        self
    }

    pub fn on_suspend(mut self, f: impl FnMut() + 'static) -> Self {
        self.on_suspend = Some(Box::new(f));
        self
    }

    pub fn on_terminate(mut self, f: impl FnMut() + 'static) -> Self {
        self.on_terminate = Some(Box::new(f));
        self
    }

    fn dispatch(&mut self, event: LifecycleEvent) {
        let callback = match event {
            LifecycleEvent::Foreground => &mut self.on_foreground,
            LifecycleEvent::Background => &mut self.on_background,
            LifecycleEvent::Suspend => &mut self.on_suspend,
            LifecycleEvent::Terminate => &mut self.on_terminate,
        };
        if let Some(f) = callback {
            f();
        }
    }
}

/// Blocks, dispatching every `Lifecycle` push to `handler`, until
/// `Lifecycle::Terminate` arrives (dispatched first, then the loop
/// exits) or the connection drops. Any non-`Lifecycle` message
/// arriving here is ignored, not an error — an app that also uses
/// `nova-notification-api`/`nova-permission-api` should finish those
/// blocking request/response calls *before* entering this loop, the
/// same sequential pattern every Day 16-20 app already follows for
/// its own setup work ahead of `idle_until_terminate`.
pub fn run_until_terminate(app_id: &str, conn: &SeqPacketSocket, mut handler: LifecycleHandler) {
    loop {
        match conn.recv() {
            Ok(Message::Lifecycle { event }) => {
                let is_terminate = matches!(event, LifecycleEvent::Terminate);
                handler.dispatch(event);
                if is_terminate {
                    println!("[{app_id}] Lifecycle::Terminate handled, exiting cleanly");
                    break;
                }
            }
            Ok(_) => {} // not a Lifecycle push; nothing for this loop to do with it
            Err(_) => break, // App Manager side closed the connection
        }
    }
}
