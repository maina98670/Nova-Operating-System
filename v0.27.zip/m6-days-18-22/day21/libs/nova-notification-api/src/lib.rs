//! Nova OS Day 21 — Notifications API.
//!
//! "Even a minimal local-only version — no push infrastructure needed
//! yet." Unlike `nova-input-api`/`nova-network-api`'s Day 19/20
//! stubs, this one actually works today: App Manager holds every
//! posted notification in memory for the life of that run
//! (`AppManager::notifications`/`notifications_for`, Day 21's
//! addition to `nova-app-manager`). No cross-device push, no
//! persistence across restarts, no compositor-rendered visual banner
//! (that's still M7's job) — but posting one and having it actually
//! recorded, queryable by id, is real, not stubbed.
//!
//! This crate is the thin wrapper so an app calls [`post`] instead of
//! constructing `Message::NotificationPost` and matching
//! `Message::NotificationPosted` itself — the same "don't hand-roll
//! the protocol" pattern every other Day 18-20 API crate follows.

use nova_ipc::{Message, SeqPacketSocket};
use std::io;

#[derive(Debug)]
pub enum NotificationError {
    Io(io::Error),
    UnexpectedResponse(String),
}

impl std::fmt::Display for NotificationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            NotificationError::Io(e) => write!(f, "I/O error posting notification: {e}"),
            NotificationError::UnexpectedResponse(s) => write!(f, "unexpected response posting notification: {s}"),
        }
    }
}
impl std::error::Error for NotificationError {}

/// Posts a local notification over an already-connected (post-`Hello`)
/// session and returns the id App Manager assigned it. Blocking:
/// sends `NotificationPost`, waits for the matching
/// `NotificationPosted`, same request/response pattern
/// `nova-permission-api::request` uses for a different message pair.
pub fn post(conn: &SeqPacketSocket, title: &str, body: &str) -> Result<u32, NotificationError> {
    conn.send(&Message::NotificationPost { title: title.to_string(), body: body.to_string() }).map_err(NotificationError::Io)?;
    match conn.recv().map_err(NotificationError::Io)? {
        Message::NotificationPosted { id } => Ok(id),
        other => Err(NotificationError::UnexpectedResponse(format!("{other:?}"))),
    }
}
