//! Nova OS Day 21 — runtime Permission-request API.
//!
//! `PermissionRequest`/`PermissionResponse` have existed since Day 11
//! and been genuinely enforced server-side since Day 15
//! (`nova-app-manager`'s `handle_connection`: declared-optional
//! permissions are granted, undeclared ones are rejected and logged —
//! see `nova-hello`'s Day 17 demonstration of the undeclared case).
//! `nova_app_runtime::connect_and_handshake` already sends one of
//! these for every permission in its `optional_permissions` argument,
//! but only ever at handshake time, baked into that one function.
//!
//! This crate is the same request/response pair exposed as its own
//! standalone call, usable *at any later point* in an app's life —
//! the literal Day 21 task: "permission-request APIs so an app can
//! ask for a permission at runtime, not just declare it statically in
//! the manifest [or request it only during the initial handshake]."
//! An app calls [`request`] whenever it actually needs the
//! permission, not only in the first few milliseconds of its process.

use nova_ipc::{Message, Permission, SeqPacketSocket};
use std::io;

#[derive(Debug)]
pub enum PermissionApiError {
    Io(io::Error),
    UnexpectedResponse(String),
}

impl std::fmt::Display for PermissionApiError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PermissionApiError::Io(e) => write!(f, "I/O error requesting permission: {e}"),
            PermissionApiError::UnexpectedResponse(s) => write!(f, "unexpected response requesting permission: {s}"),
        }
    }
}
impl std::error::Error for PermissionApiError {}

/// Requests `permission` over an already-connected (post-`Hello`)
/// session and returns whether it was granted. `Ok(false)` (not an
/// `Err`) for a well-formed denial — App Manager's own enforcement
/// (declared-optional-only, Day 15) is what actually decides this;
/// this function just reports what it said, honestly, including "no."
pub fn request(conn: &SeqPacketSocket, permission: Permission) -> Result<bool, PermissionApiError> {
    conn.send(&Message::PermissionRequest { permission }).map_err(PermissionApiError::Io)?;
    match conn.recv().map_err(PermissionApiError::Io)? {
        Message::PermissionResponse { permission: p, granted } if p == permission => Ok(granted),
        other => Err(PermissionApiError::UnexpectedResponse(format!("{other:?}"))),
    }
}
