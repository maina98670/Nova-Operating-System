#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 21: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 21: nova-ipc protocol round-trip tests (incl. new NotificationPost/Posted) ==="
cargo test -p nova-ipc

echo
echo "=== Nova OS Day 21: live acceptance ==="
echo "Installs and launches nova-lifecycletest through App Manager, then verifies its"
echo "notification post, runtime permission grant, and lifecycle callbacks -- via"
echo "AppManager's own state and the real filesystem under /var/lib/nova/apps/."
echo "Needs the same root-capable Linux environment as the Day 11-20 live tests."
cargo run -p nova-day21-notification-lifecycle-acceptance-test

echo
echo "Day 21 build + tests + live acceptance completed."
