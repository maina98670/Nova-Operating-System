//! Nova OS Day 21 live acceptance.
//!
//! DoD: "A test app posts a local notification, correctly receives a
//! lifecycle callback when backgrounded, and successfully requests a
//! runtime permission that then shows up as granted in M5's
//! enforcement layer."
//!
//! Every check below is external: `AppManager::notifications()` and
//! `granted_permissions()` are read from the same live `AppManager`
//! instance this tool itself drives (not parsed from
//! `nova-lifecycletest`'s stdout), and the lifecycle-callback checks
//! read real marker files `nova-lifecycletest` wrote to its own
//! scoped storage — the same external-verification pattern Day 20
//! established for Storage API.

use nova_app_manager::AppManager;
use nova_ipc::{Permission, SOCKET_PATH};
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const APP_ID: &str = "org.nova.lifecycletest";
const BIN_NAME: &str = "nova-lifecycletest";
const MANIFEST: &str = include_str!("../../../apps/org.nova.lifecycletest/nova-app.toml");
const REQUIRED: &[Permission] = &[Permission::Storage];
const APP_DATA_ROOT: &str = "/var/lib/nova/apps"; // SandboxPolicy::app_data_root, Day 15/20

fn app_install_dir() -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(APP_ID)
}

fn app_data_dir() -> PathBuf {
    Path::new(APP_DATA_ROOT).join(APP_ID)
}

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn main() {
    println!("=== Nova OS Day 21: Notifications + Lifecycle callbacks + Permission API acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));
    fs::create_dir_all(APP_DATA_ROOT).unwrap_or_else(|e| fail(format!("mkdir {APP_DATA_ROOT}: {e}")));
    let _ = fs::remove_dir_all(app_data_dir()); // clean slate from any previous run

    let manager = AppManager::new();
    let _server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("serve: {e}")));

    let dir = app_install_dir();
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), MANIFEST).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(BIN_NAME);
    if !bin_src.exists() {
        fail(format!(
            "expected sibling binary {} (run `cargo build --workspace` first, per the Day 21 build script)",
            bin_src.display()
        ));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(BIN_NAME);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(APP_ID).unwrap_or_else(|e| fail(format!("install (manifest validation): {e}")));
    println!("installed and validated");

    let pid = manager.launch(APP_ID).unwrap_or_else(|e| fail(format!("launch: {e}")));
    println!("launched, pid={pid}");

    let deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(APP_ID).is_none() {
        if Instant::now() >= deadline {
            fail("did not complete the Hello/HelloAck handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    println!("IPC handshake complete, cold-start = {}ms", manager.cold_start_ms(APP_ID).unwrap());

    let required_bits: u32 = REQUIRED.iter().fold(0, |acc, p| acc | p.bit());
    let granted = manager.granted_permissions(APP_ID).unwrap_or(0);
    if granted & required_bits != required_bits {
        fail(format!("required permission(s) not granted: required=0b{required_bits:b} granted=0b{granted:b}"));
    }

    // Give the notification post + runtime permission request time to
    // complete -- both happen synchronously right after the
    // handshake, before nova-lifecycletest enters its lifecycle loop.
    thread::sleep(Duration::from_millis(300));

    // --- Check 1: notification actually recorded by App Manager ---
    let notifications = manager.notifications_for(APP_ID);
    let posted = notifications.iter().find(|n| n.title == "Day 21" && n.body == "Local notification test");
    match posted {
        Some(n) => println!("VERIFIED: notification recorded by App Manager, id={}, posted_at_ms={}", n.id, n.posted_at_ms),
        None => fail(format!("no matching notification found in AppManager::notifications_for(); got {notifications:?}")),
    }

    // --- Check 2: runtime-requested permission shows up as granted ---
    let granted_after = manager.granted_permissions(APP_ID).unwrap_or(0);
    if granted_after & Permission::Network.bit() == 0 {
        fail(format!(
            "Permission::Network not granted after nova-lifecycletest's own runtime request -- granted=0b{granted_after:b}"
        ));
    }
    println!("VERIFIED: Permission::Network shows up as granted in App Manager's own bitmask (M5's enforcement layer)");

    // --- Check 3: background callback actually ran (real IPC push -> real file) ---
    manager.background(APP_ID).unwrap_or_else(|e| fail(format!("background(): {e}")));
    thread::sleep(Duration::from_millis(200));
    let bg_marker = app_data_dir().join("backgrounded.marker");
    match fs::read(&bg_marker) {
        Ok(bytes) if bytes == b"background event received" => {
            println!("VERIFIED: {} exists with expected content -- on_background actually fired", bg_marker.display());
        }
        Ok(_) => fail(format!("{} exists but has unexpected content", bg_marker.display())),
        Err(e) => fail(format!("{} missing: {e} -- background() was pushed but on_background never ran", bg_marker.display())),
    }
    match manager.lifecycle_state(APP_ID) {
        Some(nova_app_manager::AppLifecycleState::Background) => println!("VERIFIED: App Manager's own lifecycle_state() agrees: Background"),
        other => fail(format!("App Manager's lifecycle_state() disagrees after background(): {other:?}")),
    }

    // --- Check 4 (bonus): foreground callback too, both directions ---
    manager.foreground(APP_ID).unwrap_or_else(|e| fail(format!("foreground(): {e}")));
    thread::sleep(Duration::from_millis(200));
    let fg_marker = app_data_dir().join("foregrounded.marker");
    match fs::read(&fg_marker) {
        Ok(bytes) if bytes == b"foreground event received" => {
            println!("VERIFIED: {} exists with expected content -- on_foreground actually fired", fg_marker.display());
        }
        Ok(_) => fail(format!("{} exists but has unexpected content", fg_marker.display())),
        Err(e) => fail(format!("{} missing: {e}", fg_marker.display())),
    }

    manager.terminate(APP_ID).unwrap_or_else(|e| fail(format!("terminate: {e}")));
    thread::sleep(Duration::from_millis(150));
    if manager.pid_of(APP_ID).is_some() {
        fail("still tracked as running after terminate()");
    }
    println!("terminated cleanly");

    // Cleanup
    let _ = fs::remove_dir_all(app_install_dir());
    let _ = fs::remove_dir_all(app_data_dir());
    let _ = fs::remove_file(SOCKET_PATH);

    println!();
    println!("=== Day 21 ACCEPTANCE: PASS ===");
    println!("nova-lifecycletest posted a local notification (recorded by App Manager), was");
    println!("granted a runtime-requested permission (visible in App Manager's own bitmask),");
    println!("and its on_background/on_foreground callbacks actually ran in response to real");
    println!("Lifecycle IPC pushes -- verified via AppManager's own state and the real");
    println!("filesystem, not nova-lifecycletest's stdout.");
}
