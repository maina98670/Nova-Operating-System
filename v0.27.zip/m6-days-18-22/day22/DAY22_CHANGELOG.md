# Day 22 Change Log

Base: `nova-day21-package.zip`. Final day of M6.

1. Added `libs/nova-package-format` — `.npkg` pack/unpack (magic +
   version + length-prefixed manifest + length-prefixed binary).
   Unit tests cover round-trip, empty payloads, bad magic, unsupported
   version, and truncated data.
2. Split `tools/nova-cli`:
   - `build.rs` trimmed to compile-only (no longer copies to
     `<apps-dir>/<id>/`).
   - Added `package.rs` — bundles manifest + built binary into
     `.npkg`.
   - Added `install.rs` — unpacks `.npkg` to `<apps-dir>/<id>/`.
   - Added `run.rs` — the one subcommand depending on
     `nova-app-manager`/`nova-fsmgr`/`nova-ipc`/`nova-procmgr`; starts
     a transient App Manager, installs, launches, waits for handshake,
     waits for timeout-or-exit, stops. Named honestly why there's no
     persistent daemon to connect to instead.
   - Extracted shared `manifest_util::extract_toml_string` (was
     private to `build.rs`).
   - `main.rs` dispatch + usage text updated for all five subcommands.
3. Added `docs/application-developer-guide-v1.md` — Section 23 first
   draft: five-command loop walkthrough, SDK API reference table,
   troubleshooting.
4. Added `docs/M6-TAG.md` — the M6 (`v0.27`) tag writeup.
5. Added `tools/nova-day22-full-toolchain-acceptance-test` — five real
   `nova` subprocess invocations against a genuinely new app
   (`org.nova.day22_demo_app`), zero hand-editing, each step verified
   on disk including unpacking the `.npkg` and byte-comparing its
   binary against what `nova build` actually produced.
6. Updated `docs/nova-sdk-template-v1.md`'s `nova build` section to
   match the Day 22 split (was describing the old build+install
   behavior).
7. Updated the workspace `Cargo.toml` with one new lib and one new
   tool (plus `nova-cli`'s expanded dependency list, already reflected
   in its own `Cargo.toml`).

Named but not built in this delivery: the persistent-daemon /
`ListApps`/`LaunchApp` management-protocol server-side implementation
`run.rs`'s module doc points at as the real next step for `nova run`.

M7 (GUI & Window System, Days 23-28) is next — the milestone every
Window/Input API stub since Day 19 has been waiting on.
