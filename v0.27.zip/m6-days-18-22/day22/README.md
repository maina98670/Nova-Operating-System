# Nova OS — Day 22 Package: Full SDK Toolchain, Acceptance, Tag M6

This package continues directly from the Day 21 package. This is the
final day of **M6 — Nova SDK & Application Framework (v0.27, Days
18–22)**. **Assembled without running any tests or builds** — files
only. Nothing below has been compiled or verified in this pass. Run
`nova-day22-build_and_run.sh` yourself to actually confirm it.

## Day 22 goal

Per the Complete Build Guide:
1. `nova build`, `nova package`, `nova install my_app.npkg`, `nova run
   my_app` — the full developer loop, one command per step.
2. Documentation: application developer guide (Section 23), first
   draft.
3. Acceptance: build a genuinely new (not previously-existing) test
   app from `nova create` through `nova run` using only the SDK, no
   hand-editing of generated boilerplate.

DoD: the full `create -> build -> package -> install -> run` loop
works end to end for a fresh app on the first try, documented well
enough that the steps above could be followed by someone who didn't
build the SDK. Tag M6.

## What changed

`nova build` (Day 18) used to also copy the built binary + manifest to
`<apps-dir>/<id>/` — folding build and install together, explicitly
flagged then as deferred work for this day. Day 22 splits it apart:

- **`nova build`** — now *only* compiles.
- **`nova package`** (new) — bundles the manifest + built binary into
  one `.npkg` file. New format: `libs/nova-package-format`
  (magic + version + length-prefixed manifest + length-prefixed
  binary; no compression, no signing — that's M11's job). Unit-tested,
  including corrupt/truncated-data rejection.
- **`nova install`** (new) — unpacks a `.npkg` to `<apps-dir>/<id>/`,
  the same layout `build` used to write directly.
- **`nova run`** (new) — the one subcommand that breaks `nova-cli`'s
  "stay standalone" rule from Day 18, and says so plainly: there's no
  persistent Nova system daemon to connect to, so `run` starts its own
  transient App Manager, installs, launches, waits for the handshake,
  then waits for a timeout or the app's own exit before stopping it.
  `nova-ipc`'s `ListApps`/`AppList`/`LaunchApp`/`LaunchResult`
  messages (Day 12) have existed for exactly this kind of
  client/daemon protocol but were never implemented server-side —
  named as real future work in `run.rs`'s own module doc, not quietly
  assumed to already exist.

## What's new

- **`libs/nova-package-format`** — `pack`/`unpack` for `.npkg`.
- **`tools/nova-cli`** — `package.rs`, `install.rs`, `run.rs` added;
  `build.rs` trimmed to compile-only; shared `manifest_util.rs`
  extracted from the old `build.rs`.
- **`docs/application-developer-guide-v1.md`** — the Section 23
  developer guide, first draft: the full five-command loop, a
  reference table of every SDK API crate from Days 19–21, and a
  troubleshooting section.
- **`docs/M6-TAG.md`** — the M6 tag (`v0.27`) writeup.
- **`tools/nova-day22-full-toolchain-acceptance-test`** — the literal
  DoD: five real `nova` subprocess invocations
  (create/build/package/install/run) against a genuinely new app name
  (`org.nova.day22_demo_app`, distinct from every earlier day's test
  app), zero hand-editing of any generated file, each step's output
  verified on disk — including unpacking the `.npkg` and confirming
  its binary bytes exactly match what `nova build` produced.
- `docs/nova-sdk-template-v1.md` updated: its `nova build` section
  no longer describes the old build+install behavior.

## Run

```bash
./nova-day22-build_and_run.sh
```

Builds the workspace, runs `nova-package-format`'s unit tests, then
the full-toolchain live acceptance test. Needs the same root-capable
Linux environment as the Days 11–21 live tests.

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction. If it
passes, `docs/M6-TAG.md` has the tag command for the real repo.
