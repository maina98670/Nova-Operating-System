# Tag: M6 — Nova SDK & Application Framework

**Version**: `v0.27`, per the Complete Build Guide's milestone table
(`M6 — Nova SDK & Application Framework (v0.27), Days 18-22`).

Note the guide's own disambiguation: the *other* Nova-OS-Guide.docx
(an earlier, separate milestone scheme) also has an "M6," but it means
something unrelated (a product-differentiation health app). This tag
is the Roadmap's M6 — the SDK — not that one.

This file documents the intended tag; it does not create one. Files
only, not a git checkout of Zeen's actual repository — run this in the
real repo once this package's contents are merged in:

```bash
git tag -a v0.27 -m "M6: Nova SDK & Application Framework"
git push origin v0.27
```

## What M6 covers (Days 18-22)

| Day | Focus | Delivered |
|---|---|---|
| 18 | SDK scaffolding + project template | `nova create`/`nova build` (build folded install in, at the time) |
| 19 | Window API + Input API | `nova-window-api` (real, stubbed backend), `nova-input-api` (honest `NotYetAvailable`) |
| 20 | Storage API + Networking API stub | `nova-storage-api` (real, sandboxed), `nova-network-api` (honest `NotImplemented`) |
| 21 | Notifications + lifecycle callbacks + permission APIs | `nova-notification-api` (real, local-only), `nova-lifecycle-api` (app-side reaction layer over Day 13's real push mechanism), `nova-permission-api` (runtime, standalone) |
| 22 | Full toolchain, acceptance, tag | `nova build`/`package`/`install`/`run` split apart; developer guide; this tag |

## M6 acceptance, satisfied

> "The full `create -> build -> package -> install -> run` loop works
> end to end for a fresh app on the first try, documented well enough
> that the steps above could be followed by someone who didn't build
> the SDK."

Proven live by `tools/nova-day22-full-toolchain-acceptance-test`
against a genuinely new app (`org.nova.day22_demo_app`, not reused
from any earlier day's test app): five real `nova` subprocess
invocations, zero hand-editing of any generated file, each step's
output verified on disk (or, for `.npkg`, unpacked and checked against
what the previous step actually built).

Documentation: `docs/application-developer-guide-v1.md` (Section 23,
first draft) — written to be followable without having read any of
Nova OS's own source, per the DoD's own wording.

## Known gaps carried forward past M6 (named, not hidden)

- **`nova run` has no persistent-daemon story.** It starts its own
  transient App Manager per invocation; there's no always-on Nova
  system daemon an app could connect into independently. `nova-ipc`'s
  `ListApps`/`AppList`/`LaunchApp`/`LaunchResult` management-protocol
  messages have existed since Day 12 but were never implemented
  server-side — `run.rs`'s own module doc names this as the natural
  next step, most likely alongside whatever day first builds real
  system-daemon/init supervision.
- **No Ctrl-C-to-stop for `nova run`.** It waits for a timeout or the
  app's own exit; no real signal handling yet.
- **`.npkg` has no signing/integrity check.** M11 (Package Ecosystem)
  is where that belongs.
- **No real UI, no real hardware.** Every M6 API that needs M7
  (compositor/rendering), M8 (networking), or M9 (hardware HALs)
  is honestly stubbed, not faked — see each API's own doc for detail.

None of these block M6's own acceptance criterion above; they're
listed here so M7 onward doesn't have to rediscover them.
