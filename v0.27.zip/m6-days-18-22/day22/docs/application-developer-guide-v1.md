# Nova OS Application Developer Guide (Section 23, first draft)

This is the guide the Day 22 DoD asks for: enough to build and run a
Nova app **using only the SDK**, without having read any of Nova OS's
own source. If you get stuck, the deeper reference docs are linked at
the end of each section.

## Prerequisites

- A Rust toolchain (`cargo` on your `PATH`).
- A checkout of the Nova OS repository — `nova create` needs to find
  its `libs/` directory (see step 1).
- A root-capable Linux environment for `nova run` (it starts App
  Manager, which writes to `/apps`, `/run/nova`, `/var/log/nova`, and
  `/var/lib/nova/apps`).
- The `nova` CLI built: from the repo root, `cargo build --workspace`,
  then use `./target/debug/nova`.

## The five-command loop

```
nova create my_app
nova build my_app
nova package my_app
nova install my_app.npkg
nova run org.nova.my_app
```

Each command's job, in one line:

| Command | Does |
|---|---|
| `create` | Generates a working Rust crate + manifest — a skeleton, not a finished app |
| `build` | `cargo build`s it |
| `package` | Bundles the manifest + built binary into one `.npkg` file |
| `install` | Unpacks that `.npkg` to where App Manager looks for apps |
| `run` | Launches it through App Manager and waits for it to actually connect |

### 1. `nova create`

```bash
nova create my_app
```

Generates `./my_app/`: a `Cargo.toml`, a `nova-app.toml` manifest, a
`src/main.rs` skeleton, and a `README.md`. Nothing here needs editing
to build — the DoD's "no hand-editing of generated boilerplate" is
literal: you can run the rest of the loop without touching a single
generated file.

By default, `create` looks for this repo's `libs/` directory by
walking up from your current directory. If that fails (you're running
`nova` from somewhere else), pass it explicitly:

```bash
nova create my_app --libs-path /path/to/nova-os/libs
```

Full field-by-field reference: `docs/nova-sdk-template-v1.md`.

### 2. `nova build`

```bash
nova build my_app
```

Runs `cargo build --manifest-path my_app/Cargo.toml`. Produces
`my_app/target/debug/my-app` (note: hyphens, not underscores — see
the template doc if your app name has underscores in it). Nothing is
copied anywhere yet; `build` only compiles.

### 3. `nova package`

```bash
nova package my_app
```

Reads `my_app/nova-app.toml` and the binary `build` just produced,
bundles both into `my_app/my_app.npkg` (override the output path with
`--out`). The `.npkg` format is deliberately minimal — one manifest,
one binary, no compression, no signing yet (that's M11's job). Format
reference: `libs/nova-package-format`'s own module docs.

### 4. `nova install`

```bash
nova install my_app.npkg
```

Unpacks the `.npkg` and writes `/apps/org.nova.my_app/nova-app.toml`
and `/apps/org.nova.my_app/bin/my-app` — exactly where App Manager
expects to find an installed app (`--apps-dir` overrides this, but see
the warning in the next step before relying on that).

### 5. `nova run`

```bash
nova run org.nova.my_app
```

This is the one command that actually talks to Nova's own internals
(everything before it was pure file manipulation). It starts a
transient App Manager, `install()`s your app from `/apps/<id>/`
(**always** the real system path — `nova install --apps-dir` doesn't
affect where `nova run` looks; see `run.rs`'s own module doc for why),
launches it, and waits for the app to complete its `Hello`/`HelloAck`
handshake. Once connected, it prints a confirmation and then waits —
up to 15 seconds by default (`--timeout-secs` to change that), or
until your app exits on its own — before stopping it.

**Known limitation, named plainly**: there's no Ctrl-C-to-stop
interactivity yet, and no persistent system App Manager daemon your
app could instead connect to independently of `nova run` starting one
itself — see `run.rs`'s module doc for the full honest explanation.
This is enough to prove the dev loop works end to end; a real
always-on daemon your app launches into without `nova run`'s help is
future work.

## What your generated `main.rs` actually does

```rust
let (conn, outcome) = nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS)?;
// ... your logic goes here ...
nova_app_runtime::idle_until_terminate(APP_ID, &conn);
```

That's the whole lifecycle: connect, do your setup, then idle until
told to stop. From here, the SDK crates you'll actually reach for:

| You want to... | Use |
|---|---|
| Read/write your own app's data | `nova-storage-api` |
| Create a window (no real rendering until M7) | `nova-window-api` |
| React to touch/keyboard input (not available until M7) | `nova-input-api` |
| Make a network request (not available until M8) | `nova-network-api` |
| Post a local notification | `nova-notification-api` |
| React to foreground/background/terminate | `nova-lifecycle-api` |
| Ask for a permission at runtime, not just in the manifest | `nova-permission-api` |

Each has its own doc under `docs/` (`nova-window-input-api-v1.md`,
`nova-storage-network-api-v1.md`,
`nova-notification-lifecycle-permission-api-v1.md`) — read the one for
whatever you're building; none of them assume you've read Nova's own
source first.

## Troubleshooting

- **`nova create` can't find `libs/`**: pass `--libs-path` explicitly.
- **`nova build` fails to link**: check the two `path = "..."` lines
  in your app's `Cargo.toml` still point at the real `libs/` directory
  — see the "known limitation" in `docs/nova-sdk-template-v1.md` if
  you moved the generated folder after creating it.
- **`nova install` succeeds but `nova run` says "install failed"**:
  you probably used `nova install --apps-dir <custom>` — `nova run`
  always looks in the real `/apps`, not a custom path. Re-run
  `nova install` without `--apps-dir`.
- **`nova run` times out waiting for the handshake**: your app crashed
  before calling `connect_and_handshake` successfully, or before it
  returned. Run the built binary directly
  (`./my_app/target/debug/my-app`) to see its own stderr.

## What this guide doesn't cover yet (named, not hidden)

- Multi-binary apps, or apps with their own sub-crates.
- Anything about the GUI/rendering side — there isn't one yet (M7).
- Publishing/distributing a `.npkg` beyond your own machine (M11).
- `nova run`'s interactive/daemon story, per the section 5 caveat
  above.

This is a first draft, written alongside the toolchain it documents
(Day 22) — expect it to grow as the gaps above get filled in.
