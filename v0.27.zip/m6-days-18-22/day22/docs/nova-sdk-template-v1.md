# Nova SDK — `nova create` Template Reference (Day 18, first draft)

This is the "document the template's structure" deliverable from Day
18's task list — so a third-party developer (or a future you) doesn't
need to read `nova-app-manager` source, or `nova-cli` source, to
understand what `nova create` generates and why.

## What `nova create <name>` generates

```
<name>/
├── Cargo.toml       # standalone crate, depends on nova-app-runtime/nova-ipc
├── nova-app.toml     # the app manifest -- see docs/nova-app-toml-v1.md
├── README.md         # short per-app reference, generated fresh each time
└── src/
    └── main.rs        # handshake + idle loop, TODO markers for your logic
```

Four files, all editable — nothing here is a build artifact you're
expected to leave alone. The only thing `nova build` treats as
load-bearing is the `id`/`entry_point` pair in `nova-app.toml` and the
`[[bin]] name` in `Cargo.toml` (they must stay consistent with each
other, which they are as generated).

## `nova-app.toml`

Full schema: `docs/nova-app-toml-v1.md`. What `nova create` fills in:

| Field | Generated value |
|---|---|
| `id` | `org.nova.<name>`, or `--id` if you passed one |
| `name` | Title-cased `<name>` (`my_app` -> `My App`) |
| `version` | `0.1.0` |
| `entry_point` | `/apps/<id>/bin/<bin-name>` |
| `required_permissions` | `["storage"]` |
| `optional_permissions` | `[]` |

`storage` is the default required permission because a zero-permission
app is a degenerate starting point for something you're about to build
real functionality into — almost every real app ends up needing it
first. Add or remove permissions from `nova-ipc`'s fixed set (see
`nova-ipc-v1.md`'s permission model section) as your app actually
needs.

## `Cargo.toml`

A standalone crate — note the empty `[workspace]` table at the top.
That's deliberate: it opts the generated crate out of any ancestor
workspace it happens to land inside (this repo's own workspace
`Cargo.toml`, if you generated the app somewhere under it), so `cargo
build`/`nova build` work the same whether the app lives inside this
repo or somewhere else entirely — *except* for one thing:

### Known limitation: the `path = "..."` dependency

`nova-app-runtime` and `nova-ipc` aren't published anywhere yet — no
crates.io, no offline registry. M11 (Package Ecosystem) is about *app*
packages (`.nova` bundles), not shared Rust library distribution, so
it doesn't fix this either. The only way a generated app can depend on
them today is a relative `path = "..."` back to this repo's `libs/`
directory — which `nova create` computes for you (`--libs-path`,
auto-detected by walking up from the current directory looking for
`libs/nova-app-runtime` if not given explicitly), but which **breaks
if you move the generated folder** to a different depth relative to
`libs/` afterward. If that happens, edit the two `path = "..."` lines
in `Cargo.toml` by hand. This is a real, named gap — not something a
future day is quietly expected to have already fixed.

**A second, untested risk in the same area**: `nova-app-runtime` and
`nova-ipc` are both explicit members of *this repo's own* root
workspace (`Cargo.toml`'s `members = [...]`). Cargo has a known
resolution error — "current package believes it's in a workspace when
it's not" — that can trigger when a crate outside that workspace
path-depends on a crate that's already an explicit member of it,
depending on the exact Cargo version and directory layout. The
generated `Cargo.toml`'s empty `[workspace]` table (below) avoids the
*more common* version of this problem (the generated app silently
getting absorbed into an ancestor workspace if it's created somewhere
under this repo's own tree), but it does **not** provably rule out the
member-conflict case above — that has not been verified against a
real `cargo build` in this pass, per the "no testing" instruction this
whole day was built under. Test `nova build` on a freshly `nova
create`d app for real before relying on this; if you hit that error,
its own message names the fix.

## `src/main.rs`

Generated content, in order:

1. `connect_and_handshake` — the same `nova-app-runtime` call every
   Day 16/17 app uses. Exits with a clear error if App Manager
   rejects the handshake.
2. A `TODO` comment pointing at `apps/org.nova.{contacts,messages,dialer,camera,settings}`
   in this repo as real examples of a functional core loading its own
   sandbox-scoped storage after the handshake.
3. Two `println!`s: one confirming the handshake, one **explicitly
   stating there's no window yet** — the Window API lands Day 19, and
   real Wayland rendering is M7's job. This is the deliberate,
   documented version of the task list's "minimal window": a generated
   app today has nothing visual to draw, and the template says so
   rather than faking a window.
4. `idle_until_terminate` — same shared loop every Day 16/17 app uses.

If your manifest declares `optional_permissions`, list the matching
`Permission` values in `OPTIONAL_PERMISSIONS` near the top of the file
so they get requested at startup — this isn't automatic from the
manifest (`nova-cli` doesn't read the manifest back into the generated
Rust source; keeping the two in sync is on you, same as any other
manifest edit).

## `nova build <path>` (Day 18; scope updated Day 22)

1. Reads `entry_point` out of `nova-app.toml` (a tiny hand-rolled
   parser inside `nova-cli` itself, not `nova-config` — see
   `nova-cli`'s module docs for why it's kept standalone) to work out
   the expected binary name.
2. Runs `cargo build --manifest-path <path>/Cargo.toml`.

That's it as of Day 22 — `build` **only compiles**. Through Day 21 it
also copied the result to `<apps-dir>/<id>/`; that copying is now
`nova install`'s job, and bundling the manifest + binary into one file
in between is `nova package`'s job. See
`docs/application-developer-guide-v1.md` for the full five-command
loop (`create` → `build` → `package` → `install` → `run`) and
`libs/nova-package-format`'s own module docs for the `.npkg` format
`package`/`install` speak.

## What Day 18 doesn't cover (named, not hidden)

- No template customization (`nova create --template <name>`) —
  exactly one template exists.
- No dependency management beyond the two hardcoded path deps.
- No real window (Window API is Day 19; real rendering is M7) — the
  template says this explicitly rather than pretending otherwise.
