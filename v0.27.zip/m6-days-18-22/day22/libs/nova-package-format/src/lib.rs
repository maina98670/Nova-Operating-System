//! Nova OS Day 22 — the `.npkg` package format.
//!
//! `nova package` needs to bundle a built app's `nova-app.toml` and
//! its compiled binary into one file `nova install` can consume.
//! Rather than reach for a general-purpose archive format (tar, zip)
//! — which would mean either a new external dependency or a much
//! bigger implementation than this milestone needs — `.npkg` is
//! deliberately the smallest thing that does the actual job: exactly
//! one manifest and exactly one binary, no directories, no
//! compression, no metadata beyond a magic number and a format
//! version.
//!
//! ## Wire format
//! ```text
//! magic:         4 bytes   = b"NPKG"
//! format_version: 1 byte   = 1
//! manifest_len:  4 bytes   = u32 LE
//! manifest:      manifest_len bytes  (nova-app.toml, as written)
//! binary_len:    4 bytes   = u32 LE
//! binary:        binary_len bytes    (the compiled executable)
//! ```
//! No checksum, no signature — package integrity/signing is M11's job
//! (Package Ecosystem), the same "not yet, and that's fine for this
//! milestone" scope every other cross-cutting concern in this repo
//! gets named for rather than silently assumed.

pub const MAGIC: &[u8; 4] = b"NPKG";
pub const FORMAT_VERSION: u8 = 1;

#[derive(Debug)]
pub enum PackageFormatError {
    TooShort,
    BadMagic,
    UnsupportedVersion(u8),
    Truncated(&'static str),
}

impl std::fmt::Display for PackageFormatError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PackageFormatError::TooShort => write!(f, "data shorter than the .npkg header"),
            PackageFormatError::BadMagic => write!(f, "not a .npkg file (bad magic bytes)"),
            PackageFormatError::UnsupportedVersion(v) => write!(f, "unsupported .npkg format version: {v}"),
            PackageFormatError::Truncated(field) => write!(f, ".npkg data truncated while reading {field}"),
        }
    }
}
impl std::error::Error for PackageFormatError {}

/// Bundles `manifest` (the raw bytes of a `nova-app.toml`) and
/// `binary` (the compiled executable's bytes) into one `.npkg` file's
/// contents.
pub fn pack(manifest: &[u8], binary: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(4 + 1 + 4 + manifest.len() + 4 + binary.len());
    out.extend_from_slice(MAGIC);
    out.push(FORMAT_VERSION);
    out.extend_from_slice(&(manifest.len() as u32).to_le_bytes());
    out.extend_from_slice(manifest);
    out.extend_from_slice(&(binary.len() as u32).to_le_bytes());
    out.extend_from_slice(binary);
    out
}

/// The inverse of [`pack`]: `(manifest_bytes, binary_bytes)`.
pub fn unpack(data: &[u8]) -> Result<(Vec<u8>, Vec<u8>), PackageFormatError> {
    if data.len() < 5 {
        return Err(PackageFormatError::TooShort);
    }
    if &data[0..4] != MAGIC {
        return Err(PackageFormatError::BadMagic);
    }
    let version = data[4];
    if version != FORMAT_VERSION {
        return Err(PackageFormatError::UnsupportedVersion(version));
    }

    let mut pos = 5;
    let manifest_len = read_u32(data, pos, "manifest_len")?;
    pos += 4;
    let manifest = read_bytes(data, pos, manifest_len, "manifest")?;
    pos += manifest_len;

    let binary_len = read_u32(data, pos, "binary_len")?;
    pos += 4;
    let binary = read_bytes(data, pos, binary_len, "binary")?;

    Ok((manifest.to_vec(), binary.to_vec()))
}

fn read_u32(data: &[u8], pos: usize, field: &'static str) -> Result<usize, PackageFormatError> {
    let bytes = data.get(pos..pos + 4).ok_or(PackageFormatError::Truncated(field))?;
    Ok(u32::from_le_bytes(bytes.try_into().unwrap()) as usize)
}

fn read_bytes(data: &[u8], pos: usize, len: usize, field: &'static str) -> Result<&[u8], PackageFormatError> {
    data.get(pos..pos + len).ok_or(PackageFormatError::Truncated(field))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pack_unpack_round_trip() {
        let manifest = b"id = \"org.nova.example\"\n";
        let binary = b"\x7fELF-not-a-real-binary-but-arbitrary-bytes-work-fine";
        let packed = pack(manifest, binary);
        let (m, b) = unpack(&packed).unwrap();
        assert_eq!(m, manifest);
        assert_eq!(b, binary);
    }

    #[test]
    fn empty_manifest_and_binary_round_trip() {
        let packed = pack(b"", b"");
        let (m, b) = unpack(&packed).unwrap();
        assert!(m.is_empty());
        assert!(b.is_empty());
    }

    #[test]
    fn rejects_too_short_data() {
        assert!(matches!(unpack(&[1, 2, 3]), Err(PackageFormatError::TooShort)));
    }

    #[test]
    fn rejects_bad_magic() {
        let mut packed = pack(b"x", b"y");
        packed[0] = b'X'; // corrupt the magic
        assert!(matches!(unpack(&packed), Err(PackageFormatError::BadMagic)));
    }

    #[test]
    fn rejects_unsupported_version() {
        let mut packed = pack(b"x", b"y");
        packed[4] = 99;
        assert!(matches!(unpack(&packed), Err(PackageFormatError::UnsupportedVersion(99))));
    }

    #[test]
    fn rejects_truncated_payload() {
        let packed = pack(b"hello manifest", b"hello binary");
        let truncated = &packed[..packed.len() - 5]; // cut off part of the binary
        assert!(matches!(unpack(truncated), Err(PackageFormatError::Truncated(_))));
    }

    #[test]
    fn rejects_truncated_length_prefix() {
        let packed = pack(b"hello", b"world");
        let truncated = &packed[..7]; // magic + version + partial manifest_len
        assert!(matches!(unpack(truncated), Err(PackageFormatError::Truncated(_))));
    }
}
