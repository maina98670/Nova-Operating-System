#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 22: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 22: nova-package-format unit tests ==="
cargo test -p nova-package-format

echo
echo "=== Nova OS Day 22: full toolchain live acceptance ==="
echo "Runs nova create/build/package/install/run as five real subprocesses"
echo "against a genuinely new app. Needs the same root-capable Linux"
echo "environment as the Day 11-21 live tests."
cargo run -p nova-day22-full-toolchain-acceptance-test

echo
echo "Day 22 build + tests + full toolchain acceptance completed."
echo
echo "If it passed, tag the repo (see docs/M6-TAG.md):"
echo "  git tag -a v0.27 -m \"M6: Nova SDK & Application Framework\""
echo "  git push origin v0.27"
echo
echo "Try the toolchain yourself:"
echo "  ./target/debug/nova create my_app"
echo "  ./target/debug/nova build my_app"
echo "  ./target/debug/nova package my_app"
echo "  ./target/debug/nova install my_app.npkg"
echo "  ./target/debug/nova run org.nova.my_app"
