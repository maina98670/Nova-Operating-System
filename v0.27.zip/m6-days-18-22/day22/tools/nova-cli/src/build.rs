//! `nova build <path>` — compiles the generated crate. As of Day 22,
//! this **only** compiles; it no longer also copies anything to
//! `<apps-dir>/<id>/`. That copying is now `nova install`'s job (see
//! `install.rs`), and packaging the built binary + manifest into one
//! `.npkg` file in between is `nova package`'s job (see `package.rs`)
//! — the full `create -> build -> package -> install -> run` loop the
//! Day 22 DoD asks for, one command per step, matching what Day 18's
//! own module doc already flagged as deferred here.

use crate::manifest_util::extract_toml_string;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode};

pub fn run(args: &[String]) -> ExitCode {
    let mut app_path: Option<PathBuf> = None;

    for arg in args {
        if !arg.starts_with('-') && app_path.is_none() {
            app_path = Some(PathBuf::from(arg));
        } else {
            eprintln!("nova build: unrecognized argument '{arg}'");
            return ExitCode::FAILURE;
        }
    }

    let Some(app_path) = app_path else {
        eprintln!("nova build: missing <path>\nusage: nova build <path-to-app-dir>");
        return ExitCode::FAILURE;
    };

    let manifest_toml = app_path.join("nova-app.toml");
    let cargo_toml = app_path.join("Cargo.toml");
    if !manifest_toml.is_file() || !cargo_toml.is_file() {
        eprintln!(
            "nova build: {} doesn't look like a `nova create`-generated app (missing nova-app.toml or Cargo.toml)",
            app_path.display()
        );
        return ExitCode::FAILURE;
    }

    let manifest_text = match fs::read_to_string(&manifest_toml) {
        Ok(t) => t,
        Err(e) => {
            eprintln!("nova build: couldn't read {}: {e}", manifest_toml.display());
            return ExitCode::FAILURE;
        }
    };
    let Some(entry_point) = extract_toml_string(&manifest_text, "entry_point") else {
        eprintln!("nova build: {} has no `entry_point` field", manifest_toml.display());
        return ExitCode::FAILURE;
    };
    let bin_name = match Path::new(&entry_point).file_name() {
        Some(n) => n.to_string_lossy().to_string(),
        None => {
            eprintln!("nova build: couldn't extract a binary name from entry_point '{entry_point}'");
            return ExitCode::FAILURE;
        }
    };

    println!("Building {} (bin={bin_name})...", app_path.display());
    let status = Command::new("cargo").arg("build").arg("--manifest-path").arg(&cargo_toml).status();
    match status {
        Ok(s) if s.success() => {}
        Ok(s) => {
            eprintln!("nova build: cargo build failed ({s})");
            return ExitCode::FAILURE;
        }
        Err(e) => {
            eprintln!("nova build: couldn't run cargo: {e}");
            return ExitCode::FAILURE;
        }
    }

    let built_bin = app_path.join("target").join("debug").join(&bin_name);
    if !built_bin.is_file() {
        eprintln!(
            "nova build: cargo build succeeded but {} wasn't produced -- \
             does the [[bin]] name in Cargo.toml match entry_point's file name?",
            built_bin.display()
        );
        return ExitCode::FAILURE;
    }

    println!("Built: {}", built_bin.display());
    println!();
    println!("Next: nova package {}", app_path.display());
    ExitCode::SUCCESS
}
