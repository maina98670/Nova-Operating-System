//! `nova install <package.npkg>` — unpacks a `.npkg` file
//! (`nova_package_format::unpack`) and writes its manifest + binary to
//! `<apps-dir>/<id>/`, matching the layout App Manager's own
//! `install()`/`launch()` expect (`nova-app.toml`,
//! `bin/<binary>` — see `docs/nova-app-toml-v1.md`'s Day 16/17
//! addendum on this exact convention). Purely a filesystem operation —
//! this subcommand does not itself talk to App Manager, the same way
//! copying a `.deb`'s contents into place is separate from a package
//! manager actually registering/starting the service it contains.

use crate::manifest_util::extract_toml_string;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

const DEFAULT_APPS_DIR: &str = "/apps"; // mirrors nova_fsmgr::paths::APPS

pub fn run(args: &[String]) -> ExitCode {
    let mut package_path: Option<PathBuf> = None;
    let mut apps_dir = std::env::var("NOVA_APPS_DIR").unwrap_or_else(|_| DEFAULT_APPS_DIR.to_string());

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--apps-dir" => {
                i += 1;
                if let Some(v) = args.get(i) {
                    apps_dir = v.clone();
                }
            }
            other if !other.starts_with('-') && package_path.is_none() => {
                package_path = Some(PathBuf::from(other));
            }
            other => {
                eprintln!("nova install: unrecognized argument '{other}'");
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    let Some(package_path) = package_path else {
        eprintln!("nova install: missing <package.npkg>\nusage: nova install <package.npkg> [--apps-dir <dir>]");
        return ExitCode::FAILURE;
    };

    let packed = match fs::read(&package_path) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("nova install: couldn't read {}: {e}", package_path.display());
            return ExitCode::FAILURE;
        }
    };
    let (manifest_bytes, binary_bytes) = match nova_package_format::unpack(&packed) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("nova install: {} is not a valid .npkg file: {e}", package_path.display());
            return ExitCode::FAILURE;
        }
    };

    let manifest_str = String::from_utf8_lossy(&manifest_bytes).to_string();
    let Some(id) = extract_toml_string(&manifest_str, "id") else {
        eprintln!("nova install: package manifest has no `id` field");
        return ExitCode::FAILURE;
    };
    let Some(entry_point) = extract_toml_string(&manifest_str, "entry_point") else {
        eprintln!("nova install: package manifest has no `entry_point` field");
        return ExitCode::FAILURE;
    };
    let bin_name = match Path::new(&entry_point).file_name() {
        Some(n) => n.to_string_lossy().to_string(),
        None => {
            eprintln!("nova install: couldn't extract a binary name from entry_point '{entry_point}'");
            return ExitCode::FAILURE;
        }
    };

    let dest_dir = Path::new(&apps_dir).join(&id);
    let dest_bin_dir = dest_dir.join("bin");
    if let Err(e) = fs::create_dir_all(&dest_bin_dir) {
        eprintln!("nova install: couldn't create {}: {e}", dest_bin_dir.display());
        return ExitCode::FAILURE;
    }

    let dest_manifest = dest_dir.join("nova-app.toml");
    if let Err(e) = fs::write(&dest_manifest, &manifest_bytes) {
        eprintln!("nova install: couldn't write {}: {e}", dest_manifest.display());
        return ExitCode::FAILURE;
    }

    let dest_bin = dest_bin_dir.join(&bin_name);
    if let Err(e) = fs::write(&dest_bin, &binary_bytes) {
        eprintln!("nova install: couldn't write {}: {e}", dest_bin.display());
        return ExitCode::FAILURE;
    }
    if let Ok(meta) = fs::metadata(&dest_bin) {
        let mut perms = meta.permissions();
        perms.set_mode(0o755);
        let _ = fs::set_permissions(&dest_bin, perms);
    }

    println!("Installed {id}");
    println!("  {}", dest_manifest.display());
    println!("  {}", dest_bin.display());
    println!();
    println!("Next: nova run {id}");
    ExitCode::SUCCESS
}
