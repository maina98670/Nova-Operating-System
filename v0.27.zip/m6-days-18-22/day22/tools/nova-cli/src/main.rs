//! `nova` — the Nova SDK command-line tool.
//!
//! Day 18 added `create`/`build`, with `build` folding install in too
//! (documented then as deferred). Day 22 splits the full toolchain
//! apart into one command per step, per the DoD: "the full `create ->
//! build -> package -> install -> run` loop works end to end for a
//! fresh app on the first try."
//!
//! `create`/`build`/`package`/`install` stay standalone — no
//! dependency on `nova-ipc`/`nova-app-manager`/`nova-fsmgr`, the same
//! way a real third-party app developer's toolchain wouldn't link
//! against the platform's own internal crates just to scaffold,
//! compile, or bundle a file. `run` is the one exception; see
//! `run.rs`'s module doc for why, honestly, rather than silently.
//!
//! Subcommands:
//!   - `nova create <name>` — see `create.rs`.
//!   - `nova build <path>`  — see `build.rs`.
//!   - `nova package <path>` — see `package.rs`.
//!   - `nova install <package.npkg>` — see `install.rs`.
//!   - `nova run <app-id>` — see `run.rs`.

mod build;
mod create;
mod install;
mod manifest_util;
mod package;
mod run;
mod template;

use std::env;
use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = env::args().collect();

    match args.get(1).map(String::as_str) {
        Some("create") => create::run(&args[2..]),
        Some("build") => build::run(&args[2..]),
        Some("package") => package::run(&args[2..]),
        Some("install") => install::run(&args[2..]),
        Some("run") => run::run(&args[2..]),
        Some("-h") | Some("--help") | None => {
            print_usage();
            ExitCode::SUCCESS
        }
        Some(other) => {
            eprintln!("nova: unknown subcommand '{other}'");
            print_usage();
            ExitCode::FAILURE
        }
    }
}

fn print_usage() {
    eprintln!(
        "nova — Nova OS SDK CLI

USAGE:
    nova create <name> [--id <app-id>] [--out <dir>] [--libs-path <path>]
    nova build <path-to-app-dir>
    nova package <path-to-app-dir> [--out <file.npkg>]
    nova install <package.npkg> [--apps-dir <dir>]
    nova run <app-id> [--timeout-secs <seconds>]

The full loop, one command per step:

    nova create my_app
    nova build my_app
    nova package my_app
    nova install my_app.npkg
    nova run org.nova.my_app

See docs/application-developer-guide-v1.md for a full walkthrough, and
docs/nova-sdk-template-v1.md for what `create` generates.
"
    );
}

