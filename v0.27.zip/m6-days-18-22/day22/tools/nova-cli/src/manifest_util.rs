//! Deliberately minimal: this CLI doesn't depend on `nova-config`
//! (kept standalone where possible — see `main.rs`'s module doc), so
//! it can't reuse that crate's real TOML parser. Just enough to pull
//! a `key = "value"` string field out of the small, known-shape
//! manifests `nova create` itself generates — not a general TOML
//! parser, and not meant to be one. Shared by `build.rs`, `package.rs`,
//! and `install.rs`, all of which need `id`/`entry_point` at some
//! point in the toolchain.

pub fn extract_toml_string(text: &str, key: &str) -> Option<String> {
    for line in text.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix(key) {
            let rest = rest.trim_start();
            if let Some(rest) = rest.strip_prefix('=') {
                let rest = rest.trim();
                if let Some(inner) = rest.strip_prefix('"').and_then(|s| s.strip_suffix('"')) {
                    return Some(inner.to_string());
                }
            }
        }
    }
    None
}
