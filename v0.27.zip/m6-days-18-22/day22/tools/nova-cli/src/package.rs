//! `nova package <path>` — bundles an already-built app's
//! `nova-app.toml` and compiled binary into one `.npkg` file
//! (`nova_package_format::pack`). Requires `nova build` to have
//! already run (looks for `<path>/target/debug/<bin_name>`); doesn't
//! invoke cargo itself.

use crate::manifest_util::extract_toml_string;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

pub fn run(args: &[String]) -> ExitCode {
    let mut app_path: Option<PathBuf> = None;
    let mut out_override: Option<PathBuf> = None;

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--out" => {
                i += 1;
                out_override = args.get(i).map(PathBuf::from);
            }
            other if !other.starts_with('-') && app_path.is_none() => {
                app_path = Some(PathBuf::from(other));
            }
            other => {
                eprintln!("nova package: unrecognized argument '{other}'");
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    let Some(app_path) = app_path else {
        eprintln!("nova package: missing <path>\nusage: nova package <path-to-app-dir> [--out <file.npkg>]");
        return ExitCode::FAILURE;
    };

    let manifest_toml = app_path.join("nova-app.toml");
    let manifest_text = match fs::read(&manifest_toml) {
        Ok(t) => t,
        Err(e) => {
            eprintln!("nova package: couldn't read {}: {e}", manifest_toml.display());
            return ExitCode::FAILURE;
        }
    };
    let manifest_str = String::from_utf8_lossy(&manifest_text).to_string();
    let Some(id) = extract_toml_string(&manifest_str, "id") else {
        eprintln!("nova package: {} has no `id` field", manifest_toml.display());
        return ExitCode::FAILURE;
    };
    let Some(entry_point) = extract_toml_string(&manifest_str, "entry_point") else {
        eprintln!("nova package: {} has no `entry_point` field", manifest_toml.display());
        return ExitCode::FAILURE;
    };
    let bin_name = match Path::new(&entry_point).file_name() {
        Some(n) => n.to_string_lossy().to_string(),
        None => {
            eprintln!("nova package: couldn't extract a binary name from entry_point '{entry_point}'");
            return ExitCode::FAILURE;
        }
    };

    let built_bin = app_path.join("target").join("debug").join(&bin_name);
    let binary_bytes = match fs::read(&built_bin) {
        Ok(b) => b,
        Err(e) => {
            eprintln!(
                "nova package: couldn't read {} ({e}) -- run `nova build {}` first",
                built_bin.display(),
                app_path.display()
            );
            return ExitCode::FAILURE;
        }
    };

    let packed = nova_package_format::pack(&manifest_text, &binary_bytes);

    let out_path = out_override.unwrap_or_else(|| app_path.join(format!("{}.npkg", id.rsplit('.').next().unwrap_or(&id))));
    if let Err(e) = fs::write(&out_path, &packed) {
        eprintln!("nova package: couldn't write {}: {e}", out_path.display());
        return ExitCode::FAILURE;
    }

    println!("Packaged {id} ({} bytes: {} manifest + {} binary)", packed.len(), manifest_text.len(), binary_bytes.len());
    println!("  {}", out_path.display());
    println!();
    println!("Next: nova install {}", out_path.display());
    ExitCode::SUCCESS
}
