//! `nova run <app_id>` — launches an already-installed app through App
//! Manager and waits for it to complete its Hello/HelloAck handshake.
//!
//! ## The one place `nova-cli` breaks its own "stay standalone" rule
//! Every other subcommand in this crate avoids depending on Nova's
//! own `nova-ipc`/`nova-app-manager`/`nova-fsmgr` (see `main.rs`'s
//! module doc) — a real third-party app developer's toolchain
//! wouldn't link against the platform's own internals just to
//! scaffold or package a file. `run` can't avoid it: there is no
//! separately-running, persistent Nova system daemon this subcommand
//! could instead connect to as a plain client. `nova-ipc` actually
//! already defines a client/daemon management protocol for exactly
//! this (`ListApps`/`AppList`/`LaunchApp`/`LaunchResult`, added Day
//! 12) — but `nova-app-manager`'s `handle_connection` has never
//! implemented the server side of it; those message types have sat
//! unused since Day 12. Building that out is real, future work (most
//! naturally alongside whatever day first introduces persistent
//! system daemons/init supervision), not something to quietly assume
//! already exists.
//!
//! So, honestly, for now: `nova run` starts its **own**, transient
//! `AppManager`, `install()`s the target app from the same
//! `nova_fsmgr::paths::APPS` (`/apps`) location `nova install` writes
//! to by default, `launch()`es it, waits for the handshake, then waits
//! for the app to either exit on its own or `--timeout-secs` to
//! elapse (default 15s) — no real Ctrl-C-to-stop interactivity yet,
//! named rather than faked — then `terminate()`s it and exits. This
//! satisfies the Day 22 DoD (the dev loop working end to end) without
//! pretending a persistent daemon exists when it doesn't.

use nova_app_manager::AppManager;
use nova_ipc::SOCKET_PATH;
use nova_procmgr::ProcessState;
use std::process::ExitCode;
use std::thread;
use std::time::{Duration, Instant};

const DEFAULT_TIMEOUT_SECS: u64 = 15;

pub fn run(args: &[String]) -> ExitCode {
    let mut app_id: Option<String> = None;
    let mut timeout_secs = DEFAULT_TIMEOUT_SECS;

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--timeout-secs" => {
                i += 1;
                match args.get(i).and_then(|v| v.parse::<u64>().ok()) {
                    Some(v) => timeout_secs = v,
                    None => {
                        eprintln!("nova run: --timeout-secs needs a number");
                        return ExitCode::FAILURE;
                    }
                }
            }
            other if !other.starts_with('-') && app_id.is_none() => {
                app_id = Some(other.to_string());
            }
            other => {
                eprintln!("nova run: unrecognized argument '{other}'");
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    let Some(app_id) = app_id else {
        eprintln!("nova run: missing <app-id>\nusage: nova run <app-id> [--timeout-secs <seconds>]");
        return ExitCode::FAILURE;
    };

    if let Err(e) = nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG]) {
        eprintln!("nova run: couldn't prepare Nova's runtime directories: {e}");
        return ExitCode::FAILURE;
    }

    let manager = AppManager::new();
    let _server = match manager.serve(SOCKET_PATH) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("nova run: couldn't start App Manager: {e}");
            return ExitCode::FAILURE;
        }
    };

    if let Err(e) = manager.install(&app_id) {
        eprintln!("nova run: install failed: {e}\n(is {app_id} actually installed under {}? run `nova install` first)", nova_fsmgr::paths::APPS);
        return ExitCode::FAILURE;
    }

    let pid = match manager.launch(&app_id) {
        Ok(pid) => pid,
        Err(e) => {
            eprintln!("nova run: launch failed: {e}");
            return ExitCode::FAILURE;
        }
    };
    println!("Launched {app_id}, pid={pid}");

    let handshake_deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(&app_id).is_none() {
        if Instant::now() >= handshake_deadline {
            eprintln!("nova run: {app_id} did not complete its Hello/HelloAck handshake within 5s");
            let _ = manager.terminate(&app_id);
            return ExitCode::FAILURE;
        }
        thread::sleep(Duration::from_millis(20));
    }
    println!("Connected -- IPC handshake complete, cold-start = {}ms", manager.cold_start_ms(&app_id).unwrap());
    println!(
        "Running (no Ctrl-C-to-stop yet -- waiting up to {timeout_secs}s, or until {app_id} exits on its own)..."
    );

    let run_deadline = Instant::now() + Duration::from_secs(timeout_secs);
    loop {
        let still_running = manager
            .process_list()
            .into_iter()
            .find(|p| p.pid == pid)
            .map(|p| matches!(p.state, ProcessState::Running | ProcessState::Sleeping))
            .unwrap_or(false);
        if !still_running {
            println!("{app_id} exited on its own");
            break;
        }
        if Instant::now() >= run_deadline {
            println!("Timeout reached -- stopping {app_id}");
            break;
        }
        thread::sleep(Duration::from_millis(100));
    }

    let _ = manager.terminate(&app_id);
    println!("Stopped {app_id}");
    ExitCode::SUCCESS
}
