//! Nova OS Day 22 live acceptance.
//!
//! DoD: "The full `create -> build -> package -> install -> run` loop
//! works end to end for a fresh app on the first try... Acceptance:
//! build a genuinely new (not previously-existing) test app from
//! `nova create` through `nova run` using only the SDK, no
//! hand-editing of generated boilerplate."
//!
//! Every step below is a real subprocess invocation of the actual
//! `nova` binary — not a re-implementation of any subcommand's logic
//! in-process, and nothing in this file ever opens or rewrites a file
//! any `nova` subcommand generated. The app name (`day22_demo_app`) is
//! deliberately different from every previous day's test app names
//! (Day 18's `test_app`, Days 19-21's `*test` apps) to satisfy
//! "genuinely new."

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode};

const APP_NAME: &str = "day22_demo_app";
const APP_ID: &str = "org.nova.day22_demo_app";
const BIN_NAME: &str = "day22-demo-app";

fn fail(msg: impl AsRef<str>) -> ExitCode {
    eprintln!("FAIL: {}", msg.as_ref());
    ExitCode::FAILURE
}

fn run_step(nova_bin: &Path, label: &str, args: &[&str]) -> Option<ExitCode> {
    println!("--- {label} ---");
    println!("$ nova {}", args.join(" "));
    match Command::new(nova_bin).args(args).status() {
        Ok(s) if s.success() => {
            println!();
            None
        }
        Ok(s) => Some(fail(format!("{label} exited with {s}"))),
        Err(e) => Some(fail(format!("couldn't run `nova {}`: {e}", args.join(" ")))),
    }
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 22: full create -> build -> package -> install -> run loop ===");
    println!();

    let mut nova_bin = match std::env::current_exe() {
        Ok(p) => p,
        Err(e) => return fail(format!("current_exe: {e}")),
    };
    nova_bin.pop(); // .../target/debug/
    let target_debug = nova_bin.clone();
    nova_bin.push("nova");
    if !nova_bin.is_file() {
        return fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", nova_bin.display()));
    }

    let repo_root = match target_debug.parent().and_then(Path::parent) {
        Some(p) => p.to_path_buf(),
        None => return fail("couldn't derive repo root from current_exe's path"),
    };
    let libs_path = repo_root.join("libs");
    if !libs_path.join("nova-app-runtime").is_dir() {
        return fail(format!("expected {} to contain nova-app-runtime", libs_path.display()));
    }

    let workdir = PathBuf::from("/tmp").join(format!("nova-day22-test-{}", std::process::id()));
    if workdir.exists() {
        let _ = fs::remove_dir_all(&workdir);
    }
    if let Err(e) = fs::create_dir_all(&workdir) {
        return fail(format!("mkdir {}: {e}", workdir.display()));
    }
    let app_dir = workdir.join(APP_NAME);
    let npkg_path = workdir.join(format!("{APP_NAME}.npkg"));

    // --- 1. nova create ---
    let app_dir_str = app_dir.to_string_lossy().to_string();
    let libs_path_str = libs_path.to_string_lossy().to_string();
    if let Some(code) =
        run_step(&nova_bin, "1/5 nova create", &["create", APP_NAME, "--out", &app_dir_str, "--libs-path", &libs_path_str])
    {
        return code;
    }
    for expected in ["Cargo.toml", "nova-app.toml", "src/main.rs", "README.md"] {
        if !app_dir.join(expected).is_file() {
            return fail(format!("nova create didn't produce {}", app_dir.join(expected).display()));
        }
    }
    println!("VERIFIED: skeleton generated at {}", app_dir.display());
    println!();

    // --- 2. nova build ---
    if let Some(code) = run_step(&nova_bin, "2/5 nova build", &["build", &app_dir_str]) {
        return code;
    }
    let built_bin = app_dir.join("target").join("debug").join(BIN_NAME);
    if !built_bin.is_file() {
        return fail(format!("nova build didn't produce {}", built_bin.display()));
    }
    println!("VERIFIED: {} exists", built_bin.display());
    println!();

    // --- 3. nova package ---
    let npkg_path_str = npkg_path.to_string_lossy().to_string();
    if let Some(code) = run_step(&nova_bin, "3/5 nova package", &["package", &app_dir_str, "--out", &npkg_path_str]) {
        return code;
    }
    let packed_bytes = match fs::read(&npkg_path) {
        Ok(b) => b,
        Err(e) => return fail(format!("nova package didn't produce a readable {}: {e}", npkg_path.display())),
    };
    let (manifest_bytes, binary_bytes) = match nova_package_format::unpack(&packed_bytes) {
        Ok(v) => v,
        Err(e) => return fail(format!("{} is not a valid .npkg: {e}", npkg_path.display())),
    };
    if !String::from_utf8_lossy(&manifest_bytes).contains(APP_ID) {
        return fail(format!(".npkg manifest doesn't mention {APP_ID}"));
    }
    if binary_bytes != fs::read(&built_bin).unwrap_or_default() {
        return fail(".npkg binary bytes don't match the binary nova build produced".to_string());
    }
    println!("VERIFIED: {} unpacks to a manifest naming {APP_ID} and the exact binary nova build produced", npkg_path.display());
    println!();

    // --- 4. nova install ---
    let _ = fs::remove_dir_all(Path::new(nova_fsmgr::paths::APPS).join(APP_ID)); // clean slate
    if let Some(code) = run_step(&nova_bin, "4/5 nova install", &["install", &npkg_path_str]) {
        return code;
    }
    let installed_manifest = Path::new(nova_fsmgr::paths::APPS).join(APP_ID).join("nova-app.toml");
    let installed_bin = Path::new(nova_fsmgr::paths::APPS).join(APP_ID).join("bin").join(BIN_NAME);
    if !installed_manifest.is_file() || !installed_bin.is_file() {
        return fail(format!("nova install didn't produce {} + {}", installed_manifest.display(), installed_bin.display()));
    }
    println!("VERIFIED: installed to {} and {}", installed_manifest.display(), installed_bin.display());
    println!();

    // --- 5. nova run ---
    if let Some(code) = run_step(&nova_bin, "5/5 nova run", &["run", APP_ID, "--timeout-secs", "5"]) {
        return code;
    }
    println!("VERIFIED: nova run exited successfully -- the app installed and launched through App Manager,");
    println!("          completed its IPC handshake, ran, and was stopped cleanly");
    println!();

    // Cleanup
    let _ = fs::remove_dir_all(&workdir);
    let _ = fs::remove_dir_all(Path::new(nova_fsmgr::paths::APPS).join(APP_ID));

    println!("=== Day 22 ACCEPTANCE: PASS ===");
    println!("create -> build -> package -> install -> run worked end to end for a genuinely");
    println!("new app ({APP_ID}), using only the `nova` SDK CLI, with zero hand-editing of any");
    println!("generated file.");
    ExitCode::SUCCESS
}
