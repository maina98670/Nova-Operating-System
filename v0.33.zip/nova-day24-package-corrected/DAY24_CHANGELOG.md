# Day 24 Change Log

Base: `nova-day23-package.zip`

1. Added `libs/nova-shell-core` — `Shell<B: WaylandBackend>`:
   `ShellState` (Locked/Home), `unlock`/`lock` (updates real window
   title), `installed_apps()` (from `AppManager::list_apps()`),
   `launch_app()` (from `AppManager::launch()`, gated by lock state).
   5 unit tests using `nova-window-api`'s `StubBackend`.
2. Added `tools/nova-shell` — the standalone shell process: owns its
   own `AppManager` + `CompositorServer` (the shell is the session
   host, not something App Manager launches), discovers/installs apps
   already present under `/apps`, creates its lock-screen window on
   the real compositor, reads `list`/`unlock`/`lock`/`launch <id>`/
   `quit` from stdin as an honestly temporary control surface (real
   input is Day 27's job).
3. Added `tools/nova-day24-shell-acceptance-test` — the literal DoD:
   installs all six real apps unmodified, drives the shell from
   cold-boot `Locked` (real state + real window title on the real
   compositor) through a blocked launch attempt, `unlock()` to `Home`
   (again real state + title), lists all six via the launcher,
   launches all six via the launcher, confirms each completes a real
   IPC handshake, cross-checks against M4's Process Manager.
4. Updated the workspace `Cargo.toml` with one new lib and two new
   tools.

`apps/org.nova.shell` was considered and rejected as the location for
the shell binary — the shell owns/starts App Manager and the
compositor rather than being launched by them, so it doesn't fit the
`apps/` convention (every existing entry there is something App
Manager installs and launches); it lives under `tools/` instead, next
to `nova-cli` and the acceptance tests.

Named but not built in this delivery: any real authentication (trivial
`unlock()`, not in this day's DoD); any real touch-driven unlock (Day
27, per the Roadmap's own sequencing); any real rendering (still no
GPU/display, same as Day 23).

Day 25 (Status bar + Settings integration) is next.
