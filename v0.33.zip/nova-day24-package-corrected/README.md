# Nova OS — Day 24 Package: Desktop Shell + Launcher

This package continues directly from the Day 23 package (M7 started).
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day24-build_and_run.sh` yourself to actually confirm it.

## Day 24 goal

Per the Complete Build Guide:
1. Lock screen and home screen (the original architecture guide's M4
   scope, now correctly sequenced after a real compositor exists).
2. App launcher listing installed packages via M5's App Manager /
   package manifest data.

DoD: from a cold boot, the lock screen appears, unlocking reaches the
home screen, and the launcher lists and can start every
currently-installed app (Settings, Contacts, Messages, Dialer, Camera,
Hello-world).

## What's real, what isn't

Same boundary Day 23 drew for the compositor: no GPU, no display,
nothing gets rendered as pixels. "The lock screen appears" and
"unlocking reaches the home screen" are represented as **real state**
(`ShellState::Locked`/`Home`) plus a **real title change on the
shell's actual window on the real Day 23 compositor** — externally
verifiable, just not visually. Listing and starting apps is fully
real: real `AppManager::list_apps()` data, real `AppManager::launch()`
calls, real IPC handshakes.

**Authentication is honestly trivial** — `unlock()` always succeeds.
Not in this day's DoD, and no PIN/biometric system exists anywhere in
this repo; what's real is the state-transition and access-control
machinery around it (locked screens can't launch apps), which a real
auth check could plug into later without touching anything else.

**No real touch input drives this yet, on purpose** — the Roadmap
itself sequences the real input pipeline for Day 27, after this day.
`tools/nova-shell` reads plain commands from stdin as an honestly
temporary stand-in control surface until then.

## What's new

- **`libs/nova-shell-core`** — `Shell<B: WaylandBackend>`: `Locked`/
  `Home` state, its own window (generic over the backend — `StubBackend`
  in this crate's own unit tests, the real `CompositorClientBackend`
  live), `installed_apps()` (straight from `AppManager::list_apps()`),
  and `launch_app()` (straight from `AppManager::launch()`, gated to
  fail with `ShellError::Locked` outside `Home` state). The shell is a
  privileged system component — it holds a direct `AppManager` handle
  (a cheap `Arc` clone) rather than going through IPC, since there's
  no persistent daemon for it to instead be a mere client of (the same
  gap Day 22's `nova run` already named — the shell is the thing that
  would eventually own that role). 5 unit tests.
- **`tools/nova-shell`** — the standalone shell process: starts its
  own App Manager and Compositor, discovers and installs whatever
  apps are already present under `/apps`, creates its own lock-screen
  window on the real compositor, then accepts `list`/`unlock`/`lock`/
  `launch <id>`/`quit` on stdin.
- **`tools/nova-day24-shell-acceptance-test`** — the literal DoD:
  installs all six real apps (Settings, Contacts, Messages, Dialer,
  Camera, Hello-world — all built Days 16-17, unmodified), confirms
  cold-boot `Locked` state with the real window titled "Nova Lock
  Screen", confirms launching is blocked while locked, unlocks and
  confirms `Home` state with the window retitled "Nova Home", confirms
  the launcher lists all six, then actually starts all six through the
  launcher and confirms each completes its own real IPC handshake with
  App Manager, cross-checked against M4's Process Manager.

## Run

```bash
./nova-day24-build_and_run.sh
```

Builds the workspace, runs `nova-shell-core`'s unit tests, then the
live acceptance test. Needs the same root-capable Linux environment as
the Days 11–23 live tests.

Try the interactive shell directly once built:

```bash
./target/debug/nova-shell
```

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction.
