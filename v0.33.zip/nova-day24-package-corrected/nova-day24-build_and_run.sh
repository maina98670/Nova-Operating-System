#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 24: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 24: nova-shell-core unit tests ==="
cargo test -p nova-shell-core

echo
echo "=== Nova OS Day 24: live acceptance ==="
echo "Installs all six real apps, drives the shell from cold-boot lock screen through"
echo "unlock to launching every app for real. Needs the same root-capable Linux"
echo "environment as the Day 11-23 live tests."
cargo run -p nova-day24-shell-acceptance-test

echo
echo "Day 24 build + tests + live acceptance completed."
echo
echo "Try the shell yourself (interactive stdin control -- see tools/nova-shell's"
echo "module doc for why that's a temporary stand-in, not the real input pipeline):"
echo "  ./target/debug/nova-shell"
