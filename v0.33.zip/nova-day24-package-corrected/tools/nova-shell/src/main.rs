//! `nova-shell` — the standalone desktop shell process.
//!
//! Starts its own [`AppManager`] and [`CompositorServer`] (the shell
//! is the session host — see `nova-shell-core`'s own module doc for
//! why it owns these rather than connecting to already-running ones;
//! there's no persistent system daemon for it to instead be a client
//! of, same gap Day 22's `nova run` already named), discovers and
//! installs whatever apps are already present under
//! `nova_fsmgr::paths::APPS`, creates its own lock-screen window on
//! the real compositor, then reads simple commands from stdin.
//!
//! ## The stdin command loop is an honest, temporary stand-in
//! There is no real touch input pipeline until Day 27 — that's the
//! Roadmap's own sequencing, not a shortcut taken here. Rather than
//! block forever with nothing to drive `unlock`/`launch` at all,
//! `nova-shell` accepts plain-text commands on stdin as a **visibly
//! temporary** control surface: `list`, `unlock`, `lock`, `launch
//! <app-id>`, `quit`. Day 27's job is wiring a real tap gesture to
//! call the exact same `Shell` methods these commands already call —
//! not rebuilding the shell logic itself.

use nova_app_manager::AppManager;
use nova_compositor_core::client::CompositorClientBackend;
use nova_compositor_core::server::CompositorServer;
use nova_ipc::SOCKET_PATH;
use nova_shell_core::Shell;
use nova_window_api::Window;
use std::fs;
use std::io::{self, BufRead, Write};
use std::process;

const SHELL_APP_ID: &str = "org.nova.shell";
const DEFAULT_OUTPUT: u32 = 1;

fn main() {
    println!("nova-shell starting");

    if let Err(e) = nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG]) {
        eprintln!("nova-shell: couldn't prepare Nova's runtime directories: {e}");
        process::exit(1);
    }

    let manager = AppManager::new();
    let _app_server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| {
        eprintln!("nova-shell: couldn't start App Manager: {e}");
        process::exit(1);
    });

    let compositor = CompositorServer::new();
    let _compositor_server = compositor.serve(nova_compositor_core::protocol::SOCKET_PATH).unwrap_or_else(|e| {
        eprintln!("nova-shell: couldn't start the compositor: {e}");
        process::exit(1);
    });
    let output = compositor.create_output("output-0", 1080, 2400);
    println!("compositor output ready: {output:?}");

    let installed = discover_and_install(&manager);
    println!("discovered and installed {installed} app(s) from {}", nova_fsmgr::paths::APPS);

    let backend = CompositorClientBackend::connect_default(SHELL_APP_ID, DEFAULT_OUTPUT).unwrap_or_else(|e| {
        eprintln!("nova-shell: couldn't connect to its own compositor: {e}");
        process::exit(1);
    });
    let window = Window::create(backend, "unused-initial-title", 1080, 2400).unwrap_or_else(|e| {
        eprintln!("nova-shell: couldn't create its own window: {e}");
        process::exit(1);
    });

    let mut shell = Shell::new(manager, window).unwrap_or_else(|e| {
        eprintln!("nova-shell: couldn't initialize: {e}");
        process::exit(1);
    });
    println!("{:?} -- lock screen showing", shell.state());

    command_loop(&mut shell);
    println!("nova-shell exiting");
}

fn discover_and_install(manager: &AppManager) -> usize {
    let mut count = 0;
    let entries = match fs::read_dir(nova_fsmgr::paths::APPS) {
        Ok(e) => e,
        Err(_) => return 0, // nothing installed anywhere yet -- not an error
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        if !path.join("nova-app.toml").is_file() {
            continue;
        }
        let Some(id) = path.file_name().map(|n| n.to_string_lossy().to_string()) else { continue };
        match manager.install(&id) {
            Ok(()) => count += 1,
            Err(e) => eprintln!("nova-shell: couldn't install {id}, skipping: {e}"),
        }
    }
    count
}

fn command_loop<B: nova_window_api::WaylandBackend>(shell: &mut Shell<B>) {
    println!("commands: list | unlock | lock | launch <app-id> | quit");
    let stdin = io::stdin();
    loop {
        print!("nova-shell> ");
        let _ = io::stdout().flush();
        let mut line = String::new();
        if stdin.lock().read_line(&mut line).unwrap_or(0) == 0 {
            break; // stdin closed
        }
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        match line.split_once(' ').unwrap_or((line, "")) {
            ("list", _) => {
                for app in shell.installed_apps() {
                    println!("  {} ({})", app.id, app.name);
                }
            }
            ("unlock", _) => match shell.unlock() {
                Ok(()) => println!("{:?}", shell.state()),
                Err(e) => eprintln!("unlock failed: {e}"),
            },
            ("lock", _) => match shell.lock() {
                Ok(()) => println!("{:?}", shell.state()),
                Err(e) => eprintln!("lock failed: {e}"),
            },
            ("launch", app_id) if !app_id.is_empty() => match shell.launch_app(app_id) {
                Ok(pid) => println!("launched {app_id}, pid={pid}"),
                Err(e) => eprintln!("launch failed: {e}"),
            },
            ("quit", _) | ("exit", _) => break,
            (other, _) => eprintln!("unknown command: {other} (try: list | unlock | lock | launch <app-id> | quit)"),
        }
    }
}
