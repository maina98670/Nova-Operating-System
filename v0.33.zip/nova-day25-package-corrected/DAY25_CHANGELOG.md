# Day 25 Change Log

Base: `nova-day24-package.zip`

1. Removed a stray leftover file (`system/nova-shell/Cargo.toml`) that
   had carried forward from an earlier interrupted attempt at Day 24 —
   not a workspace member, didn't affect any build, but was clutter.
2. Added `libs/nova-shell-core/src/statusbar.rs` — `StatusBar`/
   `StatusBarState`, `BatteryStatus`/`ConnectivityStatus` (honest
   `Unavailable`-only placeholders), pure `format_time`. 3 unit tests.
3. Extended `libs/nova-shell-core`'s `Shell`: owns a `StatusBar`
   (`status_bar()`/`refresh_status_bar()`), added
   `open_quick_settings()` (dedicated entry point to
   `SETTINGS_APP_ID`, distinct from `launch_app()`, same lock gate).
   2 new unit tests.
4. Extended `tools/nova-shell`'s stdin commands: `status`, `settings`.
5. Added `tools/nova-day25-statusbar-settings-acceptance-test` — the
   literal DoD: real ~1.1s wait proving the status bar's time actually
   advances; honest-placeholder check for battery/connectivity;
   quick-settings lock gate; Settings opened via quick settings
   specifically (not the generic launcher), confirmed via a real IPC
   handshake and cross-checked against M4's Process Manager.
6. Updated the workspace `Cargo.toml` with one new tool (the shell
   core/binary/Day-24-test entries already existed from Day 24).

Day 26 (File manager, built against M6's Storage API) is next.
