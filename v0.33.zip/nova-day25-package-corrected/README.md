# Nova OS — Day 25 Package: Status Bar + Settings Integration

This package continues directly from the Day 24 package (M7).
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day25-build_and_run.sh` yourself to actually confirm it.

## Day 25 goal

Per the Complete Build Guide:
1. Status bar (time, battery placeholder until M9's power HAL exists,
   connectivity placeholder until M8).
2. Wire the existing Settings app into the shell (accessible from
   status bar / quick settings, not just standalone launch).

DoD: the status bar renders live, updating time at minimum, and
Settings is reachable from within the shell UI, not only by direct
process launch.

## What's real, what isn't

**Time is real.** Wall-clock time doesn't depend on any not-yet-built
subsystem — `StatusBar::refresh()` re-reads the real system clock
every call. "Renders live" is proven by the acceptance test actually
waiting past a real one-second boundary and confirming the time string
changed.

**Battery and connectivity are honest placeholders**, not fabricated
data — `BatteryStatus::Unavailable`/`ConnectivityStatus::Unavailable`
are the only values either enum has, since M9 (power HAL) and M8
(networking) don't exist yet. Same pattern as `nova-input-api`'s
`NotYetAvailable` and `nova-network-api`'s `NotImplemented`.

**No real screen, still.** Same boundary every M7 day has drawn since
Day 23 — there's no GPU or display in this environment. The status
bar's state is real and queryable; nothing renders it as pixels.

## What's new

- **`libs/nova-shell-core/src/statusbar.rs`** — `StatusBar`/
  `StatusBarState`, `BatteryStatus`, `ConnectivityStatus`, a pure
  `format_time` (independently unit-tested against fixed durations,
  separate from the "does it actually change over real time" property,
  which only the live acceptance test can honestly prove). 3 unit
  tests.
- **`libs/nova-shell-core`**: `Shell` now owns a `StatusBar`
  (`status_bar()`/`refresh_status_bar()`), and gets
  `open_quick_settings()` — a dedicated entry point to
  `SETTINGS_APP_ID`, distinct from the generic `launch_app()` Day 24
  already proved, gated by lock state the same way. 2 new unit tests.
- **`tools/nova-shell`**: stdin commands `status` and `settings`
  added, alongside Day 24's `list`/`unlock`/`lock`/`launch`.
- **`tools/nova-day25-statusbar-settings-acceptance-test`** — the
  literal DoD: reads the status bar time, sleeps ~1.1 real seconds,
  refreshes, confirms the time actually changed; confirms battery/
  connectivity are the honest placeholder, not fabricated data;
  confirms quick settings is blocked while locked; unlocks and opens
  Settings via quick settings specifically (not the generic launcher),
  confirmed via Settings' own real IPC handshake and cross-checked
  against M4's Process Manager.

## Also fixed

A stray leftover file from an earlier interrupted attempt
(`system/nova-shell/Cargo.toml`, an abandoned draft from before
settling on `tools/nova-shell/` as the shell binary's home) had
carried forward into the Day 24 package. Removed here — it wasn't a
workspace member and didn't affect any build, but it was clutter that
shouldn't ship.

## Run

```bash
./nova-day25-build_and_run.sh
```

Builds the workspace, runs `nova-shell-core`'s unit tests, then the
live acceptance test. Needs the same root-capable Linux environment as
the Days 11–24 live tests.

Try the interactive shell directly once built:

```bash
./target/debug/nova-shell
> status
> unlock
> settings
```

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction.
