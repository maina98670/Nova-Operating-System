#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 25: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 25: nova-shell-core unit tests (incl. status bar) ==="
cargo test -p nova-shell-core

echo
echo "=== Nova OS Day 25: live acceptance ==="
echo "Confirms the status bar's time actually advances across a real wait, and that"
echo "Settings is reachable from the shell's own quick-settings entry point. Needs the"
echo "same root-capable Linux environment as the Day 11-24 live tests."
cargo run -p nova-day25-statusbar-settings-acceptance-test

echo
echo "Day 25 build + tests + live acceptance completed."
echo
echo "Try the shell yourself:"
echo "  ./target/debug/nova-shell"
echo "  > status"
echo "  > unlock"
echo "  > settings"
