# Day 26 Change Log

Base: `nova-day25-package.zip`

1. **Fixed a real gap in `libs/nova-storage-api`**: `read`/`write`/
   `delete` did not actually route through `nova_fsmgr` despite this
   crate's own docs claiming to be "built on M4's Filesystem Manager"
   since Day 20 (`read`/`write` went through `SandboxPolicy::read_scoped`/
   `write_scoped`, which call raw `std::fs` internally; `delete`/`list`
   called raw `std::fs` directly). Surfaced by Day 26's own DoD wording
   ("the deletion actually reflected via M4's Filesystem Manager").
   Now: `scoped_path` (Day 15) resolves the path, `nova_fsmgr::read_file`/
   `write_file`/`delete_file` (Day 4) do the actual I/O. `list` still
   uses `std::fs::read_dir` directly — named in the module docs, since
   `nova_fsmgr` has no directory-listing function.
2. Added a new `nova-storage-api` unit test,
   `deletion_is_reflected_via_nova_fsmgr_independently` — calls
   `nova_fsmgr::read_file` directly (not through `StorageApi` again)
   to confirm deletes are visible outside the API that performed them.
3. Added `apps/org.nova.filemanager` — seeds `test-file.txt` +
   `readme.txt` on first run, then browses/opens/deletes
   `test-file.txt`, confirming each step and that the deleted file no
   longer appears in its own browse listing.
4. Added `tools/nova-day26-filemanager-acceptance-test` — the literal
   DoD, verified independently via `nova_fsmgr::read_file` called
   directly by the test tool (not the app, not `StorageApi` asked
   again), including confirming the delete was selective (the other
   seeded file survives untouched).
5. Updated the workspace `Cargo.toml` with one new app and one new
   tool (`nova-storage-api`'s Cargo.toml also gained an explicit
   `nova-fsmgr` dependency).

Day 27 (Real input pipeline: touch/keyboard/pointer wired to
`nova-input-api`, and to the shell's `unlock`/`lock`) is next — the
milestone `nova-shell-core`'s own module docs have been pointing at
since Day 24.
