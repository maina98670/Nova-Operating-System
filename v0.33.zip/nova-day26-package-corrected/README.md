# Nova OS — Day 26 Package: File Manager

This package continues directly from the Day 25 package (M7).
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day26-build_and_run.sh` yourself to actually confirm it.

## Day 26 goal

Per the Complete Build Guide: a minimal file manager app built against
M6's SDK (Storage API) — browse, open, delete within permission scope.

DoD: the file manager lists a real directory's contents through the
Storage API and can delete a test file, with the deletion actually
reflected via M4's Filesystem Manager.

## A real gap found and fixed, not just a new app added

Reading `nova-storage-api`'s own docs while building this app surfaced
something real: despite claiming since Day 20 to be "built on M4's
Filesystem Manager," `read`/`write` actually went through
`SandboxPolicy::read_scoped`/`write_scoped` (raw `std::fs` internally),
and `delete`/`list` called raw `std::fs` directly — **`nova_fsmgr` was
never actually in the loop for any of it.** The Day 26 DoD's specific
wording — "the deletion actually reflected via M4's Filesystem
Manager" — is what surfaced this; it's not something that could pass
honestly without fixing it first.

Fixed in this delivery: `read`/`write`/`delete` now resolve the path
via `SandboxPolicy::scoped_path` (Day 15, for safety) and then call
`nova_fsmgr::read_file`/`write_file`/`delete_file` (Day 4) directly —
the real Filesystem Manager, not a bypass of it. `list` still uses
`std::fs::read_dir` directly, named explicitly in the module docs,
since `nova_fsmgr` has no directory-listing function of its own (Day
4's scope was file CRUD + mount, not enumeration).

## What's new

- **`libs/nova-storage-api`** (revised) — `read`/`write`/`delete` now
  genuinely route through `nova_fsmgr`. Added a new unit test,
  `deletion_is_reflected_via_nova_fsmgr_independently`, which calls
  `nova_fsmgr::read_file` directly (not through `StorageApi` again) to
  confirm a delete is visible outside the API that performed it — the
  same independence standard the live acceptance test uses.
- **`apps/org.nova.filemanager`** — seeds a couple of files on first
  run (including `test-file.txt`, the DoD's own "test file"), then
  browses (`list`), opens (`read`), and deletes it, printing each
  step. Confirms its own browse listing no longer shows the deleted
  file afterward.
- **`tools/nova-day26-filemanager-acceptance-test`** — the literal
  DoD, verified independently: after the file manager runs, this test
  constructs the same scoped path itself and calls
  `nova_fsmgr::read_file` directly — not asking the app, and not
  asking `StorageApi` a second time — to confirm `test-file.txt` is
  actually gone, and that the *other* seeded file (`readme.txt`) is
  untouched, proving the delete was selective, not a directory wipe.

## Run

```bash
./nova-day26-build_and_run.sh
```

Builds the workspace, runs `nova-storage-api`'s unit tests (including
the new fsmgr-independence test), then the live acceptance test. Needs
the same root-capable Linux environment as the Days 11–25 live tests.

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction.
