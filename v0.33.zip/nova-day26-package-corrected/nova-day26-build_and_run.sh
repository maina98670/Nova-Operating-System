#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 26: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 26: nova-storage-api unit tests (incl. the fsmgr-routing fix) ==="
cargo test -p nova-storage-api

echo
echo "=== Nova OS Day 26: live acceptance ==="
echo "Installs and launches nova-filemanager, then independently verifies its delete"
echo "via nova_fsmgr::read_file called directly by the test tool. Needs the same"
echo "root-capable Linux environment as the Day 11-25 live tests."
cargo run -p nova-day26-filemanager-acceptance-test

echo
echo "Day 26 build + tests + live acceptance completed."
