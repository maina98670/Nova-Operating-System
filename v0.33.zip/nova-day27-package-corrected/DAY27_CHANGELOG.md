# Day 27 Change Log

Base: `nova-day26-package.zip`

1. Added `libs/nova-ipc`: `SeqPacketSocket::try_recv_bytes` (non-blocking,
   `MSG_DONTWAIT`) alongside the existing blocking `recv_bytes`.
2. Extended `libs/nova-compositor-core`:
   - `model.rs`: `Output.focused: Option<SurfaceId>`, `Rect::contains`.
   - `compositor.rs`: `hit_test`, `focus`, `focused_surface`;
     `close_surface` now clears focus if the closed surface held it.
     5 new unit tests.
   - `protocol.rs`: `RegisterInputSink`, `InputTouch`, `InputPointer`,
     `InputKey` (server -> client pushes on a dedicated connection,
     separate from window management — documented why). Roundtrip
     tests added for all four.
   - `server.rs`: restructured `Inner` to track `app_id -> input-sink
     connection`; added `inject_touch`/`inject_pointer`/`inject_key`/
     `has_input_sink`/`focused_surface`.
   - `input.rs` (new): `CompositorInputSource`, a real
     `nova_input_api::InputSource` implementation.
3. Extended `libs/nova-input-api`: `InputError::Disconnected` (real
   connection-loss, distinct from `NotYetAvailable`); `UnavailableSource`
   unchanged.
4. **Fixed a real gap in `libs/nova-window-api`**: no way to
   reposition a window after creation meant two apps' windows always
   landed on top of each other. Added `x`/`y` to `WindowState` and
   `move_to` to `WaylandBackend`/`Window<B>`/`StubBackend`/
   `CompositorClientBackend`. Updated existing tests for the new
   field; added 1 new test.
5. Rewrote `apps/org.nova.dialer`: real window, real 4-region keypad,
   real input polling loop, wired to the existing `CallLog::place_call`.
6. Rewrote `apps/org.nova.camera`: real window (moved via `move_to` to
   avoid overlapping Dialer's), real shutter region, wired to the
   existing `PhotoLibrary::capture`.
7. Added `tools/nova-day27-input-pipeline-acceptance-test` — the
   literal DoD, with the honesty note (no keypad/shutter existed
   before today, per Day 16's own scoping) stated once, plainly, at
   the top of its own module doc and this README, not buried.
8. Updated the workspace `Cargo.toml` with one new tool
   (`nova-compositor-core`, `nova-dialer`, and `nova-camera`'s
   `Cargo.toml` files also gained new dependencies, already reflected
   in their own files).

Day 28 (Theme/accessibility foundation, full-shell acceptance from
cold boot through touch interaction, tag M7 — the final day of this
milestone) is next.
