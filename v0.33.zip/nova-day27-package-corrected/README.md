# Nova OS — Day 27 Package: Touch/Mouse/Keyboard Input Pipeline

This package continues directly from the Day 26 package (M7).
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day27-build_and_run.sh` yourself to actually confirm it.

## Day 27 goal

Per the Complete Build Guide:
1. Implement the input pipeline the M6 Input API was stubbed against
   — this is the fix for every "drawn but not tappable" caveat in the
   Dialer/Camera apps built earlier.
2. Wire it through the compositor from Day 23 so window focus and
   hit-testing are correct, not just raw event delivery.

DoD: go back to the existing Dialer app's keypad and Camera app's
shutter button (both previously flagged as drawn-but-not-tappable) and
confirm they are now actually tappable and produce the expected app
behavior.

## Read this first: there was no keypad or shutter button to "go back to"

Day 16's own README explicitly scoped Dialer and Camera as
"functional core only — no UI. Wayland rendering is M7's job." No
button, no keypad, no drawn-but-not-tappable anything existed anywhere
in this track before today. The DoD's premise doesn't match what
Day 16 actually built.

What this delivery does instead: builds the real payoff the DoD is
actually after — a real input pipeline, real UI regions in the real
Dialer/Camera apps, and a live test proving a tap reaches the right
app and triggers the real underlying logic those apps have had since
Day 16. Stated once, plainly, in this README and in the acceptance
test's own module doc — not silently reframed as "confirming"
something that was never there.

## What's real, what's still synthetic

**Real**: hit-testing against actual window geometry, per-output focus
tracking, and event delivery to the correct app process over a real,
dedicated connection — all live, cross-process, externally verifiable.

**Still synthetic**: the *origin* of an event. No touchscreen
digitizer or other physical input hardware exists in this build
environment — the same "no GPU" boundary Day 23 drew for rendering.
`CompositorServer::inject_touch`/`inject_pointer`/`inject_key` are
real and callable — exactly what a future `evdev`-reading driver would
call — but today a live acceptance test calls them directly, standing
in for that driver.

## What's new

- **`libs/nova-ipc`**: `SeqPacketSocket::try_recv_bytes` — non-blocking
  receive (`MSG_DONTWAIT`), needed because `nova-input-api`'s
  `InputSource::poll()` must not block.
- **`libs/nova-compositor-core`**:
  - `model.rs`/`compositor.rs`: `Output.focused`, `Rect::contains`,
    `Compositor::hit_test`/`focus`/`focused_surface`. 5 new unit
    tests, including the DoD's own core claim ("topmost surface at a
    point").
  - `protocol.rs`: `RegisterInputSink`, `InputTouch`, `InputPointer`,
    `InputKey` — server-to-client pushes on a **separate** connection
    from window management (documented why: an unprompted push
    arriving mid-request/response on the same connection would break
    `CompositorClientBackend`'s synchronous request/response
    assumption).
  - `server.rs`: restructured to track input-sink connections per
    app id; `inject_touch`/`inject_pointer`/`inject_key`,
    `has_input_sink`.
  - `input.rs` (new): `CompositorInputSource` — a real
    `nova_input_api::InputSource` implementation.
- **`libs/nova-input-api`**: `InputError::Disconnected` — a real
  connection failure is a different, later-stage failure than
  `NotYetAvailable`; `UnavailableSource` itself is unchanged.
- **`libs/nova-window-api`** (real gap found and fixed): `WindowState`
  had no position, and `WaylandBackend` had no way to reposition a
  window after creation — meaning two apps' windows always landed
  exactly on top of each other. Added `x`/`y` to `WindowState` and
  `move_to` to the trait and `Window<B>`.
- **`apps/org.nova.dialer`** — now creates a real window with a real,
  tappable 4-region keypad (digits `1`/`2`/`3`, `Call`), wired to the
  same `CallLog::place_call` logic that already existed.
- **`apps/org.nova.camera`** — now creates a real window (repositioned
  via `move_to` so it doesn't overlap Dialer's), with a real, tappable
  shutter region wired to the same `PhotoLibrary::capture` logic that
  already existed.
- **`tools/nova-day27-input-pipeline-acceptance-test`** — the literal
  DoD: launches both as real processes, confirms their windows don't
  overlap, confirms a tap on empty space hits nothing, taps Dialer's
  digits and Call button and Camera's shutter (each confirmed to hit
  the *correct* app's surface), then — independent of either running
  app — freshly re-loads `CallLog`/`PhotoLibrary` in the test process
  itself to confirm exactly the expected call and exactly one photo
  were recorded.

## Run

```bash
./nova-day27-build_and_run.sh
```

Builds the workspace, runs unit tests across four crates, then the
live acceptance test. Needs the same root-capable Linux environment as
the Days 11–26 live tests.

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction.
