# Day 28 Change Log

Base: `nova-day27-package.zip`. Final day of M7.

1. Added `libs/nova-theme` — `Color`, `Typography`, `Theme`,
   `nova_theme::DEFAULT`, `TextScale` (validated 80-200%, real
   `apply()` rounding). 5 unit tests.
2. Extended `libs/nova-settings-core`: `text_scale` setting (default
   100%, bounds shared with `TextScale::MIN_PERCENT`/`MAX_PERCENT`
   exactly). 1 new unit test. New `nova-theme` dependency.
3. Extended `apps/org.nova.settings`: demos `text_scale` set (happy
   path + rejected out-of-range), matching the existing
   `display_brightness` demo pattern.
4. Extended `libs/nova-shell-core`: `Shell::theme()` returning
   `&nova_theme::DEFAULT`. 1 new unit test. New `nova-theme` dependency.
5. Added `docs/theme-v1.md` — theme resource reference, including the
   honest "cannot prove visual consistency without rendering" scope.
6. Added `docs/accessibility-plan-v1.md` — what's real (text scaling)
   and what's deferred, with a reason for each deferred item.
7. Added `docs/M7-TAG.md` — the M7 (`v0.33`) tag writeup covering
   Days 23-28.
8. Added `tools/nova-day28-full-shell-acceptance-test` — the literal
   DoD and M7's integration test: cold boot through lock/unlock,
   theme-consistency check, launcher listing and starting all six
   real apps, real taps through the real compositor driving Dialer's
   keypad and Camera's shutter (independently verified via fresh
   `CallLog`/`PhotoLibrary` reloads), and the shell regaining real
   compositor focus ("returning home").
9. Updated the workspace `Cargo.toml` with one new lib and one new
   tool.

Named but not built in this delivery (see `docs/M7-TAG.md`'s "known
gaps" section): any actual rendering, real input hardware, a
persistent system daemon, and every accessibility feature beyond text
scaling.

M8 (Networking, v0.40, Days 29-33) is next.
