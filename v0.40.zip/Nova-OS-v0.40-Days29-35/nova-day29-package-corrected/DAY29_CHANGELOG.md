# Day 29 — Network abstraction + Ethernet
M8 begins with a typed network abstraction and Ethernet-first virtual backend for QEMU testing.
