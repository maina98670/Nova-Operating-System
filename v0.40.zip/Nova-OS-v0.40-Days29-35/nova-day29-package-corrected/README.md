# Nova OS — Day 28 Package: Theme/Accessibility Foundation, M7 Acceptance, Tag

This package continues directly from the Day 27 package. This is the
**final day of M7 — GUI & Window System (v0.33, Days 23–28)**.
**Assembled without running any tests or builds** — files only.
Nothing below has been compiled or verified in this pass. Run
`nova-day28-build_and_run.sh` yourself to actually confirm it.

## Day 28 goal

Per the Complete Build Guide:
1. Basic theming (consistent colors/typography across shell and apps
   — most existing apps already share this by convention; formalize
   it as a shared theme resource).
2. Accessibility foundation: at minimum, text scaling and a documented
   plan for what's deferred to a later pass.
3. Full-shell acceptance: cold boot → lock screen → home screen →
   launch each app → interact via touch → return home.

DoD: the full cold-boot-to-interactive-app flow works using only touch
input, with consistent theming across shell and every app. Tag M7.

## Read this first: there was no existing theming convention

"Most existing apps already share this by convention" doesn't
describe this track — no app has any visual styling at all; every app
is headless except Dialer/Camera's Day 27 tappable regions, which are
plain, unstyled rectangles. Same pattern as every prior day's
"existing X" reference that didn't match what was actually built here
(Days 16, 19, 23, 27). Stated plainly in `docs/theme-v1.md` and here,
not silently reframed.

## What's real, what can't be verified without rendering

**Real**: `nova-theme`'s `Theme`/`Typography`/`Color` data model, and
`TextScale` — genuine, working accessibility math (validated 80–200%
scaling, correct rounding), wired into a real, persisted
`text_scale` setting in `nova-settings-core`. The shell provably
references the exact same `Theme` value (`nova_theme::DEFAULT`) as
everything else — there is only one `Theme` value in this entire
delivery, so "the same" isn't a coincidence, it's structural.

**Can't be verified**: that Nova's UI actually looks consistent. That
requires pixels on a screen, and there still aren't any anywhere in
this repo — the same boundary Day 23's ADR drew. `docs/theme-v1.md`
says this explicitly.

## What's new

- **`libs/nova-theme`** — `Color`, `Typography` (with a real
  `heading_px()` derivation), `Theme`, `nova_theme::DEFAULT`, and
  `TextScale` (validated 80–200%, real `apply()` rounding). 5 unit
  tests.
- **`libs/nova-settings-core`** — new `text_scale` setting (default
  100%, bounds shared exactly with `TextScale::MIN_PERCENT`/
  `MAX_PERCENT`). 1 new unit test.
- **`apps/org.nova.settings`** — demos setting `text_scale` (happy
  path + rejected out-of-range), matching the app's existing
  `display_brightness` demo pattern.
- **`libs/nova-shell-core`** — `Shell::theme()`, returning
  `&nova_theme::DEFAULT`. 1 new unit test.
- **`docs/theme-v1.md`** — the theme resource reference, including
  what it can and can't prove without a renderer.
- **`docs/accessibility-plan-v1.md`** — what's real (text scaling) and
  what's deferred (screen reader support, high-contrast mode, reduced
  motion, larger touch targets, colorblind palettes, haptics), with a
  reason for each.
- **`docs/M7-TAG.md`** — the M7 tag (`v0.33`) writeup covering all of
  Days 23–28.
- **`tools/nova-day28-full-shell-acceptance-test`** — the literal DoD,
  and the integration test for M7 as a whole: cold boot → `Locked`
  (real window title) → launch blocked while locked → `unlock()` →
  `Home` (real window title) → shell/theme consistency check → the
  launcher lists and starts all six real apps, each with a real IPC
  handshake → real taps drive Dialer's keypad and Camera's shutter
  (confirmed via fresh `CallLog`/`PhotoLibrary` reloads, independent
  of either running app) → the shell regains real compositor focus
  ("returns home").

## Run

```bash
./nova-day28-build_and_run.sh
```

Builds the workspace, runs unit tests across three crates, then the
full-shell live acceptance test. Needs the same root-capable Linux
environment as the Days 11–27 live tests.

## Status

Unverified until the build, tests, and live acceptance test actually
pass — none of that was run in this pass, per instruction. If it
passes, `docs/M7-TAG.md` has the tag command for the real repo.
