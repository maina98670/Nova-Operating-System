//! Camera — Day 16 reconciliation, Day 27 real shutter button.
//!
//! Connects through App Manager's Hello/HelloAck/PermissionRequest
//! handshake (`nova-app-runtime`), runs `nova-camera-core`'s real
//! functional core against this app's own sandbox-scoped storage
//! (unchanged since Day 16), and — new this day — creates a real
//! window on the real compositor (Day 23) with one real, **tappable**
//! shutter button covering the whole window. A tap registered by
//! `nova-input-api`'s real `CompositorInputSource` (Day 27) within
//! that region captures a photo for real through
//! `PhotoLibrary::capture` — the same function this app already
//! called automatically before Day 27, now triggered by an actual tap
//! instead.
//!
//! **Honest scope, matching Day 27's own task list**: no real camera
//! HAL exists yet (`StubBackend`, unchanged since Day 16 — `nova-v4l2`
//! has never been compiled or tested against real hardware, and
//! Camera HAL integration is M9's job), and no real touchscreen
//! digitizer exists in this build environment — taps here come from
//! whatever's driving `CompositorServer::inject_touch` (a live
//! acceptance test, standing in for real hardware). What's real: the
//! tap actually reaches this exact app process and triggers the exact
//! same `PhotoLibrary::capture` logic a real camera HAL's shutter
//! button would.
//!
//! Shutter region: the entire 400x400 window (window-local
//! coordinates `(0, 0, 400, 400)`) — a real phone camera app's
//! shutter button doesn't need to be the whole screen, but keeping it
//! that large here means the live acceptance test's exact tap
//! coordinates matter less than proving the tap-to-capture path
//! itself works; keep this in sync with the acceptance test if you
//! shrink it.

use nova_app_storage::SandboxStorage;
use nova_camera_core::{PhotoLibrary, StubBackend};
use nova_compositor_core::client::CompositorClientBackend;
use nova_compositor_core::input::CompositorInputSource;
use nova_input_api::{InputEvent, InputSource, TouchPhase};
use nova_ipc::{LifecycleEvent, Message as IpcMessage, Permission};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_window_api::Window;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

const APP_ID: &str = "org.nova.camera";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];
const DEFAULT_OUTPUT: u32 = 1;
const SHUTTER_REGION: (i32, i32, i32, i32) = (0, 0, 400, 400); // (x, y, width, height) -- the whole window

fn contains(region: (i32, i32, i32, i32), x: i32, y: i32) -> bool {
    let (rx, ry, rw, rh) = region;
    x >= rx && x < rx + rw && y >= ry && y < ry + rh
}

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck complete");

    // Matches this app's nova-app.toml (required = camera, storage).
    let policy = SandboxPolicy::new(
        APP_ID,
        PermissionSet::from_permissions([Permission::Camera, Permission::Storage]),
        PermissionSet::empty(),
    )
    .expect("APP_ID is a valid app id");
    if let Err(e) = policy.authorize_camera() {
        eprintln!("[{APP_ID}] camera permission check failed locally: {e}");
        std::process::exit(1);
    }
    if let Err(e) = policy.check(Permission::Storage) {
        eprintln!("[{APP_ID}] storage permission check failed locally: {e}");
        std::process::exit(1);
    }
    let mut library = match PhotoLibrary::load(SandboxStorage(policy)) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("[{APP_ID}] failed to load photo library: {e}");
            std::process::exit(1);
        }
    };

    let window_backend = match CompositorClientBackend::connect_default(APP_ID, DEFAULT_OUTPUT) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("[{APP_ID}] couldn't connect to the compositor: {e}");
            std::process::exit(2);
        }
    };
    let mut window = match Window::create(window_backend, "Camera", 400, 400) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("[{APP_ID}] Window::create failed: {e}");
            std::process::exit(2);
        }
    };
    // Windows default to (0, 0); without repositioning, Camera's
    // window would land exactly on top of Dialer's. Placed well clear
    // of Dialer's 300x200 window at (0, 0) -- keep in sync with the
    // acceptance test's coordinates if this changes.
    if let Err(e) = window.move_to(500, 0) {
        eprintln!("[{APP_ID}] Window::move_to failed: {e}");
        std::process::exit(2);
    }
    println!("[{APP_ID}] window created: id={:?}", window.id());

    let mut input = match CompositorInputSource::connect_default(APP_ID) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[{APP_ID}] couldn't connect the input sink: {e}");
            std::process::exit(2);
        }
    };
    println!("[{APP_ID}] input sink registered -- shutter is live");

    let mut backend = StubBackend;

    loop {
        match input.poll() {
            Ok(Some(InputEvent::Touch(t))) if t.phase == TouchPhase::Began => {
                let (x, y) = (t.x as i32, t.y as i32);
                if contains(SHUTTER_REGION, x, y) {
                    match library.capture(&mut backend, 1280, 720, now_unix()) {
                        Ok(id) => println!("[{APP_ID}] tap on shutter -> captured photo #{id} (1280x720, synthetic placeholder frame)"),
                        Err(e) => eprintln!("[{APP_ID}] capture failed: {e}"),
                    }
                } else {
                    println!("[{APP_ID}] tap at ({x}, {y}) missed the shutter region -- ignored");
                }
            }
            Ok(_) => {} // not a touch-began event; nothing to do
            Err(e) => {
                eprintln!("[{APP_ID}] input source error: {e}");
                break;
            }
        }

        // Non-blocking check for a Lifecycle push on the App Manager
        // connection, interleaved with input polling above -- can't
        // use nova_app_runtime::idle_until_terminate here since that
        // blocks on this connection alone.
        match conn.try_recv_bytes() {
            Ok(Some(bytes)) => {
                if let Ok(IpcMessage::Lifecycle { event: LifecycleEvent::Terminate }) = IpcMessage::decode(&bytes) {
                    println!("[{APP_ID}] received Lifecycle::Terminate, exiting cleanly");
                    let _ = window.close();
                    break;
                }
            }
            Ok(None) => {}
            Err(_) => break, // App Manager side closed the connection
        }

        std::thread::sleep(Duration::from_millis(10));
    }
}

fn now_unix() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}
