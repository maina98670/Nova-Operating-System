//! Compositor Demo B -- Day 23 compositor DoD demo app.
//!
//! Connects to App Manager (Hello/HelloAck) like every other app,
//! then separately connects to the real, running
//! `nova_compositor_core::server::CompositorServer` and creates a
//! window there via `nova-window-api`'s `Window::create`, using
//! `CompositorClientBackend` -- the real cross-process backend, not
//! `StubBackend`. This app's only job is proving the compositor
//! handles a real, separate process correctly; see
//! `tools/nova-day23-compositor-acceptance-test` for where the actual
//! damage-tracking assertions happen (against this app's real,
//! server-side surface).
//!
//! Output id `1` is a named simplification, not a discovery protocol:
//! this milestone's acceptance test creates exactly one output before
//! launching any app, and `OutputId`s are assigned starting from 1, so
//! every app in this delivery can safely assume "the" output is 1.
//! Real output discovery is future work -- see
//! `nova-compositor-core`'s own module docs.

use nova_compositor_core::client::CompositorClientBackend;
use nova_ipc::Permission;
use nova_window_api::Window;

const APP_ID: &str = "org.nova.compositor_demo_b";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];
const DEFAULT_OUTPUT: u32 = 1;

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck complete");

    let backend = match CompositorClientBackend::connect_default(APP_ID, DEFAULT_OUTPUT) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("[{APP_ID}] couldn't connect to the compositor: {e}");
            std::process::exit(2);
        }
    };

    let window = match Window::create(backend, "Compositor Demo B", 400, 600) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("[{APP_ID}] Window::create failed: {e}");
            std::process::exit(2);
        }
    };
    println!("[{APP_ID}] window created on the real compositor: id={:?}", window.id());

    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}
