//! Dialer — Day 16 reconciliation, Day 27 real keypad.
//!
//! Connects through App Manager's Hello/HelloAck/PermissionRequest
//! handshake (`nova-app-runtime`), runs `nova-dialer-core`'s real
//! functional core against this app's own sandbox-scoped storage
//! (unchanged since Day 16), and — new this day — creates a real
//! window on the real compositor (Day 23) with a small, real,
//! **tappable** keypad: digits `1`/`2`/`3` and a `Call` button, each a
//! fixed region within the window. A tap registered by
//! `nova-input-api`'s real `CompositorInputSource` (Day 27) within a
//! digit's region appends that digit to the dialed number; a tap
//! within `Call`'s region places the call for real through
//! `CallLog::place_call` — the same function this app already called
//! automatically before Day 27, now triggered by an actual tap
//! instead.
//!
//! **Honest scope, matching Day 27's own task list**: no real
//! telephony HAL exists (`StubTelephony`, unchanged since Day 16), and
//! no real touchscreen digitizer exists in this build environment —
//! taps here come from whatever's driving `CompositorServer::inject_touch`
//! (a live acceptance test, standing in for real hardware, the same
//! way Day 23's acceptance test stood in for a real buffer-commit
//! event). What's real: the tap actually reaches this exact app
//! process, at the exact region it landed in, and triggers the exact
//! same `CallLog` logic a real telephony HAL's UI would.
//!
//! Button layout (window is 300x200; the live acceptance test targets
//! these same regions directly, so keep them in sync if you change
//! this):
//! ```text
//! +--------+--------+--------+
//! |   "1"  |   "2"  |   "3"  |   y: 0..100
//! +--------+--------+--------+
//! |          "Call"          |   y: 100..200
//! +---------------------------+
//! ```

use nova_app_storage::SandboxStorage;
use nova_compositor_core::client::CompositorClientBackend;
use nova_compositor_core::input::CompositorInputSource;
use nova_dialer_core::{CallLog, StubTelephony};
use nova_input_api::{InputEvent, InputSource, TouchPhase};
use nova_ipc::{LifecycleEvent, Message as IpcMessage, Permission};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_window_api::Window;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

const APP_ID: &str = "org.nova.dialer";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];
const DEFAULT_OUTPUT: u32 = 1;

// Button regions -- window-local coordinates. See module doc's ASCII
// layout. Kept as named rects (not a table) since there are only four.
const DIGIT_1: (i32, i32, i32, i32) = (0, 0, 100, 100); // (x, y, width, height)
const DIGIT_2: (i32, i32, i32, i32) = (100, 0, 100, 100);
const DIGIT_3: (i32, i32, i32, i32) = (200, 0, 100, 100);
const CALL_BUTTON: (i32, i32, i32, i32) = (0, 100, 300, 100);

fn contains(region: (i32, i32, i32, i32), x: i32, y: i32) -> bool {
    let (rx, ry, rw, rh) = region;
    x >= rx && x < rx + rw && y >= ry && y < ry + rh
}

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            std::process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        std::process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck complete");

    // Matches this app's nova-app.toml (required = contacts).
    let policy = SandboxPolicy::new(APP_ID, PermissionSet::from_permissions([Permission::Contacts]), PermissionSet::empty())
        .expect("APP_ID is a valid app id");
    if let Err(e) = policy.authorize_contacts() {
        eprintln!("[{APP_ID}] contacts permission check failed locally: {e}");
        std::process::exit(1);
    }
    let mut log = match CallLog::load(SandboxStorage(policy)) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("[{APP_ID}] failed to load call log: {e}");
            std::process::exit(1);
        }
    };

    let window_backend = match CompositorClientBackend::connect_default(APP_ID, DEFAULT_OUTPUT) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("[{APP_ID}] couldn't connect to the compositor: {e}");
            std::process::exit(2);
        }
    };
    let mut window = match Window::create(window_backend, "Dialer", 300, 200) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("[{APP_ID}] Window::create failed: {e}");
            std::process::exit(2);
        }
    };
    println!("[{APP_ID}] window created: id={:?}", window.id());

    let mut input = match CompositorInputSource::connect_default(APP_ID) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[{APP_ID}] couldn't connect the input sink: {e}");
            std::process::exit(2);
        }
    };
    println!("[{APP_ID}] input sink registered -- keypad is live");

    let mut telephony = StubTelephony;
    let mut dialed = String::new();

    loop {
        match input.poll() {
            Ok(Some(InputEvent::Touch(t))) if t.phase == TouchPhase::Began => {
                let (x, y) = (t.x as i32, t.y as i32);
                if contains(DIGIT_1, x, y) {
                    dialed.push('1');
                    println!("[{APP_ID}] tap on '1' -> dialed = {dialed:?}");
                } else if contains(DIGIT_2, x, y) {
                    dialed.push('2');
                    println!("[{APP_ID}] tap on '2' -> dialed = {dialed:?}");
                } else if contains(DIGIT_3, x, y) {
                    dialed.push('3');
                    println!("[{APP_ID}] tap on '3' -> dialed = {dialed:?}");
                } else if contains(CALL_BUTTON, x, y) {
                    if dialed.is_empty() {
                        println!("[{APP_ID}] tap on Call with nothing dialed -- ignored");
                    } else {
                        let now = now_unix();
                        match log.place_call(&mut telephony, dialed.clone(), now) {
                            Ok(id) => println!("[{APP_ID}] tap on Call -> placed call to {dialed:?}, log id={id}"),
                            Err(e) => eprintln!("[{APP_ID}] place_call failed: {e}"),
                        }
                        dialed.clear();
                    }
                } else {
                    println!("[{APP_ID}] tap at ({x}, {y}) hit no button -- ignored");
                }
            }
            Ok(_) => {} // not a touch-began event; nothing to do
            Err(e) => {
                eprintln!("[{APP_ID}] input source error: {e}");
                break;
            }
        }

        // Non-blocking check for a Lifecycle push on the App Manager
        // connection, interleaved with input polling above -- can't
        // use nova_app_runtime::idle_until_terminate here since that
        // blocks on this connection alone.
        match conn.try_recv_bytes() {
            Ok(Some(bytes)) => {
                if let Ok(IpcMessage::Lifecycle { event: LifecycleEvent::Terminate }) = IpcMessage::decode(&bytes) {
                    println!("[{APP_ID}] received Lifecycle::Terminate, exiting cleanly");
                    let _ = window.close();
                    break;
                }
            }
            Ok(None) => {}
            Err(_) => break, // App Manager side closed the connection
        }

        std::thread::sleep(Duration::from_millis(10));
    }
}

fn now_unix() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}
