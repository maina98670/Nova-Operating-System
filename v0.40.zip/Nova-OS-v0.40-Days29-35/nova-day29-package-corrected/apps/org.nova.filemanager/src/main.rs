//! nova-filemanager — Day 26's minimal file manager.
//!
//! Built entirely against `nova-storage-api` (Day 20, revised Day 26
//! to actually route through `nova_fsmgr`) — this app never touches
//! `std::fs` itself. Three operations, matching the task list's own
//! wording ("browse, open, delete within permission scope"):
//!
//! 1. **Browse**: `storage.list("")` — lists this app's own scoped
//!    storage directory.
//! 2. **Open**: `storage.read(name)` — reads a file's contents.
//! 3. **Delete**: `storage.delete(name)` — removes a file, now
//!    routed through `nova_fsmgr::delete_file`, M4's real Filesystem
//!    Manager, per the Day 26 DoD's own wording.
//!
//! On first run (empty directory), seeds a few files so there's
//! something real to browse — including `test-file.txt`, the DoD's
//! own "a test file" this app deletes to prove the whole cycle.
//! Everything printed here is also independently, externally
//! verified by `tools/nova-day26-filemanager-acceptance-test`
//! reading the real filesystem directly — this app's stdout isn't
//! the proof, just a trace of what it did.

use nova_ipc::Permission;
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_storage_api::{StorageApi, StorageError};
use std::process;

const APP_ID: &str = "org.nova.filemanager";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];
const TEST_FILE: &str = "test-file.txt";
const TEST_FILE_CONTENTS: &[u8] = b"Day 26: a real file, in a real directory, deleted through a real Filesystem Manager call.";

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck complete");

    let policy = SandboxPolicy::new(APP_ID, PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty())
        .expect("APP_ID is a valid app id");
    let storage = match StorageApi::open(policy) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[{APP_ID}] StorageApi::open failed: {e}");
            process::exit(1);
        }
    };

    // --- Seed a couple of files on first run, so there's something real to browse ---
    if storage.read(TEST_FILE).is_err() {
        if let Err(e) = storage.write(TEST_FILE, TEST_FILE_CONTENTS) {
            eprintln!("[{APP_ID}] failed to seed {TEST_FILE}: {e}");
            process::exit(1);
        }
        let _ = storage.write("readme.txt", b"Files you create will show up here.");
    }

    // --- 1. Browse ---
    let listing = match storage.list("") {
        Ok(names) => names,
        Err(e) => {
            eprintln!("[{APP_ID}] browse (list) failed: {e}");
            process::exit(3);
        }
    };
    println!("[{APP_ID}] browse: {} file(s):", listing.len());
    for name in &listing {
        println!("[{APP_ID}]   {name}");
    }
    if !listing.iter().any(|n| n == TEST_FILE) {
        eprintln!("[{APP_ID}] browse didn't list {TEST_FILE} right after seeding it");
        process::exit(3);
    }

    // --- 2. Open ---
    match storage.read(TEST_FILE) {
        Ok(bytes) if bytes == TEST_FILE_CONTENTS => {
            println!("[{APP_ID}] open {TEST_FILE}: {} bytes, content matches what was written", bytes.len());
        }
        Ok(_) => {
            eprintln!("[{APP_ID}] open {TEST_FILE} returned unexpected content");
            process::exit(4);
        }
        Err(e) => {
            eprintln!("[{APP_ID}] open {TEST_FILE} failed: {e}");
            process::exit(4);
        }
    }

    // --- 3. Delete ---
    if let Err(e) = storage.delete(TEST_FILE) {
        eprintln!("[{APP_ID}] delete {TEST_FILE} failed: {e}");
        process::exit(5);
    }
    match storage.read(TEST_FILE) {
        Err(StorageError::NotFound(_)) => println!("[{APP_ID}] delete {TEST_FILE}: confirmed gone (StorageApi -> nova_fsmgr -> real filesystem)"),
        Ok(_) => {
            eprintln!("[{APP_ID}] {TEST_FILE} is still readable after delete()");
            process::exit(5);
        }
        Err(e) => {
            eprintln!("[{APP_ID}] unexpected error re-reading deleted file: {e}");
            process::exit(5);
        }
    }
    let listing_after = storage.list("").unwrap_or_default();
    if listing_after.iter().any(|n| n == TEST_FILE) {
        eprintln!("[{APP_ID}] {TEST_FILE} still appears in browse listing after delete()");
        process::exit(5);
    }
    println!("[{APP_ID}] browse after delete: {} file(s), {TEST_FILE} no longer present", listing_after.len());

    println!("[{APP_ID}] Day 26 checks complete: browse/open/delete all real, delete reflected via M4's Filesystem Manager");
    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}
