# Tag: M7 — GUI & Window System

**Version**: `v0.33`, per the Complete Build Guide's milestone table
(`M7 — GUI & Window System (v0.33), Days 23-28`).

This file documents the intended tag; it does not create one. Files
only, not a git checkout of Zeen's actual repository — run this in the
real repo once this package's contents are merged in:

```bash
git tag -a v0.33 -m "M7: GUI & Window System"
git push origin v0.33
```

## What M7 covers (Days 23-28)

| Day | Focus | Delivered |
|---|---|---|
| 23 | Window manager / compositor core | `nova-compositor-core`: real surface/damage/output state machine, real cross-process IPC service + client; ADR choosing a pure-Rust rendering stack (Smithay) over wlroots |
| 24 | Desktop shell + launcher | `nova-shell-core`: real lock/home state machine, real window on the real compositor, launcher backed by real `AppManager::list_apps`/`launch` |
| 25 | Status bar + Settings integration | Real, live time; honest battery/connectivity placeholders (M9/M8 don't exist); `Shell::open_quick_settings` as a dedicated entry point |
| 26 | File manager | `apps/org.nova.filemanager`, and a real gap fixed: `nova-storage-api` now actually routes through `nova_fsmgr` (M4's Filesystem Manager) instead of bypassing it |
| 27 | Touch/mouse/keyboard input pipeline | Real hit-testing, focus tracking, and cross-process event delivery (`nova-compositor-core::input`); Dialer's keypad and Camera's shutter wired to real business logic for the first time |
| 28 | Theme/accessibility foundation, acceptance, tag | `nova-theme`: real theme resource + real text-scaling logic, wired into a persisted Settings entry; this tag |

## M7 acceptance, satisfied

> "The full cold-boot-to-interactive-app flow works using only touch
> input, with consistent theming across shell and every app."

Proven live by `tools/nova-day28-full-shell-acceptance-test`: cold
start (`Shell::new` → `Locked`, real window titled "Nova Lock
Screen") → launching blocked while locked → `unlock()` → `Home` (real
window retitled "Nova Home") → the launcher lists and starts all six
real apps → **real taps**, injected through
`CompositorServer::inject_touch`, drive Dialer's keypad and Camera's
shutter to their real underlying logic → the shell regains focus
("returns home"), all cross-checked against `AppManager`'s and the
compositor's own live state, never either app's stdout.

**"Consistent theming" is satisfied at the level this milestone can
actually satisfy it at**: the shell and the theme resource are the
same `nova_theme::DEFAULT` value, provably (there is only one `Theme`
value in this entire delivery). It is *not* satisfied as a visual
claim — there is no rendering anywhere in this repo, the same
boundary Day 23's own ADR drew, and `docs/theme-v1.md` says so
explicitly rather than implying otherwise.

## Known gaps carried forward past M7 (named, not hidden)

- **No real rendering, still.** Every visual claim in M7 (lock screen,
  home screen, status bar, theme) is real *state*, not real *pixels*.
  M12 (ARM64 reference-device port) is the natural point real hardware
  and a real Smithay integration enter the picture, per Day 23's ADR.
- **No real input hardware.** Day 27's pipeline is real end-to-end
  except its origin — `inject_touch`/`inject_pointer`/`inject_key` are
  exactly what a real `evdev` driver would call, once one exists.
- **No persistent system daemon.** Named since Day 22 (`nova run`);
  every service in M7 (App Manager, Compositor) is still transient,
  owned by whatever process starts it for that run.
- **Accessibility is text-scaling only.** Screen reader support,
  high-contrast mode, reduced motion, and larger touch targets are all
  deferred — see `docs/accessibility-plan-v1.md` for why each one
  specifically waits on later milestones.
- **No package signing.** Still M11's job, unchanged since Day 22's
  own tag notes.

None of these block M7's own acceptance criterion above; they're
listed here so M8 onward doesn't have to rediscover them.
