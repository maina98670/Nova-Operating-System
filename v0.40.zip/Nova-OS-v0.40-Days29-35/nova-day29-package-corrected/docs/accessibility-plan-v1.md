# Nova OS Accessibility Plan (Day 28, first draft)

Per the Day 28 task list: "Accessibility foundation: at minimum, text
scaling and a documented plan for what's deferred to a later pass."

## What's real today

**Text scaling.** `nova-theme::TextScale` is a real, validated,
working computation: given a base pixel size and a scale percentage
(80–200%), it produces the correctly scaled size. It's wired into a
real, persisted setting — `text_scale` in `nova-settings-core`
(default 100%, same 80–200% bounds as `TextScale` itself, so a value
Settings accepts is always a value `TextScale::from_percent` accepts
too). The Settings app (`apps/org.nova.settings`) demonstrates setting
it, matching the same happy-path + rejected-out-of-range pattern every
other setting in that app already uses.

This is genuinely useful today even with no rendering: any future UI
code computes its font sizes as
`TextScale::from_percent(user_setting).apply(base_px)` rather than
hardcoding pixel values, so accessibility scaling is correct by
construction once rendering exists, not retrofitted onto hardcoded
sizes later.

## What's deferred, and why

- **Screen reader / narration support.** Needs both real rendering
  (something to describe) and a real accessibility-tree concept
  layered on top of `nova-compositor-core`'s surface model — neither
  exists yet. Natural next step once M12's rendering backend
  (Smithay, per `docs/compositor-backend-decision-v1.md`) is in place.
- **High-contrast mode.** Straightforward to add as a second
  `nova_theme::Theme` value once there's a renderer to actually apply
  it — the `Theme`/`Color` data model already supports adding one; no
  new type is needed, just a second `Theme` constant and something
  visual to test it against.
- **Reduced motion.** No animation exists anywhere in this repo (no
  rendering at all yet), so there's nothing to reduce. A real setting
  once animations exist.
- **Larger touch targets.** Day 27's Dialer/Camera regions are already
  reasonably large (100x100px minimum), but there's no user-adjustable
  target-size setting yet, and no real touchscreen to validate target
  sizes against real finger contact areas. Deferred until real
  hardware (M12/M13) makes that validation possible.
- **Colorblind-safe palette variants.** Same shape as high-contrast
  mode — straightforward once there's a renderer and real designs to
  check contrast/distinguishability against.
- **Haptic/audio feedback for interactions.** Depends on M9's hardware
  abstraction layer (haptics driver) and M8/wherever audio output
  lands — neither exists yet.

None of the above blocks Day 28's own DoD (text scaling + a documented
plan) — they're listed here so later milestones don't have to
rediscover this list from scratch.
