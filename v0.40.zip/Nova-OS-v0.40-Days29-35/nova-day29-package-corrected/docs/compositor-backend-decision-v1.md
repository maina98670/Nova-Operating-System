# ADR: Compositor Backend — wlroots vs. a Pure-Rust Stack (Day 23)

Per Day 23's task list: "Decide explicitly whether this is wlroots-based
(per the original architecture guide) or built on 'mature graphics
facilities' more generally (per the roadmap's more conservative
phrasing) — write the decision down, since it affects every app above
this layer."

## Decision

**Nova's compositor will target a pure-Rust stack — most likely
[Smithay](https://github.com/Smithay/smithay) — not wlroots.** This
decision is written down now, before any rendering backend is actually
integrated (see "What this delivery does and doesn't include" below),
specifically so it affects every app above this layer from here
forward, per the task's own reasoning.

## Why not wlroots

wlroots is the obvious, well-trodden choice — it's what the original
architecture guide names, it's what Sway/river/Hyprland and most
production Wayland compositors outside GNOME/KDE are built on, and its
API is well-documented from a decade of real-world use.

But it's a C library. Every one of the ~30 crates already built in
this repo (Days 1–22) is safe, pure Rust — no `unsafe`, no FFI, no C
toolchain in the build. Pulling in wlroots means:

- `unsafe` FFI bindings at the compositor's core, in the one
  component every single app in the system depends on transitively
  (window creation, input delivery, rendering — all of it flows
  through here).
- A C build dependency (meson + wlroots' own dependency chain:
  libinput, libdrm, pixman, wayland-server) that doesn't fit this
  project's toolchain anywhere else.
- A second memory-safety story to reason about at exactly the layer
  where a bug has the widest possible blast radius (every window,
  every app, all input).

## Why a pure-Rust stack instead

The roadmap's own "mature graphics facilities" phrasing is more
conservative than "wlroots specifically" for a reason — it leaves room
for this call. Smithay is the concrete answer:

- Pure Rust, actively maintained, and no longer experimental — it
  backs production compositors today (COSMIC's `cosmic-comp`, `niri`,
  `catacomb`, and others), not just its own `anvil` reference
  compositor.
- Same memory-safety guarantees as the rest of this codebase, all the
  way down through surface/buffer management — no `unsafe` boundary
  introduced at the one layer where it would matter most.
- Modular: Smithay exposes DRM/KMS, `libinput`, and Wayland-protocol
  handling as separable pieces, which matches this project's existing
  pattern of small, focused crates (`nova-window-api`,
  `nova-compositor-core`, etc.) better than wlroots' more monolithic
  C API would.
- Nova's own roadmap already commits to a Rust kernel eventually (the
  optional Kernel Track, K1 onward) — a pure-Rust compositor is the
  consistent choice for a project already betting on Rust end to end,
  not a late pivot.

## Trade-offs, named honestly

- wlroots has more real-world hours on it. Smithay is younger and less
  battle-tested at the "arbitrary GPU driver quirks" level — this is a
  real risk for M12's ARM64 reference-device port, not a hypothetical
  one.
- Smithay's API surface changes faster than wlroots' as it matures;
  pinning a version and expecting some churn is realistic.
- This decision is about the **rendering/protocol backend**, not
  today's deliverable — see below. It could still be revisited before
  any DRM/KMS code is actually written, if M12's specific reference
  hardware turns out to have poor Smithay-side driver support and
  good wlroots-side support. Writing the decision down now doesn't
  freeze it against real evidence later; it sets the default so every
  app built above this layer between now and M12 is written against
  compatible assumptions (pure-Rust surface/buffer semantics, not
  wlroots' C structures leaking through).

## What this delivery does and doesn't include

**Does**: the actual compositor *core logic* this decision sits above
— surface management, damage tracking, output configuration
(`nova-compositor-core`) — built and unit-tested as a real, pure Rust
library, backend-agnostic by construction (it has no dependency on
Smithay, wlroots, DRM, or any GPU/rendering API at all).

**Does not**: any actual Smithay integration, DRM/KMS device access,
EGL/GBM buffer allocation, or real pixel output. This environment has
no GPU and no display to test any of that against, and — consistent
with every hardware-adjacent piece of this project since Day 16 — code
that can't be verified shouldn't be presented as working. The seam for
that integration is real (see `nova-compositor-core`'s own module
docs), but nothing is plugged into it yet. That's real work for
whoever has actual reference hardware in hand, most naturally around
M12 per this decision's own trade-off note above.
