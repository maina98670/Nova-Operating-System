# Nova SDK — Theme Resource, v1 (Day 28, first draft)

Per the Day 28 task list: "Basic theming (consistent colors/typography
across shell and apps — most existing apps already share this by
convention; formalize it as a shared theme resource)."

## Honest starting point

"Most existing apps already share this by convention" doesn't
describe this track — no app has any visual styling at all. Every app
built since Day 16 is headless except Dialer/Camera's Day 27 tappable
regions, which are plain, unstyled rectangles. There was nothing to
formalize; `nova-theme` is built fresh.

## What it is

```rust
nova_theme::DEFAULT // the one canonical Theme
```

- `Color { r, g, b }` — plain RGB, `u8` each.
- `Typography { body_px, heading_scale_percent }` — base body size in
  logical pixels, heading size as a whole-number percentage of body
  (not a float, so `Typography`/`Theme` can derive `Eq` — the same
  "floats can't derive `Eq`" reasoning
  `nova_compositor_core::protocol::Message` already applies to its own
  wire format).
- `Theme { name, background, surface, text, accent, typography }`.
- `TextScale` — a validated 80–200% accessibility scale factor, with a
  real `apply(base_px) -> scaled_px` computation. See
  `docs/accessibility-plan-v1.md` for how this is wired into a real,
  persisted setting.

`nova-shell-core::Shell::theme()` returns `&nova_theme::DEFAULT` — the
shell's own reference to the same canonical resource a future app's UI
code would use.

## What this can and can't prove

**Can prove, and does (unit tests)**: the resource is well-defined,
`heading_px()`'s derivation is correct, `TextScale`'s bounds and
rounding are correct, and the shell references the exact same `Theme`
value nothing else has any way to diverge from (`nova_theme::DEFAULT`
is the only `Theme` value that exists anywhere in this delivery).

**Cannot prove**: that Nova's UI actually looks consistent. That's a
property of pixels on a screen, and there are no pixels anywhere in
this repo — no GPU, no display, no rendering backend integrated (see
`docs/compositor-backend-decision-v1.md`). "Consistent theming across
shell and every app" is, today, a claim about a shared data resource
existing and being referenced — not a claim anyone could look at and
confirm. That becomes checkable once M12 gives this crate something to
actually render with.

## What Day 28 doesn't cover (named, not hidden)

- No dark/light mode toggle — `DEFAULT` is the only theme.
- No per-app theme overrides or customization.
- No actual application of `Theme`/`TextScale` to Dialer/Camera's
  existing tap regions (they remain plain, unstyled rectangles) — that
  requires rendering to be meaningful at all.
