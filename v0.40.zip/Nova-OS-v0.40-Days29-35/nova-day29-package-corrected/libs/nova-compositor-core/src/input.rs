//! Nova OS Day 27 — the real `nova_input_api::InputSource`.
//!
//! `CompositorInputSource` connects to a running
//! [`crate::server::CompositorServer`] on its **own, dedicated**
//! connection (separate from `client::CompositorClientBackend`'s
//! window-management one — see `server.rs`'s own module doc for why),
//! registers itself with `RegisterInputSink`, then implements
//! `InputSource::poll()` by non-blockingly checking for pushed
//! `InputTouch`/`InputPointer`/`InputKey` messages
//! (`SeqPacketSocket::try_recv_bytes`, added this same day) and
//! converting them to `nova_input_api`'s own event types.
//!
//! This is the real thing `nova-input-api`'s `UnavailableSource` was
//! always meant to eventually be replaced by — an app written against
//! `InputSource` since Day 19 doesn't need to change to use this,
//! only which concrete type it's given changes.

use nova_input_api::{InputError, InputEvent, InputSource, KeyEvent, PointerEvent, TouchEvent, TouchPhase};
use nova_ipc::SeqPacketSocket;
use std::io;

use crate::protocol::{Message, SOCKET_PATH};

pub struct CompositorInputSource {
    conn: SeqPacketSocket,
}

impl CompositorInputSource {
    /// Connects to `socket_path` and registers as the input sink for
    /// `app_id`. This is a genuinely separate connection from
    /// whatever `CompositorClientBackend` (if any) this same app also
    /// holds for window management — see `server.rs`'s module doc.
    pub fn connect(socket_path: &str, app_id: &str) -> io::Result<Self> {
        let conn = SeqPacketSocket::connect(socket_path)?;
        conn.send_bytes(&Message::RegisterInputSink { app_id: app_id.to_string() }.encode())?;
        Ok(Self { conn })
    }

    pub fn connect_default(app_id: &str) -> io::Result<Self> {
        Self::connect(SOCKET_PATH, app_id)
    }
}

impl InputSource for CompositorInputSource {
    fn poll(&mut self) -> Result<Option<InputEvent>, InputError> {
        let bytes = match self.conn.try_recv_bytes() {
            Ok(Some(b)) => b,
            Ok(None) => return Ok(None), // nothing queued right now -- not an error
            Err(e) => return Err(InputError::Disconnected(e.to_string())),
        };
        let msg = Message::decode(&bytes).map_err(|e| InputError::Disconnected(e.to_string()))?;
        match msg {
            Message::InputTouch { x, y, phase } => Ok(Some(InputEvent::Touch(TouchEvent { x: x as f32, y: y as f32, phase: decode_phase(phase) }))),
            Message::InputPointer { x, y, buttons } => Ok(Some(InputEvent::Pointer(PointerEvent { x: x as f32, y: y as f32, buttons }))),
            Message::InputKey { keycode, pressed } => Ok(Some(InputEvent::Key(KeyEvent { keycode, pressed }))),
            other => Err(InputError::Disconnected(format!("unexpected message on the input-sink connection: {other:?}"))),
        }
    }
}

fn decode_phase(byte: u8) -> TouchPhase {
    match byte {
        0 => TouchPhase::Began,
        1 => TouchPhase::Moved,
        2 => TouchPhase::Ended,
        _ => TouchPhase::Cancelled,
    }
}
