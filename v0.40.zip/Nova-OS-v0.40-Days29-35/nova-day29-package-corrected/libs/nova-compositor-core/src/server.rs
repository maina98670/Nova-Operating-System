//! The compositor as a running service — mirrors
//! `nova-app-manager::AppManager`'s own `serve()` pattern (`Arc<Mutex<..>>`
//! state, one thread per connection) so anyone already familiar with
//! that crate recognizes this one immediately.
//!
//! Like every service in this repo so far (see Day 22's `nova
//! run` module docs), this is a **transient** service — whatever
//! process calls `serve()` owns it for as long as that process runs.
//! There's still no persistent Nova system daemon; that gap is named,
//! not hidden, in `nova-cli::run`'s own module doc from Day 22 and
//! applies equally here.
//!
//! ## Day 27: input delivery
//! An app's window-management connection (`CompositorClientBackend`,
//! `client.rs`) does synchronous request/response — send a
//! `ResizeSurface`, block for the matching `Ack`. If the server could
//! also push an unprompted `InputTouch` down that *same* connection at
//! any moment, it could arrive in between a request and its response
//! and break that assumption. So input uses its own, separate
//! connection: a client sends `RegisterInputSink { app_id }` once, and
//! this server stores that connection (indexed by `app_id`) purely for
//! pushing `InputTouch`/`InputPointer`/`InputKey` later —
//! `inject_touch`/`inject_pointer`/`inject_key` below are what an
//! input source (a real one, or a live acceptance test standing in for
//! one — see `input.rs`'s own module doc) calls to actually deliver an
//! event.

use crate::compositor::{Compositor, CompositorError, FrameDamage};
use crate::model::{Output, OutputId, Rect, Surface, SurfaceId};
use crate::protocol::Message;
use nova_ipc::SeqPacketSocket;
use std::collections::HashMap;
use std::io;
use std::sync::{Arc, Mutex};
use std::thread;

struct Inner {
    compositor: Compositor,
    /// Day 27: `app_id` -> its dedicated input-delivery connection
    /// (see this module's own doc comment for why it's separate from
    /// the window-management one).
    input_sinks: HashMap<String, Arc<SeqPacketSocket>>,
}

pub struct CompositorServer {
    inner: Arc<Mutex<Inner>>,
}

impl Default for CompositorServer {
    fn default() -> Self {
        Self::new()
    }
}

impl CompositorServer {
    pub fn new() -> Self {
        Self { inner: Arc::new(Mutex::new(Inner { compositor: Compositor::new(), input_sinks: HashMap::new() })) }
    }

    /// Binds the compositor's own socket (separate from App Manager's
    /// — see `protocol`'s module doc) and starts accepting
    /// connections, one thread per client, the same pattern
    /// `AppManager::serve` already uses. Both window-management
    /// connections (`CreateSurface`, ...) and input-sink registration
    /// connections (`RegisterInputSink`) arrive here; which kind a
    /// given connection is only becomes clear from its first message.
    pub fn serve(&self, socket_path: &str) -> io::Result<thread::JoinHandle<()>> {
        let listener = SeqPacketSocket::listen(socket_path)?;
        let inner = self.inner.clone();
        Ok(thread::spawn(move || loop {
            match listener.accept() {
                Ok(conn) => {
                    let inner = inner.clone();
                    thread::spawn(move || handle_connection(inner, conn));
                }
                Err(_) => break, // listener closed / fatal accept error
            }
        }))
    }

    // --- Direct, locking-wrapper access for whatever process is
    // hosting this server (a live acceptance test, or an eventual
    // shell) to introspect real state without going over its own
    // socket to itself -- the exact pattern
    // `AppManager::notifications()`/`process_list()` already
    // established for the same reason: external verification that
    // doesn't have to trust a client's own claims about itself.

    pub fn create_output(&self, name: &str, width: u32, height: u32) -> OutputId {
        self.inner.lock().unwrap().compositor.create_output(name, width, height)
    }

    pub fn output(&self, id: OutputId) -> Option<Output> {
        self.inner.lock().unwrap().compositor.output(id).cloned()
    }

    pub fn surface(&self, id: SurfaceId) -> Option<Surface> {
        self.inner.lock().unwrap().compositor.surface(id).cloned()
    }

    pub fn surfaces_on(&self, output: OutputId) -> Vec<Surface> {
        self.inner.lock().unwrap().compositor.surfaces_on(output).into_iter().cloned().collect()
    }

    pub fn mark_damaged(&self, id: SurfaceId, region: Rect) -> Result<(), CompositorError> {
        self.inner.lock().unwrap().compositor.mark_damaged(id, region)
    }

    pub fn frame(&self, output: OutputId) -> Result<FrameDamage, CompositorError> {
        self.inner.lock().unwrap().compositor.frame(output)
    }

    pub fn focused_surface(&self, output: OutputId) -> Option<SurfaceId> {
        self.inner.lock().unwrap().compositor.focused_surface(output)
    }

    /// Day 27: whether `app_id` currently has an input sink
    /// registered (its input source connected and sent
    /// `RegisterInputSink`) — exposed so a live test can wait for this
    /// deterministically instead of guessing a sleep duration.
    pub fn has_input_sink(&self, app_id: &str) -> bool {
        self.inner.lock().unwrap().input_sinks.contains_key(app_id)
    }

    /// The actual input pipeline entry point for touch: hit-tests
    /// `(x, y)` on `output` against **real surface geometry**
    /// (`Compositor::hit_test`), focuses the hit surface, translates
    /// to surface-local coordinates, and pushes `InputTouch` to that
    /// surface's owning app over its dedicated input-sink connection
    /// — "wire it through the compositor... so window focus and
    /// hit-testing are correct, not just raw event delivery," per the
    /// Day 27 task list, is this method. `phase` is the wire encoding
    /// (0=Began, 1=Moved, 2=Ended, 3=Cancelled — see `protocol`'s
    /// module doc); returns which surface was hit, or `None` if
    /// nothing was there, so a caller can assert on it directly.
    pub fn inject_touch(&self, output: OutputId, x: i32, y: i32, phase: u8) -> Option<SurfaceId> {
        let mut guard = self.inner.lock().unwrap();
        let hit = guard.compositor.hit_test(output, x, y)?;
        let _ = guard.compositor.focus(output, hit);
        let surface = guard.compositor.surface(hit)?.clone();
        let (local_x, local_y) = (x - surface.geometry.x, y - surface.geometry.y);
        if let Some(conn) = guard.input_sinks.get(&surface.app_id) {
            let _ = conn.send_bytes(&Message::InputTouch { x: local_x, y: local_y, phase }.encode());
        }
        Some(hit)
    }

    /// Same shape as `inject_touch`, for pointer (mouse) events.
    pub fn inject_pointer(&self, output: OutputId, x: i32, y: i32, buttons: u8) -> Option<SurfaceId> {
        let mut guard = self.inner.lock().unwrap();
        let hit = guard.compositor.hit_test(output, x, y)?;
        let _ = guard.compositor.focus(output, hit);
        let surface = guard.compositor.surface(hit)?.clone();
        let (local_x, local_y) = (x - surface.geometry.x, y - surface.geometry.y);
        if let Some(conn) = guard.input_sinks.get(&surface.app_id) {
            let _ = conn.send_bytes(&Message::InputPointer { x: local_x, y: local_y, buttons }.encode());
        }
        Some(hit)
    }

    /// Keyboard events have no `(x, y)` of their own — routed to
    /// whichever surface currently has focus on `output` instead of
    /// hit-tested by position.
    pub fn inject_key(&self, output: OutputId, keycode: u32, pressed: bool) -> Option<SurfaceId> {
        let guard = self.inner.lock().unwrap();
        let focused = guard.compositor.focused_surface(output)?;
        let surface = guard.compositor.surface(focused)?;
        if let Some(conn) = guard.input_sinks.get(&surface.app_id) {
            let _ = conn.send_bytes(&Message::InputKey { keycode, pressed }.encode());
        }
        Some(focused)
    }
}

fn handle_connection(inner: Arc<Mutex<Inner>>, conn: SeqPacketSocket) {
    let conn = Arc::new(conn);
    let mut registered_as: Option<String> = None;

    loop {
        let bytes = match conn.recv_bytes() {
            Ok(b) => b,
            Err(_) => break, // client disconnected
        };
        let msg = match Message::decode(&bytes) {
            Ok(m) => m,
            Err(e) => {
                let _ = conn.send_bytes(&Message::Error { message: e.to_string() }.encode());
                continue;
            }
        };

        if let Message::RegisterInputSink { app_id } = msg {
            inner.lock().unwrap().input_sinks.insert(app_id.clone(), conn.clone());
            registered_as = Some(app_id);
            // No response by design -- registration is one-way setup,
            // not a request awaiting an Ack; the client doesn't block
            // on it (see input.rs).
            continue;
        }

        let response = dispatch(&inner, msg);
        if conn.send_bytes(&response.encode()).is_err() {
            break;
        }
    }

    if let Some(app_id) = registered_as {
        inner.lock().unwrap().input_sinks.remove(&app_id);
    }
}

fn dispatch(inner: &Arc<Mutex<Inner>>, msg: Message) -> Message {
    let mut guard = inner.lock().unwrap();
    let c = &mut guard.compositor;
    match msg {
        Message::CreateSurface { app_id, output, title, x, y, width, height } => {
            match c.create_surface(&app_id, OutputId(output), &title, Rect::new(x, y, width, height)) {
                Ok(id) => Message::SurfaceCreated { surface: id.0 },
                Err(e) => Message::Error { message: e.to_string() },
            }
        }
        Message::ResizeSurface { surface, width, height } => match c.resize_surface(SurfaceId(surface), width, height) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::MoveSurface { surface, x, y } => match c.move_surface(SurfaceId(surface), x, y) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::SetTitle { surface, title } => match c.set_title(SurfaceId(surface), &title) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::MarkDamaged { surface, x, y, width, height } => match c.mark_damaged(SurfaceId(surface), Rect::new(x, y, width, height)) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        Message::CloseSurface { surface } => match c.close_surface(SurfaceId(surface)) {
            Ok(()) => Message::Ack,
            Err(e) => Message::Error { message: e.to_string() },
        },
        // SurfaceCreated/Ack/Error/InputTouch/InputPointer/InputKey
        // are server -> client only; RegisterInputSink is handled
        // before this function is ever called. A client sending any
        // of these is a protocol misuse, reported honestly rather
        // than silently ignored.
        other => Message::Error { message: format!("not a valid client request: {other:?}") },
    }
}
