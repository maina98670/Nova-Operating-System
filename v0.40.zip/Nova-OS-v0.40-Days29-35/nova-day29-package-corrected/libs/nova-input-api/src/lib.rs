//! Nova OS Day 19 — Input API. Real implementation wired up Day 27.
//!
//! Touch/keyboard/pointer plumbing every app so far has been missing.
//! Per the Day 19 DoD: "the Input API compiles and returns a defined
//! 'not yet available' state honestly rather than pretending input
//! works before M7." The real input pipeline (actual touch/keyboard/
//! pointer events flowing from hardware through the compositor to an
//! app) is M7's job, the same milestone that builds the compositor
//! itself (`nova-window-api`'s module docs cover the same dependency).
//!
//! What Day 19 actually delivers: the **event types and the trait
//! shape** an app codes against today, so that when M7 lands, an app
//! built against [`InputSource`] doesn't need to change its own code
//! — only which backend it's given changes, from [`UnavailableSource`]
//! to a real one. That's the entire point of exposing the API now
//! rather than waiting for M7 to define it retroactively.
//!
//! ## Day 27
//! That real backend now exists:
//! `nova_compositor_core::input::CompositorInputSource`, which
//! receives events the compositor delivers after real hit-testing
//! (see that crate's own Day 27 module docs). `UnavailableSource`
//! itself is unchanged — it still always returns
//! `Err(InputError::NotYetAvailable)`, since that's a different,
//! still-true statement for anything using it. [`InputError::Disconnected`]
//! is new: a real, working input source's connection can still drop,
//! which is a different failure than "input doesn't exist yet" and
//! deserves its own honest variant rather than reusing
//! `NotYetAvailable` for something that was, in fact, available a
//! moment ago.

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum TouchPhase {
    Began,
    Moved,
    Ended,
    Cancelled,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TouchEvent {
    pub x: f32,
    pub y: f32,
    pub phase: TouchPhase,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct KeyEvent {
    /// Linux evdev keycode, matching the convention M7's real input
    /// pipeline will use — chosen now so a future backend swap doesn't
    /// also require renumbering every key an app already checks for.
    pub keycode: u32,
    pub pressed: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PointerEvent {
    pub x: f32,
    pub y: f32,
    /// Bitmask: bit 0 = left, bit 1 = right, bit 2 = middle.
    pub buttons: u8,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum InputEvent {
    Touch(TouchEvent),
    Key(KeyEvent),
    Pointer(PointerEvent),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InputError {
    /// The honest, defined state the Day 19 DoD asks for. Every
    /// `InputSource` implementation shipped in *this* crate returns
    /// this from every call — there is no "sometimes works" path.
    /// `nova-compositor-core::input::CompositorInputSource` (Day 27)
    /// is a real implementation that lives in a different crate and
    /// does not return this.
    NotYetAvailable,
    /// Day 27: a real input source's connection to the compositor
    /// dropped. Distinct from `NotYetAvailable` on purpose — this
    /// means input *was* working and stopped, not that it never
    /// existed.
    Disconnected(String),
}

impl std::fmt::Display for InputError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            InputError::NotYetAvailable => write!(f, "input is not yet available -- the real pipeline lands in M7"),
            InputError::Disconnected(reason) => write!(f, "input source disconnected: {reason}"),
        }
    }
}
impl std::error::Error for InputError {}

/// The seam a real M7 input pipeline plugs into.
pub trait InputSource {
    /// Non-blocking: `Ok(Some(event))` if one is queued, `Ok(None)`
    /// if none is available right now, `Err` if input isn't available
    /// at all yet.
    fn poll(&mut self) -> Result<Option<InputEvent>, InputError>;
}

/// The only `InputSource` this crate ships. Always returns
/// `Err(InputError::NotYetAvailable)` — never `Ok`, never panics.
/// This is the literal Day 19 DoD, not a placeholder pending a real
/// implementation elsewhere in this same delivery.
#[derive(Default)]
pub struct UnavailableSource;

impl InputSource for UnavailableSource {
    fn poll(&mut self) -> Result<Option<InputEvent>, InputError> {
        Err(InputError::NotYetAvailable)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unavailable_source_always_errs() {
        let mut source = UnavailableSource;
        for _ in 0..5 {
            assert_eq!(source.poll(), Err(InputError::NotYetAvailable));
        }
    }

    #[test]
    fn event_types_are_constructible_and_comparable() {
        let a = InputEvent::Touch(TouchEvent { x: 1.0, y: 2.0, phase: TouchPhase::Began });
        let b = InputEvent::Touch(TouchEvent { x: 1.0, y: 2.0, phase: TouchPhase::Began });
        assert_eq!(a, b);

        let key = InputEvent::Key(KeyEvent { keycode: 30, pressed: true }); // evdev KEY_A
        assert!(matches!(key, InputEvent::Key(KeyEvent { pressed: true, .. })));

        let pointer = InputEvent::Pointer(PointerEvent { x: 0.0, y: 0.0, buttons: 0b001 });
        assert!(matches!(pointer, InputEvent::Pointer(PointerEvent { buttons: 1, .. })));
    }
}
