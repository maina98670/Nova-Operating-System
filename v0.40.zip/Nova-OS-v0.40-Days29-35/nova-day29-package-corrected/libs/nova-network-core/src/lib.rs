//! M8 Day 29 network abstraction.
#[derive(Clone,Debug,PartialEq,Eq)] pub enum LinkType{Ethernet,Wifi}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct NetworkInterface{pub name:String,pub link_type:LinkType,pub mac:Option<String>,pub up:bool,pub mtu:u32}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct NetworkAddress{pub address:String,pub prefix:u8}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct Route{pub destination:String,pub gateway:Option<String>,pub interface:String}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct NetworkSnapshot{pub interfaces:Vec<NetworkInterface>,pub addresses:Vec<NetworkAddress>,pub routes:Vec<Route>}
#[derive(Clone,Debug,PartialEq,Eq)] pub enum NetworkError{InvalidName,NotFound,Unsupported}
pub trait NetworkBackend{fn snapshot(&self)->Result<NetworkSnapshot,NetworkError>;}
pub struct VirtualEthernetBackend{interface:String}
impl VirtualEthernetBackend{pub fn new(name:&str)->Result<Self,NetworkError>{if name.is_empty(){Err(NetworkError::InvalidName)}else{Ok(Self{interface:name.into()})}}}
impl NetworkBackend for VirtualEthernetBackend{fn snapshot(&self)->Result<NetworkSnapshot,NetworkError>{Ok(NetworkSnapshot{interfaces:vec![NetworkInterface{name:self.interface.clone(),link_type:LinkType::Ethernet,mac:Some("52:54:00:12:34:56".into()),up:true,mtu:1500}],addresses:vec![],routes:vec![]})}}
pub struct NetworkManager<B:NetworkBackend>{backend:B}
impl<B:NetworkBackend> NetworkManager<B>{pub fn new(backend:B)->Self{Self{backend}} pub fn snapshot(&self)->Result<NetworkSnapshot,NetworkError>{self.backend.snapshot()}}
#[cfg(test)]mod tests{use super::*;#[test]fn ethernet_visible(){let s=NetworkManager::new(VirtualEthernetBackend::new("eth0").unwrap()).snapshot().unwrap();assert!(s.interfaces[0].up);assert_eq!(s.interfaces[0].link_type,LinkType::Ethernet);}}
