//! Nova OS Day 24-25 — Desktop shell core: lock screen, home screen,
//! app launcher, status bar, quick-settings access to Settings.
//!
//! Per the Complete Build Guide's Day 24 row: "Lock screen and home
//! screen (the original architecture guide's M4 scope, now correctly
//! sequenced after a real compositor exists)" and "App launcher
//! listing installed packages via M5's App Manager / package manifest
//! data." Day 25 adds: "Status bar (time, battery placeholder until
//! M9's power HAL exists, connectivity placeholder until M8)" and
//! "Wire the existing Settings app into the shell (accessible from
//! status bar / quick settings, not just standalone launch)."
//!
//! ## Honest scope
//! - **No real rendering.** Same boundary as Day 23's compositor:
//!   there's no GPU or display in this environment. "The lock screen
//!   appears" / "unlocking reaches the home screen" / "the status bar
//!   renders live" are represented here as real state (`ShellState`,
//!   `statusbar::StatusBarState`) and a real, externally-verifiable
//!   window title change on the shell's own compositor surface (via
//!   `nova-window-api`, generic over `WaylandBackend` — `StubBackend`
//!   for this crate's own unit tests, the real
//!   `nova_compositor_core::client::CompositorClientBackend` for the
//!   live acceptance test) — not actual pixels.
//! - **No real authentication.** [`Shell::unlock`] always succeeds.
//!   The Day 24 DoD doesn't ask for a PIN/biometric system (and one
//!   doesn't exist anywhere in this repo yet); what's real here is
//!   the *state transition itself* — locked apps can't be launched
//!   (see [`Shell::launch_app`]), and unlocking is the only way out
//!   of that. Wiring a real auth check into `unlock` later shouldn't
//!   require touching anything else in this crate.
//! - **No real touch input drives `unlock`/`lock` yet.** The Roadmap
//!   sequences the real input pipeline for Day 27, *after* this day —
//!   deliberately, per its own Day 27 row. `unlock`/`lock` are plain
//!   callable methods today; Day 27's job is wiring a real tap gesture
//!   to call them, not rebuilding them.
//! - **Battery and connectivity are honest placeholders.** See
//!   `statusbar`'s own module docs — `BatteryStatus`/
//!   `ConnectivityStatus` have exactly one variant each,
//!   `Unavailable`, until M9 and M8 respectively exist to fill them in
//!   for real.
//! - **Theming can't be visually verified.** Day 28 adds
//!   [`Shell::theme`], returning the one canonical
//!   `nova_theme::Theme` — but there's still no rendering anywhere in
//!   this repo, so "consistent theming across shell and every app" is
//!   only verifiable as "they reference the same resource," not as a
//!   visual property. See `nova-theme`'s own module docs.
//!
//! The shell is a privileged system component, not a sandboxed app —
//! unlike every app built since Day 16, it holds a direct
//! `nova_app_manager::AppManager` handle (a cheap `Arc` clone; the
//! same handle whatever process starts App Manager for this session
//! already has) rather than going through IPC to reach it. There's no
//! persistent system daemon for it to instead be a mere IPC client of
//! (the same gap Day 22's `nova run` already named); the shell **is**
//! the thing that would eventually own that relationship.

pub mod statusbar;

use nova_app_manager::{AppListEntry, AppManager, AppManagerError};
use nova_window_api::{WaylandBackend, Window, WindowError, WindowState};
use statusbar::{StatusBar, StatusBarState};

pub const LOCK_SCREEN_TITLE: &str = "Nova Lock Screen";
pub const HOME_SCREEN_TITLE: &str = "Nova Home";

/// Day 25: the one app the shell knows how to reach directly, by id
/// — see [`Shell::open_quick_settings`].
pub const SETTINGS_APP_ID: &str = "org.nova.settings";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ShellState {
    Locked,
    Home,
}

#[derive(Debug)]
pub enum ShellError {
    /// Tried to launch an app while the shell isn't in `Home` state.
    Locked,
    AppManager(AppManagerError),
    Window(WindowError),
}

impl std::fmt::Display for ShellError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ShellError::Locked => write!(f, "can't launch an app while the shell is locked"),
            ShellError::AppManager(e) => write!(f, "app manager error: {e}"),
            ShellError::Window(e) => write!(f, "shell window error: {e}"),
        }
    }
}
impl std::error::Error for ShellError {}

/// The desktop shell: lock/home state, its own compositor window, and
/// the app launcher (backed directly by `AppManager::list_apps`/
/// `launch`, per the Day 24 DoD's own wording — "via M5's App
/// Manager / package manifest data").
pub struct Shell<B: WaylandBackend> {
    state: ShellState,
    apps: AppManager,
    window: Window<B>,
    status_bar: StatusBar,
}

impl<B: WaylandBackend> Shell<B> {
    /// Starts `Locked`, with `window`'s title set to
    /// [`LOCK_SCREEN_TITLE`] — "from a cold boot, the lock screen
    /// appears" is this: a real window, with this real title, on
    /// whatever real compositor `window`'s backend is connected to.
    pub fn new(apps: AppManager, mut window: Window<B>) -> Result<Self, ShellError> {
        window.set_title(LOCK_SCREEN_TITLE).map_err(ShellError::Window)?;
        Ok(Self { state: ShellState::Locked, apps, window, status_bar: StatusBar::new() })
    }

    pub fn state(&self) -> ShellState {
        self.state
    }

    pub fn window_state(&self) -> Result<WindowState, ShellError> {
        self.window.state().map_err(ShellError::Window)
    }

    /// Always succeeds today — see this module's own doc comment on
    /// why that's a named simplification, not an oversight. Updates
    /// the shell's real window title to [`HOME_SCREEN_TITLE`] — the
    /// externally-verifiable half of "unlocking reaches the home
    /// screen."
    pub fn unlock(&mut self) -> Result<(), ShellError> {
        self.state = ShellState::Home;
        self.window.set_title(HOME_SCREEN_TITLE).map_err(ShellError::Window)
    }

    pub fn lock(&mut self) -> Result<(), ShellError> {
        self.state = ShellState::Locked;
        self.window.set_title(LOCK_SCREEN_TITLE).map_err(ShellError::Window)
    }

    /// The launcher's app list, straight from `AppManager::list_apps`
    /// — i.e. from real installed-package manifest data (Day 14's
    /// `nova-app.toml` schema, validated through `AppManager::install`),
    /// not a hardcoded or cached list this crate maintains itself.
    /// Available regardless of lock state — seeing what's installed
    /// isn't gated, only *launching* is.
    pub fn installed_apps(&self) -> Vec<AppListEntry> {
        self.apps.list_apps()
    }

    /// Launches `app_id` through the same `AppManager::launch` every
    /// other app in this repo goes through — the launcher doesn't get
    /// a special, separate launch path. Blocked entirely while
    /// `Locked`, which is the one piece of access control this DoD
    /// actually asks for.
    pub fn launch_app(&self, app_id: &str) -> Result<u32, ShellError> {
        if self.state != ShellState::Home {
            return Err(ShellError::Locked);
        }
        self.apps.launch(app_id).map_err(ShellError::AppManager)
    }

    /// Current status bar state — time, plus the honest battery/
    /// connectivity placeholders. Does not itself re-read the clock;
    /// call [`Shell::refresh_status_bar`] first for that.
    pub fn status_bar(&self) -> &StatusBarState {
        self.status_bar.state()
    }

    /// Re-reads the real system clock into the status bar's `time`
    /// field. The Day 25 DoD's "renders live, updating time" is this
    /// being called again later and the returned state's `time`
    /// having actually changed — proven live (not just
    /// formatting-correct) by
    /// `tools/nova-day25-statusbar-settings-acceptance-test`.
    pub fn refresh_status_bar(&mut self) -> &StatusBarState {
        self.status_bar.refresh()
    }

    /// Day 25: "Wire the existing Settings app into the shell
    /// (accessible from status bar / quick settings, not just
    /// standalone launch)." A dedicated entry point distinct from
    /// [`Shell::launch_app`] — Settings already appears in the
    /// generic launcher list too (it's one of the six real apps), but
    /// this is the shell's *own* direct route to it, the same way a
    /// real status bar's quick-settings panel has its own gear icon
    /// rather than making you find Settings in an app drawer. Gated
    /// by lock state the same as any other launch.
    pub fn open_quick_settings(&self) -> Result<u32, ShellError> {
        if self.state != ShellState::Home {
            return Err(ShellError::Locked);
        }
        self.apps.launch(SETTINGS_APP_ID).map_err(ShellError::AppManager)
    }

    /// Day 28: the shell's own reference to the one canonical theme
    /// resource — the "shell" half of "consistent theming across
    /// shell and every app." See this module's own doc comment for
    /// why that can only be a data-level claim today, not a visual
    /// one.
    pub fn theme(&self) -> &'static nova_theme::Theme {
        &nova_theme::DEFAULT
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_window_api::StubBackend;

    fn new_shell() -> Shell<StubBackend> {
        let apps = AppManager::new();
        let window = Window::create(StubBackend::new(), "unused-initial-title", 1080, 2400).unwrap();
        Shell::new(apps, window).unwrap()
    }

    #[test]
    fn starts_locked_with_lock_screen_title() {
        let shell = new_shell();
        assert_eq!(shell.state(), ShellState::Locked);
        assert_eq!(shell.window_state().unwrap().title, LOCK_SCREEN_TITLE);
    }

    #[test]
    fn unlock_transitions_to_home_and_updates_window_title() {
        let mut shell = new_shell();
        shell.unlock().unwrap();
        assert_eq!(shell.state(), ShellState::Home);
        assert_eq!(shell.window_state().unwrap().title, HOME_SCREEN_TITLE);
    }

    #[test]
    fn lock_after_unlock_returns_to_lock_screen() {
        let mut shell = new_shell();
        shell.unlock().unwrap();
        shell.lock().unwrap();
        assert_eq!(shell.state(), ShellState::Locked);
        assert_eq!(shell.window_state().unwrap().title, LOCK_SCREEN_TITLE);
    }

    #[test]
    fn launch_app_while_locked_is_rejected_before_touching_app_manager() {
        let shell = new_shell();
        assert_eq!(shell.state(), ShellState::Locked);
        // No app was ever installed on `shell.apps` -- if this
        // incorrectly reached AppManager::launch, it would fail for a
        // *different* reason (no such app). Getting exactly
        // `ShellError::Locked` proves the gate runs first.
        assert!(matches!(shell.launch_app("org.nova.anything"), Err(ShellError::Locked)));
    }

    #[test]
    fn installed_apps_reflects_app_manager_regardless_of_lock_state() {
        let shell = new_shell();
        // Nothing installed on a fresh AppManager -- the launcher
        // list is real data, not a fabricated placeholder list.
        assert!(shell.installed_apps().is_empty());
    }

    #[test]
    fn status_bar_starts_populated_with_honest_placeholders() {
        let shell = new_shell();
        assert!(!shell.status_bar().time.is_empty());
        assert_eq!(shell.status_bar().battery, statusbar::BatteryStatus::Unavailable);
        assert_eq!(shell.status_bar().connectivity, statusbar::ConnectivityStatus::Unavailable);
    }

    #[test]
    fn open_quick_settings_while_locked_is_rejected_before_touching_app_manager() {
        let shell = new_shell();
        assert_eq!(shell.state(), ShellState::Locked);
        // No app was ever installed on `shell.apps` -- same reasoning
        // as the launch_app test above: getting exactly
        // ShellError::Locked (not an AppManager "no such app" error)
        // proves the gate runs first.
        assert!(matches!(shell.open_quick_settings(), Err(ShellError::Locked)));
    }

    #[test]
    fn theme_returns_the_one_canonical_resource() {
        let shell = new_shell();
        assert_eq!(shell.theme(), &nova_theme::DEFAULT);
    }
}
