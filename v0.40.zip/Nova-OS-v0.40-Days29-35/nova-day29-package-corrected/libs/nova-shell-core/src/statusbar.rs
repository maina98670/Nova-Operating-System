//! Nova OS Day 25 — status bar.
//!
//! Per the Day 25 task list: "Status bar (time, battery placeholder
//! until M9's power HAL exists, connectivity placeholder until M8)."
//!
//! - **Time is real.** Wall-clock time doesn't depend on any
//!   not-yet-built subsystem — `refresh()` re-reads the real system
//!   clock every call. "Renders live, updating time" (the DoD's own
//!   wording) means exactly this: call `refresh()` again later, get a
//!   different [`StatusBarState::time`].
//! - **Battery and connectivity are honest placeholders, not fake
//!   data.** [`BatteryStatus::Unavailable`] and
//!   [`ConnectivityStatus::Unavailable`] are the only values either
//!   enum has today — same pattern as `nova-input-api::InputError::NotYetAvailable`
//!   and `nova-network-api::NetworkError::NotImplemented`. M9 (power
//!   HAL) and M8 (networking) are what fill these in for real; until
//!   then, a status bar showing a fabricated battery percentage would
//!   be a lie this crate isn't willing to tell.

use std::time::{Duration, SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BatteryStatus {
    /// No power HAL exists yet — that's M9's job.
    Unavailable,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConnectivityStatus {
    /// No networking stack exists yet — that's M8's job.
    Unavailable,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StatusBarState {
    /// `HH:MM:SS UTC`, from the real system clock as of the last
    /// `refresh()`. No timezone database is available or needed for
    /// this milestone — UTC, labeled as such, rather than silently
    /// wrong local time.
    pub time: String,
    pub battery: BatteryStatus,
    pub connectivity: ConnectivityStatus,
}

pub struct StatusBar {
    state: StatusBarState,
}

impl Default for StatusBar {
    fn default() -> Self {
        Self::new()
    }
}

impl StatusBar {
    pub fn new() -> Self {
        let mut bar = Self { state: StatusBarState { time: String::new(), battery: BatteryStatus::Unavailable, connectivity: ConnectivityStatus::Unavailable } };
        bar.refresh();
        bar
    }

    /// Re-reads the real system clock. The DoD's "renders live,
    /// updating time" is this being called repeatedly over real
    /// elapsed time — proven live (not just formatting-correct) by
    /// `tools/nova-day25-statusbar-settings-acceptance-test`, which
    /// actually waits and calls this twice.
    pub fn refresh(&mut self) -> &StatusBarState {
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default();
        self.state.time = format_time(now);
        &self.state
    }

    pub fn state(&self) -> &StatusBarState {
        &self.state
    }
}

/// Pure and independently testable, separate from `refresh()`'s own
/// call to the real clock — so formatting correctness (this function)
/// and "does it actually change over real wall-clock time"
/// (`refresh()`, proven live in the acceptance test) are tested
/// separately rather than forcing every test to sleep on the real
/// clock.
fn format_time(elapsed_since_epoch: Duration) -> String {
    let secs = elapsed_since_epoch.as_secs();
    let h = (secs / 3600) % 24;
    let m = (secs / 60) % 60;
    let s = secs % 60;
    format!("{h:02}:{m:02}:{s:02} UTC")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn format_time_examples() {
        assert_eq!(format_time(Duration::from_secs(0)), "00:00:00 UTC");
        assert_eq!(format_time(Duration::from_secs(3661)), "01:01:01 UTC");
        assert_eq!(format_time(Duration::from_secs(90_000)), "01:00:00 UTC"); // 25h wraps to 01:00:00
        assert_eq!(format_time(Duration::from_secs(86_399)), "23:59:59 UTC");
    }

    #[test]
    fn new_status_bar_starts_with_placeholders_not_fake_data() {
        let bar = StatusBar::new();
        assert_eq!(bar.state().battery, BatteryStatus::Unavailable);
        assert_eq!(bar.state().connectivity, ConnectivityStatus::Unavailable);
        assert!(!bar.state().time.is_empty());
    }

    #[test]
    fn refresh_returns_the_same_state_it_stores() {
        let mut bar = StatusBar::new();
        let refreshed = bar.refresh().clone();
        assert_eq!(refreshed, *bar.state());
    }
}
