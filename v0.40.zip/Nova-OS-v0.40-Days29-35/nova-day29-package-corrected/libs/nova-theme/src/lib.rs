//! Nova OS Day 28 — shared theme resource.
//!
//! Per the Day 28 task list: "Basic theming (consistent colors/
//! typography across shell and apps — most existing apps already
//! share this by convention; formalize it as a shared theme
//! resource)."
//!
//! ## Honest starting point
//! No app or the shell shares any visual convention today — there is
//! no visual anything today. Every app built since Day 16 is headless
//! except Dialer/Camera's Day 27 tappable regions, which are plain,
//! unstyled rectangles with no color or font attached. "Most existing
//! apps already share this by convention" doesn't describe this
//! track, the same gap between the guide's assumptions and what was
//! actually built that Days 16/19/23/27 already named for their own
//! tasks.
//!
//! What's real here instead: [`Theme`] and [`Typography`] are the
//! **one canonical resource** a future renderer (Smithay, per
//! `docs/compositor-backend-decision-v1.md`) and every app's own
//! future UI code would reference, defined now so nothing has to
//! invent its own colors later. [`TextScale`] is real, working
//! accessibility logic — computing a scaled pixel size is pure math,
//! not dependent on rendering existing — wired into a real, persisted
//! setting in `nova-settings-core` (`text_scale`, Day 28).
//!
//! **What this crate cannot do**: make Nova's UI visually consistent.
//! That's a property of pixels on a screen, and there are no pixels
//! anywhere in this repo yet. "Consistent theming across shell and
//! every app" is unverifiable as a visual claim until real rendering
//! exists (M12, per the Day 23 ADR); what's verifiable today is that
//! the resource exists, is well-defined, and that scaling it produces
//! correct numbers — both covered by this crate's own unit tests.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Color {
    pub r: u8,
    pub g: u8,
    pub b: u8,
}

impl Color {
    pub const fn rgb(r: u8, g: u8, b: u8) -> Self {
        Self { r, g, b }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Typography {
    /// Base body-text size, in logical pixels, before any
    /// accessibility scaling is applied.
    pub body_px: u32,
    /// Heading size relative to body, expressed as a whole-number
    /// percentage (e.g. `150` = 1.5x body) rather than a float, so
    /// this struct (and `Theme`, which embeds it) can derive `Eq` —
    /// the same reasoning `nova-compositor-core::protocol::Message`
    /// uses floats-on-the-wire vs `Eq` for.
    pub heading_scale_percent: u32,
}

impl Typography {
    pub const fn heading_px(&self) -> u32 {
        self.body_px * self.heading_scale_percent / 100
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Theme {
    pub name: &'static str,
    pub background: Color,
    pub surface: Color,
    pub text: Color,
    pub accent: Color,
    pub typography: Typography,
}

/// The one canonical theme every app and the shell reference — see
/// this module's own doc comment on what "reference" can and can't
/// mean without a renderer to actually apply it to.
pub const DEFAULT: Theme = Theme {
    name: "Nova Default",
    background: Color::rgb(18, 18, 20),
    surface: Color::rgb(30, 30, 34),
    text: Color::rgb(240, 240, 245),
    accent: Color::rgb(90, 140, 255),
    typography: Typography { body_px: 16, heading_scale_percent: 150 },
};

#[derive(Debug)]
pub enum TextScaleError {
    OutOfRange(u32),
}

impl std::fmt::Display for TextScaleError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TextScaleError::OutOfRange(percent) => write!(f, "text scale {percent}% is outside the supported 80-200% range"),
        }
    }
}
impl std::error::Error for TextScaleError {}

/// Real accessibility logic: a validated text-scale factor, expressed
/// as a whole-number percentage (matching `nova-settings-core`'s
/// `text_scale` setting, which stores exactly this). `100` = no
/// scaling.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TextScale(u32);

impl TextScale {
    pub const MIN_PERCENT: u32 = 80;
    pub const MAX_PERCENT: u32 = 200;

    pub fn from_percent(percent: u32) -> Result<Self, TextScaleError> {
        if (Self::MIN_PERCENT..=Self::MAX_PERCENT).contains(&percent) {
            Ok(Self(percent))
        } else {
            Err(TextScaleError::OutOfRange(percent))
        }
    }

    pub fn percent(self) -> u32 {
        self.0
    }

    /// Applies this scale to a base pixel size — the actual, working
    /// text-scaling computation. Rounds to the nearest pixel rather
    /// than truncating, so a 150% scale on 16px gives 24px exactly
    /// instead of drifting down over repeated small bases.
    pub fn apply(self, base_px: u32) -> u32 {
        (base_px * self.0 + 50) / 100
    }
}

impl Default for TextScale {
    fn default() -> Self {
        Self(100)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn heading_px_derives_from_body_and_scale() {
        assert_eq!(DEFAULT.typography.heading_px(), 24); // 16 * 150 / 100
    }

    #[test]
    fn text_scale_rejects_out_of_range() {
        assert!(matches!(TextScale::from_percent(50), Err(TextScaleError::OutOfRange(50))));
        assert!(matches!(TextScale::from_percent(250), Err(TextScaleError::OutOfRange(250))));
        assert!(TextScale::from_percent(80).is_ok());
        assert!(TextScale::from_percent(200).is_ok());
    }

    #[test]
    fn default_scale_is_identity() {
        let scale = TextScale::default();
        assert_eq!(scale.percent(), 100);
        assert_eq!(scale.apply(16), 16);
    }

    #[test]
    fn scaling_rounds_to_nearest_pixel() {
        let scale = TextScale::from_percent(150).unwrap();
        assert_eq!(scale.apply(16), 24); // 24.0 exactly
        assert_eq!(scale.apply(11), 17); // 16.5 -> rounds to 17
    }

    #[test]
    fn scaling_the_whole_theme_is_consistent() {
        let scale = TextScale::from_percent(200).unwrap();
        assert_eq!(scale.apply(DEFAULT.typography.body_px), 32);
        assert_eq!(scale.apply(DEFAULT.typography.heading_px()), 48);
    }
}
