#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 27: build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 27: unit tests (nova-ipc, nova-window-api, nova-compositor-core, nova-input-api) ==="
cargo test -p nova-ipc -p nova-window-api -p nova-compositor-core -p nova-input-api

echo
echo "=== Nova OS Day 27: live acceptance ==="
echo "Launches Dialer and Camera as real, separate processes with real, non-overlapping"
echo "windows, injects real taps through the compositor's real hit-testing, and confirms"
echo "the resulting call log / photo library by reloading each app's persisted state fresh."
echo "Needs the same root-capable Linux environment as the Day 11-26 live tests."
cargo run -p nova-day27-input-pipeline-acceptance-test

echo
echo "Day 27 build + tests + live acceptance completed."
