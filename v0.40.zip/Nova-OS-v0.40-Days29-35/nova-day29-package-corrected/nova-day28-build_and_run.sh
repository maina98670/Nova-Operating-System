#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 28 (M7 final): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 28: unit tests (nova-theme, nova-settings-core, nova-shell-core) ==="
cargo test -p nova-theme -p nova-settings-core -p nova-shell-core

echo
echo "=== Nova OS Day 28: full-shell live acceptance ==="
echo "The complete cold-boot-to-interactive-app-to-home flow: all six real apps, real"
echo "taps through the real compositor, real theme consistency. Needs the same"
echo "root-capable Linux environment as the Day 11-27 live tests."
cargo run -p nova-day28-full-shell-acceptance-test

echo
echo "Day 28 build + tests + full-shell acceptance completed."
echo
echo "If it passed, tag the repo (see docs/M7-TAG.md):"
echo "  git tag -a v0.33 -m \"M7: GUI & Window System\""
echo "  git push origin v0.33"
