//! Nova OS Day 23 live acceptance.
//!
//! DoD: "Two or more existing apps (e.g. Settings and Camera) can run
//! as separate windows composited on the same output simultaneously,
//! each getting correct damage/redraw."
//!
//! This uses two dedicated demo apps (`org.nova.compositor_demo_a`/
//! `_b`) rather than modifying Settings/Camera themselves — the same
//! call Days 19-21 made for their own new-API demos, to avoid
//! repeatedly touching already-built app code. The DoD's own wording
//! ("e.g.") treats the specific apps as illustrative, not mandatory;
//! what matters is that they're **two real, separate OS processes**,
//! which these are.
//!
//! Every assertion below is against the compositor's own live state
//! (`CompositorServer`'s direct methods, run in this same process),
//! not either demo app's stdout — the same external-verification
//! standard every acceptance test since Day 20 has used.

use nova_app_manager::AppManager;
use nova_compositor_core::model::Rect;
use nova_compositor_core::server::CompositorServer;
use nova_compositor_core::{OutputId, SurfaceId};
use nova_ipc::SOCKET_PATH;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

struct DemoApp {
    id: &'static str,
    bin_name: &'static str,
    manifest: &'static str,
}

const APPS: &[DemoApp] = &[
    DemoApp {
        id: "org.nova.compositor_demo_a",
        bin_name: "nova-compositor-demo-a",
        manifest: include_str!("../../../apps/org.nova.compositor_demo_a/nova-app.toml"),
    },
    DemoApp {
        id: "org.nova.compositor_demo_b",
        bin_name: "nova-compositor-demo-b",
        manifest: include_str!("../../../apps/org.nova.compositor_demo_b/nova-app.toml"),
    },
];

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn app_dir(id: &str) -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(id)
}

fn install_and_launch(manager: &AppManager, app: &DemoApp) -> u32 {
    let dir = app_dir(app.id);
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), app.manifest).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(app.bin_name);
    if !bin_src.exists() {
        fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", bin_src.display()));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(app.bin_name);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(app.id).unwrap_or_else(|e| fail(format!("install {}: {e}", app.id)));
    manager.launch(app.id).unwrap_or_else(|e| fail(format!("launch {}: {e}", app.id)))
}

fn main() {
    println!("=== Nova OS Day 23: compositor core acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));

    // --- App Manager, for the two demo apps' Hello handshake ---
    let manager = AppManager::new();
    let _app_server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("app manager serve: {e}")));

    // --- Compositor, on its own separate socket ---
    let compositor = CompositorServer::new();
    let _compositor_server = compositor
        .serve(nova_compositor_core::protocol::SOCKET_PATH)
        .unwrap_or_else(|e| fail(format!("compositor serve: {e}")));

    let output = compositor.create_output("output-0", 1080, 2400);
    if output != OutputId(1) {
        fail(format!(
            "expected the first created output to be id 1 (the demo apps hardcode this) -- got {output:?}. \
             If CompositorServer's OutputId allocation changed, the demo apps' DEFAULT_OUTPUT constant needs updating too."
        ));
    }
    println!("compositor output created: {output:?} (1080x2400)");

    // --- Launch both demo apps as real, separate processes ---
    let mut pids = Vec::new();
    for app in APPS {
        let pid = install_and_launch(&manager, app);
        println!("launched {} pid={pid}", app.id);
        pids.push(pid);
    }

    for app in APPS {
        let deadline = Instant::now() + Duration::from_secs(5);
        while manager.cold_start_ms(app.id).is_none() {
            if Instant::now() >= deadline {
                fail(format!("{} did not complete its Hello/HelloAck handshake within 5s", app.id));
            }
            thread::sleep(Duration::from_millis(20));
        }
    }
    println!("both apps completed their App Manager handshake");

    // --- Wait for both apps to have connected to the compositor and created a window ---
    let deadline = Instant::now() + Duration::from_secs(5);
    let mut surfaces = compositor.surfaces_on(output);
    while surfaces.len() < 2 {
        if Instant::now() >= deadline {
            fail(format!(
                "expected 2 surfaces on {output:?} within 5s, got {} -- check each demo app's stderr for a Window::create failure",
                surfaces.len()
            ));
        }
        thread::sleep(Duration::from_millis(50));
        surfaces = compositor.surfaces_on(output);
    }

    let surface_a = surfaces.iter().find(|s| s.app_id == APPS[0].id).unwrap_or_else(|| fail(format!("no surface from {}", APPS[0].id))).id;
    let surface_b = surfaces.iter().find(|s| s.app_id == APPS[1].id).unwrap_or_else(|| fail(format!("no surface from {}", APPS[1].id))).id;
    println!(
        "VERIFIED: both apps created real windows on the same output -- {} -> {surface_a:?}, {} -> {surface_b:?}",
        APPS[0].id, APPS[1].id
    );

    // Consume the "just created" damage from both, so the DoD's own
    // incremental checks below start from a clean slate.
    let initial = compositor.frame(output).unwrap_or_else(|e| fail(format!("initial frame(): {e}")));
    println!("consumed initial creation damage: {} surface(s)", initial.damaged_surfaces.len());

    // --- The actual DoD: damage one, confirm only that one is reported ---
    let region_a = Rect::new(10, 10, 20, 20);
    compositor.mark_damaged(surface_a, region_a).unwrap_or_else(|e| fail(format!("mark_damaged(a): {e}")));
    let frame1 = compositor.frame(output).unwrap_or_else(|e| fail(format!("frame() after damaging a: {e}")));
    if frame1.damaged_surfaces != vec![(surface_a, region_a)] {
        fail(format!(
            "expected exactly [(a, {region_a:?})] damaged, got {:?} -- damage isolation between separate app processes is broken",
            frame1.damaged_surfaces
        ));
    }
    println!("VERIFIED: damaging only {}'s window reports only its surface, not {}'s", APPS[0].id, APPS[1].id);

    // --- Damage both, confirm both reported, correctly ordered ---
    let region_a2 = Rect::new(0, 0, 5, 5);
    let region_b = Rect::new(50, 50, 30, 30);
    compositor.mark_damaged(surface_a, region_a2).unwrap_or_else(|e| fail(format!("mark_damaged(a2): {e}")));
    compositor.mark_damaged(surface_b, region_b).unwrap_or_else(|e| fail(format!("mark_damaged(b): {e}")));
    let frame2 = compositor.frame(output).unwrap_or_else(|e| fail(format!("frame() after damaging both: {e}")));
    if frame2.damaged_surfaces != vec![(surface_a, region_a2), (surface_b, region_b)] {
        fail(format!(
            "expected [(a, {region_a2:?}), (b, {region_b:?})] in that (bottom-to-top creation) order, got {:?}",
            frame2.damaged_surfaces
        ));
    }
    println!("VERIFIED: damaging both windows reports both surfaces, correctly ordered, in one frame");

    // Third frame with nothing newly damaged must be empty -- proves
    // damage is actually cleared, not just reported and left dangling.
    let frame3 = compositor.frame(output).unwrap_or_else(|e| fail(format!("frame() #3: {e}")));
    if !frame3.is_empty() {
        fail(format!("expected an empty frame with nothing newly damaged, got {frame3:?}"));
    }
    println!("VERIFIED: damage is cleared after each frame(), not left to re-report stale damage");

    // --- Cleanup ---
    for app in APPS {
        let _ = manager.terminate(app.id);
    }
    thread::sleep(Duration::from_millis(150));
    for app in APPS {
        if manager.pid_of(app.id).is_some() {
            fail(format!("{} still tracked as running after terminate()", app.id));
        }
        let _ = fs::remove_dir_all(app_dir(app.id));
    }
    let _ = fs::remove_file(SOCKET_PATH);
    let _ = fs::remove_file(nova_compositor_core::protocol::SOCKET_PATH);
    let _: Vec<u32> = pids; // kept for readability of the log above, not asserted on further

    println!();
    println!("=== Day 23 ACCEPTANCE: PASS ===");
    println!("Two real, separate app processes each created a window on the same real compositor");
    println!("output; the compositor correctly isolated damage to whichever surface(s) were");
    println!("actually marked damaged, in the right order, and cleared it after each frame.");
    println!("No pixels were rendered anywhere -- see docs/compositor-backend-decision-v1.md for");
    println!("why that's out of reach in this environment, not silently skipped.");
}
