//! Nova OS Day 24 live acceptance.
//!
//! DoD: "From a cold boot, the lock screen appears, unlocking reaches
//! the home screen, and the launcher lists and can start every
//! currently-installed app (Settings, Contacts, Messages, Dialer,
//! Camera, Hello-world)."
//!
//! Every assertion is against real state: `Shell`'s own `state()`/
//! `window_state()` (window title on the real compositor, via
//! `CompositorClientBackend`, not `StubBackend`), `AppManager`'s own
//! `list_apps()`/`cold_start_ms()`/`process_list()` for each of the
//! six real apps built Days 16-17 -- not any app's stdout, and not
//! `nova-shell-core`'s own unit tests (which use `StubBackend` and
//! don't touch real processes at all).

use nova_app_manager::AppManager;
use nova_compositor_core::client::CompositorClientBackend;
use nova_compositor_core::server::CompositorServer;
use nova_compositor_core::OutputId;
use nova_ipc::SOCKET_PATH;
use nova_shell_core::{Shell, ShellError, ShellState, HOME_SCREEN_TITLE, LOCK_SCREEN_TITLE};
use nova_window_api::Window;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

struct RealApp {
    id: &'static str,
    bin_name: &'static str,
    manifest: &'static str,
}

const REAL_APPS: &[RealApp] = &[
    RealApp { id: "org.nova.settings", bin_name: "nova-settings", manifest: include_str!("../../../apps/org.nova.settings/nova-app.toml") },
    RealApp { id: "org.nova.contacts", bin_name: "nova-contacts", manifest: include_str!("../../../apps/org.nova.contacts/nova-app.toml") },
    RealApp { id: "org.nova.messages", bin_name: "nova-messages", manifest: include_str!("../../../apps/org.nova.messages/nova-app.toml") },
    RealApp { id: "org.nova.dialer", bin_name: "nova-dialer", manifest: include_str!("../../../apps/org.nova.dialer/nova-app.toml") },
    RealApp { id: "org.nova.camera", bin_name: "nova-camera", manifest: include_str!("../../../apps/org.nova.camera/nova-app.toml") },
    RealApp { id: "org.nova.hello", bin_name: "nova-hello", manifest: include_str!("../../../apps/org.nova.hello/nova-app.toml") },
];

const SHELL_APP_ID: &str = "org.nova.shell-test";

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn app_dir(id: &str) -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(id)
}

/// Installs (manifest + binary onto disk, then `AppManager::install`)
/// without launching -- "currently-installed" per the DoD, ready for
/// the shell's own launcher to list and start.
fn install_only(manager: &AppManager, app: &RealApp) {
    let dir = app_dir(app.id);
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), app.manifest).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(app.bin_name);
    if !bin_src.exists() {
        fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", bin_src.display()));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(app.bin_name);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(app.id).unwrap_or_else(|e| fail(format!("install {}: {e}", app.id)));
}

fn main() {
    println!("=== Nova OS Day 24: desktop shell + launcher acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));

    let manager = AppManager::new();
    let _app_server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("app manager serve: {e}")));

    let compositor = CompositorServer::new();
    let _compositor_server = compositor
        .serve(nova_compositor_core::protocol::SOCKET_PATH)
        .unwrap_or_else(|e| fail(format!("compositor serve: {e}")));
    let output = compositor.create_output("output-0", 1080, 2400);
    if output != OutputId(1) {
        fail(format!("expected output id 1 (the shell hardcodes this) -- got {output:?}"));
    }

    // --- "currently-installed": install all six real apps, don't launch yet ---
    for app in REAL_APPS {
        install_only(&manager, app);
    }
    println!("installed {} real apps (not yet launched)", REAL_APPS.len());

    // --- Cold boot: the shell itself, locked ---
    let backend = CompositorClientBackend::connect_default(SHELL_APP_ID, 1).unwrap_or_else(|e| fail(format!("connect to compositor: {e}")));
    let window = Window::create(backend, "unused-initial-title", 1080, 2400).unwrap_or_else(|e| fail(format!("Window::create: {e}")));
    let mut shell = Shell::new(manager.clone(), window).unwrap_or_else(|e| fail(format!("Shell::new: {e}")));

    if shell.state() != ShellState::Locked {
        fail(format!("expected Locked on a cold start, got {:?}", shell.state()));
    }
    let locked_title = shell.window_state().unwrap_or_else(|e| fail(format!("window_state(): {e}"))).title;
    if locked_title != LOCK_SCREEN_TITLE {
        fail(format!("expected the shell's real window title to be {LOCK_SCREEN_TITLE:?} while locked, got {locked_title:?}"));
    }
    println!("VERIFIED: cold boot -- shell is Locked, real compositor window titled {locked_title:?}");

    // --- Launcher lists installed apps regardless of lock state ---
    let listed = shell.installed_apps();
    for app in REAL_APPS {
        if !listed.iter().any(|e| e.id == app.id) {
            fail(format!("launcher's installed_apps() is missing {} -- got {listed:?}", app.id));
        }
    }
    println!("VERIFIED: launcher lists all {} currently-installed apps", REAL_APPS.len());

    // --- Locked screen actually blocks launching ---
    match shell.launch_app(REAL_APPS[0].id) {
        Err(ShellError::Locked) => println!("VERIFIED: launching while locked is correctly rejected"),
        Ok(pid) => fail(format!("SECURITY REGRESSION: launch_app succeeded while locked (pid={pid})")),
        Err(e) => fail(format!("expected ShellError::Locked, got a different error: {e}")),
    }

    // --- Unlock: reaches the home screen ---
    shell.unlock().unwrap_or_else(|e| fail(format!("unlock(): {e}")));
    if shell.state() != ShellState::Home {
        fail(format!("expected Home after unlock(), got {:?}", shell.state()));
    }
    let home_title = shell.window_state().unwrap_or_else(|e| fail(format!("window_state(): {e}"))).title;
    if home_title != HOME_SCREEN_TITLE {
        fail(format!("expected the shell's real window title to be {HOME_SCREEN_TITLE:?} after unlock, got {home_title:?}"));
    }
    println!("VERIFIED: unlock() -- shell is Home, real compositor window titled {home_title:?}");

    // --- The launcher can actually start every one of the six apps ---
    let mut pids = Vec::new();
    for app in REAL_APPS {
        let pid = shell.launch_app(app.id).unwrap_or_else(|e| fail(format!("launch_app({}): {e}", app.id)));
        pids.push((app.id, pid));
    }
    for (id, _) in pids.iter().copied() {
        let deadline = Instant::now() + Duration::from_secs(5);
        while manager.cold_start_ms(id).is_none() {
            if Instant::now() >= deadline {
                fail(format!("{id} did not complete its Hello/HelloAck handshake within 5s after being launched via the shell"));
            }
            thread::sleep(Duration::from_millis(20));
        }
    }
    println!("VERIFIED: the launcher started all {} apps, each completing its own real IPC handshake with App Manager", REAL_APPS.len());

    for (id, pid) in pids.iter().copied() {
        if !manager.process_list().iter().any(|p| p.pid == pid) {
            fail(format!("{id}'s pid {pid} missing from M4 Process Manager's process_list()"));
        }
    }
    println!("VERIFIED: all six launched processes cross-checked against M4's Process Manager");

    // --- Cleanup ---
    for (id, _) in pids.iter().copied() {
        let _ = manager.terminate(id);
    }
    thread::sleep(Duration::from_millis(200));
    for app in REAL_APPS {
        if manager.pid_of(app.id).is_some() {
            fail(format!("{} still tracked as running after terminate()", app.id));
        }
        let _ = fs::remove_dir_all(app_dir(app.id));
    }
    let _ = fs::remove_file(SOCKET_PATH);
    let _ = fs::remove_file(nova_compositor_core::protocol::SOCKET_PATH);

    println!();
    println!("=== Day 24 ACCEPTANCE: PASS ===");
    println!("From a cold start: the lock screen appeared (real state + real compositor window");
    println!("title), launching was correctly blocked while locked, unlocking reached the home");
    println!("screen (again real state + real window title), and the launcher listed and actually");
    println!("started all six currently-installed apps, each verified via its own real IPC");
    println!("handshake and cross-checked against M4's Process Manager.");
}
