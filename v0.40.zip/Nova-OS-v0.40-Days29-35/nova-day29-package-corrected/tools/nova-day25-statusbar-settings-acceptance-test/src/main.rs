//! Nova OS Day 25 live acceptance.
//!
//! DoD: "The status bar renders live, updating time at minimum, and
//! Settings is reachable from within the shell UI, not only by direct
//! process launch."
//!
//! Two independent proofs:
//! 1. **Live status bar**: read `shell.status_bar().time`, sleep past
//!    a real one-second boundary, call `shell.refresh_status_bar()`,
//!    confirm the time string actually changed — a real wait against
//!    the real system clock, not a mocked one.
//! 2. **Settings reachable from the shell UI**: `shell.open_quick_settings()`
//!    — a dedicated entry point, not `shell.launch_app("org.nova.settings")`
//!    (which Day 24 already proved works as part of the generic
//!    launcher) — confirmed via Settings' own real IPC handshake with
//!    App Manager, cross-checked against M4's Process Manager. Also
//!    confirms quick settings is blocked while locked, same gate as
//!    the generic launcher.

use nova_app_manager::AppManager;
use nova_compositor_core::client::CompositorClientBackend;
use nova_compositor_core::server::CompositorServer;
use nova_compositor_core::OutputId;
use nova_ipc::SOCKET_PATH;
use nova_shell_core::{Shell, ShellError, ShellState, SETTINGS_APP_ID};
use nova_window_api::Window;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const SETTINGS_BIN: &str = "nova-settings";
const SETTINGS_MANIFEST: &str = include_str!("../../../apps/org.nova.settings/nova-app.toml");
const SHELL_APP_ID: &str = "org.nova.shell-test";

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn app_dir(id: &str) -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(id)
}

fn install_settings(manager: &AppManager) {
    let dir = app_dir(SETTINGS_APP_ID);
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), SETTINGS_MANIFEST).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(SETTINGS_BIN);
    if !bin_src.exists() {
        fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", bin_src.display()));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(SETTINGS_BIN);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(SETTINGS_APP_ID).unwrap_or_else(|e| fail(format!("install {SETTINGS_APP_ID}: {e}")));
}

fn main() {
    println!("=== Nova OS Day 25: status bar + Settings integration acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));

    let manager = AppManager::new();
    let _app_server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("app manager serve: {e}")));

    let compositor = CompositorServer::new();
    let _compositor_server = compositor
        .serve(nova_compositor_core::protocol::SOCKET_PATH)
        .unwrap_or_else(|e| fail(format!("compositor serve: {e}")));
    let output = compositor.create_output("output-0", 1080, 2400);
    if output != OutputId(1) {
        fail(format!("expected output id 1 -- got {output:?}"));
    }

    install_settings(&manager);
    println!("installed {SETTINGS_APP_ID} (not yet launched)");

    let backend = CompositorClientBackend::connect_default(SHELL_APP_ID, 1).unwrap_or_else(|e| fail(format!("connect to compositor: {e}")));
    let window = Window::create(backend, "unused-initial-title", 1080, 2400).unwrap_or_else(|e| fail(format!("Window::create: {e}")));
    let mut shell = Shell::new(manager.clone(), window).unwrap_or_else(|e| fail(format!("Shell::new: {e}")));

    // --- Proof 1: the status bar renders live ---
    let t1 = shell.status_bar().time.clone();
    println!("status bar time (before wait): {t1}");
    // Sleep past a real one-second boundary so a second-resolution
    // clock read is guaranteed to differ, not just likely to.
    thread::sleep(Duration::from_millis(1100));
    let t2 = shell.refresh_status_bar().time.clone();
    println!("status bar time (after ~1.1s wait + refresh): {t2}");
    if t1 == t2 {
        fail("status bar time did not change after a real 1.1s wait -- it isn't actually live");
    }
    println!("VERIFIED: status bar renders live -- time actually advanced across a real wait");

    let battery = shell.status_bar().battery;
    let connectivity = shell.status_bar().connectivity;
    println!("battery={battery:?} connectivity={connectivity:?} (honest placeholders -- M9/M8 don't exist yet)");
    if battery != nova_shell_core::statusbar::BatteryStatus::Unavailable || connectivity != nova_shell_core::statusbar::ConnectivityStatus::Unavailable {
        fail("status bar reported something other than the honest Unavailable placeholder -- M8/M9 don't exist, this would be fabricated data");
    }
    println!("VERIFIED: battery/connectivity are honest placeholders, not fabricated data");

    // --- Proof 2, part A: quick settings is blocked while locked, same as the generic launcher ---
    if shell.state() != ShellState::Locked {
        fail(format!("expected Locked on a cold start, got {:?}", shell.state()));
    }
    match shell.open_quick_settings() {
        Err(ShellError::Locked) => println!("VERIFIED: quick settings is correctly blocked while locked"),
        Ok(pid) => fail(format!("SECURITY REGRESSION: open_quick_settings succeeded while locked (pid={pid})")),
        Err(e) => fail(format!("expected ShellError::Locked, got a different error: {e}")),
    }

    // --- Proof 2, part B: Settings reachable from the shell UI once unlocked ---
    shell.unlock().unwrap_or_else(|e| fail(format!("unlock(): {e}")));
    let pid = shell.open_quick_settings().unwrap_or_else(|e| fail(format!("open_quick_settings(): {e}")));
    println!("opened Settings via the shell's quick-settings entry point, pid={pid}");

    let deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(SETTINGS_APP_ID).is_none() {
        if Instant::now() >= deadline {
            fail("Settings did not complete its Hello/HelloAck handshake within 5s after being opened via quick settings");
        }
        thread::sleep(Duration::from_millis(20));
    }
    println!("VERIFIED: Settings completed a real IPC handshake with App Manager after being opened via the shell's quick settings");

    if !manager.process_list().iter().any(|p| p.pid == pid) {
        fail(format!("Settings' pid {pid} missing from M4 Process Manager's process_list()"));
    }
    println!("VERIFIED: cross-checked against M4's Process Manager");

    // --- Cleanup ---
    let _ = manager.terminate(SETTINGS_APP_ID);
    thread::sleep(Duration::from_millis(150));
    if manager.pid_of(SETTINGS_APP_ID).is_some() {
        fail("Settings still tracked as running after terminate()");
    }
    let _ = fs::remove_dir_all(app_dir(SETTINGS_APP_ID));
    let _ = fs::remove_file(SOCKET_PATH);
    let _ = fs::remove_file(nova_compositor_core::protocol::SOCKET_PATH);

    println!();
    println!("=== Day 25 ACCEPTANCE: PASS ===");
    println!("The status bar's time actually advanced across a real wait (battery/connectivity");
    println!("stayed honest placeholders), and Settings was reachable from the shell's own");
    println!("quick-settings entry point -- blocked while locked, working once unlocked, and");
    println!("confirmed via a real IPC handshake -- not only by a direct, standalone process launch.");
}
