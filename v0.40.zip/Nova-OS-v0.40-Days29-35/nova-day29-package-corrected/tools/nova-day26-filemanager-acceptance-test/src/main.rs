//! Nova OS Day 26 live acceptance.
//!
//! DoD: "The file manager lists a real directory's contents through
//! the Storage API and can delete a test file, with the deletion
//! actually reflected via M4's Filesystem Manager."
//!
//! The key word is "actually" — this test doesn't just ask
//! `nova-filemanager` whether it thinks the delete worked (its stdout)
//! or even ask `nova-storage-api` again (which could, in principle,
//! delete from some in-memory index without touching disk). It
//! resolves the same path `nova-storage-api` would have used
//! (`SandboxPolicy::scoped_path`) and calls `nova_fsmgr::read_file`
//! directly and independently — M4's Filesystem Manager, called by
//! this test tool, not by the app or the API under test.

use nova_app_manager::AppManager;
use nova_ipc::{Permission, SOCKET_PATH};
use nova_procmgr::ProcessState;
use nova_sandbox::{PermissionSet, SandboxPolicy};
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const APP_ID: &str = "org.nova.filemanager";
const BIN_NAME: &str = "nova-filemanager";
const MANIFEST: &str = include_str!("../../../apps/org.nova.filemanager/nova-app.toml");
const REQUIRED: &[Permission] = &[Permission::Storage];
const APP_DATA_ROOT: &str = "/var/lib/nova/apps"; // SandboxPolicy::app_data_root, Day 15/20

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn app_install_dir() -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(APP_ID)
}

fn app_data_dir() -> PathBuf {
    Path::new(APP_DATA_ROOT).join(APP_ID)
}

fn main() {
    println!("=== Nova OS Day 26: file manager acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));
    fs::create_dir_all(APP_DATA_ROOT).unwrap_or_else(|e| fail(format!("mkdir {APP_DATA_ROOT}: {e}")));
    let _ = fs::remove_dir_all(app_data_dir()); // clean slate so the app's first-run seeding triggers

    let manager = AppManager::new();
    let _server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("serve: {e}")));

    let dir = app_install_dir();
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), MANIFEST).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(BIN_NAME);
    if !bin_src.exists() {
        fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", bin_src.display()));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(BIN_NAME);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(APP_ID).unwrap_or_else(|e| fail(format!("install (manifest validation): {e}")));
    println!("installed and validated");

    let pid = manager.launch(APP_ID).unwrap_or_else(|e| fail(format!("launch: {e}")));
    println!("launched, pid={pid}");

    let deadline = Instant::now() + Duration::from_secs(5);
    while manager.cold_start_ms(APP_ID).is_none() {
        if Instant::now() >= deadline {
            fail("did not complete the Hello/HelloAck handshake within 5s");
        }
        thread::sleep(Duration::from_millis(20));
    }
    println!("IPC handshake complete, cold-start = {}ms", manager.cold_start_ms(APP_ID).unwrap());

    let granted = manager.granted_permissions(APP_ID).unwrap_or(0);
    let required_bits: u32 = REQUIRED.iter().fold(0, |acc, p| acc | p.bit());
    if granted & required_bits != required_bits {
        fail(format!("required permission(s) not granted: required=0b{required_bits:b} granted=0b{granted:b}"));
    }

    // Give the app's browse/open/delete sequence time to run -- disk
    // I/O, so a bit generous, matching Day 20's own timing.
    thread::sleep(Duration::from_millis(500));

    let process = manager
        .process_list()
        .into_iter()
        .find(|p| p.pid == pid)
        .unwrap_or_else(|| fail("pid missing from M4 Process Manager's process_list() entirely"));
    match process.state {
        ProcessState::Running | ProcessState::Sleeping => {
            println!("nova-filemanager is still {:?} -- didn't hit its own early-exit path", process.state);
        }
        other => fail(format!(
            "nova-filemanager exited early (state={other:?}, exit_code={:?}) -- see its own stderr for which step failed \
             (exit 3 = browse failed, 4 = open failed, 5 = delete/verification failed)",
            process.exit_code
        )),
    }

    // --- Independent, external verification via M4's Filesystem Manager directly ---
    // Same path resolution nova-storage-api itself would have used --
    // constructed here independently, not borrowed from the app.
    let policy = SandboxPolicy::new(APP_ID, PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty())
        .unwrap_or_else(|e| fail(format!("SandboxPolicy::new: {e}")));
    let test_file_path = policy.scoped_path("test-file.txt").unwrap_or_else(|e| fail(format!("scoped_path: {e}")));
    let readme_path = policy.scoped_path("readme.txt").unwrap_or_else(|e| fail(format!("scoped_path: {e}")));

    match nova_fsmgr::read_file(&test_file_path) {
        Err(_) => println!("VERIFIED (via nova_fsmgr::read_file directly): {} does not exist -- delete really happened", test_file_path.display()),
        Ok(_) => fail(format!(
            "{} still exists per nova_fsmgr::read_file -- the file manager's delete() did not actually reach the filesystem",
            test_file_path.display()
        )),
    }

    // The *other* seeded file must still be there -- proves delete
    // was selective (removed exactly the target file), not a wipe of
    // the whole directory or a false-positive from an empty directory.
    match nova_fsmgr::read_file(&readme_path) {
        Ok(bytes) if bytes == b"Files you create will show up here." => {
            println!("VERIFIED (via nova_fsmgr::read_file directly): {} still exists, untouched -- delete was selective", readme_path.display());
        }
        Ok(_) => fail(format!("{} exists but has unexpected content", readme_path.display())),
        Err(e) => fail(format!("{} unexpectedly missing: {e} -- delete may have wiped more than the target file", readme_path.display())),
    }

    manager.terminate(APP_ID).unwrap_or_else(|e| fail(format!("terminate: {e}")));
    thread::sleep(Duration::from_millis(150));
    if manager.pid_of(APP_ID).is_some() {
        fail("still tracked as running after terminate()");
    }
    println!("terminated cleanly");

    // Cleanup
    let _ = fs::remove_dir_all(app_install_dir());
    let _ = fs::remove_dir_all(app_data_dir());
    let _ = fs::remove_file(SOCKET_PATH);

    println!();
    println!("=== Day 26 ACCEPTANCE: PASS ===");
    println!("nova-filemanager listed its real directory and deleted a real test file through");
    println!("the Storage API, and the deletion was independently confirmed by this test tool");
    println!("calling nova_fsmgr::read_file directly -- M4's Filesystem Manager, not the app's");
    println!("word for it and not StorageApi asked a second time.");
}
