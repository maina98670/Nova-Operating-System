//! Nova OS Day 27 live acceptance.
//!
//! DoD: "Go back to the existing Dialer app's keypad and Camera app's
//! shutter button (both previously flagged as drawn-but-not-tappable)
//! and confirm they are now actually tappable and produce the
//! expected app behavior."
//!
//! **Honesty note, stated once here rather than buried**: no
//! keypad/shutter-button UI existed anywhere in this track before
//! today — Day 16 explicitly scoped Dialer and Camera as "functional
//! core only, no UI, that's M7's job" (see that day's own README).
//! There was nothing to "go back to." What this test actually proves
//! is the DoD's real payoff, built fresh this day: real UI regions in
//! the real Dialer/Camera apps, reachable through a real input
//! pipeline (hit-testing real window geometry, real per-app event
//! delivery), triggering the real underlying business logic
//! (`CallLog::place_call`, `PhotoLibrary::capture`) those apps already
//! had since Day 16.
//!
//! Every check is external: `CompositorServer::inject_touch` return
//! values (which surface it hit) and, for the actual business-logic
//! payoff, a **fresh** `CallLog::load`/`PhotoLibrary::load` in this
//! test process — re-reading each app's persisted state from disk,
//! not asking the app or trusting its stdout.

use nova_app_manager::AppManager;
use nova_app_storage::SandboxStorage;
use nova_camera_core::PhotoLibrary;
use nova_compositor_core::server::CompositorServer;
use nova_compositor_core::OutputId;
use nova_dialer_core::{CallDirection, CallLog};
use nova_ipc::{Permission, SOCKET_PATH};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

struct RealApp {
    id: &'static str,
    bin_name: &'static str,
    manifest: &'static str,
}

const DIALER: RealApp =
    RealApp { id: "org.nova.dialer", bin_name: "nova-dialer", manifest: include_str!("../../../apps/org.nova.dialer/nova-app.toml") };
const CAMERA: RealApp =
    RealApp { id: "org.nova.camera", bin_name: "nova-camera", manifest: include_str!("../../../apps/org.nova.camera/nova-app.toml") };

const APP_DATA_ROOT: &str = "/var/lib/nova/apps"; // SandboxPolicy::app_data_root, Day 15/20

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn app_install_dir(id: &str) -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(id)
}

fn app_data_dir(id: &str) -> PathBuf {
    Path::new(APP_DATA_ROOT).join(id)
}

fn install_and_launch(manager: &AppManager, app: &RealApp) -> u32 {
    let dir = app_install_dir(app.id);
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), app.manifest).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(app.bin_name);
    if !bin_src.exists() {
        fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", bin_src.display()));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(app.bin_name);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(app.id).unwrap_or_else(|e| fail(format!("install {}: {e}", app.id)));
    manager.launch(app.id).unwrap_or_else(|e| fail(format!("launch {}: {e}", app.id)))
}

fn main() {
    println!("=== Nova OS Day 27: input pipeline acceptance ===");
    println!();
    println!("(No keypad/shutter UI existed before today -- Day 16 explicitly scoped Dialer/");
    println!(" Camera as functional-core-only. This test proves the real payoff built fresh");
    println!(" this day: real regions, real hit-testing, real per-app delivery. See this file's");
    println!(" own module doc for the full honesty note.)");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));
    fs::create_dir_all(APP_DATA_ROOT).unwrap_or_else(|e| fail(format!("mkdir {APP_DATA_ROOT}: {e}")));
    let _ = fs::remove_dir_all(app_data_dir(DIALER.id));
    let _ = fs::remove_dir_all(app_data_dir(CAMERA.id));

    let manager = AppManager::new();
    let _app_server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("app manager serve: {e}")));

    let compositor = CompositorServer::new();
    let _compositor_server = compositor
        .serve(nova_compositor_core::protocol::SOCKET_PATH)
        .unwrap_or_else(|e| fail(format!("compositor serve: {e}")));
    let output = compositor.create_output("output-0", 1080, 2400);
    if output != OutputId(1) {
        fail(format!("expected output id 1 -- got {output:?}"));
    }

    let dialer_pid = install_and_launch(&manager, &DIALER);
    let camera_pid = install_and_launch(&manager, &CAMERA);
    println!("launched dialer pid={dialer_pid}, camera pid={camera_pid}");

    for app in [&DIALER, &CAMERA] {
        let deadline = Instant::now() + Duration::from_secs(5);
        while manager.cold_start_ms(app.id).is_none() {
            if Instant::now() >= deadline {
                fail(format!("{} did not complete its Hello/HelloAck handshake within 5s", app.id));
            }
            thread::sleep(Duration::from_millis(20));
        }
    }
    println!("both apps completed their App Manager handshake");

    // --- Wait for both windows to exist ---
    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        if compositor.surfaces_on(output).len() >= 2 {
            break;
        }
        if Instant::now() >= deadline {
            fail(format!("expected 2 surfaces on {output:?} within 5s, got {}", compositor.surfaces_on(output).len()));
        }
        thread::sleep(Duration::from_millis(50));
    }
    let surfaces = compositor.surfaces_on(output);
    let dialer_surface = surfaces.iter().find(|s| s.app_id == DIALER.id).unwrap_or_else(|| fail("no surface from dialer")).clone();
    let camera_surface = surfaces.iter().find(|s| s.app_id == CAMERA.id).unwrap_or_else(|| fail("no surface from camera")).clone();
    println!(
        "VERIFIED: both real windows exist -- dialer at ({}, {}) {}x{}, camera at ({}, {}) {}x{}",
        dialer_surface.geometry.x,
        dialer_surface.geometry.y,
        dialer_surface.geometry.width,
        dialer_surface.geometry.height,
        camera_surface.geometry.x,
        camera_surface.geometry.y,
        camera_surface.geometry.width,
        camera_surface.geometry.height
    );
    if dialer_surface.geometry.x == camera_surface.geometry.x {
        fail("dialer's and camera's windows overlap at the same x -- Window::move_to didn't separate them");
    }

    // --- Wait for both input sinks to register ---
    let deadline = Instant::now() + Duration::from_secs(5);
    while !(compositor.has_input_sink(DIALER.id) && compositor.has_input_sink(CAMERA.id)) {
        if Instant::now() >= deadline {
            fail("both apps' input sinks did not register within 5s");
        }
        thread::sleep(Duration::from_millis(50));
    }
    println!("VERIFIED: both apps registered a real input sink");

    // --- Miss: tap somewhere on neither window ---
    let miss = compositor.inject_touch(output, 5000, 5000, 0);
    if miss.is_some() {
        fail(format!("expected no surface at (5000, 5000), hit-test returned {miss:?}"));
    }
    println!("VERIFIED: a tap on empty space correctly hits nothing");

    // --- Tap Dialer's keypad: digits '1', '2', then Call ---
    // Global = dialer's window offset + local region coordinates
    // (see apps/org.nova.dialer/src/main.rs's own layout doc comment).
    let dx = dialer_surface.geometry.x;
    let dy = dialer_surface.geometry.y;
    let tap_dialer = |x: i32, y: i32, label: &str| {
        let hit = compositor.inject_touch(output, dx + x, dy + y, 0 /* Began */);
        if hit != Some(dialer_surface.id) {
            fail(format!("tap on dialer's {label} region did not hit dialer's surface (got {hit:?})"));
        }
        thread::sleep(Duration::from_millis(100));
    };
    tap_dialer(50, 50, "digit '1'");
    tap_dialer(150, 50, "digit '2'");
    tap_dialer(150, 150, "Call");
    println!("VERIFIED: taps on dialer's digit '1', digit '2', and Call regions all hit dialer's own surface");

    // --- Tap Camera's shutter ---
    let cx = camera_surface.geometry.x;
    let cy = camera_surface.geometry.y;
    let hit = compositor.inject_touch(output, cx + 200, cy + 200, 0);
    if hit != Some(camera_surface.id) {
        fail(format!("tap on camera's shutter region did not hit camera's surface (got {hit:?})"));
    }
    println!("VERIFIED: tap on camera's shutter region hit camera's own surface");

    thread::sleep(Duration::from_millis(300)); // let both apps' poll loops process everything above

    // --- Independent verification: re-load each app's persisted state fresh ---
    let dialer_policy = SandboxPolicy::new(DIALER.id, PermissionSet::from_permissions([Permission::Contacts]), PermissionSet::empty())
        .unwrap_or_else(|e| fail(format!("SandboxPolicy::new(dialer): {e}")));
    let call_log = CallLog::load(SandboxStorage(dialer_policy)).unwrap_or_else(|e| fail(format!("CallLog::load: {e}")));
    let recent = call_log.recent(10);
    if recent.len() != 1 {
        fail(format!("expected exactly 1 call logged, found {}: {recent:?}", recent.len()));
    }
    if recent[0].number != "12" || recent[0].direction != CallDirection::Outgoing {
        fail(format!("expected an outgoing call to \"12\", got {:?}", recent[0]));
    }
    println!("VERIFIED (fresh CallLog::load, independent of the running app): exactly one outgoing call to \"12\" was logged");

    let camera_policy = SandboxPolicy::new(CAMERA.id, PermissionSet::from_permissions([Permission::Camera, Permission::Storage]), PermissionSet::empty())
        .unwrap_or_else(|e| fail(format!("SandboxPolicy::new(camera): {e}")));
    let library = PhotoLibrary::load(SandboxStorage(camera_policy)).unwrap_or_else(|e| fail(format!("PhotoLibrary::load: {e}")));
    if library.list().len() != 1 {
        fail(format!("expected exactly 1 photo captured, found {}", library.list().len()));
    }
    println!("VERIFIED (fresh PhotoLibrary::load, independent of the running app): exactly one photo was captured");

    // --- Cleanup ---
    for app in [&DIALER, &CAMERA] {
        let _ = manager.terminate(app.id);
    }
    thread::sleep(Duration::from_millis(200));
    for app in [&DIALER, &CAMERA] {
        if manager.pid_of(app.id).is_some() {
            fail(format!("{} still tracked as running after terminate()", app.id));
        }
        let _ = fs::remove_dir_all(app_install_dir(app.id));
        let _ = fs::remove_dir_all(app_data_dir(app.id));
    }
    let _ = fs::remove_file(SOCKET_PATH);
    let _ = fs::remove_file(nova_compositor_core::protocol::SOCKET_PATH);

    println!();
    println!("=== Day 27 ACCEPTANCE: PASS ===");
    println!("Real taps, injected through CompositorServer::inject_touch, correctly hit-tested");
    println!("against real window geometry from two separate real processes, were delivered to");
    println!("the correct app over a real dedicated input connection, and triggered the real");
    println!("underlying CallLog/PhotoLibrary logic -- confirmed by freshly re-loading each");
    println!("app's persisted state, not by trusting either app's own word for it.");
}
