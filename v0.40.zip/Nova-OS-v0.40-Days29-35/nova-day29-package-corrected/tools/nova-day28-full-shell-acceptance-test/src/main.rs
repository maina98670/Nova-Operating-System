//! Nova OS Day 28 (M7 final day) live acceptance.
//!
//! DoD: "The full cold-boot-to-interactive-app flow works using only
//! touch input, with consistent theming across shell and every app."
//!
//! This is the integration test for M7 as a whole — it exercises, in
//! one run: `nova-app-manager` (Day 13), `nova-sandbox` (Day 15),
//! all six real apps (Days 16-17), `nova-compositor-core` (Day 23),
//! `nova-shell-core` (Day 24-25), the Day 27 input pipeline, and
//! `nova-theme` (Day 28). Every check is against real, live state —
//! `Shell`'s own `state()`/`window_state()`, `AppManager`'s own
//! `cold_start_ms`/`process_list`, the compositor's own
//! `surfaces_on`/`focused_surface`, and (for the actual tap-triggered
//! business logic) a fresh `CallLog::load`/`PhotoLibrary::load` — the
//! same external-verification standard every acceptance test since
//! Day 20 has used. See `docs/theme-v1.md` for what "consistent
//! theming" can and can't mean without any rendering existing yet.

use nova_app_manager::AppManager;
use nova_app_storage::SandboxStorage;
use nova_camera_core::PhotoLibrary;
use nova_compositor_core::client::CompositorClientBackend;
use nova_compositor_core::server::CompositorServer;
use nova_compositor_core::{OutputId, SurfaceId};
use nova_dialer_core::{CallDirection, CallLog};
use nova_ipc::{Permission, SOCKET_PATH};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_shell_core::{Shell, ShellError, ShellState, HOME_SCREEN_TITLE, LOCK_SCREEN_TITLE};
use nova_window_api::Window;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

struct RealApp {
    id: &'static str,
    bin_name: &'static str,
    manifest: &'static str,
}

const APPS: &[RealApp] = &[
    RealApp { id: "org.nova.settings", bin_name: "nova-settings", manifest: include_str!("../../../apps/org.nova.settings/nova-app.toml") },
    RealApp { id: "org.nova.contacts", bin_name: "nova-contacts", manifest: include_str!("../../../apps/org.nova.contacts/nova-app.toml") },
    RealApp { id: "org.nova.messages", bin_name: "nova-messages", manifest: include_str!("../../../apps/org.nova.messages/nova-app.toml") },
    RealApp { id: "org.nova.dialer", bin_name: "nova-dialer", manifest: include_str!("../../../apps/org.nova.dialer/nova-app.toml") },
    RealApp { id: "org.nova.camera", bin_name: "nova-camera", manifest: include_str!("../../../apps/org.nova.camera/nova-app.toml") },
    RealApp { id: "org.nova.hello", bin_name: "nova-hello", manifest: include_str!("../../../apps/org.nova.hello/nova-app.toml") },
];

const SHELL_APP_ID: &str = "org.nova.shell-test";
const APP_DATA_ROOT: &str = "/var/lib/nova/apps"; // SandboxPolicy::app_data_root, Day 15/20

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("FAIL: {}", msg.as_ref());
    process::exit(1);
}

fn app_install_dir(id: &str) -> PathBuf {
    Path::new(nova_fsmgr::paths::APPS).join(id)
}

fn app_data_dir(id: &str) -> PathBuf {
    Path::new(APP_DATA_ROOT).join(id)
}

fn install_only(manager: &AppManager, app: &RealApp) {
    let dir = app_install_dir(app.id);
    fs::create_dir_all(&dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", dir.display())));
    fs::write(dir.join("nova-app.toml"), app.manifest).unwrap_or_else(|e| fail(format!("write manifest: {e}")));

    let mut bin_src = std::env::current_exe().unwrap_or_else(|e| fail(format!("current_exe: {e}")));
    bin_src.pop();
    bin_src.push(app.bin_name);
    if !bin_src.exists() {
        fail(format!("expected sibling binary {} (run `cargo build --workspace` first)", bin_src.display()));
    }
    let bin_dest_dir = dir.join("bin");
    fs::create_dir_all(&bin_dest_dir).unwrap_or_else(|e| fail(format!("mkdir {}: {e}", bin_dest_dir.display())));
    let bin_dest = bin_dest_dir.join(app.bin_name);
    fs::copy(&bin_src, &bin_dest).unwrap_or_else(|e| fail(format!("copy binary: {e}")));
    let mut perms = fs::metadata(&bin_dest).unwrap().permissions();
    perms.set_mode(0o755);
    fs::set_permissions(&bin_dest, perms).unwrap_or_else(|e| fail(format!("chmod: {e}")));

    manager.install(app.id).unwrap_or_else(|e| fail(format!("install {}: {e}", app.id)));
}

fn main() {
    println!("=== Nova OS Day 28 (M7 final): full cold-boot-to-interactive-app acceptance ===");
    println!();

    nova_fsmgr::ensure_dirs(&[nova_fsmgr::paths::RUN, nova_fsmgr::paths::APPS, nova_fsmgr::paths::LOG])
        .unwrap_or_else(|e| fail(format!("ensure dirs: {e}")));
    fs::create_dir_all(APP_DATA_ROOT).unwrap_or_else(|e| fail(format!("mkdir {APP_DATA_ROOT}: {e}")));
    for app in APPS {
        let _ = fs::remove_dir_all(app_data_dir(app.id)); // clean slate
    }

    let manager = AppManager::new();
    let _app_server = manager.serve(SOCKET_PATH).unwrap_or_else(|e| fail(format!("app manager serve: {e}")));

    let compositor = CompositorServer::new();
    let _compositor_server = compositor
        .serve(nova_compositor_core::protocol::SOCKET_PATH)
        .unwrap_or_else(|e| fail(format!("compositor serve: {e}")));
    let output = compositor.create_output("output-0", 1080, 2400);
    if output != OutputId(1) {
        fail(format!("expected output id 1 -- got {output:?}"));
    }

    // --- "currently-installed": all six real apps, not yet launched ---
    for app in APPS {
        install_only(&manager, app);
    }
    println!("installed {} real apps (not yet launched)", APPS.len());

    // --- Cold boot: the shell itself, locked ---
    let shell_backend = CompositorClientBackend::connect_default(SHELL_APP_ID, 1).unwrap_or_else(|e| fail(format!("connect to compositor: {e}")));
    let shell_window = Window::create(shell_backend, "unused-initial-title", 1080, 2400).unwrap_or_else(|e| fail(format!("Window::create: {e}")));
    let shell_surface_id = SurfaceId(shell_window.id().raw());
    let mut shell = Shell::new(manager.clone(), shell_window).unwrap_or_else(|e| fail(format!("Shell::new: {e}")));

    if shell.state() != ShellState::Locked {
        fail(format!("expected Locked on a cold start, got {:?}", shell.state()));
    }
    let locked_title = shell.window_state().unwrap_or_else(|e| fail(format!("window_state(): {e}"))).title;
    if locked_title != LOCK_SCREEN_TITLE {
        fail(format!("expected the shell's real window title to be {LOCK_SCREEN_TITLE:?} while locked, got {locked_title:?}"));
    }
    println!("VERIFIED: cold boot -- shell Locked, real compositor window titled {locked_title:?}");

    match shell.launch_app(APPS[0].id) {
        Err(ShellError::Locked) => println!("VERIFIED: launching while locked is correctly rejected"),
        Ok(pid) => fail(format!("SECURITY REGRESSION: launch_app succeeded while locked (pid={pid})")),
        Err(e) => fail(format!("expected ShellError::Locked, got: {e}")),
    }

    // --- Unlock: home screen ---
    shell.unlock().unwrap_or_else(|e| fail(format!("unlock(): {e}")));
    if shell.state() != ShellState::Home {
        fail(format!("expected Home after unlock(), got {:?}", shell.state()));
    }
    let home_title = shell.window_state().unwrap_or_else(|e| fail(format!("window_state(): {e}"))).title;
    if home_title != HOME_SCREEN_TITLE {
        fail(format!("expected the shell's real window title to be {HOME_SCREEN_TITLE:?} after unlock, got {home_title:?}"));
    }
    println!("VERIFIED: unlock() -- shell Home, real compositor window titled {home_title:?}");

    // --- Consistent theming: the shell references the one canonical resource ---
    if shell.theme() != &nova_theme::DEFAULT {
        fail("shell.theme() does not match nova_theme::DEFAULT -- the shell and the theme resource have diverged");
    }
    println!("VERIFIED: shell.theme() is the same canonical nova_theme::DEFAULT value every app would reference (see docs/theme-v1.md for the honest scope of this claim)");

    // --- Launcher lists and starts every currently-installed app ---
    let listed = shell.installed_apps();
    for app in APPS {
        if !listed.iter().any(|e| e.id == app.id) {
            fail(format!("launcher's installed_apps() is missing {} -- got {listed:?}", app.id));
        }
    }
    let mut pids = Vec::new();
    for app in APPS {
        let pid = shell.launch_app(app.id).unwrap_or_else(|e| fail(format!("launch_app({}): {e}", app.id)));
        pids.push((app.id, pid));
    }
    for (id, _) in pids.iter().copied() {
        let deadline = Instant::now() + Duration::from_secs(5);
        while manager.cold_start_ms(id).is_none() {
            if Instant::now() >= deadline {
                fail(format!("{id} did not complete its Hello/HelloAck handshake within 5s"));
            }
            thread::sleep(Duration::from_millis(20));
        }
    }
    println!("VERIFIED: launcher lists and started all {} real apps, each completing its own IPC handshake", APPS.len());

    // --- Wait for Dialer's and Camera's real windows + input sinks ---
    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        if compositor.surfaces_on(output).len() >= 3 {
            break; // shell + dialer + camera
        }
        if Instant::now() >= deadline {
            fail(format!("expected >= 3 surfaces on {output:?} within 5s, got {}", compositor.surfaces_on(output).len()));
        }
        thread::sleep(Duration::from_millis(50));
    }
    let surfaces = compositor.surfaces_on(output);
    let dialer_surface = surfaces.iter().find(|s| s.app_id == "org.nova.dialer").unwrap_or_else(|| fail("no surface from dialer")).clone();
    let camera_surface = surfaces.iter().find(|s| s.app_id == "org.nova.camera").unwrap_or_else(|| fail("no surface from camera")).clone();

    let deadline = Instant::now() + Duration::from_secs(5);
    while !(compositor.has_input_sink("org.nova.dialer") && compositor.has_input_sink("org.nova.camera")) {
        if Instant::now() >= deadline {
            fail("dialer/camera input sinks did not register within 5s");
        }
        thread::sleep(Duration::from_millis(50));
    }
    println!("VERIFIED: dialer and camera created real windows and registered real input sinks");

    // --- Interact via touch: Dialer's keypad, then Camera's shutter ---
    let (dx, dy) = (dialer_surface.geometry.x, dialer_surface.geometry.y);
    let tap_dialer = |x: i32, y: i32, label: &str| {
        let hit = compositor.inject_touch(output, dx + x, dy + y, 0 /* Began */);
        if hit != Some(dialer_surface.id) {
            fail(format!("tap on dialer's {label} region did not hit dialer's surface (got {hit:?})"));
        }
        thread::sleep(Duration::from_millis(100));
    };
    tap_dialer(50, 50, "digit '1'");
    tap_dialer(150, 50, "digit '2'");
    tap_dialer(150, 150, "Call");

    let (cx, cy) = (camera_surface.geometry.x, camera_surface.geometry.y);
    let hit = compositor.inject_touch(output, cx + 200, cy + 200, 0);
    if hit != Some(camera_surface.id) {
        fail(format!("tap on camera's shutter region did not hit camera's surface (got {hit:?})"));
    }
    println!("VERIFIED: real taps through the real compositor reached dialer's keypad and camera's shutter, each on the correct app's own surface");

    thread::sleep(Duration::from_millis(300)); // let both apps' poll loops process everything above

    // --- Independent verification: re-load each app's persisted state fresh ---
    let dialer_policy = SandboxPolicy::new("org.nova.dialer", PermissionSet::from_permissions([Permission::Contacts]), PermissionSet::empty())
        .unwrap_or_else(|e| fail(format!("SandboxPolicy::new(dialer): {e}")));
    let call_log = CallLog::load(SandboxStorage(dialer_policy)).unwrap_or_else(|e| fail(format!("CallLog::load: {e}")));
    let recent = call_log.recent(10);
    if recent.len() != 1 || recent[0].number != "12" || recent[0].direction != CallDirection::Outgoing {
        fail(format!("expected exactly one outgoing call to \"12\", got {recent:?}"));
    }
    println!("VERIFIED (fresh CallLog::load): exactly one outgoing call to \"12\" was logged from the tapped digits");

    let camera_policy =
        SandboxPolicy::new("org.nova.camera", PermissionSet::from_permissions([Permission::Camera, Permission::Storage]), PermissionSet::empty())
            .unwrap_or_else(|e| fail(format!("SandboxPolicy::new(camera): {e}")));
    let library = PhotoLibrary::load(SandboxStorage(camera_policy)).unwrap_or_else(|e| fail(format!("PhotoLibrary::load: {e}")));
    if library.list().len() != 1 {
        fail(format!("expected exactly 1 photo captured, found {}", library.list().len()));
    }
    println!("VERIFIED (fresh PhotoLibrary::load): exactly one photo was captured from the tapped shutter");

    // --- Return home: the shell regains focus ---
    // In a real system, "returning home" is the user's own action (a
    // home gesture); here, a tap on the shell's own window is the same
    // real, compositor-level focus change that action would trigger.
    if !focus_shell(&compositor, output, shell_surface_id) {
        fail("shell could not regain focus after interacting with dialer/camera");
    }
    println!("VERIFIED: the shell regained real compositor focus after interacting with dialer and camera -- \"returned home\"");

    // --- Cleanup ---
    for (id, _) in pids.iter().copied() {
        let _ = manager.terminate(id);
    }
    thread::sleep(Duration::from_millis(200));
    for app in APPS {
        if manager.pid_of(app.id).is_some() {
            fail(format!("{} still tracked as running after terminate()", app.id));
        }
        let _ = fs::remove_dir_all(app_install_dir(app.id));
        let _ = fs::remove_dir_all(app_data_dir(app.id));
    }
    let _ = fs::remove_file(SOCKET_PATH);
    let _ = fs::remove_file(nova_compositor_core::protocol::SOCKET_PATH);

    println!();
    println!("=== Day 28 / M7 ACCEPTANCE: PASS ===");
    println!("Cold boot -> lock screen -> blocked launch -> unlock -> home screen -> launcher");
    println!("lists and starts all six real apps -> real taps drive dialer's keypad and camera's");
    println!("shutter to their real underlying logic -> shell returns to real compositor focus.");
    println!("Shell and the theme resource provably share one canonical nova_theme::DEFAULT value.");
    println!("See docs/M7-TAG.md for the tag and docs/theme-v1.md for what \"consistent theming\"");
    println!("does and doesn't mean without any rendering existing yet.");
}

/// A tap anywhere within the shell's own window bounds refocuses it —
/// the same implicit-focus-on-hit mechanism `inject_touch` already
/// uses for dialer/camera above, applied to the shell's own surface
/// to represent "returning home."
fn focus_shell(compositor: &CompositorServer, output: OutputId, shell_surface: SurfaceId) -> bool {
    let Some(shell_bounds) = compositor.surface(shell_surface).map(|s| s.geometry) else {
        return false;
    };
    let hit = compositor.inject_touch(output, shell_bounds.x + 1, shell_bounds.y + 1, 0);
    hit == Some(shell_surface) && compositor.focused_surface(output) == Some(shell_surface)
}
