# Day 30 — Wi-Fi
Adds a Wi-Fi abstraction with scan, associate, state and signal models plus a Settings-facing data shape. Hardware radio control remains backend-specific.
