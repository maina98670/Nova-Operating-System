//! M8 Day 30 Wi-Fi model and connection state machine.
#[derive(Clone,Debug,PartialEq,Eq)]pub struct WifiNetwork{pub ssid:String,pub signal_dbm:i32,pub secured:bool}
#[derive(Clone,Debug,PartialEq,Eq)]pub enum WifiState{Disabled,Scanning,Available,Connecting,Connected,Failed}
# [allow(dead_code)]
pub struct WifiManager{state:WifiState,networks:Vec<WifiNetwork>,connected:Option<String>}
impl WifiManager{pub fn new()->Self{Self{state:WifiState::Disabled,networks:vec![],connected:None}} pub fn scan(&mut self)->&[WifiNetwork]{self.state=WifiState::Available;self.networks=vec![WifiNetwork{ssid:"Nova-Test".into(),signal_dbm:-42,secured:true}];&self.networks} pub fn connect(&mut self,ssid:&str)->bool{if self.networks.iter().any(|n|n.ssid==ssid){self.state=WifiState::Connected;self.connected=Some(ssid.into());true}else{self.state=WifiState::Failed;false}} pub fn state(&self)->&WifiState{&self.state} pub fn connected_ssid(&self)->Option<&str>{self.connected.as_deref()}}
