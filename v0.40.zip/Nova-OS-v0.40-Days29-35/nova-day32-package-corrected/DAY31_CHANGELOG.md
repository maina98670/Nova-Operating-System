# Day 31 — DHCP + DNS
Adds DHCP lease and DNS resolver abstractions with deterministic test backends for the QEMU network path.
