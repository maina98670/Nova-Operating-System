//! M8 Day 31 DHCP + DNS service models.
use std::net::Ipv4Addr;
#[derive(Clone,Debug,PartialEq,Eq)]pub struct DhcpLease{pub address:Ipv4Addr,pub prefix:u8,pub gateway:Option<Ipv4Addr>,pub dns:Vec<Ipv4Addr>}
pub trait DhcpClient{fn acquire(&self)->Option<DhcpLease>;}
pub struct TestDhcpClient;impl DhcpClient for TestDhcpClient{fn acquire(&self)->Option<DhcpLease>{Some(DhcpLease{address:Ipv4Addr::new(192,168,122,50),prefix:24,gateway:Some(Ipv4Addr::new(192,168,122,1)),dns:vec![Ipv4Addr::new(192,168,122,1)]})}}
#[derive(Clone,Debug,PartialEq,Eq)]pub enum DnsError{NotFound}
pub trait DnsResolver{fn resolve(&self,name:&str)->Result<Ipv4Addr,DnsError>;}
pub struct TestDnsResolver;impl DnsResolver for TestDnsResolver{fn resolve(&self,name:&str)->Result<Ipv4Addr,DnsError>{match name{"nova.test"=>Ok(Ipv4Addr::new(192,168,122,10)),_=>Err(DnsError::NotFound)}}}
