//! M8 Day 32 TCP integration seam.
use std::io::{Read,Write};use std::net::{TcpStream,ToSocketAddrs};
pub fn connect_and_roundtrip<A:ToSocketAddrs>(addr:A,payload:&[u8])->std::io::Result<Vec<u8>>{let mut s=TcpStream::connect(addr)?;s.write_all(payload)?;let mut out=Vec::new();s.read_to_end(&mut out)?;Ok(out)}
#[derive(Clone,Debug,PartialEq,Eq)]pub struct NetworkConfig{pub interface:String,pub address:Option<String>,pub gateway:Option<String>,pub connected:bool}
impl NetworkConfig{pub fn disconnected(interface:&str)->Self{Self{interface:interface.into(),address:None,gateway:None,connected:false}}}
