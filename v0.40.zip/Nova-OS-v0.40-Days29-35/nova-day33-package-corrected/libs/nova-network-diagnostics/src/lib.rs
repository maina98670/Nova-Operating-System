//! M8 Day 33 diagnostics.
#[derive(Clone,Debug,PartialEq,Eq)]pub enum Connectivity{Connected,Disconnected,Unknown}
#[derive(Clone,Debug,PartialEq,Eq)]pub struct Diagnostics{pub interface:String,pub connectivity:Connectivity,pub signal_dbm:Option<i32>,pub detail:String}
pub fn diagnose(interface:&str,connected:bool,signal_dbm:Option<i32>)->Diagnostics{Diagnostics{interface:interface.into(),connectivity:if connected{Connectivity::Connected}else{Connectivity::Disconnected},signal_dbm,detail:if connected{"network reachable".into()}else{"interface disconnected; reconnect required".into()}}}
