# Day 35 — Audio HAL
Adds audio output behind the same Device Manager pattern, with a safe tone model. Actual hardware playback is backend-dependent and remains an explicit integration step.
