use nova_device_manager::{Device,DeviceClass};
#[derive(Clone,Debug,PartialEq,Eq)]pub struct Tone{pub frequency_hz:u32,pub duration_ms:u32}
pub fn descriptor()->Device{Device{id:"audio0".into(),class:DeviceClass::Audio,available:true,description:"Nova audio output HAL".into()}}
pub fn validate_tone(t:Tone)->bool{(20..=20000).contains(&t.frequency_hz)&&t.duration_ms>0}
