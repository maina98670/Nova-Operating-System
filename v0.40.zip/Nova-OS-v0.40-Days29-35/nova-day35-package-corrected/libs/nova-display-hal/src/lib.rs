use nova_device_manager::{Device,DeviceClass};
pub fn descriptor()->Device{Device{id:"display0".into(),class:DeviceClass::Display,available:true,description:"Nova display HAL".into()}}
