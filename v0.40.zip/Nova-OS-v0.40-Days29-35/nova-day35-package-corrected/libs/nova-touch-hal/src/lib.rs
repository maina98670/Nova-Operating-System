use nova_device_manager::{Device,DeviceClass};
pub fn descriptor()->Device{Device{id:"touch0".into(),class:DeviceClass::Touch,available:true,description:"Nova touch HAL".into()}}
