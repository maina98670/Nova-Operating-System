# Nova OS v0.47 — Days 36–42

This release continues from v0.40 and contains the complete cumulative Day 36 through Day 42 progression.

## Days
- Day 36 — Power management
- Day 37 — Battery and thermal management
- Day 38 — Sensor HAL
- Day 39 — USB and Bluetooth device layer
- Day 40 — Camera HAL
- Day 41 — Device manager integration
- Day 42 — Unified system hardware services / M10 completion

Each later day package contains the previous day's source plus its new changes. The previous v0.40 Days 29–35 source is carried into Day 36.

Build with a standard Rust toolchain using `cargo check --workspace` from a day package. Physical hardware functionality depends on platform-specific drivers; these interfaces are designed to fail honestly when hardware is unavailable.
