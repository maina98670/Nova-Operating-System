# Nova OS Day 40

## Camera HAL

Day 40 adds the camera device abstraction, formats, capture lifecycle and capability reporting.

### Acceptance
- Workspace member added.
- Dedicated acceptance test added.
- Existing Nova OS components from Day 39 are preserved unchanged except for cumulative workspace integration.
