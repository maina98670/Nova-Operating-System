# Fixes applied to the v0.47 Day 39 package

Verified in Google Colab (Rust stable): Days 34-39 compile, unit tests and acceptance tests pass.
Run `./VERIFY_DAYS34-39.sh` to repeat.

1. Cargo.toml: added libs/nova-power-core, nova-battery-thermal-core, nova-sensor-hal,
   nova-connectivity-hal as workspace members (they were never built or tested before).
2. libs/nova-power-core: removed `Default` from the PowerManager derive (conflicted with the manual impl).
3. tools/nova-day34..39-acceptance-test: replaced print-only stubs (Days 36-39) with real assertions;
   Days 34-35 tightened. Days 36-39 tools now depend on their libraries.
4. libs/nova-package-format: named the lifetime in `read_bytes` (older code, failed on current Rust).
5. libs/nova-device-manager: added `impl Default for DeviceManager` (clippy).
6. tools/nova-shell: declared the missing `nova-window-api` dependency (older Day 24 bug).

Not verified: whole-workspace `cargo test` after fix 6, the Day 11-33 live tests (need root Linux),
and Days 40-42 (not included in this package).
