#!/usr/bin/env bash
# Verifies Nova OS Days 34-39. Run from the repo root.
set -e
CRATES="-p nova-device-manager -p nova-display-hal -p nova-touch-hal -p nova-audio-hal -p nova-power-core -p nova-battery-thermal-core -p nova-sensor-hal -p nova-connectivity-hal"
TOOLS="-p nova-day34-hal-acceptance-test -p nova-day35-audio-acceptance-test -p nova-day36-acceptance-test -p nova-day37-acceptance-test -p nova-day38-acceptance-test -p nova-day39-acceptance-test"
echo "=== CHECK ===";            cargo check --all-targets $CRATES $TOOLS
echo "=== UNIT TESTS ===";       cargo test $CRATES
echo "=== ACCEPTANCE TESTS ==="
for t in nova-day34-hal nova-day35-audio nova-day36 nova-day37 nova-day38 nova-day39; do
  cargo run -q -p ${t}-acceptance-test
done
echo "=== DAYS 34-39: ALL PASSED ==="
