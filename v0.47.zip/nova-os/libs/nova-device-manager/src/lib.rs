//! M9 Day 34 generic device registry.
#[derive(Clone,Debug,PartialEq,Eq)]pub enum DeviceClass{Display,Touch,Audio,Camera,Sensors,Storage,Usb,Bluetooth,Battery,Platform}
#[derive(Clone,Debug,PartialEq,Eq)]pub struct Device{pub id:String,pub class:DeviceClass,pub available:bool,pub description:String}
pub struct DeviceManager{devices:Vec<Device>}
impl DeviceManager{pub fn new()->Self{Self{devices:Vec::new()}} pub fn register(&mut self,d:Device){self.devices.retain(|x|x.id!=d.id);self.devices.push(d)} pub fn list(&self)->&[Device]{&self.devices} pub fn get(&self,id:&str)->Option<&Device>{self.devices.iter().find(|d|d.id==id)}}

impl Default for DeviceManager{fn default()->Self{Self::new()}}
