#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PowerProfile { Balanced, Performance, BatterySaver }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PowerState { Running, Suspending, Suspended, Resuming, Unavailable }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WakeSource { Timer, PowerButton, Network, Unknown }

#[derive(Debug)]
pub struct PowerManager { state: PowerState }

impl Default for PowerManager { fn default() -> Self { Self { state: PowerState::Running } } }
impl PowerManager {
    pub fn state(&self) -> PowerState { self.state }
    pub fn request_suspend(&mut self) -> bool { if self.state == PowerState::Running { self.state = PowerState::Suspending; true } else { false } }
    pub fn mark_suspended(&mut self) { if self.state == PowerState::Suspending { self.state = PowerState::Suspended; } }
    pub fn resume(&mut self) -> bool { if self.state == PowerState::Suspended { self.state = PowerState::Resuming; self.state = PowerState::Running; true } else { false } }
}

#[cfg(test)] mod tests { use super::*; #[test] fn suspend_resume() { let mut p=PowerManager::default(); assert!(p.request_suspend()); p.mark_suspended(); assert_eq!(p.state(),PowerState::Suspended); assert!(p.resume()); assert_eq!(p.state(),PowerState::Running); }}
