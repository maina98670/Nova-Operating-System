use nova_device_manager::*;
use nova_display_hal::descriptor as display;
use nova_touch_hal::descriptor as touch;
fn main() {
    let mut m = DeviceManager::new();
    assert!(m.list().is_empty());
    m.register(display());
    m.register(touch());
    assert_eq!(m.list().len(), 2);
    assert_eq!(m.get("display0").unwrap().class, DeviceClass::Display);
    assert_eq!(m.get("touch0").unwrap().class, DeviceClass::Touch);
    assert!(m.get("display0").unwrap().available && m.get("touch0").unwrap().available);
    assert!(m.get("nonexistent").is_none());
    m.register(display());
    assert_eq!(m.list().len(), 2, "re-registering the same id must replace, not duplicate");
    println!("PASS: Day 34 display and touch devices registered");
}
