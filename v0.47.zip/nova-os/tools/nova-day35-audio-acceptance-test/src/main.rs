use nova_audio_hal::*;
use nova_device_manager::*;
fn main() {
    let mut m = DeviceManager::new();
    m.register(descriptor());
    let d = m.get("audio0").unwrap();
    assert!(d.available);
    assert_eq!(d.class, DeviceClass::Audio);
    assert!(validate_tone(Tone { frequency_hz: 440, duration_ms: 250 }));
    assert!(validate_tone(Tone { frequency_hz: 20, duration_ms: 1 }));
    assert!(validate_tone(Tone { frequency_hz: 20000, duration_ms: 1 }));
    assert!(!validate_tone(Tone { frequency_hz: 19, duration_ms: 250 }));
    assert!(!validate_tone(Tone { frequency_hz: 20001, duration_ms: 250 }));
    assert!(!validate_tone(Tone { frequency_hz: 440, duration_ms: 0 }));
    println!("PASS: Day 35 audio HAL device and tone validation");
}
