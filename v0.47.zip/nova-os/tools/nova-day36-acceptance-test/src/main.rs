use nova_power_core::*;
fn main() {
    let mut p = PowerManager::default();
    assert_eq!(p.state(), PowerState::Running);
    assert!(!p.resume(), "resume must be rejected while running");
    p.mark_suspended();
    assert_eq!(p.state(), PowerState::Running, "mark_suspended must not skip Suspending");
    assert!(p.request_suspend());
    assert_eq!(p.state(), PowerState::Suspending);
    assert!(!p.request_suspend(), "double suspend must be rejected");
    assert!(!p.resume(), "cannot resume before fully suspended");
    p.mark_suspended();
    assert_eq!(p.state(), PowerState::Suspended);
    assert!(!p.request_suspend(), "cannot suspend while suspended");
    assert!(p.resume());
    assert_eq!(p.state(), PowerState::Running);
    assert_ne!(PowerProfile::Balanced, PowerProfile::BatterySaver);
    assert_ne!(WakeSource::Timer, WakeSource::PowerButton);
    println!("Nova Day 36 power acceptance: PASS");
}
