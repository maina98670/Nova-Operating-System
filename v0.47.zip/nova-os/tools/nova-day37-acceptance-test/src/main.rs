use nova_battery_thermal_core::*;
fn main() {
    let mut m = BatteryThermalManager::default();
    assert!(m.battery().is_none(), "no battery must report unavailable, not fake data");
    assert!(m.zones().is_empty());
    assert!(!m.thermal_warning());
    m.set_battery(BatteryInfo { percentage: 80, charging: true, temperature_c: 30.0 });
    let b = m.battery().unwrap();
    assert_eq!(b.percentage, 80);
    assert!(b.charging);
    m.add_zone(ThermalZone { id: 1, temperature_c: 40.0, critical_c: 85.0 });
    assert!(!m.thermal_warning(), "cool zone must not warn");
    m.add_zone(ThermalZone { id: 2, temperature_c: 85.0, critical_c: 85.0 });
    assert!(m.thermal_warning(), "zone at critical threshold must warn");
    assert_eq!(m.zones().len(), 2);
    println!("Nova Day 37 battery/thermal acceptance: PASS");
}
