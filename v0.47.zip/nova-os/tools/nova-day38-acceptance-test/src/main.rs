use nova_sensor_hal::*;
fn main() {
    let kinds = [SensorKind::Accelerometer, SensorKind::Gyroscope, SensorKind::Proximity, SensorKind::Light];
    let sensors: Vec<Box<dyn Sensor>> = kinds
        .iter()
        .map(|k| Box::new(StaticSensor::new(*k, SensorSample { x: 1.0, y: 2.0, z: 9.81, timestamp_ms: 7 })) as Box<dyn Sensor>)
        .collect();
    assert_eq!(sensors.len(), 4);
    for (s, k) in sensors.iter().zip(kinds.iter()) {
        assert_eq!(s.kind(), *k);
        let v = s.sample().expect("static sensor must return a sample");
        assert_eq!(v.x, 1.0);
        assert_eq!(v.y, 2.0);
        assert!((v.z - 9.81).abs() < 1e-6);
        assert_eq!(v.timestamp_ms, 7);
    }
    println!("Nova Day 38 sensor HAL acceptance: PASS");
}
