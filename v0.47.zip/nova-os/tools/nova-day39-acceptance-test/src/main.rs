use nova_connectivity_hal::*;
fn main() {
    let mut r = ConnectivityRegistry::default();
    assert!(r.usb().is_empty() && r.bluetooth().is_empty());
    r.add_usb(UsbDevice { vendor_id: 0x1d6b, product_id: 2, name: "hub".into() });
    r.add_bluetooth(BluetoothDevice { address: "AA:BB:CC:DD:EE:FF".into(), name: "headset".into(), connected: false });
    assert_eq!(r.usb().len(), 1);
    assert_eq!(r.bluetooth().len(), 1);
    assert_eq!(r.usb()[0].vendor_id, 0x1d6b);
    assert_eq!(r.usb()[0].name, "hub");
    assert_eq!(r.bluetooth()[0].address, "AA:BB:CC:DD:EE:FF");
    assert!(!r.bluetooth()[0].connected);
    r.add_usb(UsbDevice { vendor_id: 1, product_id: 3, name: "mouse".into() });
    assert_eq!(r.usb().len(), 2);
    assert_eq!(r.bluetooth().len(), 1, "USB and Bluetooth lists must stay separate");
    println!("Nova Day 39 USB/Bluetooth acceptance: PASS");
}
