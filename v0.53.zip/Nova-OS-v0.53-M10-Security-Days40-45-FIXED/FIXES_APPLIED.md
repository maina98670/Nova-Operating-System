# Corrections applied on top of the v0.53 FIXED tree

The six retrofits in RETROFITS-README.md are unchanged. These were found by running Day 41 in Google Colab
(root, Rust stable) and are verified there: Day 40, 42, 43, 44, 45 acceptance and Day 41 live test PASS
(control run: 3 escapes; sandboxed run: 0 escapes; the hostile app reported its own verdict).

1. libs/nova-isolation: `spawn` no longer combines a user namespace with root's setuid/setgid drop.
   A fresh user namespace leaves the app uid unmapped, so setuid() failed with EINVAL.
2. tools/nova-m10-day41-sandbox-hardening-acceptance-test: a zero-escape count is only accepted if the
   hostile app actually printed `ESCAPES=`. Before, a crashed adversary produced a false PASS.
3. libs/nova-isolation: the seccomp filter is installed before the exec that launches the app, and the
   allowlist had no `execve`, so the sandbox blocked its own launch. `execve`/`execveat` and the startup
   syscalls of a dynamic binary are now allowed. clone/fork/vfork, socket (without Permission::Network),
   mount and ptrace stay blocked. New predicate `allows_spawn()`; the unit test and the Day 45 audit check
   now assert "no child processes" instead of "no exec".
4. docs/sandbox-hardening-v1.md: updated, with a design-change note recording the weaker guarantee.

## Known limits (not fixed here)
- An app can still `execve` another binary it can read; it keeps the same filter, uid and namespaces.
  Restricting reachable binaries needs a private root filesystem (pivot_root).
- File isolation between apps comes from per-app uids and ownership (Day 40), not from the mount namespace.
- Core services (nova-svcmgr, nova-shell, ...) still run without a seccomp filter (Day 45 notes).
- Day 41's user-namespace path (non-root runs) has not been exercised.
- The Day 36-39 acceptance tools are still print-only, and nova-power-core, nova-battery-thermal-core,
  nova-sensor-hal and nova-connectivity-hal are not workspace members in this tree.
- The Day 11-33 live tests need a root-capable Linux environment and were not run.
