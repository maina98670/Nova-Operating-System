# This is v0.53 (M10, Days 40-45) with six build/runtime defects fixed

The original v0.53 package was assembled and shipped without ever being
compiled (no Rust toolchain was available at the time). This tree is the
same v0.53 codebase with the six defects found the first time it actually
was compiled and run — all described in detail in
`docs/M11-RETROFITS.md`.

## The six fixes

1. **`nova-package-format`** — missing lifetime specifier on `read_bytes`;
   this crate could not compile at all, so nothing downstream of it
   (`nova install`, `nova package`, M10 signing) could have worked either.
2. **`nova-shell`** — used `nova_window_api` without declaring it as a
   dependency in `Cargo.toml`.
3. **`org.nova.windowtest`** — non-exhaustive match on `InputError`
   (missing the `Disconnected` variant added after the match was written).
4. **`nova-config`** — `load_or_default` returned zeroed defaults instead
   of the intended serde defaults whenever a config file was *missing*
   (as opposed to present-but-empty). `#[derive(Default)]` does not read
   `#[serde(default = "...")]` attributes; `Default` is now written by
   hand to delegate to the same functions.
5. **`nova-storage-api`** — every app's first `write()` failed with
   ENOENT, because Day 26 moved this crate onto `nova_fsmgr::write_file`
   directly and nothing ever created an app's data root or a key's parent
   directories. Fixed in `open()` and `write()`.
6. **`nova-identity`** — `apply_ownership` only chowned the single path it
   was given, not the subtree, so a freshly provisioned app data root
   populated after provisioning ended up owned by the installing process
   rather than the app — Nova's own ownership gate then denied the app
   access to its own files. Fixed to recurse into directories before
   chowning. The Day 40 acceptance test itself had a matching ordering
   bug (it planted the secret file to protect *after* calling
   `apply_ownership`), also fixed.

## Verification

`cargo build --workspace` and `cargo test --workspace` both exit 0 on
this tree. All existing M1-M10 acceptance test binaries
(`nova-m*-day*-acceptance-test`) run successfully, including
`nova-m10-day40-identity-acceptance-test`, whose failure surfaced fix #6.

## What is unchanged

No behavior from Days 1-45 was altered beyond these six fixes — nothing
was refactored, renamed, or redesigned. This is the v0.53 package with
its own bugs removed, nothing added.

Full narrative for each fix, including the original error output, is in
`docs/M11-RETROFITS.md`.
