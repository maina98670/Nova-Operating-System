#!/usr/bin/env bash
# Verifies Nova OS v0.53 (M10 Security, Days 40-45). Run from the repo root.
# Day 41 launches a real hostile binary and needs namespace privileges (root, or unprivileged user namespaces).
set -u
declare -A R
step() { local l="$1"; shift; echo; echo "=== $l ==="; "$@"; R["$l"]=$?; }
step "BUILD workspace"       cargo build --workspace
step "UNIT TESTS workspace"  cargo test --workspace
step "Day 40 identity"       cargo run -q -p nova-m10-day40-identity-acceptance-test
step "Day 41 sandbox (live)" cargo run -q -p nova-m10-day41-sandbox-hardening-acceptance-test
step "Day 42 secure IPC"     cargo run -q -p nova-m10-day42-secure-ipc-acceptance-test
step "Day 43 signing"        cargo run -q -p nova-m10-day43-package-signing-acceptance-test
step "Day 44 security log"   cargo run -q -p nova-m10-day44-security-logging-acceptance-test
step "Day 45 M10 acceptance" cargo run -q -p nova-m10-day45-acceptance-test
echo; echo "=== SUMMARY ==="
for k in "BUILD workspace" "UNIT TESTS workspace" "Day 40 identity" "Day 41 sandbox (live)" "Day 42 secure IPC" "Day 43 signing" "Day 44 security log" "Day 45 M10 acceptance"; do
  printf "%-24s %s\n" "$k" "$([ "${R[$k]}" -eq 0 ] && echo PASS || echo "FAIL (${R[$k]})")"
done
