//! nova-windowtest — Day 19's "test app built against the new Window
//! API" from the DoD.
//!
//! Launches through App Manager exactly like every other app (Hello/
//! HelloAck), then exercises `nova-window-api` (create/resize/
//! set_title/close) and `nova-input-api` (poll) — note that neither
//! `use` statement below, nor anything in this file, ever names a
//! Wayland protocol type (`wl_surface`, `xdg_toplevel`, etc.). That
//! absence is itself the proof of the DoD's "without touching Wayland
//! protocol code directly" — this app only ever talks to
//! `nova_window_api::Window`.
//!
//! Exits early with a distinct nonzero code on the first failure,
//! rather than continuing past a broken step — so an external
//! observer (see `tools/nova-day19-window-acceptance-test`) can tell
//! "reached the idle loop, meaning every step above succeeded" apart
//! from "crashed partway through" by whether this process is still
//! running a moment after launch.

use nova_input_api::{InputError, InputSource, UnavailableSource};
use nova_ipc::Permission;
use nova_window_api::{StubBackend, Window};
use std::process;

const APP_ID: &str = "org.nova.windowtest";
const OPTIONAL_PERMISSIONS: &[Permission] = &[];

fn main() {
    let (conn, outcome) = match nova_app_runtime::connect_and_handshake(APP_ID, OPTIONAL_PERMISSIONS) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("[{APP_ID}] handshake failed: {e}");
            process::exit(1);
        }
    };
    if !outcome.accepted {
        eprintln!("[{APP_ID}] App Manager rejected Hello (HelloAck.accepted=false)");
        process::exit(1);
    }
    println!("[{APP_ID}] Hello/HelloAck complete");

    // --- Window API ---
    let mut window = match Window::create(StubBackend::new(), "Nova Window Test", 640, 480) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("[{APP_ID}] Window::create failed: {e}");
            process::exit(2);
        }
    };
    println!("[{APP_ID}] window created: id={:?}", window.id());

    if let Err(e) = window.resize(1024, 768) {
        eprintln!("[{APP_ID}] Window::resize failed: {e}");
        process::exit(2);
    }
    if let Err(e) = window.set_title("Nova Window Test (resized)") {
        eprintln!("[{APP_ID}] Window::set_title failed: {e}");
        process::exit(2);
    }
    match window.state() {
        Ok(state) => println!("[{APP_ID}] window state after resize+retitle: {state:?}"),
        Err(e) => {
            eprintln!("[{APP_ID}] Window::state failed: {e}");
            process::exit(2);
        }
    }
    if let Err(e) = window.close() {
        eprintln!("[{APP_ID}] Window::close failed: {e}");
        process::exit(2);
    }
    println!("[{APP_ID}] window closed -- Window API exercised end to end, no Wayland protocol code touched");

    // --- Input API ---
    let mut input = UnavailableSource;
    match input.poll() {
        Err(InputError::NotYetAvailable) => {
            println!("[{APP_ID}] Input API correctly reports NotYetAvailable (real pipeline lands in M7)");
        }
        Ok(_) => {
            eprintln!("[{APP_ID}] SECURITY/HONESTY REGRESSION: Input API returned an event before M7 exists");
            process::exit(2);
        }
        Err(other) => {
            eprintln!("[{APP_ID}] unexpected Input API error: {other:?}");
            process::exit(2);
        }
    }

    println!("[{APP_ID}] Day 19 checks complete: window API real and usable, input API honestly unavailable");
    nova_app_runtime::idle_until_terminate(APP_ID, &conn);
}
