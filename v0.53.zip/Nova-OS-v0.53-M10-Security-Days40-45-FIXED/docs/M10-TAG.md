# M10 — Security (v0.53), Days 40-45

Per the Complete Build Guide's milestone table: **M10 — Security (v0.53),
Days 40-45, 6 days.** This tag covers all six.

## What each day delivered

| Day | Focus | Delivered |
|---|---|---|
| Day 40 | User/process identity + filesystem permissions | `nova-identity`: stable, persisted, never-reused per-app uids in a reserved range; an `Enforcer` that resolves real paths and checks ownership, closing the symlink escape M5's lexical scoping could not see |
| Day 41 | Application sandboxing hardening | `nova-isolation`: mount/PID/network/IPC/UTS namespaces plus a hand-assembled seccomp-bpf allowlist, both derived from the app's own manifest; fails closed; a real hostile test app that proves it |
| Day 42 | Capability/permission refinement + secure IPC | `nova-crypto` (SHA-256, HMAC-SHA256, constant-time compare), `nova-capability` (unforgeable, expiring, attenuable tokens), `nova-secure-ipc` (`SO_PEERCRED` endpoint authentication, rejections logged) |
| Day 43 | Signed packages + verification | `nova-package-sign`: a signature trailer on an unmodified `.npkg`, verified before anything is unpacked; `nova keygen` / `nova sign`; `nova install` now refuses unsigned packages |
| Day 44 | Secure-boot strategy + security logging | `nova-seclog`: a separate, separately queryable, hash-chained security event log built on M4's logging subsystem; `docs/secure-boot-strategy-v1.md` |
| Day 45 | Least-privilege audit, acceptance, tag | `nova-privilege-audit`: the audit as code, seven services, zero failures, reconciled against a real process's `/proc` status; `docs/security-model-v1.md`; this tag |

## Definition of Done for the milestone

Day 45's DoD: *"No core service runs with broader permissions than its own
audited task list requires; the security model doc is complete enough for
an external reviewer to assess. Tag M10."*

Both are checked by `nova-m10-day45-acceptance-test`, which also re-runs
the load-bearing property from each of Days 40-44 — a milestone tag that
only proved its last day would be worth less than it looks.

## Before tagging

```bash
./nova-m10-day45-build_and_run.sh
```

That runs the workspace build, the unit tests for all eight new crates,
each day's acceptance test in order, and the M10 integration test. The
Day 41 test needs namespace privileges (run as root, or on a kernel with
unprivileged user namespaces enabled); it is the one step that can
legitimately fail in a restricted container, and it fails loudly rather
than downgrading itself.

Only if everything passes:

```bash
git tag -a v0.53 -m "M10: Security"
git push origin v0.53
```

## Honest status at the tag

**Verified by running code:** cross-app filesystem isolation including
symlink escape; namespace + seccomp derivation and filter construction;
package signing against substitution, tampering, unsigned and untrusted
keys; IPC endpoint authentication; capability forge/steal/widen/expire/
revoke; security log separation and tamper evidence; the least-privilege
audit.

**Not verified here, and not claimed:** secure boot on real hardware
(M12, device-dependent); kernel-enforced file ownership without
`CAP_CHOWN`; publisher identity, which the symmetric signature scheme
cannot provide (M11); core-service sandboxing (M13/M14). All ten known
limitations are in `docs/security-model-v1.md` with an owner each.

## Day-number note

The Days 36-42 packages in v0.47 used those numbers for M9's hardware
abstraction work. This release follows the Build Guide's own milestone
table, where Days 40-45 are M10 (Security). The overlap is in the
numbering only — v0.47's Day 42 source is carried forward unchanged as
this milestone's base, and nothing from it was replaced.

## Next

**M11 — Package Ecosystem (v0.60), Days 46-49.** Per the Roadmap's
caution, a store is built only after package integrity and the security
model are mature — which is what this milestone was for. M11's first
blocker is limitation #1: the repository needs asymmetric signatures.
