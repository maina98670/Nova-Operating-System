# Nova sandbox hardening, v1

Day 41 (M10, v0.53). Implemented in `libs/nova-isolation`.

## The gap this closes

Day 15's `nova-sandbox` enforces permissions inside Nova's own code. An
app that asks the platform for the camera without declaring it is
refused. An app that ignores `nova-sandbox` and calls
`open("/dev/video0")` is not refused by anything at all. Day 15's module
doc says this and points at M10.

## The three escapes and the three mechanisms

| Escape (from the Day 41 DoD) | Mechanism |
|---|---|
| access another app's data | mount namespace + Day 40's per-app uid and file ownership |
| spawn processes outside its permission set | seccomp allowlist without `clone`/`fork` (no child processes; `execve` is allowed so the app can be launched, see the design-change note below), plus a PID namespace |
| unauthorized network connections | network namespace, plus `socket` absent from the allowlist — unless `Permission::Network` is declared |

Both network mechanisms are keyed off the same manifest declaration, so
they cannot drift apart: `IsolationSpec::from_policy` derives everything
from the app's own `SandboxPolicy`. There is no second place to configure
an app's isolation.

## The seccomp filter

Hand-assembled classic BPF. The layout is documented in the source, and
its shape is unit-tested rather than eyeballed — an off-by-one in the
jump offsets would make the last comparison fall through to *allow*,
producing a filter that appears to work and permits everything.

Two details worth knowing:

* **The architecture is checked first.** A filter that does not check
  `seccomp_data.arch` can be bypassed on a multi-ABI kernel by making
  the same call through a different ABI, where the syscall numbers mean
  something else.
* **The default violation action is `EPERM`, not kill.** A killed process
  is indistinguishable from a crash in the logs, and Day 44 wants the
  difference to be visible.

The allowlist is written with `libc::SYS_*` constants rather than numbers
so it is correct on both aarch64 (the real target) and x86_64 (the
development host) from one list.

## Failing closed

`unshare(2)` for mount/PID/network namespaces normally needs
`CAP_SYS_ADMIN`. When a requested namespace cannot be entered, the spawn
**fails** — the child exits from `pre_exec` and the program is never
executed. A sandbox that silently downgrades itself is worse than one
that refuses to start, because everything downstream keeps assuming it
held.

`with_user_namespace(true)` asks for a user namespace first, which on a
kernel with unprivileged user namespaces enabled grants the capabilities
needed for the rest inside it. That is what lets the Day 41 acceptance
test run for real in a developer shell instead of only under root.

## What is not claimed

Five namespaces and a syscall allowlist are a serious boundary, not a
proof. Kernel bugs, a too-generous allowlist, and anything reachable
through a file descriptor passed *into* the sandbox all remain real. Day
45 audits the allowlist; `security-model-v1.md` carries the residual
risk.

Core services are **not** yet isolated this way — only apps are. Day 45's
audit records that as a note against every service profile rather than
leaving it implicit.

## Design change (found by running Day 41)

The original allowlist omitted `execve`, but the filter is installed in the child before the `execve`
that launches the app, so the sandbox refused to start the app it was meant to contain (`execve` returned
EPERM under strace). `execve`/`execveat` are now allowed, plus the few startup syscalls a dynamically
linked program needs.

Still enforced: no `clone`/`fork`/`vfork` (an app cannot spawn children), no `socket` without
`Permission::Network`, no `mount`/`ptrace`, `no_new_privs`, the per-app uid, and the namespaces.

Weaker than this document previously claimed: an app can `execve` another binary it can read, replacing
its own image. That image inherits the same filter, uid and namespaces. Restricting which binaries are
reachable needs a private root filesystem (pivot_root), which is not implemented. Residual risk: recorded
here, not solved.
