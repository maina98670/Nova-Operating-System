//! Nova identity & filesystem permission enforcement — M10 Day 40.
//!
//! Day 15 (`nova-sandbox`) gave every app a *lexically* scoped data
//! directory: a relative path with no `..` components, joined onto
//! `/var/lib/nova/apps/<app-id>`. That was explicitly labelled a
//! minimum, with the real work deferred to M10. This is that work's
//! first half.
//!
//! Two things are added here, and they are different things:
//!
//! 1. **A real identity concept.** Nova is single-user-per-phone, so
//!    there is no multi-user login story to build — but "one human"
//!    does not mean "one principal". Every installed app is its own
//!    principal, with its own stable, persisted, kernel-visible uid
//!    drawn from a reserved range. That uid is what makes per-app
//!    isolation enforceable by the kernel (Day 41's namespaces,
//!    Day 42's `SO_PEERCRED` IPC authentication, and Day 45's
//!    least-privilege service audit all key off it) instead of being
//!    a user-space convention any process could ignore.
//!
//! 2. **Filesystem permission enforcement past lexical scoping.**
//!    `SandboxPolicy::scoped_path` rejects `..` and absolute paths,
//!    which stops the naive traversal attempt. It does *not* stop a
//!    symlink: `notes/link` is a perfectly legal relative path with no
//!    `..` in it, and following it can land anywhere on the disk.
//!    [`Enforcer`] closes that by resolving the real path
//!    (`fs::canonicalize`) and requiring the result to still live
//!    under the app's own canonicalized root, then checking ownership
//!    and mode bits before returning a path to the caller.
//!
//! ## What this crate does and does not claim
//!
//! It **does** enforce, in Nova's own code, that one app identity
//! cannot reach another app identity's files through the APIs Nova
//! apps are given — including via symlink, including via a crafted
//! traversal string.
//!
//! It **does not** claim a process that ignores these APIs entirely
//! and calls `open(2)` itself is stopped by this crate. That is the
//! kernel's job, and it requires the uids here to actually be applied
//! to files on disk ([`Enforcer::apply_ownership`], which needs
//! `CAP_CHOWN`) and the process to actually run as that uid. Day 41
//! adds the process-side half of that. Stated here rather than left to
//! be assumed.

use nova_sandbox::{SandboxError, SandboxPolicy};
use std::collections::BTreeMap;
use std::fs;
use std::io;
use std::os::unix::fs::MetadataExt;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

/// First uid handed to an installed app. Chosen to sit well above the
/// 1000-range a Linux distribution gives human users and well below
/// the 65534 `nobody` convention, so a Nova app uid is recognisable on
/// sight and never collides with a system account.
pub const APP_UID_BASE: u32 = 20000;
/// Last uid available to apps. 10 000 slots is far more than a phone
/// will ever install; the cap exists so uid allocation fails loudly
/// rather than wandering into another range.
pub const APP_UID_MAX: u32 = 29999;
/// The uid Nova's own core services run as — deliberately *not* 0.
/// Day 45 audits every service against this.
pub const SYSTEM_UID: u32 = 1000;

/// Default mode for an app's own data root: owner-only, no group, no
/// other. Tighter than M5, which never set a mode at all and inherited
/// whatever the process umask produced.
pub const APP_DIR_MODE: u32 = 0o700;
/// Default mode for a file inside an app's data root.
pub const APP_FILE_MODE: u32 = 0o600;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Uid(pub u32);

impl std::fmt::Display for Uid {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IdentityKind {
    /// Nova's own core services (App Manager, Service Manager, the
    /// compositor, the shell).
    System,
    /// One installed application.
    App,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Identity {
    pub app_id: String,
    pub uid: Uid,
    /// Nova gives each app a private group with the same numeric id as
    /// its uid — the standard "user private group" arrangement. It
    /// means group bits can be used later (a media group, say) without
    /// every app silently sharing one.
    pub gid: u32,
    pub kind: IdentityKind,
}

impl Identity {
    pub fn system(name: &str) -> Self {
        Identity { app_id: name.to_string(), uid: Uid(SYSTEM_UID), gid: SYSTEM_UID, kind: IdentityKind::System }
    }

    pub fn is_system(&self) -> bool {
        matches!(self.kind, IdentityKind::System)
    }
}

#[derive(Debug)]
pub enum IdentityError {
    InvalidAppId(String),
    UnknownApp(String),
    UidSpaceExhausted,
    /// The uid table on disk disagrees with itself — two app ids
    /// claiming one uid, or a malformed line. Never silently repaired:
    /// a corrupt identity table is a security-relevant event, not a
    /// formatting nuisance.
    CorruptTable(String),
    /// The path resolved, but outside the requesting identity's root.
    EscapesRoot { app_id: String, resolved: PathBuf },
    /// The path is inside the root, but this identity doesn't own it.
    AccessDenied { app_id: String, owner: Uid, path: PathBuf, access: Access },
    Sandbox(SandboxError),
    Io(String),
}

impl std::fmt::Display for IdentityError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IdentityError::InvalidAppId(id) => write!(f, "invalid app id: {id}"),
            IdentityError::UnknownApp(id) => write!(f, "no identity allocated for app: {id}"),
            IdentityError::UidSpaceExhausted => {
                write!(f, "app uid space {APP_UID_BASE}-{APP_UID_MAX} is exhausted")
            }
            IdentityError::CorruptTable(why) => write!(f, "identity table is corrupt: {why}"),
            IdentityError::EscapesRoot { app_id, resolved } => {
                write!(f, "path escapes {app_id}'s sandbox root (resolved to {})", resolved.display())
            }
            IdentityError::AccessDenied { app_id, owner, path, access } => write!(
                f,
                "{app_id} denied {} access to {} (owned by uid {owner})",
                access.name(),
                path.display()
            ),
            IdentityError::Sandbox(e) => write!(f, "sandbox: {e}"),
            IdentityError::Io(e) => write!(f, "io: {e}"),
        }
    }
}

impl std::error::Error for IdentityError {}

impl From<SandboxError> for IdentityError {
    fn from(e: SandboxError) -> Self {
        IdentityError::Sandbox(e)
    }
}

impl From<io::Error> for IdentityError {
    fn from(e: io::Error) -> Self {
        IdentityError::Io(e.to_string())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Access {
    Read,
    Write,
    Execute,
}

impl Access {
    pub fn name(self) -> &'static str {
        match self {
            Access::Read => "read",
            Access::Write => "write",
            Access::Execute => "execute",
        }
    }

    fn owner_bit(self) -> u32 {
        match self {
            Access::Read => 0o400,
            Access::Write => 0o200,
            Access::Execute => 0o100,
        }
    }

    fn group_bit(self) -> u32 {
        self.owner_bit() >> 3
    }

    fn other_bit(self) -> u32 {
        self.owner_bit() >> 6
    }
}

/// The owner/group/mode triple of a real file, read from the kernel
/// rather than tracked separately — the same discipline `nova-procmgr`
/// applies to process state (read `/proc`, never guess).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Ownership {
    pub uid: Uid,
    pub gid: u32,
    pub mode: u32,
}

impl Ownership {
    pub fn of(path: &Path) -> Result<Ownership, IdentityError> {
        let meta = fs::metadata(path)?;
        Ok(Ownership { uid: Uid(meta.uid()), gid: meta.gid(), mode: meta.mode() & 0o7777 })
    }

    /// Classic owner/group/other evaluation. System identities are not
    /// short-circuited to "always allowed" here: a service that should
    /// not be reading an app's private file is exactly what Day 45's
    /// least-privilege audit is looking for, and silently exempting
    /// uid 1000 would hide it.
    pub fn permits(&self, who: &Identity, access: Access) -> bool {
        if who.uid == self.uid {
            self.mode & access.owner_bit() != 0
        } else if who.gid == self.gid {
            self.mode & access.group_bit() != 0
        } else {
            self.mode & access.other_bit() != 0
        }
    }
}

fn valid_app_id(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 128
        && id.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_'))
}

/// The persisted app-id -> uid table.
///
/// Allocation is sequential and *never reused*: uninstalling an app
/// does not free its uid for the next installer. Reusing a uid would
/// mean a newly installed app inheriting access to any file the old
/// app left behind on disk, which is a real, well-documented failure
/// mode in systems that recycle ids aggressively.
#[derive(Debug, Default)]
pub struct IdentityRegistry {
    by_app: BTreeMap<String, Identity>,
    by_uid: BTreeMap<u32, String>,
    next_uid: u32,
    path: Option<PathBuf>,
}

impl IdentityRegistry {
    pub fn new() -> Self {
        IdentityRegistry { by_app: BTreeMap::new(), by_uid: BTreeMap::new(), next_uid: APP_UID_BASE, path: None }
    }

    /// Loads (or starts) a registry persisted at `path`. Tab-separated,
    /// one `app_id<TAB>uid` per line — the same dependency-free
    /// convention `nova-log`, `nova-contacts` and `nova-messages`
    /// already use, so there is one file format in this OS, not five.
    pub fn open(path: impl Into<PathBuf>) -> Result<Self, IdentityError> {
        let path = path.into();
        let mut reg = IdentityRegistry::new();
        reg.path = Some(path.clone());

        if !path.exists() {
            return Ok(reg);
        }

        let text = fs::read_to_string(&path)?;
        for (lineno, line) in text.lines().enumerate() {
            if line.trim().is_empty() {
                continue;
            }
            let mut parts = line.split('\t');
            let (Some(app_id), Some(uid_str), None) = (parts.next(), parts.next(), parts.next()) else {
                return Err(IdentityError::CorruptTable(format!("line {}: expected 2 tab-separated fields", lineno + 1)));
            };
            if !valid_app_id(app_id) {
                return Err(IdentityError::CorruptTable(format!("line {}: invalid app id", lineno + 1)));
            }
            let uid: u32 = uid_str
                .parse()
                .map_err(|_| IdentityError::CorruptTable(format!("line {}: uid is not a number", lineno + 1)))?;
            if !(APP_UID_BASE..=APP_UID_MAX).contains(&uid) {
                return Err(IdentityError::CorruptTable(format!("line {}: uid {uid} is outside the app range", lineno + 1)));
            }
            if let Some(existing) = reg.by_uid.get(&uid) {
                return Err(IdentityError::CorruptTable(format!("uid {uid} claimed by both {existing} and {app_id}")));
            }
            reg.by_uid.insert(uid, app_id.to_string());
            reg.by_app.insert(
                app_id.to_string(),
                Identity { app_id: app_id.to_string(), uid: Uid(uid), gid: uid, kind: IdentityKind::App },
            );
            reg.next_uid = reg.next_uid.max(uid + 1);
        }
        Ok(reg)
    }

    fn persist(&self) -> Result<(), IdentityError> {
        let Some(path) = &self.path else { return Ok(()) };
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }
        let mut out = String::new();
        for (app_id, identity) in &self.by_app {
            out.push_str(app_id);
            out.push('\t');
            out.push_str(&identity.uid.0.to_string());
            out.push('\n');
        }
        fs::write(path, out.as_bytes())?;
        // The identity table decides who can read what. It must not be
        // world-writable, and there is no reason for it to be
        // world-readable either.
        let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o600));
        Ok(())
    }

    /// Idempotent: installing the same app twice keeps the same uid,
    /// which is what makes the uid *stable* and therefore usable as an
    /// on-disk ownership marker across reboots and reinstalls.
    pub fn allocate(&mut self, app_id: &str) -> Result<Identity, IdentityError> {
        if !valid_app_id(app_id) {
            return Err(IdentityError::InvalidAppId(app_id.to_string()));
        }
        if let Some(existing) = self.by_app.get(app_id) {
            return Ok(existing.clone());
        }
        if self.next_uid > APP_UID_MAX {
            return Err(IdentityError::UidSpaceExhausted);
        }
        let uid = self.next_uid;
        self.next_uid += 1;
        let identity =
            Identity { app_id: app_id.to_string(), uid: Uid(uid), gid: uid, kind: IdentityKind::App };
        self.by_app.insert(app_id.to_string(), identity.clone());
        self.by_uid.insert(uid, app_id.to_string());
        self.persist()?;
        Ok(identity)
    }

    /// Records an identity Nova did **not** allocate: the uid of a core
    /// service, or (during development) the uid a developer's shell
    /// happens to be running as.
    ///
    /// This exists because not every principal on the system comes out
    /// of `allocate` — Day 45 audits core services, which have fixed
    /// uids, and Day 42's IPC authentication has to be able to answer
    /// "who is uid 1000?" as well as "who is uid 20003?". A uid outside
    /// the app range is recorded as [`IdentityKind::System`], which is
    /// a statement of fact about where the uid came from, not a grant
    /// of any privilege — [`Ownership::permits`] gives system
    /// identities no special treatment.
    pub fn reserve(&mut self, app_id: &str, uid: u32) -> Result<Identity, IdentityError> {
        if !valid_app_id(app_id) {
            return Err(IdentityError::InvalidAppId(app_id.to_string()));
        }
        if let Some(existing) = self.by_uid.get(&uid) {
            if existing != app_id {
                return Err(IdentityError::CorruptTable(format!("uid {uid} is already {existing}, not {app_id}")));
            }
        }
        let kind =
            if (APP_UID_BASE..=APP_UID_MAX).contains(&uid) { IdentityKind::App } else { IdentityKind::System };
        let identity = Identity { app_id: app_id.to_string(), uid: Uid(uid), gid: uid, kind };
        self.by_app.insert(app_id.to_string(), identity.clone());
        self.by_uid.insert(uid, app_id.to_string());
        if kind == IdentityKind::App {
            self.next_uid = self.next_uid.max(uid + 1);
        }
        Ok(identity)
    }

    pub fn get(&self, app_id: &str) -> Result<Identity, IdentityError> {
        self.by_app.get(app_id).cloned().ok_or_else(|| IdentityError::UnknownApp(app_id.to_string()))
    }

    /// Reverse lookup — this is the function Day 42's IPC endpoint
    /// authentication uses to turn an `SO_PEERCRED` uid back into "which
    /// app is actually on the other end of this socket".
    pub fn by_uid(&self, uid: Uid) -> Option<Identity> {
        self.by_uid.get(&uid.0).and_then(|id| self.by_app.get(id)).cloned()
    }

    pub fn len(&self) -> usize {
        self.by_app.len()
    }

    pub fn is_empty(&self) -> bool {
        self.by_app.is_empty()
    }
}

/// Resolves and authorises app filesystem access.
///
/// `root` is the parent of every app's data directory — `/var/lib/nova/apps`
/// in a real Nova system (matching `SandboxPolicy::app_data_root`), and a
/// temporary directory in tests, which is the only reason it's a
/// parameter rather than a constant.
#[derive(Debug, Clone)]
pub struct Enforcer {
    root: PathBuf,
}

impl Enforcer {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Enforcer { root: root.into() }
    }

    /// The real Nova layout.
    pub fn system() -> Self {
        Enforcer::new("/var/lib/nova/apps")
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    pub fn app_root(&self, identity: &Identity) -> PathBuf {
        self.root.join(&identity.app_id)
    }

    /// Creates the app's data root with the tight default mode and, if
    /// the caller has the privilege to do so, the app's own uid/gid.
    pub fn provision(&self, identity: &Identity) -> Result<PathBuf, IdentityError> {
        let dir = self.app_root(identity);
        fs::create_dir_all(&dir)?;
        fs::set_permissions(&dir, fs::Permissions::from_mode(APP_DIR_MODE))?;
        self.apply_ownership(&dir, identity)?;
        Ok(dir)
    }

    /// `chown(2)` to the app's identity.
    ///
    /// Honest about privilege: `chown` to another uid requires
    /// `CAP_CHOWN`. When Nova's App Manager runs this as a system
    /// service that holds it, ownership is really applied and the
    /// kernel enforces it. When a unit test or an unprivileged
    /// developer shell runs it, the call fails with `EPERM` and is
    /// reported — not swallowed — via [`OwnershipOutcome`]. Nova's own
    /// checks in [`Enforcer::authorize`] still hold either way; what's
    /// missing without privilege is the *kernel's* second, independent
    /// enforcement of the same rule.
    pub fn apply_ownership(&self, path: &Path, identity: &Identity) -> Result<OwnershipOutcome, IdentityError> {
        // Recurse into directories before chowning the directory
        // itself.
        //
        // M11 found this when Day 40's acceptance test was first
        // actually run: the call chowned only the path it was handed,
        // so an app data root populated after provisioning -- which is
        // every real app, since `provision` runs at install time and
        // files arrive afterwards -- ended up with a correctly-owned
        // root full of files owned by the installing process. Nova's
        // own ownership gate then denied the app access to its own
        // data. A per-file chown at write time would be the wrong fix
        // (it would trust whoever is writing); ownership is a property
        // of the subtree, so it is applied to the subtree.
        if path.is_dir() && !path.is_symlink() {
            for entry in fs::read_dir(path).map_err(|e| IdentityError::Io(e.to_string()))? {
                let entry = entry.map_err(|e| IdentityError::Io(e.to_string()))?;
                if let OwnershipOutcome::NotPermitted = self.apply_ownership(&entry.path(), identity)? {
                    return Ok(OwnershipOutcome::NotPermitted);
                }
            }
        }
        let c_path = std::ffi::CString::new(path.as_os_str().as_encoded_bytes())
            .map_err(|_| IdentityError::Io("path contains an interior NUL byte".into()))?;
        // SAFETY: c_path is a valid NUL-terminated C string that lives
        // for the duration of the call; chown takes no ownership of it.
        let rc = unsafe { libc::chown(c_path.as_ptr(), identity.uid.0, identity.gid) };
        if rc == 0 {
            Ok(OwnershipOutcome::Applied)
        } else {
            let err = io::Error::last_os_error();
            if err.raw_os_error() == Some(libc::EPERM) {
                Ok(OwnershipOutcome::NotPermitted)
            } else {
                Err(IdentityError::Io(err.to_string()))
            }
        }
    }

    /// Resolve a relative, app-supplied path to a real path the app is
    /// allowed to use — or refuse.
    ///
    /// Four gates, in order, each defeating a different attack:
    ///
    /// 1. `SandboxPolicy::scoped_path` — rejects absolute paths and any
    ///    `..` component. Defeats `../other-app/data`.
    /// 2. Canonicalisation of the deepest existing ancestor — defeats a
    ///    symlink whose *target* is outside the root, which gate 1
    ///    cannot see because the path string itself is innocent.
    /// 3. Prefix check against the canonicalised app root — the actual
    ///    containment decision, made on real paths, not strings.
    /// 4. Ownership/mode check — defeats the case where the file really
    ///    is inside this app's root but belongs to someone else (a
    ///    shared or migrated directory, a file planted by another
    ///    identity).
    pub fn authorize(
        &self,
        policy: &SandboxPolicy,
        identity: &Identity,
        relative: impl AsRef<Path>,
        access: Access,
    ) -> Result<PathBuf, IdentityError> {
        if policy.app_id != identity.app_id {
            return Err(IdentityError::InvalidAppId(format!(
                "policy is for {}, identity is for {}",
                policy.app_id, identity.app_id
            )));
        }

        // Gate 1: lexical scoping (Day 15's rule, unchanged and still
        // load-bearing — this crate tightens it, it does not replace it).
        let scoped = policy.scoped_path(relative.as_ref())?;
        // `SandboxPolicy` hardcodes /var/lib/nova/apps; re-root it onto
        // this Enforcer's root so the same policy object works in a test
        // directory and on a real device without two code paths.
        let suffix = scoped.strip_prefix("/var/lib/nova/apps").unwrap_or(&scoped);
        let candidate = self.root.join(suffix);

        // Gates 2 and 3: real-path containment.
        let app_root = self.app_root(identity);
        let real_root = canonical_or_self(&app_root);
        let resolved = resolve_existing(&candidate);
        if !resolved.starts_with(&real_root) {
            return Err(IdentityError::EscapesRoot { app_id: identity.app_id.clone(), resolved });
        }

        // Gate 4: ownership. A path that doesn't exist yet can't be
        // owned by anyone; for a write, the *parent* is what must be
        // writable, which is the check that actually matters.
        let subject = if resolved.exists() { resolved.clone() } else { resolved.parent().unwrap_or(&real_root).to_path_buf() };
        if subject.exists() {
            let ownership = Ownership::of(&subject)?;
            if !ownership.permits(identity, access) {
                return Err(IdentityError::AccessDenied {
                    app_id: identity.app_id.clone(),
                    owner: ownership.uid,
                    path: subject,
                    access,
                });
            }
        }

        Ok(resolved)
    }

    pub fn read(&self, policy: &SandboxPolicy, identity: &Identity, relative: impl AsRef<Path>) -> Result<Vec<u8>, IdentityError> {
        let path = self.authorize(policy, identity, relative, Access::Read)?;
        Ok(fs::read(path)?)
    }

    pub fn write(
        &self,
        policy: &SandboxPolicy,
        identity: &Identity,
        relative: impl AsRef<Path>,
        data: &[u8],
    ) -> Result<PathBuf, IdentityError> {
        let path = self.authorize(policy, identity, relative, Access::Write)?;
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }
        fs::write(&path, data)?;
        fs::set_permissions(&path, fs::Permissions::from_mode(APP_FILE_MODE))?;
        self.apply_ownership(&path, identity)?;
        Ok(path)
    }
}

/// Whether a `chown` actually took effect. Returned rather than
/// discarded so callers (and Day 45's audit) can tell a genuinely
/// kernel-enforced install from a developer-shell one.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OwnershipOutcome {
    Applied,
    /// The process lacks `CAP_CHOWN`. Nova-level checks still apply;
    /// kernel-level ownership does not.
    NotPermitted,
}

fn canonical_or_self(path: &Path) -> PathBuf {
    fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf())
}

/// Canonicalises as much of `path` as exists, then re-appends the
/// components that don't. `fs::canonicalize` fails outright on a
/// non-existent path, which would make every create-a-new-file call
/// unresolvable — but the symlink that matters is always in an
/// *existing* ancestor, so resolving the deepest existing prefix is
/// exactly as strong and works for paths that aren't there yet.
fn resolve_existing(path: &Path) -> PathBuf {
    let mut missing: Vec<std::ffi::OsString> = Vec::new();
    let mut cursor = path.to_path_buf();
    loop {
        if let Ok(real) = fs::canonicalize(&cursor) {
            let mut out = real;
            for part in missing.iter().rev() {
                out.push(part);
            }
            return out;
        }
        let Some(name) = cursor.file_name().map(|n| n.to_os_string()) else {
            // Ran out of ancestors without finding anything real.
            let mut out = cursor;
            for part in missing.iter().rev() {
                out.push(part);
            }
            return out;
        };
        missing.push(name);
        cursor.pop();
    }
}

/// A sink for refusals the [`Enforcer`] makes — added on Day 44.
///
/// The trait is declared here, in the layer that *detects* a violation,
/// and implemented in `nova-seclog`, the layer that *records* one. That
/// keeps the dependency pointing one way: filesystem enforcement knows
/// nothing about logging, and the security log knows nothing about path
/// resolution. `nova-identity` gains no new dependency from this.
pub trait SecurityObserver {
    fn violation(&mut self, principal: &str, detail: &str);
}

impl Enforcer {
    /// [`Enforcer::authorize`], with refusals reported to `observer`.
    ///
    /// Only containment and permission refusals are reported. An
    /// `Io(NotFound)` from a missing file is not a security event, and
    /// filling the security log with them would bury the ones that are
    /// — which is precisely what Day 44's separate channel exists to
    /// avoid.
    pub fn authorize_observed(
        &self,
        policy: &SandboxPolicy,
        identity: &Identity,
        relative: impl AsRef<Path>,
        access: Access,
        observer: &mut dyn SecurityObserver,
    ) -> Result<PathBuf, IdentityError> {
        let result = self.authorize(policy, identity, relative, access);
        if let Err(
            e @ (IdentityError::EscapesRoot { .. }
            | IdentityError::AccessDenied { .. }
            | IdentityError::Sandbox(_)),
        ) = &result
        {
            observer.violation(&identity.app_id, &e.to_string());
        }
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_sandbox::PermissionSet;
    use std::os::unix::fs::symlink;

    fn tmp(name: &str) -> PathBuf {
        let p = std::env::temp_dir().join(format!("nova-identity-{}-{}", std::process::id(), name));
        let _ = fs::remove_dir_all(&p);
        fs::create_dir_all(&p).unwrap();
        p
    }

    fn policy(app_id: &str) -> SandboxPolicy {
        SandboxPolicy::new(app_id, PermissionSet::empty(), PermissionSet::empty()).unwrap()
    }

    #[test]
    fn uids_are_stable_and_never_reused() {
        let dir = tmp("stable");
        let table = dir.join("identities.tsv");

        let first = {
            let mut reg = IdentityRegistry::open(&table).unwrap();
            let a = reg.allocate("org.nova.alpha").unwrap();
            let b = reg.allocate("org.nova.beta").unwrap();
            assert_ne!(a.uid, b.uid);
            assert_eq!(a.uid, Uid(APP_UID_BASE));
            // Idempotent.
            assert_eq!(reg.allocate("org.nova.alpha").unwrap().uid, a.uid);
            a
        };

        // Survives a "reboot": same uid, read back from disk.
        let mut reloaded = IdentityRegistry::open(&table).unwrap();
        assert_eq!(reloaded.get("org.nova.alpha").unwrap().uid, first.uid);
        // A third app gets a fresh uid, not beta's or alpha's.
        let c = reloaded.allocate("org.nova.gamma").unwrap();
        assert_eq!(c.uid, Uid(APP_UID_BASE + 2));

        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn reverse_lookup_finds_the_app_behind_a_uid() {
        let mut reg = IdentityRegistry::new();
        let a = reg.allocate("org.nova.alpha").unwrap();
        assert_eq!(reg.by_uid(a.uid).unwrap().app_id, "org.nova.alpha");
        assert!(reg.by_uid(Uid(APP_UID_MAX)).is_none());
    }

    #[test]
    fn corrupt_table_is_rejected_not_repaired() {
        let dir = tmp("corrupt");
        let table = dir.join("identities.tsv");
        fs::write(&table, "org.nova.alpha\t20000\norg.nova.beta\t20000\n").unwrap();
        assert!(matches!(IdentityRegistry::open(&table), Err(IdentityError::CorruptTable(_))));
        let _ = fs::remove_dir_all(&dir);
    }

    /// The literal Day 40 DoD, part one: a deliberately crafted path
    /// traversal attempt.
    #[test]
    fn day40_traversal_attempt_is_refused() {
        let dir = tmp("traversal");
        let enforcer = Enforcer::new(&dir);
        let mut reg = IdentityRegistry::new();
        let alpha = reg.allocate("org.nova.alpha").unwrap();
        let beta = reg.allocate("org.nova.beta").unwrap();
        enforcer.provision(&alpha).unwrap();
        enforcer.provision(&beta).unwrap();
        fs::write(enforcer.app_root(&beta).join("secret.txt"), b"beta's private data").unwrap();

        let err = enforcer
            .authorize(&policy("org.nova.alpha"), &alpha, "../org.nova.beta/secret.txt", Access::Read)
            .unwrap_err();
        assert!(matches!(err, IdentityError::Sandbox(SandboxError::PathOutsideSandbox)));

        let _ = fs::remove_dir_all(&dir);
    }

    /// The Day 40 DoD's real teeth: the attempt Day 15's lexical check
    /// could not see. `link` contains no `..` and is not absolute.
    #[test]
    fn day40_symlink_escape_is_refused() {
        let dir = tmp("symlink");
        let enforcer = Enforcer::new(&dir);
        let mut reg = IdentityRegistry::new();
        let alpha = reg.allocate("org.nova.alpha").unwrap();
        let beta = reg.allocate("org.nova.beta").unwrap();
        enforcer.provision(&alpha).unwrap();
        enforcer.provision(&beta).unwrap();
        fs::write(enforcer.app_root(&beta).join("secret.txt"), b"beta's private data").unwrap();

        symlink(enforcer.app_root(&beta), enforcer.app_root(&alpha).join("link")).unwrap();

        // Day 15's own check passes this happily — that's the point.
        assert!(policy("org.nova.alpha").scoped_path("link/secret.txt").is_ok());

        let err =
            enforcer.authorize(&policy("org.nova.alpha"), &alpha, "link/secret.txt", Access::Read).unwrap_err();
        match err {
            IdentityError::EscapesRoot { app_id, .. } => assert_eq!(app_id, "org.nova.alpha"),
            other => panic!("expected EscapesRoot, got {other}"),
        }

        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn own_files_are_still_reachable() {
        let dir = tmp("own");
        let enforcer = Enforcer::new(&dir);
        let mut reg = IdentityRegistry::new();
        let alpha = reg.allocate("org.nova.alpha").unwrap();
        enforcer.provision(&alpha).unwrap();

        let written = enforcer.write(&policy("org.nova.alpha"), &alpha, "notes/todo.txt", b"buy milk").unwrap();
        assert!(written.starts_with(enforcer.app_root(&alpha)));
        let back = enforcer.read(&policy("org.nova.alpha"), &alpha, "notes/todo.txt").unwrap();
        assert_eq!(back, b"buy milk");
        // Tighter than M5: the file is not group- or world-readable.
        assert_eq!(Ownership::of(&written).unwrap().mode, APP_FILE_MODE);

        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn ownership_check_is_independent_of_path_containment() {
        // A file genuinely inside alpha's root, owned by someone else.
        // Containment says yes; ownership must still say no.
        let alpha = Identity { app_id: "a".into(), uid: Uid(20000), gid: 20000, kind: IdentityKind::App };
        let owned_by_beta = Ownership { uid: Uid(20001), gid: 20001, mode: 0o600 };
        assert!(!owned_by_beta.permits(&alpha, Access::Read));
        assert!(!owned_by_beta.permits(&alpha, Access::Write));

        let world_readable = Ownership { uid: Uid(20001), gid: 20001, mode: 0o644 };
        assert!(world_readable.permits(&alpha, Access::Read));
        assert!(!world_readable.permits(&alpha, Access::Write));
    }

    #[test]
    fn reserve_records_a_uid_nova_did_not_allocate() {
        let mut reg = IdentityRegistry::new();
        let svc = reg.reserve("nova-app-manager", SYSTEM_UID).unwrap();
        assert_eq!(svc.kind, IdentityKind::System);
        assert_eq!(reg.by_uid(Uid(SYSTEM_UID)).unwrap().app_id, "nova-app-manager");
        // Reserving does not consume an app uid.
        assert_eq!(reg.allocate("org.nova.alpha").unwrap().uid, Uid(APP_UID_BASE));
        // A conflicting claim on the same uid is refused, not overwritten.
        assert!(reg.reserve("nova-shell", SYSTEM_UID).is_err());
    }

    #[test]
    fn a_system_identity_is_not_exempt() {
        let system = Identity::system("nova-app-manager");
        let app_private = Ownership { uid: Uid(20000), gid: 20000, mode: 0o600 };
        assert!(!app_private.permits(&system, Access::Read));
    }

    #[test]
    fn policy_and_identity_must_refer_to_the_same_app() {
        let dir = tmp("mismatch");
        let enforcer = Enforcer::new(&dir);
        let mut reg = IdentityRegistry::new();
        let alpha = reg.allocate("org.nova.alpha").unwrap();
        enforcer.provision(&alpha).unwrap();

        let err = enforcer.authorize(&policy("org.nova.beta"), &alpha, "x.txt", Access::Read).unwrap_err();
        assert!(matches!(err, IdentityError::InvalidAppId(_)));
        let _ = fs::remove_dir_all(&dir);
    }
}
