//! Day 40 acceptance test — the literal Definition of Done:
//!
//! > Two test apps with different identities cannot read each other's
//! > files even with a deliberately crafted path traversal attempt.
//!
//! "Deliberately crafted" is taken seriously here: four separate
//! attacks are run, not one. The first is the obvious `../` string that
//! Day 15 already stopped; the rest are the ones that get past a purely
//! lexical check and are the actual reason M10 exists.
//!
//! This is a live test. It creates real directories, real files and a
//! real symlink under a temporary root, then tries to read across the
//! boundary as the wrong identity. Nothing is simulated and nothing is
//! asserted about code that wasn't executed.

use nova_identity::{Access, Enforcer, IdentityError, IdentityRegistry, Ownership, OwnershipOutcome};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use std::fs;
use std::os::unix::fs::symlink;
use std::os::unix::fs::PermissionsExt;
use std::path::PathBuf;
use std::process::ExitCode;

const ALPHA: &str = "org.nova.alpha";
const BETA: &str = "org.nova.beta";

fn policy(app_id: &str) -> SandboxPolicy {
    SandboxPolicy::new(app_id, PermissionSet::empty(), PermissionSet::empty())
        .expect("test app ids are valid")
}

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 40 acceptance: identity & filesystem permissions ===\n");

    let root: PathBuf = std::env::temp_dir().join(format!("nova-day40-acceptance-{}", std::process::id()));
    let _ = fs::remove_dir_all(&root);
    fs::create_dir_all(&root).expect("create test root");

    let enforcer = Enforcer::new(&root);
    let mut registry = IdentityRegistry::open(root.join("identities.tsv")).expect("open identity registry");

    let alpha = registry.allocate(ALPHA).expect("allocate alpha identity");
    let beta = registry.allocate(BETA).expect("allocate beta identity");

    println!("Identities allocated from the reserved app range:");
    println!("  {ALPHA}  uid={} gid={}", alpha.uid, alpha.gid);
    println!("  {BETA}  uid={} gid={}", beta.uid, beta.gid);
    println!();

    let alpha_root = enforcer.provision(&alpha).expect("provision alpha");
    let beta_root = enforcer.provision(&beta).expect("provision beta");

    // Beta's private file. This is the thing alpha must never reach.
    //
    // Order matters here, and M11 found it the hard way when this test
    // was first compiled and run: `apply_ownership` walks the tree that
    // exists when it is called. Creating the secret *after* the chown
    // left it owned by the installing uid rather than by beta, so the
    // final control check -- beta reading its own file -- failed while
    // every "denied" check passed. A test whose controls fail proves
    // nothing, so the file is now planted before ownership is applied.
    let secret_rel = "private/secret.txt";
    let secret_abs = beta_root.join(secret_rel);
    fs::create_dir_all(secret_abs.parent().unwrap()).unwrap();
    fs::write(&secret_abs, b"beta's private data").unwrap();
    fs::set_permissions(&secret_abs, fs::Permissions::from_mode(0o600)).unwrap();

    let chown = enforcer.apply_ownership(&beta_root, &beta).expect("chown attempt");
    match chown {
        OwnershipOutcome::Applied => println!("chown(2) applied: the kernel is independently enforcing these uids."),
        OwnershipOutcome::NotPermitted => println!(
            "chown(2) returned EPERM: this process lacks CAP_CHOWN, so the kernel is NOT\n\
             independently enforcing these uids in this run. Nova's own checks below are\n\
             still exercised for real; run as root (or under Day 41's isolated launcher) to\n\
             exercise the kernel's half too."
        ),
    }
    let _ = enforcer.apply_ownership(&alpha_root, &alpha).expect("chown attempt");
    println!();

    let mut checks: Vec<Check> = Vec::new();

    // --- Attack 1: the plain traversal string. -------------------------
    let attempt = enforcer.authorize(&policy(ALPHA), &alpha, "../org.nova.beta/private/secret.txt", Access::Read);
    checks.push(judge("relative `../` traversal is refused", attempt));

    // --- Attack 2: an absolute path straight at the target. ------------
    let attempt = enforcer.authorize(&policy(ALPHA), &alpha, secret_abs.clone(), Access::Read);
    checks.push(judge("absolute path is refused", attempt));

    // --- Attack 3: a symlink. No `..`, not absolute, entirely legal as
    // a string — and this is what Day 15's lexical check could not see.
    symlink(&beta_root, alpha_root.join("neighbour")).expect("create symlink");
    let lexically_fine = policy(ALPHA).scoped_path("neighbour/private/secret.txt").is_ok();
    let attempt = enforcer.authorize(&policy(ALPHA), &alpha, "neighbour/private/secret.txt", Access::Read);
    let mut symlink_check = judge("symlink escape is refused", attempt);
    symlink_check.detail = format!(
        "{} (M5's lexical scoped_path accepted this same path: {})",
        symlink_check.detail, lexically_fine
    );
    checks.push(symlink_check);

    // --- Attack 4: a symlink to a *file*, dressed up with `./` noise. --
    symlink(&secret_abs, alpha_root.join("note.txt")).expect("create file symlink");
    let attempt = enforcer.authorize(&policy(ALPHA), &alpha, "./note.txt", Access::Read);
    checks.push(judge("symlinked file with ./ prefix is refused", attempt));

    // --- Attack 5: ownership, independent of containment. --------------
    // A file physically inside alpha's own root, but owned by beta.
    // Containment says yes; ownership must still say no. Since an
    // unprivileged test run can't really chown, this is checked against
    // the ownership rule directly rather than pretended on disk.
    let planted = Ownership { uid: beta.uid, gid: beta.gid, mode: 0o600 };
    let ownership_denies = !planted.permits(&alpha, Access::Read);
    checks.push(Check {
        name: "ownership denies a beta-owned file sitting inside alpha's root",
        passed: ownership_denies,
        detail: format!("Ownership{{uid:{}, mode:0600}}.permits(alpha, read) == {}", beta.uid, !ownership_denies),
    });

    // --- Control: the test is not vacuous. -----------------------------
    // Alpha can still reach its own data. If this failed, every "denied"
    // above would be meaningless — the enforcer would just be broken.
    let own = enforcer
        .write(&policy(ALPHA), &alpha, "notes/todo.txt", b"alpha's own data")
        .and_then(|_| enforcer.read(&policy(ALPHA), &alpha, "notes/todo.txt"));
    checks.push(Check {
        name: "control: alpha can still read and write its own data",
        passed: matches!(&own, Ok(bytes) if bytes == b"alpha's own data"),
        detail: match &own {
            Ok(_) => "round-tripped".to_string(),
            Err(e) => format!("FAILED: {e}"),
        },
    });

    // --- Control: beta can read its own secret. ------------------------
    let beta_reads = enforcer.read(&policy(BETA), &beta, secret_rel);
    checks.push(Check {
        name: "control: beta can read its own secret",
        passed: matches!(&beta_reads, Ok(bytes) if bytes == b"beta's private data"),
        detail: match &beta_reads {
            Ok(_) => "read back".to_string(),
            Err(e) => format!("FAILED: {e}"),
        },
    });

    println!("Checks:");
    let mut failures = 0;
    for check in &checks {
        if check.passed {
            println!("  [PASS] {}\n         {}", check.name, check.detail);
        } else {
            failures += 1;
            println!("  [FAIL] {}\n         {}", check.name, check.detail);
        }
    }

    let _ = fs::remove_dir_all(&root);

    println!();
    if failures == 0 {
        println!("Day 40 acceptance: PASS ({} checks)", checks.len());
        println!(
            "Two identities, five distinct cross-app access attempts, all refused; both apps\n\
             still reach their own data."
        );
        ExitCode::SUCCESS
    } else {
        println!("Day 40 acceptance: FAIL ({failures} of {} checks failed)", checks.len());
        ExitCode::FAILURE
    }
}

/// A cross-app attempt passes the check only when it was *refused*, and
/// refused for a containment/permission reason — not because the file
/// happened to be missing or the call errored for some unrelated
/// reason. "It failed somehow" is not the same as "it was denied".
fn judge(name: &'static str, result: Result<PathBuf, IdentityError>) -> Check {
    match result {
        Ok(path) => Check {
            name,
            passed: false,
            detail: format!("ACCESS GRANTED to {} — this is a sandbox escape", path.display()),
        },
        Err(e @ (IdentityError::EscapesRoot { .. } | IdentityError::AccessDenied { .. } | IdentityError::Sandbox(_))) => {
            Check { name, passed: true, detail: format!("refused: {e}") }
        }
        Err(other) => Check {
            name,
            passed: false,
            detail: format!("refused, but for the wrong reason (expected a containment/permission denial): {other}"),
        },
    }
}
