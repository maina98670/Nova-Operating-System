# Nova OS Day 36

## Power management

Day 36 adds the powerstate, power profiles, suspend readiness and wake sources.

### Acceptance
- Workspace member added.
- Dedicated acceptance test added.
- Existing Nova OS components from Day 35 are preserved unchanged except for cumulative workspace integration.
