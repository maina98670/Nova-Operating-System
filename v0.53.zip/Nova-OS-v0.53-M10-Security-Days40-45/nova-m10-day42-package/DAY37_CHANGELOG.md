# Nova OS Day 37

## Battery and thermal management

Day 37 adds the battery telemetry, charging state and thermal zones with safe unavailable states.

### Acceptance
- Workspace member added.
- Dedicated acceptance test added.
- Existing Nova OS components from Day 36 are preserved unchanged except for cumulative workspace integration.
