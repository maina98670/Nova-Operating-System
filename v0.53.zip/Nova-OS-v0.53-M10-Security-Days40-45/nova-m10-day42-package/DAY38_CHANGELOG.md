# Nova OS Day 38

## Sensor HAL

Day 38 adds the stable sensor abstraction for accelerometer, gyroscope, proximity and light sensors.

### Acceptance
- Workspace member added.
- Dedicated acceptance test added.
- Existing Nova OS components from Day 37 are preserved unchanged except for cumulative workspace integration.
