# Nova OS Day 40 — User/process identity + filesystem permissions

M10 (Security), v0.53. Continues directly from v0.47's Day 42 package.

## Definition of Done

> Two test apps with different identities cannot read each other's files even with a deliberately crafted path traversal attempt.

## New in this package

- `libs/nova-identity`
- `tools/nova-m10-day40-identity-acceptance-test`
- `docs/M10-SECURITY-DAY40.md`

## Unchanged

Everything from the previous package is carried forward as-is, except
for the workspace member list and the retrofits named above. No earlier
day's behaviour was replaced.
