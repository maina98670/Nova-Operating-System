# Nova OS Day 41 — Application sandboxing hardening

M10 (Security), v0.53. Continues directly from the Day 40 package.

## Definition of Done

> A deliberately malicious test app cannot escape its sandbox to access another app's data, spawn arbitrary processes outside its permission set, or make unauthorized network connections.

## New in this package

- `libs/nova-isolation`
- `tools/nova-m10-day41-hostile-app`
- `tools/nova-m10-day41-sandbox-hardening-acceptance-test`
- `docs/M10-SECURITY-DAY41.md`
- `docs/sandbox-hardening-v1.md`

## Unchanged

Everything from the previous package is carried forward as-is, except
for the workspace member list and the retrofits named above. No earlier
day's behaviour was replaced.
