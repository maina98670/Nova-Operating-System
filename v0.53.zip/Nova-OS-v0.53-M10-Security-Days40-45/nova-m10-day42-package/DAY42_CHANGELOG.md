# Nova OS Day 42 — Capability/permission model refinement + secure IPC

M10 (Security), v0.53. Continues directly from the Day 41 package.

## Definition of Done

> An unauthorized process attempting to connect to another app's IPC channel is rejected and the attempt is logged.

## New in this package

- `libs/nova-log`
- `libs/nova-crypto`
- `libs/nova-capability`
- `libs/nova-secure-ipc`
- `tools/nova-m10-day42-secure-ipc-acceptance-test`
- `docs/M10-SECURITY-DAY42.md`
- `docs/capability-model-v1.md`

## Unchanged

Everything from the previous package is carried forward as-is, except
for the workspace member list and the retrofits named above. No earlier
day's behaviour was replaced.
