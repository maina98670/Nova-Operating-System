# Nova OS — Day 42 Package: Capability/permission model refinement + secure IPC

M10 — Security (v0.53, Days 40-45). Continues directly from the Day 41 package.

**Assembled without running any build or test** — files only. Nothing
here has been compiled or executed in this pass. Run
`nova-m10-day42-build_and_run.sh` yourself to actually confirm it.

## Day 42 goal

Per the Complete Build Guide's M10 table.

**Definition of Done:** An unauthorized process attempting to connect to another app's IPC channel is rejected and the attempt is logged.

## What's new

- `libs/nova-log`
- `libs/nova-crypto`
- `libs/nova-capability`
- `libs/nova-secure-ipc`
- `tools/nova-m10-day42-secure-ipc-acceptance-test`
- `docs/M10-SECURITY-DAY42.md`
- `docs/capability-model-v1.md`

## Run

```bash
./nova-m10-day42-build_and_run.sh
```

## nova-log is back in the workspace

M4 Day 7 built `nova-log`, and the cumulative packages from Day 11 onward
did not carry it. Day 42's DoD needs a rejected connection to be *logged*,
so the crate is restored here rather than a second logging path being
invented beside it. Same file, same format, same crate as Day 7.

## Status

Unverified until the build, unit tests and acceptance test above actually
pass — none of that was run in this pass.
