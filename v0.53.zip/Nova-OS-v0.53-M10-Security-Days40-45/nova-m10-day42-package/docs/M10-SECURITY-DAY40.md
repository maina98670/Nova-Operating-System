# M10 — Day 40: User/process identity + filesystem permissions

**Focus.** A formal user/process identity model, and filesystem
permission enforcement tightened beyond M5's scoped-storage minimum.

**Delivered.** `libs/nova-identity` — `Uid`/`Identity`/`IdentityKind`, an
`IdentityRegistry` that allocates stable per-app uids in the reserved
20000-29999 range and persists them (never reusing a uid, so an
uninstalled app's leftover files cannot be inherited by the next
installer), and an `Enforcer` that turns an app-supplied relative path
into a path the app is actually allowed to use.

**The tightening, specifically.** M5 rejected `..` and absolute paths —
lexically. `notes/link` contains neither and can point anywhere. The
`Enforcer` canonicalises the deepest existing ancestor and requires the
result to still live under the app's canonical root, then checks
ownership and mode. Four gates, each defeating a different attack.

**DoD.** *Two test apps with different identities cannot read each
other's files even with a deliberately crafted path traversal attempt.*
`tools/nova-m10-day40-identity-acceptance-test` runs five distinct
attempts (relative traversal, absolute path, directory symlink, file
symlink, planted ownership) plus two controls proving each app still
reaches its own data.

**Honest note.** `chown(2)` to another uid needs `CAP_CHOWN`. Without it
the call returns `OwnershipOutcome::NotPermitted` and the test says so:
Nova's own checks are exercised for real either way, but the kernel's
second, independent enforcement of the same rule is not.
