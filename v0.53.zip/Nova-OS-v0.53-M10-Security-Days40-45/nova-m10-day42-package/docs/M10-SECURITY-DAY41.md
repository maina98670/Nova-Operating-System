# M10 — Day 41: Application sandboxing hardening

**Focus.** Move from M5's basic enforcement to real OS-level isolation
for process, filesystem and network access.

**Delivered.** `libs/nova-isolation` — namespace selection
(mount/PID/network/IPC/UTS, optionally inside a user namespace) and a
hand-assembled seccomp-bpf allowlist, both derived from the app's own
`SandboxPolicy` so the kernel-level and Nova-level policies cannot drift
apart. `spawn` applies both in the child between fork and exec, so the
target program never runs outside the sandbox for an instant.

**Fails closed.** A namespace that cannot be entered aborts the spawn.
The child exits from `pre_exec` and the program is never executed.

**DoD.** *A deliberately malicious test app cannot escape its sandbox to
access another app's data, spawn arbitrary processes outside its
permission set, or make unauthorized network connections.*
`tools/nova-m10-day41-hostile-app` really attempts all three;
`tools/nova-m10-day41-sandbox-hardening-acceptance-test` runs it twice —
unsandboxed (which must escape at least once, or the test proves
nothing) and sandboxed (which must escape zero times).

See `docs/sandbox-hardening-v1.md` for the filter layout and what is not
claimed.
