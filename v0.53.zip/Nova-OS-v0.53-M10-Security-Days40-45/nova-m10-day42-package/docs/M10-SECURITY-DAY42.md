# M10 — Day 42: Capability/permission model refinement + secure IPC

**Focus.** Refine M5's permission model into a proper capability system
where hardening found gaps, and authenticate the endpoints of every IPC
channel instead of trusting whoever connects to the socket.

**Delivered.**
* `libs/nova-crypto` — SHA-256, HMAC-SHA256, constant-time comparison.
  Dependency-free, checked against FIPS 180-4 and RFC 4231 vectors.
* `libs/nova-capability` — tokens naming one permission, for one app,
  until one expiry, HMAC-tagged and attenuable on delegation.
* `libs/nova-secure-ipc` — `SO_PEERCRED` endpoint authentication
  resolved through Day 40's uids, with every rejection recorded through
  M4's logging subsystem.

**The gaps hardening exposed.** Ambient authority has no way to express
"take one photo in the next 30 seconds", and an authenticated peer still
had no token to present for a specific grant. Both are in
`docs/capability-model-v1.md`.

**DoD.** *An unauthorized process attempting to connect to another app's
IPC channel is rejected and the attempt is logged.* Both halves in
`tools/nova-m10-day42-secure-ipc-acceptance-test`, against real
socketpair endpoints and real kernel credentials.

**Honest note.** Day 11's wire format still carries the app id in
`Hello`. It is no longer believed — it is compared against the kernel's
answer, and a mismatch is a rejection.
