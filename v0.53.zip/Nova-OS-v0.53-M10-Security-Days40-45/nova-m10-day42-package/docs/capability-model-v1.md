# Nova capability model, v1

Day 42 (M10, v0.53). Implemented in `libs/nova-capability`.

## What was wrong with the M5 model

Day 15's `PermissionSet` is *ambient authority*: the Camera app holds
`Permission::Camera` because it is the Camera app, for as long as it
runs, for every operation. Hardening on Day 41 made two gaps concrete.

1. **No attenuation.** When Messages asks Camera to take one photo,
   there is no way to express "take one photo, in the next 30 seconds".
   The only unit of authority is "be the Camera app".
2. **Nothing to present.** Once Day 42's `SO_PEERCRED` check tells a
   service *which app* is calling, the service still has no token proving
   a specific grant — so every service re-consults the permission table
   and trusts it.

## The token

```rust
Capability {
    app_id, permission, issued_at, expires_at,
    epoch, delegations_left, tag,   // tag = HMAC-SHA256(issuer key, canonical bytes)[..16]
}
```

Verification recomputes the tag; it never trusts the fields. The order is
deliberate: **tag first**, then epoch, then expiry, then bearer. Checking
expiry before authenticity would mean answering a question about a field
not yet shown to be genuine.

The canonical bytes are length-prefixed per field. Without that,
`("org.nova.a", permission 5)` and `("org.nova.a5", permission 0)` could
serialise identically and one token would authenticate the other.

## Attenuation

`delegate` takes no argument that could widen anything. The child gets:
the same permission, an expiry no later than the parent's, and one fewer
delegation hop. A chain therefore terminates, and every step is weaker
than the one before it. The rules are enforced in code and asserted in
tests, not described in a comment.

## Known limitations

* **Symmetric.** The issuing key is in App Manager's memory. Anything
  that can read App Manager's memory can mint capabilities. True of any
  secret-key design; the mitigation is that the key never leaves.
* **Wall-clock expiry.** Moving the device clock backwards revives an
  expired capability. M15 owns time handling.
* **Revocation is all-or-nothing.** `revoke_all` bumps an epoch and
  invalidates everything outstanding. Per-token revocation would need a
  list consulted on every check; on a 1GB device (Section 21) that is an
  unbounded structure with no owner, and short expiries make it mostly
  unnecessary. Revisit if a real use case appears.
* **Bearer tokens.** A capability presented by the app it was issued to
  is valid; the `app_id` check means a stolen token is useless to
  another app, but anything running *inside* that app has it.

## Migration

M5's `SandboxPolicy::check` is unchanged and still the enforcement point
for ambient permissions. Capabilities are additive: they are used where a
narrower, time-bounded, delegable grant is actually needed, and nothing
in M5-M9 was rewritten to use them. Rewriting five apps' permission
handling on the last day of a security milestone would have been a poor
trade against the value of doing it deliberately in M14.
