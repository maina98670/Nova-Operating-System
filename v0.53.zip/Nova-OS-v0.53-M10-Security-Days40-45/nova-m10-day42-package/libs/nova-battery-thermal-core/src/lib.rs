#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BatteryInfo { pub percentage: u8, pub charging: bool, pub temperature_c: f32 }

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ThermalZone { pub id: u32, pub temperature_c: f32, pub critical_c: f32 }

#[derive(Debug, Default)]
pub struct BatteryThermalManager { battery: Option<BatteryInfo>, zones: Vec<ThermalZone> }

impl BatteryThermalManager {
    pub fn battery(&self) -> Option<BatteryInfo> { self.battery }
    pub fn set_battery(&mut self, info: BatteryInfo) { self.battery = Some(info); }
    pub fn add_zone(&mut self, zone: ThermalZone) { self.zones.push(zone); }
    pub fn zones(&self) -> &[ThermalZone] { &self.zones }
    pub fn thermal_warning(&self) -> bool { self.zones.iter().any(|z| z.temperature_c >= z.critical_c) }
}

#[cfg(test)] mod tests { use super::*; #[test] fn reports_hot_zone(){ let mut m=BatteryThermalManager::default(); m.add_zone(ThermalZone{id:1,temperature_c:90.0,critical_c:85.0}); assert!(m.thermal_warning()); }}
