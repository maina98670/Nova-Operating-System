#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PixelFormat { Rgb565, Rgba8888, Nv12 }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CameraMode { pub width: u32, pub height: u32, pub fps: u32, pub format: PixelFormat }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CaptureState { Closed, Open, Streaming }
#[derive(Debug)] pub struct CameraDevice { state: CaptureState, mode: Option<CameraMode> }
impl Default for CameraDevice { fn default()->Self{Self{state:CaptureState::Closed,mode:None}} }
impl CameraDevice { pub fn open(&mut self)->bool{if self.state==CaptureState::Closed{self.state=CaptureState::Open;true}else{false}} pub fn configure(&mut self,m:CameraMode)->bool{if self.state==CaptureState::Open{self.mode=Some(m);true}else{false}} pub fn start(&mut self)->bool{if self.state==CaptureState::Open && self.mode.is_some(){self.state=CaptureState::Streaming;true}else{false}} pub fn state(&self)->CaptureState{self.state} pub fn mode(&self)->Option<CameraMode>{self.mode} }
#[cfg(test)] mod tests {use super::*;#[test]fn lifecycle(){let mut c=CameraDevice::default();assert!(c.open());assert!(c.configure(CameraMode{width:640,height:480,fps:30,format:PixelFormat::Rgb565}));assert!(c.start());assert_eq!(c.state(),CaptureState::Streaming);}}
