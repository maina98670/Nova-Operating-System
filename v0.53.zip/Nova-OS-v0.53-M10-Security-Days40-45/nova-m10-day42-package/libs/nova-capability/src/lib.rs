//! Nova capabilities — M10 Day 42.
//!
//! Day 15's `PermissionSet` answers "may this app use the camera?" by
//! looking the app up in a table Nova owns. That is an *ambient
//! authority* model: authority comes from who you are, and any code
//! running as that app has all of it, all the time.
//!
//! Hardening on Day 41 exposed the gap the Day 42 row anticipates
//! ("refine M5's permission model into a proper capability system if
//! gaps were found during hardening"). Two concrete ones:
//!
//! 1. **No attenuation.** The Camera app holds `Permission::Camera` for
//!    its whole lifetime. When the Messages app asks it to take one
//!    photo, there is no way to hand over "take one photo, in the next
//!    30 seconds" — only "be the Camera app".
//! 2. **Nothing to present.** Once IPC endpoints are authenticated
//!    (see `nova-secure-ipc`), a service knows *which app* is calling.
//!    It still has no token the caller can present to prove a specific
//!    grant, so every service has to re-consult the permission table
//!    and trust it.
//!
//! A [`Capability`] closes both. It is a bearer token that names one
//! permission, for one app, until one expiry, tagged with HMAC-SHA256
//! under a key only the issuer holds. It can be attenuated on
//! delegation — never widened — and it is verified by recomputing the
//! tag, not by trusting the fields inside it.
//!
//! ## Honest scope
//!
//! * The issuing key is symmetric and lives in the issuer's memory. A
//!   process that can read App Manager's memory can mint capabilities;
//!   that is true of any secret-key design and is why the key never
//!   leaves the issuer.
//! * Expiry uses wall-clock time. A device whose clock is moved
//!   backwards can revive an expired capability. M15's time handling is
//!   where that gets addressed; it is recorded, not hidden.
//! * Revocation before expiry is by epoch bump ([`CapabilityIssuer::revoke_all`]),
//!   which invalidates every outstanding capability at once. Per-token
//!   revocation would need a list the issuer consults on every check —
//!   deliberately not built, because short expiries make it mostly
//!   unnecessary and an unbounded revocation list on a 1GB device is a
//!   cost with no owner.

use nova_crypto::{constant_time_eq, hmac_sha256, to_hex};
use nova_ipc::Permission;
use std::time::{SystemTime, UNIX_EPOCH};

pub const TAG_LEN: usize = 16;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Capability {
    pub app_id: String,
    pub permission: Permission,
    pub issued_at: u64,
    pub expires_at: u64,
    /// Bumped by the issuer to invalidate everything it has minted.
    pub epoch: u64,
    /// How many further delegations this capability permits. Every
    /// delegation decrements it, so a chain cannot grow without bound.
    pub delegations_left: u8,
    tag: [u8; TAG_LEN],
}

impl Capability {
    pub fn tag_hex(&self) -> String {
        to_hex(&self.tag)
    }

    /// The exact bytes the tag covers. Every field is length-prefixed
    /// or fixed-width: without that, `app_id` "org.nova.a" + permission
    /// 5 and `app_id` "org.nova.a5" + permission 0 could serialise
    /// identically and one token would authenticate the other. This is
    /// the canonicalisation bug that breaks real signature schemes, so
    /// it is written out rather than left to `format!`.
    fn signing_bytes(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(64 + self.app_id.len());
        out.extend_from_slice(b"nova-capability-v1");
        out.extend_from_slice(&(self.app_id.len() as u32).to_le_bytes());
        out.extend_from_slice(self.app_id.as_bytes());
        out.push(self.permission as u8);
        out.extend_from_slice(&self.issued_at.to_le_bytes());
        out.extend_from_slice(&self.expires_at.to_le_bytes());
        out.extend_from_slice(&self.epoch.to_le_bytes());
        out.push(self.delegations_left);
        out
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CapabilityError {
    /// The tag does not match — the token was forged or altered.
    BadTag,
    Expired { expires_at: u64, now: u64 },
    /// Minted under a previous epoch; the issuer has revoked.
    Revoked,
    /// The bearer is not the app the capability was issued to.
    WrongApp,
    /// Asked to delegate a permission the parent capability doesn't hold.
    Widening,
    /// The delegation budget is used up.
    DelegationExhausted,
    /// Asked for an expiry beyond the parent's.
    ExpiryExtension,
}

impl std::fmt::Display for CapabilityError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CapabilityError::BadTag => write!(f, "capability tag is invalid (forged or altered)"),
            CapabilityError::Expired { expires_at, now } => {
                write!(f, "capability expired at {expires_at} (now {now})")
            }
            CapabilityError::Revoked => write!(f, "capability was minted before the issuer's current epoch"),
            CapabilityError::WrongApp => write!(f, "capability was issued to a different app"),
            CapabilityError::Widening => write!(f, "a delegation cannot grant a permission the parent lacks"),
            CapabilityError::DelegationExhausted => write!(f, "this capability may not be delegated further"),
            CapabilityError::ExpiryExtension => write!(f, "a delegation cannot outlive its parent"),
        }
    }
}

impl std::error::Error for CapabilityError {}

fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

/// Mints and verifies capabilities. One of these lives inside App
/// Manager; its key never leaves the process.
pub struct CapabilityIssuer {
    key: Vec<u8>,
    epoch: u64,
}

impl CapabilityIssuer {
    /// `key` must be unpredictable. Nova's App Manager reads 32 bytes
    /// from `getrandom(2)` at startup; a fixed key here would make
    /// every capability forgeable by anyone who read the source, which
    /// is why there is no `Default` for this type.
    pub fn new(key: Vec<u8>) -> Self {
        CapabilityIssuer { key, epoch: 1 }
    }

    pub fn epoch(&self) -> u64 {
        self.epoch
    }

    /// Invalidates every capability minted so far. Used at app
    /// termination, at permission revocation from Settings, and at
    /// shutdown.
    pub fn revoke_all(&mut self) {
        self.epoch += 1;
    }

    fn tag_for(&self, cap: &Capability) -> [u8; TAG_LEN] {
        let full = hmac_sha256(&self.key, &cap.signing_bytes());
        let mut tag = [0u8; TAG_LEN];
        tag.copy_from_slice(&full[..TAG_LEN]);
        tag
    }

    pub fn issue(&self, app_id: &str, permission: Permission, ttl_secs: u64) -> Capability {
        self.issue_at(app_id, permission, ttl_secs, now_secs())
    }

    /// Time is a parameter so the tests below can exercise expiry
    /// without sleeping. Production callers use [`CapabilityIssuer::issue`].
    pub fn issue_at(&self, app_id: &str, permission: Permission, ttl_secs: u64, now: u64) -> Capability {
        let mut cap = Capability {
            app_id: app_id.to_string(),
            permission,
            issued_at: now,
            expires_at: now.saturating_add(ttl_secs),
            epoch: self.epoch,
            delegations_left: 1,
            tag: [0u8; TAG_LEN],
        };
        cap.tag = self.tag_for(&cap);
        cap
    }

    pub fn verify(&self, cap: &Capability, bearer_app_id: &str) -> Result<(), CapabilityError> {
        self.verify_at(cap, bearer_app_id, now_secs())
    }

    /// Order matters: the tag is checked **first**. Checking expiry or
    /// app id before authenticity would answer questions about fields
    /// that have not yet been shown to be genuine.
    pub fn verify_at(&self, cap: &Capability, bearer_app_id: &str, now: u64) -> Result<(), CapabilityError> {
        let expected = self.tag_for(cap);
        if !constant_time_eq(&expected, &cap.tag) {
            return Err(CapabilityError::BadTag);
        }
        if cap.epoch != self.epoch {
            return Err(CapabilityError::Revoked);
        }
        if now >= cap.expires_at {
            return Err(CapabilityError::Expired { expires_at: cap.expires_at, now });
        }
        if cap.app_id != bearer_app_id {
            return Err(CapabilityError::WrongApp);
        }
        Ok(())
    }

    /// Hands a narrower capability to another app.
    ///
    /// Attenuation only: same permission, an expiry no later than the
    /// parent's, and one less delegation left. There is deliberately no
    /// argument that could widen anything — the type system, not a
    /// runtime check, is what prevents "delegate camera *and* mic".
    pub fn delegate(
        &self,
        parent: &Capability,
        parent_holder: &str,
        to_app_id: &str,
        ttl_secs: u64,
    ) -> Result<Capability, CapabilityError> {
        self.delegate_at(parent, parent_holder, to_app_id, ttl_secs, now_secs())
    }

    pub fn delegate_at(
        &self,
        parent: &Capability,
        parent_holder: &str,
        to_app_id: &str,
        ttl_secs: u64,
        now: u64,
    ) -> Result<Capability, CapabilityError> {
        self.verify_at(parent, parent_holder, now)?;
        if parent.delegations_left == 0 {
            return Err(CapabilityError::DelegationExhausted);
        }
        let expires_at = now.saturating_add(ttl_secs);
        if expires_at > parent.expires_at {
            return Err(CapabilityError::ExpiryExtension);
        }
        let mut child = Capability {
            app_id: to_app_id.to_string(),
            permission: parent.permission,
            issued_at: now,
            expires_at,
            epoch: self.epoch,
            delegations_left: parent.delegations_left - 1,
            tag: [0u8; TAG_LEN],
        };
        child.tag = self.tag_for(&child);
        Ok(child)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn issuer() -> CapabilityIssuer {
        CapabilityIssuer::new(b"test-key-not-a-real-one-0123456789".to_vec())
    }

    #[test]
    fn a_valid_capability_verifies() {
        let iss = issuer();
        let cap = iss.issue_at("org.nova.camera", Permission::Camera, 60, 1000);
        assert_eq!(iss.verify_at(&cap, "org.nova.camera", 1030), Ok(()));
    }

    #[test]
    fn every_mutated_field_breaks_the_tag() {
        let iss = issuer();
        let cap = iss.issue_at("org.nova.camera", Permission::Camera, 60, 1000);

        let mut widened = cap.clone();
        widened.permission = Permission::Microphone;
        assert_eq!(iss.verify_at(&widened, "org.nova.camera", 1030), Err(CapabilityError::BadTag));

        let mut extended = cap.clone();
        extended.expires_at = 99_999;
        assert_eq!(iss.verify_at(&extended, "org.nova.camera", 1030), Err(CapabilityError::BadTag));

        let mut stolen = cap.clone();
        stolen.app_id = "org.nova.evil".to_string();
        assert_eq!(iss.verify_at(&stolen, "org.nova.evil", 1030), Err(CapabilityError::BadTag));

        let mut budget = cap.clone();
        budget.delegations_left = 200;
        assert_eq!(iss.verify_at(&budget, "org.nova.camera", 1030), Err(CapabilityError::BadTag));
    }

    #[test]
    fn a_capability_from_another_issuer_is_worthless() {
        let mine = issuer();
        let theirs = CapabilityIssuer::new(b"a completely different key".to_vec());
        let forged = theirs.issue_at("org.nova.camera", Permission::Camera, 60, 1000);
        assert_eq!(mine.verify_at(&forged, "org.nova.camera", 1030), Err(CapabilityError::BadTag));
    }

    #[test]
    fn expiry_is_enforced() {
        let iss = issuer();
        let cap = iss.issue_at("org.nova.camera", Permission::Camera, 30, 1000);
        assert!(iss.verify_at(&cap, "org.nova.camera", 1029).is_ok());
        assert_eq!(
            iss.verify_at(&cap, "org.nova.camera", 1030),
            Err(CapabilityError::Expired { expires_at: 1030, now: 1030 })
        );
    }

    #[test]
    fn a_genuine_capability_presented_by_the_wrong_app_is_refused() {
        let iss = issuer();
        let cap = iss.issue_at("org.nova.camera", Permission::Camera, 60, 1000);
        assert_eq!(iss.verify_at(&cap, "org.nova.messages", 1030), Err(CapabilityError::WrongApp));
    }

    #[test]
    fn revoke_all_invalidates_outstanding_capabilities() {
        let mut iss = issuer();
        let cap = iss.issue_at("org.nova.camera", Permission::Camera, 600, 1000);
        assert!(iss.verify_at(&cap, "org.nova.camera", 1030).is_ok());
        iss.revoke_all();
        assert_eq!(iss.verify_at(&cap, "org.nova.camera", 1030), Err(CapabilityError::Revoked));
    }

    /// The attenuation property, stated as a test rather than as a
    /// comment: a delegated capability is strictly weaker.
    #[test]
    fn delegation_attenuates_and_never_widens() {
        let iss = issuer();
        let parent = iss.issue_at("org.nova.camera", Permission::Camera, 600, 1000);

        let child = iss.delegate_at(&parent, "org.nova.camera", "org.nova.messages", 30, 1000).unwrap();
        assert_eq!(child.permission, parent.permission);
        assert!(child.expires_at <= parent.expires_at);
        assert_eq!(child.delegations_left, parent.delegations_left - 1);
        assert!(iss.verify_at(&child, "org.nova.messages", 1010).is_ok());

        // The child cannot outlive the parent...
        assert_eq!(
            iss.delegate_at(&parent, "org.nova.camera", "org.nova.messages", 9_000, 1000),
            Err(CapabilityError::ExpiryExtension)
        );
        // ...and the chain terminates.
        assert_eq!(
            iss.delegate_at(&child, "org.nova.messages", "org.nova.evil", 10, 1000),
            Err(CapabilityError::DelegationExhausted)
        );
    }

    #[test]
    fn delegation_requires_actually_holding_the_parent() {
        let iss = issuer();
        let parent = iss.issue_at("org.nova.camera", Permission::Camera, 600, 1000);
        assert_eq!(
            iss.delegate_at(&parent, "org.nova.evil", "org.nova.evil", 10, 1000),
            Err(CapabilityError::WrongApp)
        );
    }

    /// The canonicalisation check: two different (app_id, permission)
    /// pairs must never produce the same signed bytes.
    #[test]
    fn field_boundaries_are_unambiguous() {
        let iss = issuer();
        let a = iss.issue_at("org.nova.a", Permission::Microphone, 60, 1000);
        let b = iss.issue_at("org.nova.a\u{0}", Permission::Microphone, 60, 1000);
        assert_ne!(a.tag_hex(), b.tag_hex());

        // Tag a's bytes must not authenticate b's content.
        let mut spliced = b.clone();
        spliced.app_id = a.app_id.clone();
        assert!(iss.verify_at(&spliced, &a.app_id, 1010).is_err());
    }
}
