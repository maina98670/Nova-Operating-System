#[derive(Clone, Debug, PartialEq, Eq)]
pub struct UsbDevice { pub vendor_id: u16, pub product_id: u16, pub name: String }
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct BluetoothDevice { pub address: String, pub name: String, pub connected: bool }

#[derive(Debug, Default)] pub struct ConnectivityRegistry { usb: Vec<UsbDevice>, bluetooth: Vec<BluetoothDevice> }
impl ConnectivityRegistry {
 pub fn add_usb(&mut self,d:UsbDevice){self.usb.push(d)} pub fn add_bluetooth(&mut self,d:BluetoothDevice){self.bluetooth.push(d)}
 pub fn usb(&self)->&[UsbDevice]{&self.usb} pub fn bluetooth(&self)->&[BluetoothDevice]{&self.bluetooth}
}

#[cfg(test)] mod tests { use super::*; #[test] fn registers_devices(){let mut r=ConnectivityRegistry::default();r.add_usb(UsbDevice{vendor_id:1,product_id:2,name:"test".into()});assert_eq!(r.usb().len(),1);}}
