//! Nova's minimal cryptographic primitives — M10 Day 42.
//!
//! SHA-256 (FIPS 180-4) and HMAC-SHA256 (RFC 2104), implemented here
//! with no external dependency, and a constant-time comparison to use
//! them safely.
//!
//! ## Why hand-rolled, and where that stops being acceptable
//!
//! Every other format in this project that could have pulled in a
//! dependency didn't — `.npkg` isn't tar, the log isn't JSON, the
//! identity table isn't sqlite — because the actual need was small and
//! a dependency is a permanent cost. SHA-256 and HMAC are in the same
//! category: both are short, both are fully specified, and both have
//! published test vectors that make "is this correct?" an answerable
//! question rather than a matter of trust. The vectors from FIPS 180-4
//! and RFC 4231 are in the test module below, and they are the reason
//! to believe this code.
//!
//! That reasoning does **not** extend to public-key cryptography.
//! Nothing in this crate implements a signature scheme with a
//! public/private keypair, and Day 43 says plainly what that costs:
//! Nova's package signing is symmetric, which proves integrity and
//! proves the signer held the key, but cannot prove publisher identity
//! to a third party. M11's package repository needs that property, and
//! the right way to get it is a reviewed, constant-time Ed25519
//! implementation — not three hundred more lines of hand-written field
//! arithmetic in this file. Recorded in `docs/security-model-v1.md` as
//! a named limitation with an owner, not discovered later.
//!
//! ## Side channels
//!
//! [`constant_time_eq`] is genuinely constant-time with respect to the
//! *contents* of equal-length inputs. SHA-256 and HMAC here are not
//! hardened against timing analysis of the key beyond that; on the
//! single-user phone Nova targets, the attacker model for a local
//! timing attack on the package-verification key is weak, but this is
//! stated rather than assumed.

// --- SHA-256 ---------------------------------------------------------

const H0: [u32; 8] =
    [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];

const K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98,
    0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
    0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8,
    0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
    0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
    0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7,
    0xc67178f2,
];

pub const DIGEST_LEN: usize = 32;
pub const BLOCK_LEN: usize = 64;

pub type Digest = [u8; DIGEST_LEN];

/// Streaming SHA-256. Streaming rather than one-shot because a package
/// is hashed in pieces (header, then manifest, then binary) and buffering
/// a whole app binary in memory to hash it would be a poor fit for a
/// 1GB device — Section 21's constraint reaching even here.
#[derive(Clone)]
pub struct Sha256 {
    state: [u32; 8],
    buffer: [u8; BLOCK_LEN],
    buffered: usize,
    total_len: u64,
}

impl Default for Sha256 {
    fn default() -> Self {
        Self::new()
    }
}

impl Sha256 {
    pub fn new() -> Self {
        Sha256 { state: H0, buffer: [0u8; BLOCK_LEN], buffered: 0, total_len: 0 }
    }

    pub fn update(&mut self, mut data: &[u8]) {
        self.total_len = self.total_len.wrapping_add(data.len() as u64);

        if self.buffered > 0 {
            let need = BLOCK_LEN - self.buffered;
            let take = need.min(data.len());
            self.buffer[self.buffered..self.buffered + take].copy_from_slice(&data[..take]);
            self.buffered += take;
            data = &data[take..];
            if self.buffered == BLOCK_LEN {
                let block = self.buffer;
                self.compress(&block);
                self.buffered = 0;
            }
        }

        while data.len() >= BLOCK_LEN {
            let (block, rest) = data.split_at(BLOCK_LEN);
            let mut b = [0u8; BLOCK_LEN];
            b.copy_from_slice(block);
            self.compress(&b);
            data = rest;
        }

        if !data.is_empty() {
            self.buffer[..data.len()].copy_from_slice(data);
            self.buffered = data.len();
        }
    }

    pub fn finalize(mut self) -> Digest {
        let bit_len = self.total_len.wrapping_mul(8);

        // Padding: 0x80, then zeros, then the 64-bit big-endian length.
        self.append_padding_byte();
        while self.buffered != BLOCK_LEN - 8 {
            self.append_zero();
        }
        let len_bytes = bit_len.to_be_bytes();
        self.buffer[BLOCK_LEN - 8..].copy_from_slice(&len_bytes);
        let block = self.buffer;
        self.compress(&block);

        let mut out = [0u8; DIGEST_LEN];
        for (i, word) in self.state.iter().enumerate() {
            out[i * 4..i * 4 + 4].copy_from_slice(&word.to_be_bytes());
        }
        out
    }

    fn append_padding_byte(&mut self) {
        self.buffer[self.buffered] = 0x80;
        self.buffered += 1;
        if self.buffered == BLOCK_LEN {
            let block = self.buffer;
            self.compress(&block);
            self.buffered = 0;
        }
    }

    fn append_zero(&mut self) {
        self.buffer[self.buffered] = 0;
        self.buffered += 1;
        if self.buffered == BLOCK_LEN {
            let block = self.buffer;
            self.compress(&block);
            self.buffered = 0;
        }
    }

    fn compress(&mut self, block: &[u8; BLOCK_LEN]) {
        let mut w = [0u32; 64];
        for i in 0..16 {
            w[i] = u32::from_be_bytes([block[i * 4], block[i * 4 + 1], block[i * 4 + 2], block[i * 4 + 3]]);
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16].wrapping_add(s0).wrapping_add(w[i - 7]).wrapping_add(s1);
        }

        let [mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut h] = self.state;

        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let temp1 = h.wrapping_add(s1).wrapping_add(ch).wrapping_add(K[i]).wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let temp2 = s0.wrapping_add(maj);

            h = g;
            g = f;
            f = e;
            e = d.wrapping_add(temp1);
            d = c;
            c = b;
            b = a;
            a = temp1.wrapping_add(temp2);
        }

        self.state[0] = self.state[0].wrapping_add(a);
        self.state[1] = self.state[1].wrapping_add(b);
        self.state[2] = self.state[2].wrapping_add(c);
        self.state[3] = self.state[3].wrapping_add(d);
        self.state[4] = self.state[4].wrapping_add(e);
        self.state[5] = self.state[5].wrapping_add(f);
        self.state[6] = self.state[6].wrapping_add(g);
        self.state[7] = self.state[7].wrapping_add(h);
    }
}

pub fn sha256(data: &[u8]) -> Digest {
    let mut h = Sha256::new();
    h.update(data);
    h.finalize()
}

// --- HMAC-SHA256 -----------------------------------------------------

/// HMAC-SHA256 per RFC 2104. Keys longer than the block size are
/// hashed first; shorter keys are zero-padded — both are the spec's
/// behaviour, not a convenience, and getting either wrong produces a
/// function that still "works" while being wrong, which is why RFC
/// 4231's vectors are tested below rather than just the easy case.
pub fn hmac_sha256(key: &[u8], message: &[u8]) -> Digest {
    let mut block = [0u8; BLOCK_LEN];
    if key.len() > BLOCK_LEN {
        let hashed = sha256(key);
        block[..DIGEST_LEN].copy_from_slice(&hashed);
    } else {
        block[..key.len()].copy_from_slice(key);
    }

    let mut ipad = [0u8; BLOCK_LEN];
    let mut opad = [0u8; BLOCK_LEN];
    for i in 0..BLOCK_LEN {
        ipad[i] = block[i] ^ 0x36;
        opad[i] = block[i] ^ 0x5c;
    }

    let mut inner = Sha256::new();
    inner.update(&ipad);
    inner.update(message);
    let inner_digest = inner.finalize();

    let mut outer = Sha256::new();
    outer.update(&opad);
    outer.update(&inner_digest);
    outer.finalize()
}

/// Compares two byte slices without an early return on the first
/// differing byte.
///
/// A naive `==` leaks, through timing, how many leading bytes of a
/// candidate tag were correct, which turns forging a tag from a
/// 2^256 problem into a 32-step one. This is the single most commonly
/// skipped line in hand-written verification code, so it is a named
/// function here and every comparison of a tag or digest in this
/// project goes through it.
pub fn constant_time_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff: u8 = 0;
    for i in 0..a.len() {
        diff |= a[i] ^ b[i];
    }
    diff == 0
}

pub fn to_hex(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push(char::from_digit((b >> 4) as u32, 16).unwrap());
        s.push(char::from_digit((b & 0x0f) as u32, 16).unwrap());
    }
    s
}

pub fn from_hex(s: &str) -> Option<Vec<u8>> {
    if s.len() % 2 != 0 {
        return None;
    }
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(s.len() / 2);
    let mut i = 0;
    while i < bytes.len() {
        let hi = (bytes[i] as char).to_digit(16)?;
        let lo = (bytes[i + 1] as char).to_digit(16)?;
        out.push(((hi << 4) | lo) as u8);
        i += 2;
    }
    Some(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// FIPS 180-4 / NIST CAVP known-answer tests.
    #[test]
    fn sha256_known_answers() {
        assert_eq!(to_hex(&sha256(b"")), "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
        assert_eq!(to_hex(&sha256(b"abc")), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
        assert_eq!(
            to_hex(&sha256(b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq")),
            "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"
        );
    }

    /// One million 'a's — the classic vector, and the only one that
    /// exercises the multi-block streaming path hard enough to catch a
    /// buffer-boundary bug.
    #[test]
    fn sha256_one_million_a() {
        let mut h = Sha256::new();
        let chunk = vec![b'a'; 1000];
        for _ in 0..1000 {
            h.update(&chunk);
        }
        assert_eq!(to_hex(&h.finalize()), "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
    }

    /// The padding edge cases: a message that ends exactly where the
    /// length field needs to go (55 bytes fits, 56 forces a second
    /// block). Off-by-one here is the classic SHA implementation bug.
    #[test]
    fn sha256_padding_boundaries() {
        for len in [54usize, 55, 56, 57, 63, 64, 65, 119, 120] {
            let msg = vec![b'x'; len];
            // Streamed one byte at a time must equal the one-shot.
            let mut streamed = Sha256::new();
            for b in &msg {
                streamed.update(&[*b]);
            }
            assert_eq!(streamed.finalize(), sha256(&msg), "length {len} disagrees between streamed and one-shot");
        }
    }

    #[test]
    fn sha256_chunking_is_irrelevant_to_the_result() {
        let msg: Vec<u8> = (0..500u32).map(|i| (i % 251) as u8).collect();
        let one_shot = sha256(&msg);
        for chunk in [1usize, 3, 7, 31, 63, 64, 65, 128] {
            let mut h = Sha256::new();
            for piece in msg.chunks(chunk) {
                h.update(piece);
            }
            assert_eq!(h.finalize(), one_shot, "chunk size {chunk} changed the digest");
        }
    }

    /// RFC 4231 test cases 1 and 2.
    #[test]
    fn hmac_sha256_known_answers() {
        let key = [0x0bu8; 20];
        assert_eq!(
            to_hex(&hmac_sha256(&key, b"Hi There")),
            "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7"
        );

        assert_eq!(
            to_hex(&hmac_sha256(b"Jefe", b"what do ya want for nothing?")),
            "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843"
        );
    }

    /// RFC 4231 test case 6: a key longer than the block size, which
    /// must be hashed down first.
    #[test]
    fn hmac_sha256_oversized_key_is_hashed_first() {
        let key = [0xaau8; 131];
        assert_eq!(
            to_hex(&hmac_sha256(&key, b"Test Using Larger Than Block-Size Key - Hash Key First")),
            "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54"
        );
    }

    #[test]
    fn hmac_changes_completely_with_the_key() {
        let a = hmac_sha256(b"key-one", b"same message");
        let b = hmac_sha256(b"key-two", b"same message");
        assert_ne!(a, b);
        // And with the message.
        assert_ne!(hmac_sha256(b"key-one", b"message a"), hmac_sha256(b"key-one", b"message b"));
    }

    #[test]
    fn constant_time_eq_still_compares_correctly() {
        assert!(constant_time_eq(b"abcdef", b"abcdef"));
        assert!(!constant_time_eq(b"abcdef", b"abcdeg"));
        assert!(!constant_time_eq(b"abcdef", b"abcde"));
        assert!(constant_time_eq(b"", b""));
    }

    #[test]
    fn hex_round_trips() {
        let d = sha256(b"round trip");
        assert_eq!(from_hex(&to_hex(&d)).unwrap(), d.to_vec());
        assert!(from_hex("abc").is_none());
        assert!(from_hex("zz").is_none());
    }
}
