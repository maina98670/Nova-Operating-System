#[derive(Clone, Debug, PartialEq, Eq)]
pub enum DeviceClass { Display, Touch, Audio, Network, Storage, Power, Battery, Sensor, Usb, Bluetooth, Camera, Other }
#[derive(Clone, Debug, PartialEq, Eq)] pub struct DeviceRecord { pub id:String, pub class:DeviceClass, pub ready:bool }
#[derive(Debug,Default)] pub struct DeviceRegistry { devices:Vec<DeviceRecord> }
impl DeviceRegistry { pub fn register(&mut self,d:DeviceRecord){self.devices.push(d)} pub fn devices(&self)->&[DeviceRecord]{&self.devices} pub fn ready_count(&self)->usize{self.devices.iter().filter(|d|d.ready).count()} pub fn find(&self,id:&str)->Option<&DeviceRecord>{self.devices.iter().find(|d|d.id==id)} }
#[cfg(test)] mod tests {use super::*;#[test]fn counts_ready(){let mut r=DeviceRegistry::default();r.register(DeviceRecord{id:"battery0".into(),class:DeviceClass::Battery,ready:true});r.register(DeviceRecord{id:"cam0".into(),class:DeviceClass::Camera,ready:false});assert_eq!(r.ready_count(),1);}}
