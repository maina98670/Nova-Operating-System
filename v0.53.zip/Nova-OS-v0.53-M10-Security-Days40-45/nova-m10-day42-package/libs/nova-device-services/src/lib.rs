pub use nova_battery_thermal_core::{BatteryInfo, BatteryThermalManager, ThermalZone};
pub use nova_connectivity_hal::{BluetoothDevice, ConnectivityRegistry, UsbDevice};
pub use nova_power_core::{PowerManager, PowerProfile, PowerState, WakeSource};
pub use nova_sensor_hal::{Sensor, SensorKind, SensorSample, StaticSensor};
pub use nova_camera_hal::{CameraDevice, CameraMode, CaptureState, PixelFormat};

#[derive(Debug, Default)] pub struct HardwareServices { pub power: PowerManager, pub battery: BatteryThermalManager, pub connectivity: ConnectivityRegistry, pub camera: CameraDevice }
impl HardwareServices { pub fn readiness(&self)->bool { self.camera.state()!=CaptureState::Streaming || self.camera.mode().is_some() } }
#[cfg(test)] mod tests {use super::*;#[test]fn services_boot(){let s=HardwareServices::default();assert!(s.readiness());}}
