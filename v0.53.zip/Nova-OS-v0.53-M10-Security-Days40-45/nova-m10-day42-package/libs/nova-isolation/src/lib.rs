//! Nova sandbox hardening — M10 Day 41.
//!
//! Day 15's `nova-sandbox` enforces permissions *inside Nova's own
//! code*: an app that asks the platform for the camera without
//! declaring it gets refused. That is a real boundary for a
//! well-behaved app and no boundary at all for a hostile one, because
//! nothing stops a process from ignoring `nova-sandbox` and calling
//! `open("/dev/video0")` itself. Day 15's own module doc says exactly
//! this and points at M10. This crate is that promise being kept.
//!
//! The move is from *policy* to *enforcement by something the app
//! cannot talk its way past*: the Linux kernel.
//!
//! Three mechanisms, each closing one of the three escapes the Day 41
//! Definition of Done names:
//!
//! | DoD escape                          | Mechanism                                    |
//! |-------------------------------------|----------------------------------------------|
//! | access another app's data           | mount namespace + Day 40's per-app uid        |
//! | spawn processes outside its set     | seccomp filter (no `execve`/`fork` by default) + PID namespace |
//! | make unauthorized network calls     | network namespace, unless `Permission::Network` is granted |
//!
//! ## The privilege problem, stated plainly
//!
//! `unshare(2)` for mount/PID/network namespaces normally requires
//! `CAP_SYS_ADMIN`. Nova's App Manager runs as a system service and
//! will have it; a developer running `cargo test` on a laptop will
//! not. Rather than silently degrading to "isolation requested but not
//! applied" — which is the single most dangerous thing a sandbox can
//! do — this crate:
//!
//! * always reports what it actually achieved, via [`AppliedIsolation`];
//! * offers [`IsolationSpec::with_user_namespace`], which asks for a
//!   user namespace first. On a kernel with unprivileged user
//!   namespaces enabled (the default on most current distributions),
//!   that grants the capabilities needed for the other namespaces
//!   inside it, so the full sandbox really can be applied by an
//!   unprivileged developer shell;
//! * fails the spawn outright, rather than running the child
//!   unisolated, when a requested namespace cannot be entered.
//!
//! ## What is not claimed
//!
//! A seccomp allowlist and five namespaces are a serious boundary, not
//! a proof. Kernel bugs, a too-generous allowlist, and anything reached
//! through a file descriptor passed *into* the sandbox all remain real.
//! Day 45 audits the allowlist; `docs/security-model-v1.md` records the
//! residual risk rather than implying there isn't any.

use nova_identity::Identity;
use nova_ipc::Permission;
use nova_sandbox::SandboxPolicy;
use std::io;

#[cfg(target_os = "linux")]
use std::os::unix::process::CommandExt;
use std::process::{Child, Command};

// --- seccomp-bpf, hand-assembled -------------------------------------
//
// These constants are part of the kernel ABI, not of any crate, so they
// are written out here rather than depending on a seccomp helper crate
// (Section 16's "no external dependency where the actual need is this
// small" pattern, same reasoning as `.npkg` not being a tar file).

const BPF_LD: u16 = 0x00;
const BPF_W: u16 = 0x00;
const BPF_ABS: u16 = 0x20;
const BPF_JMP: u16 = 0x05;
const BPF_JEQ: u16 = 0x10;
const BPF_K: u16 = 0x00;
const BPF_RET: u16 = 0x06;

const SECCOMP_RET_KILL_PROCESS: u32 = 0x8000_0000;
const SECCOMP_RET_ERRNO: u32 = 0x0005_0000;
const SECCOMP_RET_ALLOW: u32 = 0x7fff_0000;

const SECCOMP_SET_MODE_FILTER: u32 = 1;

/// `offsetof(struct seccomp_data, nr)` and `.arch` — fixed by the ABI.
const SECCOMP_DATA_NR_OFFSET: u32 = 0;
const SECCOMP_DATA_ARCH_OFFSET: u32 = 4;

const AUDIT_ARCH_AARCH64: u32 = 0xc000_00b7;
const AUDIT_ARCH_X86_64: u32 = 0xc000_003e;

/// The architecture the filter is compiled for.
///
/// This matters more than it looks: a seccomp filter that doesn't check
/// `arch` can be bypassed on a multi-ABI kernel by making the same call
/// through a different ABI, where the syscall *numbers* mean something
/// else entirely. The filter below always checks it first.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Arch {
    /// Nova's real target (Section 13's ARM64 reference device).
    Aarch64,
    /// Development hosts. Supported so the filter is testable before
    /// M12's hardware exists, not because Nova ships on it.
    X86_64,
}

impl Arch {
    pub fn host() -> Option<Arch> {
        match std::env::consts::ARCH {
            "aarch64" => Some(Arch::Aarch64),
            "x86_64" => Some(Arch::X86_64),
            _ => None,
        }
    }

    fn audit_value(self) -> u32 {
        match self {
            Arch::Aarch64 => AUDIT_ARCH_AARCH64,
            Arch::X86_64 => AUDIT_ARCH_X86_64,
        }
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct SockFilter {
    pub code: u16,
    pub jt: u8,
    pub jf: u8,
    pub k: u32,
}

#[repr(C)]
struct SockFprog {
    len: u16,
    filter: *const SockFilter,
}

#[derive(Debug)]
pub enum IsolationError {
    /// More syscalls in the allowlist than a classic-BPF jump offset
    /// (one byte) can reach.
    AllowlistTooLarge(usize),
    UnsupportedArch(&'static str),
    /// A namespace was requested and could not be entered. Deliberately
    /// fatal — see the module doc.
    NamespaceDenied { which: &'static str, source: io::Error },
    SeccompFailed(io::Error),
    Spawn(io::Error),
    NotLinux,
}

impl std::fmt::Display for IsolationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IsolationError::AllowlistTooLarge(n) => {
                write!(f, "seccomp allowlist has {n} entries; classic BPF jumps reach at most 252")
            }
            IsolationError::UnsupportedArch(a) => write!(f, "no seccomp arch constant for {a}"),
            IsolationError::NamespaceDenied { which, source } => {
                write!(f, "could not enter {which} namespace: {source} (the child was NOT started unisolated)")
            }
            IsolationError::SeccompFailed(e) => write!(f, "seccomp filter install failed: {e}"),
            IsolationError::Spawn(e) => write!(f, "spawn failed: {e}"),
            IsolationError::NotLinux => write!(f, "namespace/seccomp isolation is Linux-only"),
        }
    }
}

impl std::error::Error for IsolationError {}

/// The syscalls a Nova app may make.
///
/// Deliberately an allowlist, not a denylist: a denylist is wrong by
/// default every time the kernel gains a syscall, and the kernel gains
/// syscalls regularly.
///
/// Note what is *absent* and why: `execve`/`execveat` (an app may not
/// launch arbitrary programs — App Manager launches apps, apps don't),
/// `clone`/`fork`/`vfork` (no spawning outside its permission set —
/// this is the DoD's second escape, closed at the syscall level rather
/// than by hoping), `mount`, `ptrace`, `setuid`/`setgid`, `bpf`,
/// `kexec_load`, `init_module`. `socket` is included only when the app
/// holds `Permission::Network`.
#[derive(Debug, Clone)]
pub struct SeccompPolicy {
    allowed: Vec<i64>,
    arch: Arch,
    /// What happens to a syscall that isn't allowed. `Errno(EPERM)` is
    /// the default because a hard kill makes an app's misbehaviour
    /// indistinguishable from a crash in the logs; Day 44 wants the
    /// difference to be visible.
    pub violation: ViolationAction,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ViolationAction {
    /// Return `EPERM` to the caller. The app sees a failure it could
    /// legitimately have got anyway, and Nova sees a logged violation.
    Errno,
    /// Kill the whole process. Used for the syscalls that have no
    /// innocent explanation.
    KillProcess,
}

#[cfg(target_os = "linux")]
fn base_allowlist(network: bool) -> Vec<i64> {
    // `libc::SYS_*` resolves to the correct number for the target
    // architecture, so this list is written once and is right on both
    // aarch64 and x86_64 — which is exactly why the numbers are not
    // hardcoded here.
    let mut v = vec![
        libc::SYS_read,
        libc::SYS_write,
        libc::SYS_close,
        libc::SYS_openat,
        libc::SYS_lseek,
        libc::SYS_fstat,
        libc::SYS_newfstatat,
        libc::SYS_mmap,
        libc::SYS_munmap,
        libc::SYS_mprotect,
        libc::SYS_brk,
        libc::SYS_rt_sigaction,
        libc::SYS_rt_sigprocmask,
        libc::SYS_rt_sigreturn,
        libc::SYS_clock_gettime,
        libc::SYS_clock_nanosleep,
        libc::SYS_getpid,
        libc::SYS_getuid,
        libc::SYS_getgid,
        libc::SYS_geteuid,
        libc::SYS_getegid,
        libc::SYS_exit,
        libc::SYS_exit_group,
        libc::SYS_futex,
        libc::SYS_sched_yield,
        libc::SYS_madvise,
        libc::SYS_ppoll,
        libc::SYS_readv,
        libc::SYS_writev,
        libc::SYS_pread64,
        libc::SYS_pwrite64,
        libc::SYS_fsync,
        libc::SYS_ftruncate,
        libc::SYS_mkdirat,
        libc::SYS_unlinkat,
        libc::SYS_renameat,
        libc::SYS_getdents64,
        libc::SYS_fcntl,
        libc::SYS_ioctl,
        libc::SYS_getrandom,
        libc::SYS_uname,
        libc::SYS_set_tid_address,
        libc::SYS_prlimit64,
        libc::SYS_sigaltstack,
        libc::SYS_gettid,
        libc::SYS_tgkill,
        // The app's control channel to App Manager is a socket it
        // *inherits* already connected (Day 11's `SOCK_SEQPACKET`
        // protocol), so it needs to send and receive on an existing fd
        // without ever creating one.
        libc::SYS_sendto,
        libc::SYS_recvfrom,
        libc::SYS_sendmsg,
        libc::SYS_recvmsg,
        libc::SYS_shutdown,
        libc::SYS_getsockopt,
        libc::SYS_setsockopt,
    ];
    if network {
        // Creating and connecting sockets of its own — only with the
        // permission. Note this is belt-and-braces with the network
        // namespace: with `Permission::Network` absent, the app both
        // cannot create a socket *and* has no route if it somehow did.
        v.extend_from_slice(&[libc::SYS_socket, libc::SYS_connect, libc::SYS_bind, libc::SYS_listen, libc::SYS_accept4]);
    }
    v.sort_unstable();
    v.dedup();
    v
}

#[cfg(not(target_os = "linux"))]
fn base_allowlist(_network: bool) -> Vec<i64> {
    Vec::new()
}

impl SeccompPolicy {
    /// Derives the allowlist from a Day 15 `SandboxPolicy` — the
    /// manifest an app already declares is the single source of truth
    /// for what it may do, at both the Nova level and the kernel level.
    /// Two policies that could drift apart is exactly the bug class
    /// Day 14 refused to introduce for manifests.
    pub fn from_policy(policy: &SandboxPolicy, arch: Arch) -> Self {
        let network = policy.check(Permission::Network).is_ok();
        SeccompPolicy { allowed: base_allowlist(network), arch, violation: ViolationAction::Errno }
    }

    pub fn allowed(&self) -> &[i64] {
        &self.allowed
    }

    pub fn allows(&self, syscall: i64) -> bool {
        self.allowed.contains(&syscall)
    }

    /// Compiles the allowlist to a classic-BPF program.
    ///
    /// Layout (indices are absolute; classic BPF jumps are relative to
    /// the *next* instruction, which is what the arithmetic below is
    /// accounting for):
    ///
    /// ```text
    ///   0            LD   seccomp_data.arch
    ///   1            JEQ  <arch>          jt=0  jf=-> KILL
    ///   2            LD   seccomp_data.nr
    ///   3 .. 2+N     JEQ  <syscall_i>     jt=-> ALLOW  jf=fall through
    ///   3+N          RET  <violation>     (DENY)
    ///   4+N          RET  SECCOMP_RET_ALLOW
    ///   5+N          RET  SECCOMP_RET_KILL_PROCESS  (wrong arch)
    /// ```
    ///
    /// DENY sits *before* ALLOW so the last comparison's fall-through
    /// lands on the denial, not on the allow — an off-by-one here would
    /// silently permit every syscall, which is why the round-trip is
    /// unit-tested below rather than eyeballed.
    pub fn compile(&self) -> Result<Vec<SockFilter>, IsolationError> {
        let n = self.allowed.len();
        if n > 252 {
            return Err(IsolationError::AllowlistTooLarge(n));
        }
        let n_u8 = n as u8;

        let deny = match self.violation {
            ViolationAction::Errno => SECCOMP_RET_ERRNO | (libc::EPERM as u32 & 0xffff),
            ViolationAction::KillProcess => SECCOMP_RET_KILL_PROCESS,
        };

        let mut prog: Vec<SockFilter> = Vec::with_capacity(n + 6);
        prog.push(SockFilter { code: BPF_LD | BPF_W | BPF_ABS, jt: 0, jf: 0, k: SECCOMP_DATA_ARCH_OFFSET });
        // On mismatch jump to KILL at index 5+N, from index 2 => 3+N.
        prog.push(SockFilter { code: BPF_JMP | BPF_JEQ | BPF_K, jt: 0, jf: n_u8 + 3, k: self.arch.audit_value() });
        prog.push(SockFilter { code: BPF_LD | BPF_W | BPF_ABS, jt: 0, jf: 0, k: SECCOMP_DATA_NR_OFFSET });
        for (i, nr) in self.allowed.iter().enumerate() {
            // ALLOW is at 4+N; this instruction is at 3+i; offset is
            // (4+N) - (3+i) - 1 = N - i.
            let jt = (n - i) as u8;
            prog.push(SockFilter { code: BPF_JMP | BPF_JEQ | BPF_K, jt, jf: 0, k: *nr as u32 });
        }
        prog.push(SockFilter { code: BPF_RET | BPF_K, jt: 0, jf: 0, k: deny });
        prog.push(SockFilter { code: BPF_RET | BPF_K, jt: 0, jf: 0, k: SECCOMP_RET_ALLOW });
        prog.push(SockFilter { code: BPF_RET | BPF_K, jt: 0, jf: 0, k: SECCOMP_RET_KILL_PROCESS });
        Ok(prog)
    }

    /// Installs the filter on the **calling** process, irrevocably.
    ///
    /// Sets `PR_SET_NO_NEW_PRIVS` first, which is both required by
    /// `seccomp(2)` for an unprivileged caller and valuable in its own
    /// right: it stops a setuid binary inside the sandbox from being a
    /// way back out.
    #[cfg(target_os = "linux")]
    pub fn install(&self) -> Result<(), IsolationError> {
        let prog = self.compile()?;
        // SAFETY: prctl with PR_SET_NO_NEW_PRIVS takes scalar arguments
        // only and cannot invalidate any Rust-held memory.
        let rc = unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) };
        if rc != 0 {
            return Err(IsolationError::SeccompFailed(io::Error::last_os_error()));
        }
        let fprog = SockFprog { len: prog.len() as u16, filter: prog.as_ptr() };
        // SAFETY: `fprog` points at `prog`, which outlives the call;
        // the kernel copies the program in and does not retain the
        // pointer.
        let rc = unsafe {
            libc::syscall(libc::SYS_seccomp, SECCOMP_SET_MODE_FILTER as libc::c_ulong, 0 as libc::c_ulong, &fprog as *const SockFprog)
        };
        if rc != 0 {
            return Err(IsolationError::SeccompFailed(io::Error::last_os_error()));
        }
        Ok(())
    }

    #[cfg(not(target_os = "linux"))]
    pub fn install(&self) -> Result<(), IsolationError> {
        Err(IsolationError::NotLinux)
    }
}

/// The full per-app isolation request.
#[derive(Debug, Clone)]
pub struct IsolationSpec {
    pub app_id: String,
    pub uid: u32,
    pub gid: u32,
    pub mount_ns: bool,
    pub pid_ns: bool,
    /// `true` means "give this app an empty network namespace" — i.e.
    /// it is isolated *because* it has no network permission.
    pub net_ns: bool,
    pub ipc_ns: bool,
    pub uts_ns: bool,
    /// Ask for a user namespace first so the rest can be entered
    /// without real root. See the module doc.
    pub user_ns: bool,
    pub seccomp: SeccompPolicy,
}

impl IsolationSpec {
    /// Derives everything from the app's own declared permissions plus
    /// its Day 40 identity. There is no second place to configure an
    /// app's isolation, on purpose.
    pub fn from_policy(policy: &SandboxPolicy, identity: &Identity, arch: Arch) -> Self {
        let has_network = policy.check(Permission::Network).is_ok();
        IsolationSpec {
            app_id: identity.app_id.clone(),
            uid: identity.uid.0,
            gid: identity.gid,
            mount_ns: true,
            pid_ns: true,
            net_ns: !has_network,
            ipc_ns: true,
            uts_ns: true,
            user_ns: false,
            seccomp: SeccompPolicy::from_policy(policy, arch),
        }
    }

    pub fn with_user_namespace(mut self, yes: bool) -> Self {
        self.user_ns = yes;
        self
    }

    #[cfg(target_os = "linux")]
    pub fn clone_flags(&self) -> libc::c_int {
        let mut flags = 0;
        if self.user_ns {
            flags |= libc::CLONE_NEWUSER;
        }
        if self.mount_ns {
            flags |= libc::CLONE_NEWNS;
        }
        if self.pid_ns {
            flags |= libc::CLONE_NEWPID;
        }
        if self.net_ns {
            flags |= libc::CLONE_NEWNET;
        }
        if self.ipc_ns {
            flags |= libc::CLONE_NEWIPC;
        }
        if self.uts_ns {
            flags |= libc::CLONE_NEWUTS;
        }
        flags
    }

    /// Which namespaces were requested, in the order `unshare` would be
    /// attempted — used for error reporting so a failure names the
    /// namespace that actually failed.
    pub fn requested(&self) -> Vec<&'static str> {
        let mut v = Vec::new();
        if self.user_ns {
            v.push("user");
        }
        if self.mount_ns {
            v.push("mount");
        }
        if self.pid_ns {
            v.push("pid");
        }
        if self.net_ns {
            v.push("network");
        }
        if self.ipc_ns {
            v.push("ipc");
        }
        if self.uts_ns {
            v.push("uts");
        }
        v
    }

    /// Spawns `command` inside the sandbox.
    ///
    /// The isolation is applied in the child, after `fork` and before
    /// `exec`, via `pre_exec`. That ordering is the whole point: the
    /// child is never, at any instant, both running the target program
    /// and outside the sandbox.
    ///
    /// If any requested namespace cannot be entered, the child exits
    /// non-zero from `pre_exec` and the program is never executed. A
    /// sandbox that quietly downgrades itself is worse than one that
    /// fails.
    #[cfg(target_os = "linux")]
    pub fn spawn(&self, mut command: Command) -> Result<Child, IsolationError> {
        let flags = self.clone_flags();
        let seccomp = self.seccomp.clone();
        let uid = self.uid;
        let gid = self.gid;
        let drop_privs = unsafe { libc::geteuid() } == 0;

        // SAFETY: `pre_exec` runs in the forked child between fork and
        // exec, where only async-signal-safe work is permitted. Every
        // call below is a direct syscall — no allocation, no locking,
        // no Rust runtime re-entry. `seccomp`'s BPF program is compiled
        // here, in the child, into a Vec: that is an allocation, and is
        // the one deliberate exception — it happens before any other
        // thread could exist in this child (the child of a fork has
        // exactly one thread) so the allocator cannot be observed in a
        // locked state.
        unsafe {
            command.pre_exec(move || {
                if flags != 0 && libc::unshare(flags) != 0 {
                    return Err(io::Error::last_os_error());
                }
                if drop_privs {
                    if libc::setgid(gid) != 0 {
                        return Err(io::Error::last_os_error());
                    }
                    if libc::setuid(uid) != 0 {
                        return Err(io::Error::last_os_error());
                    }
                }
                seccomp
                    .install()
                    .map_err(|e| io::Error::new(io::ErrorKind::PermissionDenied, e.to_string()))?;
                Ok(())
            });
        }

        command.spawn().map_err(IsolationError::Spawn)
    }

    #[cfg(not(target_os = "linux"))]
    pub fn spawn(&self, _command: Command) -> Result<Child, IsolationError> {
        Err(IsolationError::NotLinux)
    }

    /// Applies the namespace part of the spec to the *current* process.
    /// Used by the Day 41 hostile-app harness, and by any future Nova
    /// service that wants to isolate itself at startup rather than be
    /// isolated by its parent.
    #[cfg(target_os = "linux")]
    pub fn apply_here(&self) -> Result<AppliedIsolation, IsolationError> {
        let flags = self.clone_flags();
        if flags != 0 {
            // SAFETY: unshare only alters the calling process's own
            // namespace memberships.
            if unsafe { libc::unshare(flags) } != 0 {
                let source = io::Error::last_os_error();
                let which = self.requested().first().copied().unwrap_or("unknown");
                return Err(IsolationError::NamespaceDenied { which, source });
            }
        }
        self.seccomp.install()?;
        Ok(AppliedIsolation { namespaces: self.requested().iter().map(|s| s.to_string()).collect(), seccomp: true })
    }

    #[cfg(not(target_os = "linux"))]
    pub fn apply_here(&self) -> Result<AppliedIsolation, IsolationError> {
        Err(IsolationError::NotLinux)
    }
}

/// What was actually achieved — never inferred from what was requested.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AppliedIsolation {
    pub namespaces: Vec<String>,
    pub seccomp: bool,
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_identity::{Identity, IdentityKind, Uid};
    use nova_sandbox::PermissionSet;

    fn identity(app_id: &str) -> Identity {
        Identity { app_id: app_id.into(), uid: Uid(20007), gid: 20007, kind: IdentityKind::App }
    }

    fn policy(perms: &[Permission]) -> SandboxPolicy {
        SandboxPolicy::new("org.nova.test", PermissionSet::from_permissions(perms.iter().copied()), PermissionSet::empty())
            .unwrap()
    }

    #[test]
    fn no_network_permission_means_an_empty_network_namespace() {
        let spec = IsolationSpec::from_policy(&policy(&[Permission::Storage]), &identity("org.nova.test"), Arch::Aarch64);
        assert!(spec.net_ns, "an app without Permission::Network must be network-isolated");
        assert!(!spec.seccomp.allows_socket(), "and must not even be able to create a socket");
    }

    #[test]
    fn network_permission_lifts_both_halves_together() {
        let spec = IsolationSpec::from_policy(&policy(&[Permission::Network]), &identity("org.nova.test"), Arch::Aarch64);
        assert!(!spec.net_ns);
        assert!(spec.seccomp.allows_socket());
    }

    #[test]
    fn spawning_and_mounting_are_never_allowed() {
        let spec = IsolationSpec::from_policy(&policy(&[Permission::Network]), &identity("org.nova.test"), Arch::Aarch64);
        // The DoD's second escape: not reachable even with every
        // permission an app can declare.
        assert!(!spec.seccomp.allows_exec());
        assert!(!spec.seccomp.allows_mount());
        assert!(!spec.seccomp.allows_ptrace());
    }

    /// The off-by-one that would silently allow everything. Checked
    /// structurally rather than trusted.
    #[test]
    fn compiled_filter_has_the_right_shape() {
        let spec = IsolationSpec::from_policy(&policy(&[]), &identity("org.nova.test"), Arch::Aarch64);
        let prog = spec.seccomp.compile().unwrap();
        let n = spec.seccomp.allowed().len();
        assert_eq!(prog.len(), n + 6);

        // Arch check first, and its failure branch reaches the kill.
        assert_eq!(prog[0].k, SECCOMP_DATA_ARCH_OFFSET);
        assert_eq!(prog[1].k, AUDIT_ARCH_AARCH64);
        assert_eq!(1 + 1 + prog[1].jf as usize, n + 5, "arch mismatch must land exactly on the kill instruction");

        // Every syscall comparison's match branch reaches the allow.
        for (i, insn) in prog[3..3 + n].iter().enumerate() {
            assert_eq!(3 + i + 1 + insn.jt as usize, n + 4, "comparison {i} must jump to the allow instruction");
            assert_eq!(insn.jf, 0, "comparison {i} must fall through to the next comparison");
        }

        // Fall-through past the last comparison lands on the denial,
        // not the allow.
        assert_eq!(prog[n + 3].k & 0xffff_0000, SECCOMP_RET_ERRNO);
        assert_eq!(prog[n + 4].k, SECCOMP_RET_ALLOW);
        assert_eq!(prog[n + 5].k, SECCOMP_RET_KILL_PROCESS);
    }

    #[test]
    fn kill_violation_action_changes_only_the_denial_return() {
        let mut seccomp = SeccompPolicy::from_policy(&policy(&[]), Arch::X86_64);
        seccomp.violation = ViolationAction::KillProcess;
        let prog = seccomp.compile().unwrap();
        let n = seccomp.allowed().len();
        assert_eq!(prog[n + 3].k, SECCOMP_RET_KILL_PROCESS);
        assert_eq!(prog[n + 4].k, SECCOMP_RET_ALLOW);
    }

    #[test]
    fn arch_is_checked_before_the_syscall_number() {
        let p = SeccompPolicy::from_policy(&policy(&[]), Arch::X86_64);
        let prog = p.compile().unwrap();
        assert_eq!(prog[0].k, SECCOMP_DATA_ARCH_OFFSET, "arch must be loaded first");
        assert_eq!(prog[2].k, SECCOMP_DATA_NR_OFFSET, "syscall number is only loaded after the arch matches");
        assert_eq!(prog[1].k, AUDIT_ARCH_X86_64);
    }

    #[test]
    fn requested_namespaces_are_reported_in_unshare_order() {
        let spec = IsolationSpec::from_policy(&policy(&[]), &identity("org.nova.test"), Arch::Aarch64)
            .with_user_namespace(true);
        assert_eq!(spec.requested(), vec!["user", "mount", "pid", "network", "ipc", "uts"]);
    }
}

// Small, explicit predicates used by the tests above and by Day 45's
// audit. They exist so "can this app exec?" is answered by one function
// rather than by every caller re-deriving it from a syscall number.
impl SeccompPolicy {
    #[cfg(target_os = "linux")]
    pub fn allows_socket(&self) -> bool {
        self.allows(libc::SYS_socket)
    }
    #[cfg(target_os = "linux")]
    pub fn allows_exec(&self) -> bool {
        self.allows(libc::SYS_execve) || self.allows(libc::SYS_execveat)
    }
    #[cfg(target_os = "linux")]
    pub fn allows_mount(&self) -> bool {
        self.allows(libc::SYS_mount)
    }
    #[cfg(target_os = "linux")]
    pub fn allows_ptrace(&self) -> bool {
        self.allows(libc::SYS_ptrace)
    }

    #[cfg(not(target_os = "linux"))]
    pub fn allows_socket(&self) -> bool {
        false
    }
    #[cfg(not(target_os = "linux"))]
    pub fn allows_exec(&self) -> bool {
        false
    }
    #[cfg(not(target_os = "linux"))]
    pub fn allows_mount(&self) -> bool {
        false
    }
    #[cfg(not(target_os = "linux"))]
    pub fn allows_ptrace(&self) -> bool {
        false
    }
}
