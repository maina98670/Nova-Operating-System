//! Nova structured logging — M4 Day 7.
//!
//! Persistence goes through `nova-fsmgr` (Day 4) — specifically its
//! new `append_file` (added today, alongside this module, since
//! logging is exactly the use case that motivated adding append
//! semantics to the Filesystem Manager in the first place) — never a
//! bespoke file-writing path of its own. That's the literal Day 7
//! task: "Persistent logs where practical (written through the
//! Filesystem Manager built two days ago, not a bespoke log path)."
//!
//! "Structured" (the DoD's own word) means each entry is a real,
//! parseable record — timestamp, level, source, message — not a
//! free-form string. `filter_by_level`/`filter_by_source` and
//! `load_from_file`'s round-trip parsing are what make logs
//! "queryable/filterable afterward, not just scrolling text," per the
//! DoD's explicit framing.
//!
//! File format: tab-separated, one entry per line — the same
//! hand-rolled, dependency-free convention already used by
//! `nova-contacts` and `nova-messages`, including the same
//! escape/unescape approach for the free-text `message` field.

use nova_fsmgr::append_file as fs_append_file;
use nova_fsmgr::read_file as fs_read_file;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum LogLevel {
    Debug,
    Info,
    Warning,
    Error,
    Critical,
}

impl LogLevel {
    fn as_str(self) -> &'static str {
        match self {
            LogLevel::Debug => "DEBUG",
            LogLevel::Info => "INFO",
            LogLevel::Warning => "WARNING",
            LogLevel::Error => "ERROR",
            LogLevel::Critical => "CRITICAL",
        }
    }
    fn from_str(s: &str) -> Option<LogLevel> {
        match s {
            "DEBUG" => Some(LogLevel::Debug),
            "INFO" => Some(LogLevel::Info),
            "WARNING" => Some(LogLevel::Warning),
            "ERROR" => Some(LogLevel::Error),
            "CRITICAL" => Some(LogLevel::Critical),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LogEntry {
    pub timestamp_secs: u64,
    pub level: LogLevel,
    /// Which subsystem logged this — e.g. "nova-procmgrd",
    /// "nova-svcmgr" — the field that makes M4's various subsystems
    /// distinguishable in a shared log, per Day 7's retrofit task.
    pub source: String,
    pub message: String,
}

fn escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('\t', "\\t").replace('\n', "\\n")
}
fn unescape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\' {
            match chars.next() {
                Some('t') => out.push('\t'),
                Some('n') => out.push('\n'),
                Some('\\') => out.push('\\'),
                Some(other) => {
                    out.push('\\');
                    out.push(other);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn serialize(entry: &LogEntry) -> String {
    format!(
        "{}\t{}\t{}\t{}\n",
        entry.timestamp_secs,
        entry.level.as_str(),
        escape(&entry.source),
        escape(&entry.message)
    )
}

fn parse_line(line: &str) -> Option<LogEntry> {
    let parts: Vec<&str> = line.splitn(4, '\t').collect();
    if parts.len() != 4 {
        return None;
    }
    let timestamp_secs = parts[0].parse().ok()?;
    let level = LogLevel::from_str(parts[1])?;
    Some(LogEntry { timestamp_secs, level, source: unescape(parts[2]), message: unescape(parts[3]) })
}

fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

pub struct Logger {
    entries: Vec<LogEntry>,
    persist_path: Option<PathBuf>,
}

impl Logger {
    /// In-memory only — no persistence. Useful for tests and for any
    /// caller that doesn't need logs to survive process exit.
    pub fn new() -> Self {
        Logger { entries: Vec::new(), persist_path: None }
    }

    /// Persists every logged entry through `nova-fsmgr::append_file`
    /// at `path` — the actual "through the Filesystem Manager, not a
    /// bespoke log path" requirement, not just a design intention.
    pub fn with_persistence(path: PathBuf) -> Self {
        Logger { entries: Vec::new(), persist_path: Some(path) }
    }

    pub fn log(&mut self, level: LogLevel, source: &str, message: &str) {
        let entry =
            LogEntry { timestamp_secs: now_secs(), level, source: source.to_string(), message: message.to_string() };

        if let Some(path) = &self.persist_path {
            // Best-effort: a logging failure should never be allowed
            // to crash the caller (imagine a full disk taking down
            // every service that logs) -- this mirrors real-world
            // logging library behavior everywhere, not a shortcut.
            let _ = fs_append_file(path, serialize(&entry).as_bytes());
        }

        self.entries.push(entry);
    }

    pub fn debug(&mut self, source: &str, message: &str) {
        self.log(LogLevel::Debug, source, message);
    }
    pub fn info(&mut self, source: &str, message: &str) {
        self.log(LogLevel::Info, source, message);
    }
    pub fn warning(&mut self, source: &str, message: &str) {
        self.log(LogLevel::Warning, source, message);
    }
    pub fn error(&mut self, source: &str, message: &str) {
        self.log(LogLevel::Error, source, message);
    }
    pub fn critical(&mut self, source: &str, message: &str) {
        self.log(LogLevel::Critical, source, message);
    }

    pub fn all(&self) -> &[LogEntry] {
        &self.entries
    }

    /// The literal "queryable/filterable afterward" requirement: only
    /// entries at or above `min_level` (e.g. `Warning` returns
    /// Warning, Error, and Critical, matching how every real logging
    /// system's level filtering works).
    pub fn filter_by_level(&self, min_level: LogLevel) -> Vec<&LogEntry> {
        self.entries.iter().filter(|e| e.level >= min_level).collect()
    }

    pub fn filter_by_source(&self, source: &str) -> Vec<&LogEntry> {
        self.entries.iter().filter(|e| e.source == source).collect()
    }
}

impl Default for Logger {
    fn default() -> Self {
        Self::new()
    }
}

/// Reads a persisted log file back into structured entries — proves
/// the round-trip (written through `nova-fsmgr`, read back through
/// `nova-fsmgr`, correctly parsed) rather than just claiming
/// persistence works.
pub fn load_from_file(path: &Path) -> std::io::Result<Vec<LogEntry>> {
    let contents = fs_read_file(path)?;
    let text = String::from_utf8_lossy(&contents);
    Ok(text.lines().filter_map(parse_line).collect())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;
    use std::fs;

    fn temp_log_path(name: &str) -> PathBuf {
        env::temp_dir().join(format!("nova-log-test-{}-{}", std::process::id(), name))
    }

    /// The literal Day 7 DoD: emit log lines at each level, and
    /// they're queryable/filterable afterward -- through a real,
    /// persisted, round-tripped log file, not just an in-memory Vec.
    #[test]
    fn day7_definition_of_done_structured_logs() {
        let path = temp_log_path("dod.log");
        let _ = fs::remove_file(&path);

        let mut logger = Logger::with_persistence(path.clone());
        logger.debug("test", "debug message");
        logger.info("test", "info message");
        logger.warning("test", "warning message");
        logger.error("test", "error message");
        logger.critical("test", "critical message");

        assert_eq!(logger.all().len(), 5, "all five levels should be recorded in memory");

        // Queryable/filterable, not just scrolling text:
        let warnings_and_above = logger.filter_by_level(LogLevel::Warning);
        assert_eq!(warnings_and_above.len(), 3, "Warning, Error, Critical should match a Warning-and-above filter");

        // Persisted through nova-fsmgr, and readable back through it too.
        let loaded = load_from_file(&path).expect("load_from_file should succeed");
        assert_eq!(loaded.len(), 5, "all five entries should have been persisted and are readable back");
        assert_eq!(loaded[0].level, LogLevel::Debug);
        assert_eq!(loaded[4].level, LogLevel::Critical);
        assert_eq!(loaded[2].message, "warning message");

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn filter_by_source_isolates_one_subsystem() {
        let mut logger = Logger::new();
        logger.info("nova-procmgr", "process spawned");
        logger.info("nova-svcmgr", "service started");
        logger.error("nova-procmgr", "spawn failed");

        let procmgr_entries = logger.filter_by_source("nova-procmgr");
        assert_eq!(procmgr_entries.len(), 2);
        assert!(procmgr_entries.iter().all(|e| e.source == "nova-procmgr"));
    }

    #[test]
    fn level_filter_excludes_lower_levels() {
        let mut logger = Logger::new();
        logger.debug("x", "d");
        logger.info("x", "i");
        let only_error_and_above = logger.filter_by_level(LogLevel::Error);
        assert_eq!(only_error_and_above.len(), 0, "no entries should match an Error-and-above filter here");
    }

    #[test]
    fn escaping_handles_tabs_and_newlines_in_message() {
        let path = temp_log_path("escape.log");
        let _ = fs::remove_file(&path);

        let mut logger = Logger::with_persistence(path.clone());
        logger.info("test", "line one\twith a tab\nand a newline");

        let loaded = load_from_file(&path).unwrap();
        assert_eq!(loaded[0].message, "line one\twith a tab\nand a newline");

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn multiple_log_calls_append_not_overwrite() {
        let path = temp_log_path("append.log");
        let _ = fs::remove_file(&path);

        {
            let mut logger = Logger::with_persistence(path.clone());
            logger.info("test", "first entry");
        }
        {
            // A fresh Logger instance, same path -- simulates a
            // second process/run logging to the same file, which is
            // exactly the boot-diagnostics retrofit scenario (Day
            // 7's third task): many subsystems, one shared log.
            let mut logger = Logger::with_persistence(path.clone());
            logger.info("test", "second entry");
        }

        let loaded = load_from_file(&path).unwrap();
        assert_eq!(loaded.len(), 2, "second Logger instance should append, not overwrite the first entry");

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn load_from_missing_file_errors_cleanly() {
        let path = temp_log_path("does-not-exist.log");
        let _ = fs::remove_file(&path);
        assert!(load_from_file(&path).is_err());
    }

    #[test]
    fn in_memory_only_logger_works_without_a_path() {
        let mut logger = Logger::new();
        logger.warning("test", "no persistence configured");
        assert_eq!(logger.all().len(), 1);
    }
}
