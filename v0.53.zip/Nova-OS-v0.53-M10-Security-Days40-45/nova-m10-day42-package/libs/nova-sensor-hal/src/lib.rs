#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SensorSample { pub x: f32, pub y: f32, pub z: f32, pub timestamp_ms: u64 }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SensorKind { Accelerometer, Gyroscope, Proximity, Light }

pub trait Sensor { fn kind(&self) -> SensorKind; fn sample(&self) -> Option<SensorSample>; }

#[derive(Debug)] pub struct StaticSensor { kind: SensorKind, value: SensorSample }
impl StaticSensor { pub fn new(kind: SensorKind, value: SensorSample) -> Self { Self{kind,value} } }
impl Sensor for StaticSensor { fn kind(&self)->SensorKind{self.kind} fn sample(&self)->Option<SensorSample>{Some(self.value)} }

#[cfg(test)] mod tests { use super::*; #[test] fn sample_is_stable(){ let s=StaticSensor::new(SensorKind::Accelerometer,SensorSample{x:0.0,y:0.0,z:9.81,timestamp_ms:1}); assert_eq!(s.kind(),SensorKind::Accelerometer); assert!(s.sample().is_some()); }}
