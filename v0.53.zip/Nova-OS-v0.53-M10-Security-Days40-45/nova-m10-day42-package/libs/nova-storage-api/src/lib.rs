//! Nova OS Day 20 — Storage API.
//!
//! "A scoped, permission-checked file/data API for apps, built on
//! M4's Filesystem Manager and M5's sandbox boundaries — not raw
//! filesystem access." Every operation here goes through
//! `SandboxPolicy::scoped_path` (Day 15) for path resolution/safety,
//! then `nova_fsmgr`'s own `read_file`/`write_file`/`delete_file`
//! (Day 4) for the actual I/O — this crate never calls `std::fs`
//! directly on a path itself. That's the literal proof both DoDs
//! this crate now serves ask for: Day 20's "M5's sandboxing is
//! actually wired to the SDK, not bypassed," and Day 26's "the
//! deletion actually reflected via M4's Filesystem Manager."
//!
//! **Day 26 fix, not a Day 20 oversight left in place**: through Day
//! 25, `delete`/`list` called raw `std::fs` directly, and
//! `read`/`write` went through `SandboxPolicy::read_scoped`/
//! `write_scoped`, which themselves call raw `std::fs` internally —
//! neither route touched `nova_fsmgr` at all, despite this module's
//! own doc claiming to be "built on M4's Filesystem Manager" since
//! Day 20. Day 26's file manager app and its own DoD are what
//! surfaced this; fixed here by routing every operation through
//! `nova_fsmgr` explicitly, using `SandboxPolicy::scoped_path` only
//! for resolving *where* — never *how* — I/O happens.
//!
//! Also closes a gap Day 16's `nova-camera-core` named in its own
//! doc comment ("no delete-scoped storage API yet") — `delete` and
//! `list` were added Day 20, on top of Day 15's existing
//! `read_scoped`/`write_scoped`, both routed through `scoped_path`
//! for the same traversal protection.
//!
//! ## Two different "`/apps`" paths — don't confuse them
//! `nova_fsmgr::paths::APPS` (`/apps`) is where App Manager installs
//! a manifest + binary (Days 14/16). `SandboxPolicy::app_data_root`
//! (`/var/lib/nova/apps/<id>`, Day 15) is where *this* crate's
//! `read`/`write`/`delete`/`list` actually touch disk — an app's own
//! *data*, not its installed package. They happen to share the word
//! "apps" and nothing else.
//!
//! ## What "blocked from another app's data" means today, honestly
//! [`StorageApi`] structurally cannot escape its own
//! `app_data_root()` via a relative path — `..` and absolute paths
//! are rejected before any filesystem call, proven by this crate's
//! own unit tests. What it does **not** defend against: a process
//! constructing a [`SandboxPolicy`] for a *different* app id and
//! opening `StorageApi` against it directly — nothing today ties an
//! app id to the process that's allowed to claim it (no per-process
//! OS-level isolation exists yet; that's still M10's job, the exact
//! same caveat Day 15/16 already state). Traversal protection is real
//! and structural; identity-spoofing protection is not yet.

use nova_ipc::Permission;
use nova_sandbox::{SandboxError, SandboxPolicy};
use std::fs;
use std::io;

#[derive(Debug)]
pub enum StorageError {
    NotFound(String),
    Sandbox(SandboxError),
    Io(String),
}

impl std::fmt::Display for StorageError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            StorageError::NotFound(key) => write!(f, "no such key: {key}"),
            StorageError::Sandbox(e) => write!(f, "sandbox error: {e}"),
            StorageError::Io(e) => write!(f, "storage I/O error: {e}"),
        }
    }
}
impl std::error::Error for StorageError {}

/// A permission-checked handle onto one app's own scoped storage.
/// Cannot be constructed unless `Permission::Storage` is already
/// granted on the given policy — the permission check is part of
/// `open`, not something a caller can forget to do first.
pub struct StorageApi {
    policy: SandboxPolicy,
}

impl StorageApi {
    pub fn open(policy: SandboxPolicy) -> Result<Self, StorageError> {
        policy.check(Permission::Storage).map_err(StorageError::Sandbox)?;
        Ok(Self { policy })
    }

    /// Resolves `key` against this app's own sandbox root
    /// (`SandboxPolicy::scoped_path`, Day 15 — rejects `..` and
    /// absolute paths before this ever reaches a filesystem call),
    /// then reads through `nova_fsmgr::read_file` (Day 4) — M4's
    /// Filesystem Manager, not a direct `std::fs::read`.
    pub fn read(&self, key: &str) -> Result<Vec<u8>, StorageError> {
        let path = self.policy.scoped_path(key).map_err(StorageError::Sandbox)?;
        nova_fsmgr::read_file(&path).map_err(|e| {
            if e.kind() == io::ErrorKind::NotFound {
                StorageError::NotFound(key.to_string())
            } else {
                StorageError::Io(e.to_string())
            }
        })
    }

    /// Same resolve-then-delegate shape as `read`, through
    /// `nova_fsmgr::write_file`.
    pub fn write(&self, key: &str, data: &[u8]) -> Result<(), StorageError> {
        let path = self.policy.scoped_path(key).map_err(StorageError::Sandbox)?;
        nova_fsmgr::write_file(&path, data).map_err(|e| StorageError::Io(e.to_string()))
    }

    /// Same resolve-then-delegate shape, through
    /// `nova_fsmgr::delete_file` — the literal Day 26 DoD: "the
    /// deletion actually reflected via M4's Filesystem Manager"
    /// means this call, not a `std::fs::remove_file` this crate
    /// happens to also make.
    pub fn delete(&self, key: &str) -> Result<(), StorageError> {
        let path = self.policy.scoped_path(key).map_err(StorageError::Sandbox)?;
        nova_fsmgr::delete_file(&path).map_err(|e| {
            if e.kind() == io::ErrorKind::NotFound {
                StorageError::NotFound(key.to_string())
            } else {
                StorageError::Io(e.to_string())
            }
        })
    }

    /// Lists entries directly under `prefix` (relative to this app's
    /// own storage root; `""` for the root itself). Non-recursive,
    /// file names only — enough for the apps built so far
    /// (`nova-camera-core`'s photo index, etc. already keep their own
    /// richer listing in a JSON index file rather than relying on
    /// directory listing). `nova_fsmgr` has no directory-listing
    /// function of its own (Day 4's scope was file CRUD + mount, not
    /// directory enumeration), so this one operation still uses
    /// `std::fs::read_dir` directly — named here rather than left
    /// silently inconsistent with the rest of this crate's now-fsmgr-
    /// routed operations.
    pub fn list(&self, prefix: &str) -> Result<Vec<String>, StorageError> {
        let dir = self.policy.scoped_path(prefix).map_err(StorageError::Sandbox)?;
        if !dir.exists() {
            return Ok(Vec::new());
        }
        let mut names: Vec<String> = fs::read_dir(&dir)
            .map_err(|e| StorageError::Io(e.to_string()))?
            .filter_map(|entry| entry.ok())
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .collect();
        names.sort();
        Ok(names)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_sandbox::PermissionSet;

    fn open_test_policy(app_id: &str) -> StorageApi {
        let policy = SandboxPolicy::new(app_id, PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty()).unwrap();
        StorageApi::open(policy).unwrap()
    }

    #[test]
    fn open_without_storage_permission_is_rejected() {
        let policy = SandboxPolicy::new("org.nova.day20test.noperms", PermissionSet::empty(), PermissionSet::empty()).unwrap();
        assert!(matches!(StorageApi::open(policy), Err(StorageError::Sandbox(_))));
    }

    #[test]
    fn write_read_round_trip() {
        let storage = open_test_policy("org.nova.day20test.roundtrip");
        storage.write("greeting.txt", b"hello").unwrap();
        assert_eq!(storage.read("greeting.txt").unwrap(), b"hello");
        let _ = storage.delete("greeting.txt");
    }

    #[test]
    fn delete_then_read_is_not_found() {
        let storage = open_test_policy("org.nova.day20test.deletecheck");
        storage.write("scratch.txt", b"temp").unwrap();
        storage.delete("scratch.txt").unwrap();
        assert!(matches!(storage.read("scratch.txt"), Err(StorageError::NotFound(_))));
    }

    #[test]
    fn deleting_a_missing_key_is_not_found_not_a_panic() {
        let storage = open_test_policy("org.nova.day20test.deletemissing");
        assert!(matches!(storage.delete("never-existed.txt"), Err(StorageError::NotFound(_))));
    }

    #[test]
    fn list_reflects_written_keys() {
        let storage = open_test_policy("org.nova.day20test.listing");
        storage.write("a.txt", b"1").unwrap();
        storage.write("b.txt", b"2").unwrap();
        let names = storage.list("").unwrap();
        assert!(names.contains(&"a.txt".to_string()));
        assert!(names.contains(&"b.txt".to_string()));
        let _ = storage.delete("a.txt");
        let _ = storage.delete("b.txt");
    }

    /// The actual Day 20 DoD proof: traversal out of this app's own
    /// root is rejected by the same `scoped_path` call every other
    /// operation here goes through -- not a special case, just the
    /// normal path.
    #[test]
    fn traversal_outside_the_sandbox_is_rejected_on_every_operation() {
        let storage = open_test_policy("org.nova.day20test.traversal");
        assert!(matches!(storage.write("../org.nova.other/pwned.txt", b"nope"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.read("../org.nova.other/secret.txt"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.delete("../org.nova.other/secret.txt"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.list("../org.nova.other"), Err(StorageError::Sandbox(_))));
        assert!(matches!(storage.write("/etc/passwd", b"nope"), Err(StorageError::Sandbox(_))));
    }

    /// Two different app ids resolve to two different, non-overlapping
    /// roots -- real isolation between two apps that each behave
    /// (neither tries to construct a policy for the other's id).
    #[test]
    fn two_different_app_ids_never_see_each_others_writes() {
        let a = open_test_policy("org.nova.day20test.isoA");
        let b = open_test_policy("org.nova.day20test.isoB");
        a.write("shared-key-name.txt", b"from A").unwrap();
        b.write("shared-key-name.txt", b"from B").unwrap();
        assert_eq!(a.read("shared-key-name.txt").unwrap(), b"from A");
        assert_eq!(b.read("shared-key-name.txt").unwrap(), b"from B");
        let _ = a.delete("shared-key-name.txt");
        let _ = b.delete("shared-key-name.txt");
    }

    /// Day 26's own point, proven directly: deleting through
    /// `StorageApi` is visible to `nova_fsmgr::read_file` called
    /// completely independently afterward -- not just to another
    /// `StorageApi` call, which alone wouldn't distinguish "actually
    /// deleted from disk" from "deleted from some in-memory index."
    #[test]
    fn deletion_is_reflected_via_nova_fsmgr_independently() {
        let storage = open_test_policy("org.nova.day20test.fsmgrcheck");
        let policy = SandboxPolicy::new("org.nova.day20test.fsmgrcheck", PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty()).unwrap();
        let path = policy.scoped_path("proof.txt").unwrap();

        storage.write("proof.txt", b"before delete").unwrap();
        assert_eq!(nova_fsmgr::read_file(&path).unwrap(), b"before delete", "nova_fsmgr should see the write independently of StorageApi");

        storage.delete("proof.txt").unwrap();
        assert!(nova_fsmgr::read_file(&path).is_err(), "nova_fsmgr should also see the delete independently of StorageApi");
    }
}
