#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 40 (M10 Security): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 40: unit tests ==="
cargo test -p nova-identity

echo
echo "=== nova-m10-day40-identity-acceptance-test ==="
cargo run -p nova-m10-day40-identity-acceptance-test

echo
echo "Day 40 build + tests + acceptance completed."
