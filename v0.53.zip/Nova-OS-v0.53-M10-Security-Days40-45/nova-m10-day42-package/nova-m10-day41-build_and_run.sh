#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 41 (M10 Security): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 41: unit tests ==="
cargo test -p nova-identity -p nova-isolation

echo
echo "=== nova-m10-day41-sandbox-hardening-acceptance-test ==="
echo "This one launches a real hostile binary and needs namespace privileges."
echo "Run as root, or on a kernel with unprivileged user namespaces enabled."
cargo run -p nova-m10-day41-sandbox-hardening-acceptance-test

echo
echo "Day 41 build + tests + acceptance completed."
