#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 42 (M10 Security): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 42: unit tests ==="
cargo test -p nova-crypto -p nova-capability -p nova-secure-ipc

echo
echo "=== nova-m10-day42-secure-ipc-acceptance-test ==="
cargo run -p nova-m10-day42-secure-ipc-acceptance-test

echo
echo "Day 42 build + tests + acceptance completed."
