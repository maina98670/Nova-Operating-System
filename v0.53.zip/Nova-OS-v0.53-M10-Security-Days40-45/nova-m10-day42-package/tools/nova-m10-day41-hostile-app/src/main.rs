//! Day 41's "deliberately malicious test app".
//!
//! This binary is the adversary the Day 41 Definition of Done names. It
//! makes no attempt to be well-behaved: it tries, in order, to read
//! another app's private data, to execute an arbitrary program, and to
//! open a network socket it was never granted. It reports what it
//! managed to do, and the harness decides whether that is a pass.
//!
//! It is written to be *honest about success*, which is the unusual
//! part: a sandbox test whose adversary quietly fails for an unrelated
//! reason (wrong path, missing binary) proves nothing, so each attempt
//! distinguishes "blocked" from "couldn't even try" and says which.
//!
//! Usage: `nova-m10-day41-hostile-app <victim-file-path>`
//!
//! Output: one `KEY=value` line per attempt on stdout, where value is
//! `escaped`, `blocked`, or `inconclusive:<reason>`. Exit code is the
//! number of successful escapes, so `0` means the sandbox held.

use std::io::Read;
use std::process::{Command, ExitCode};

#[derive(PartialEq)]
enum Outcome {
    Escaped(String),
    Blocked(String),
    Inconclusive(String),
}

impl Outcome {
    fn render(&self) -> String {
        match self {
            Outcome::Escaped(d) => format!("escaped ({d})"),
            Outcome::Blocked(d) => format!("blocked ({d})"),
            Outcome::Inconclusive(d) => format!("inconclusive ({d})"),
        }
    }
}

fn main() -> ExitCode {
    let victim = std::env::args().nth(1).unwrap_or_default();

    let fs = attempt_read_other_apps_data(&victim);
    let exec = attempt_spawn_arbitrary_process();
    let net = attempt_unauthorized_network();

    println!("FS_ESCAPE={}", fs.render());
    println!("EXEC_ESCAPE={}", exec.render());
    println!("NET_ESCAPE={}", net.render());

    let escapes = [&fs, &exec, &net].iter().filter(|o| matches!(o, Outcome::Escaped(_))).count();
    println!("ESCAPES={escapes}");

    // Exit code carries the count so a harness that loses stdout still
    // learns the verdict.
    ExitCode::from(escapes as u8)
}

/// Escape 1: another app's data. The path is handed in by the harness
/// and really does exist and really does contain readable bytes when
/// read from outside the sandbox — so a failure here is the sandbox
/// working, not a typo.
fn attempt_read_other_apps_data(victim: &str) -> Outcome {
    if victim.is_empty() {
        return Outcome::Inconclusive("no victim path given".into());
    }
    match std::fs::File::open(victim) {
        Ok(mut f) => {
            let mut buf = String::new();
            match f.read_to_string(&mut buf) {
                Ok(0) => Outcome::Inconclusive("opened but empty; nothing was actually exfiltrated".into()),
                Ok(n) => Outcome::Escaped(format!("read {n} bytes of another app's private file")),
                Err(e) => Outcome::Blocked(format!("opened but unreadable: {e}")),
            }
        }
        Err(e) => Outcome::Blocked(format!("open failed: {e}")),
    }
}

/// Escape 2: spawning a process outside the permission set. `/bin/sh`
/// is the canonical target because it is the difference between "this
/// app misbehaved" and "this app now runs anything".
fn attempt_spawn_arbitrary_process() -> Outcome {
    if !std::path::Path::new("/bin/sh").exists() {
        return Outcome::Inconclusive("/bin/sh not present on this system".into());
    }
    match Command::new("/bin/sh").arg("-c").arg("exit 0").status() {
        Ok(status) => Outcome::Escaped(format!("spawned /bin/sh, which exited with {status}")),
        Err(e) => Outcome::Blocked(format!("spawn refused: {e}")),
    }
}

/// Escape 3: an unauthorized network connection. The marker is the
/// ability to *create and bind* an INET socket, not whether a remote
/// host answered — a test that depends on the internet being reachable
/// would be flaky in exactly the environments Nova is developed in.
///
/// `socket(2)` is called directly rather than through `std::net` so the
/// failure can be attributed precisely: a `std::net::TcpStream::connect`
/// error could mean "seccomp blocked socket creation", "the network
/// namespace has no route", or "that host is simply down", and those
/// are three very different findings.
fn attempt_unauthorized_network() -> Outcome {
    // SAFETY: plain syscalls with scalar arguments and a locally owned
    // `sockaddr_in`; nothing here aliases Rust-managed memory.
    unsafe {
        let fd = libc::socket(libc::AF_INET, libc::SOCK_STREAM, 0);
        if fd < 0 {
            return Outcome::Blocked(format!("socket(AF_INET) refused: {}", std::io::Error::last_os_error()));
        }
        let mut addr: libc::sockaddr_in = std::mem::zeroed();
        addr.sin_family = libc::AF_INET as libc::sa_family_t;
        addr.sin_port = 0; // let the kernel choose
        addr.sin_addr.s_addr = u32::from_ne_bytes([0, 0, 0, 0]);
        let rc = libc::bind(
            fd,
            &addr as *const libc::sockaddr_in as *const libc::sockaddr,
            std::mem::size_of::<libc::sockaddr_in>() as libc::socklen_t,
        );
        let outcome = if rc == 0 {
            Outcome::Escaped("created and bound an INET socket without Permission::Network".into())
        } else {
            Outcome::Blocked(format!("socket created but bind refused: {}", std::io::Error::last_os_error()))
        };
        libc::close(fd);
        outcome
    }
}
