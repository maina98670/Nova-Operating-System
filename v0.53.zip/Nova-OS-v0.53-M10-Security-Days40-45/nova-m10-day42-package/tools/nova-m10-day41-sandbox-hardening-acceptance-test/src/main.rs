//! Day 41 acceptance test — the literal Definition of Done:
//!
//! > A deliberately malicious test app cannot escape its sandbox to
//! > access another app's data, spawn arbitrary processes outside its
//! > permission set, or make unauthorized network connections.
//!
//! The adversary is `nova-m10-day41-hostile-app`, a real binary that
//! really tries all three. It is run **twice**:
//!
//! 1. **Unisolated control.** If the hostile app cannot escape even
//!    *without* a sandbox, the isolated run proves nothing — the test
//!    would be measuring a broken adversary. This run must succeed at
//!    at least one escape for the verdict below to mean anything.
//! 2. **Isolated.** Same binary, same arguments, launched through
//!    `IsolationSpec::spawn`. Zero escapes required.
//!
//! Comparing the two is the whole design: the difference between the
//! runs is attributable to the sandbox and nothing else.

use nova_identity::{Enforcer, IdentityRegistry};
use nova_ipc::Permission;
use nova_isolation::{Arch, IsolationError, IsolationSpec};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use std::fs;
use std::path::PathBuf;
use std::process::{Command, ExitCode, Stdio};

const HOSTILE: &str = "org.nova.hostile";
const VICTIM: &str = "org.nova.victim";

struct RunResult {
    escapes: usize,
    lines: Vec<String>,
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 41 acceptance: sandbox hardening ===\n");

    let hostile_bin = match locate_hostile_binary() {
        Some(p) => p,
        None => {
            eprintln!(
                "Could not find nova-m10-day41-hostile-app next to this binary.\n\
                 Build the workspace first (`cargo build --workspace`), or pass the path:\n\
                 cargo run -p nova-m10-day41-sandbox-hardening-acceptance-test -- <path>"
            );
            return ExitCode::FAILURE;
        }
    };
    println!("Adversary: {}", hostile_bin.display());

    // --- Set the stage: two identities, one with a real secret. ------
    let root = std::env::temp_dir().join(format!("nova-day41-acceptance-{}", std::process::id()));
    let _ = fs::remove_dir_all(&root);
    fs::create_dir_all(&root).expect("create test root");

    let enforcer = Enforcer::new(&root);
    let mut registry = IdentityRegistry::open(root.join("identities.tsv")).expect("identity registry");
    let hostile_id = registry.allocate(HOSTILE).expect("hostile identity");
    let victim_id = registry.allocate(VICTIM).expect("victim identity");
    enforcer.provision(&hostile_id).expect("provision hostile");
    let victim_root = enforcer.provision(&victim_id).expect("provision victim");

    let secret = victim_root.join("secret.txt");
    fs::write(&secret, b"the victim app's private data").expect("write victim secret");

    println!("Victim secret at: {}", secret.display());
    println!("Hostile app identity: uid={} (no Permission::Network declared)\n", hostile_id.uid);

    // The hostile app's manifest declares storage only. Network is
    // *not* declared, which is what makes its socket attempt
    // unauthorized rather than merely unsuccessful.
    let policy = SandboxPolicy::new(
        HOSTILE,
        PermissionSet::from_permissions([Permission::Storage]),
        PermissionSet::empty(),
    )
    .expect("hostile policy");
    assert!(policy.check(Permission::Network).is_err(), "the adversary must not hold Permission::Network");

    let Some(arch) = Arch::host() else {
        eprintln!("Unsupported host architecture {} — seccomp filters are compiled per-arch.", std::env::consts::ARCH);
        return ExitCode::FAILURE;
    };

    // --- Run 1: the control. -----------------------------------------
    println!("--- Control run (no sandbox) ---");
    let control = run_plain(&hostile_bin, &secret);
    for line in &control.lines {
        println!("  {line}");
    }
    println!("  -> {} escape(s) without a sandbox\n", control.escapes);

    if control.escapes == 0 {
        println!("Day 41 acceptance: FAIL");
        println!(
            "The adversary escaped nothing even unsandboxed, so the isolated run below would\n\
             prove nothing. Check that /bin/sh exists and that the victim file is readable by\n\
             this user before trusting any result from this test."
        );
        let _ = fs::remove_dir_all(&root);
        return ExitCode::FAILURE;
    }

    // --- Run 2: the sandbox. -----------------------------------------
    println!("--- Isolated run ---");
    let spec = IsolationSpec::from_policy(&policy, &hostile_id, arch).with_user_namespace(true);
    println!("  namespaces requested: {}", spec.requested().join(", "));
    println!("  seccomp allowlist: {} syscalls", spec.seccomp.allowed().len());
    println!("  socket() allowed: {} | execve() allowed: {}", spec.seccomp.allows_socket(), spec.seccomp.allows_exec());

    let isolated = match run_isolated(&spec, &hostile_bin, &secret) {
        Ok(r) => r,
        Err(e) => {
            println!("\nDay 41 acceptance: FAIL");
            println!("  {e}");
            println!(
                "\nThis is the sandbox refusing to start the app rather than starting it\n\
                 unisolated, which is the intended failure mode — but it is still a failure of\n\
                 this test, because nothing was proved. Re-run as root, or on a kernel with\n\
                 unprivileged user namespaces enabled\n\
                 (`sysctl kernel.unprivileged_userns_clone=1` on the distributions that gate it)."
            );
            let _ = fs::remove_dir_all(&root);
            return ExitCode::FAILURE;
        }
    };
    for line in &isolated.lines {
        println!("  {line}");
    }
    println!("  -> {} escape(s) inside the sandbox\n", isolated.escapes);

    let _ = fs::remove_dir_all(&root);

    if isolated.escapes == 0 {
        println!("Day 41 acceptance: PASS");
        println!(
            "The same adversary binary escaped {} time(s) unsandboxed and 0 times inside the\n\
             sandbox. Filesystem, process-spawning and network escapes were all refused.",
            control.escapes
        );
        ExitCode::SUCCESS
    } else {
        println!("Day 41 acceptance: FAIL");
        println!("{} escape(s) succeeded inside the sandbox. See the lines above for which.", isolated.escapes);
        ExitCode::FAILURE
    }
}

fn locate_hostile_binary() -> Option<PathBuf> {
    if let Some(arg) = std::env::args().nth(1) {
        let p = PathBuf::from(arg);
        return p.exists().then_some(p);
    }
    let here = std::env::current_exe().ok()?;
    let candidate = here.parent()?.join("nova-m10-day41-hostile-app");
    candidate.exists().then_some(candidate)
}

fn run_plain(bin: &PathBuf, victim: &PathBuf) -> RunResult {
    let mut cmd = Command::new(bin);
    cmd.arg(victim).stdout(Stdio::piped()).stderr(Stdio::piped());
    match cmd.output() {
        Ok(out) => parse(&String::from_utf8_lossy(&out.stdout)),
        Err(e) => RunResult { escapes: 0, lines: vec![format!("control run failed to start: {e}")] },
    }
}

fn run_isolated(spec: &IsolationSpec, bin: &PathBuf, victim: &PathBuf) -> Result<RunResult, IsolationError> {
    let mut cmd = Command::new(bin);
    cmd.arg(victim).stdout(Stdio::piped()).stderr(Stdio::piped());
    let child = spec.spawn(cmd)?;
    let out = child.wait_with_output().map_err(IsolationError::Spawn)?;
    Ok(parse(&String::from_utf8_lossy(&out.stdout)))
}

fn parse(stdout: &str) -> RunResult {
    let lines: Vec<String> = stdout.lines().map(|l| l.to_string()).collect();
    let escapes = lines
        .iter()
        .find_map(|l| l.strip_prefix("ESCAPES=").and_then(|n| n.trim().parse::<usize>().ok()))
        .unwrap_or_else(|| lines.iter().filter(|l| l.contains("=escaped")).count());
    RunResult { escapes, lines }
}
