//! Day 42 acceptance test — the literal Definition of Done:
//!
//! > An unauthorized process attempting to connect to another app's IPC
//! > channel is rejected and the attempt is logged.
//!
//! Both halves are checked, and so is the capability refinement the
//! same day's task list asks for. Nothing here is simulated: the
//! sockets are real `socketpair` endpoints, the credentials come from
//! the kernel via `SO_PEERCRED`, and the log entries are read back out
//! of a real `nova-log` `Logger` after the fact.
//!
//! The one thing that cannot be done inside a single unprivileged test
//! process is *become a second uid* — so the "unauthorized process" is
//! modelled by registering this process's real uid under the attacker's
//! app id and pointing it at a different app's channel. The rejection
//! path exercised is byte-for-byte the one a genuinely separate process
//! would hit, because the decision is made from the kernel's answer
//! about the peer, not from anything this process says about itself.

use nova_capability::{CapabilityError, CapabilityIssuer};
use nova_identity::IdentityRegistry;
use nova_ipc::Permission;
use nova_log::Logger;
use nova_secure_ipc::{Authenticator, IpcAuthError};
use std::os::unix::net::UnixStream;
use std::process::ExitCode;

const EVIL: &str = "org.nova.evil";
const VICTIM: &str = "org.nova.victim";
const CAMERA: &str = "org.nova.camera";
const MESSAGES: &str = "org.nova.messages";

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 42 acceptance: capabilities & authenticated IPC ===\n");
    let mut checks: Vec<Check> = Vec::new();

    // SAFETY: getuid cannot fail and touches no memory.
    let uid = unsafe { libc::getuid() };

    let mut registry = IdentityRegistry::new();
    registry.reserve(EVIL, uid).expect("reserve attacker identity");
    registry.allocate(VICTIM).expect("allocate victim identity");
    registry.allocate(CAMERA).expect("allocate camera identity");
    registry.allocate(MESSAGES).expect("allocate messages identity");

    println!("This process is uid {uid}, registered as {EVIL}.");
    println!("{VICTIM} exists as a separate identity with its own channel.\n");

    // --- Part 1: the IPC boundary. ------------------------------------
    let (client, _server) = UnixStream::pair().expect("socketpair");
    let auth = Authenticator::new(&registry).with_logger(Logger::new());

    let result = auth.authorize_channel(&client, VICTIM);
    checks.push(match &result {
        Err(e @ IpcAuthError::WrongApp { actual, claimed, .. })
            if actual.as_str() == EVIL && claimed.as_str() == VICTIM =>
        {
            Check {
                name: "connection to another app's channel is rejected",
                passed: true,
                detail: format!("rejected: {e}"),
            }
        }
        Err(e) => Check {
            name: "connection to another app's channel is rejected",
            passed: false,
            detail: format!("rejected, but not as an impersonation: {e}"),
        },
        Ok(_) => Check {
            name: "connection to another app's channel is rejected",
            passed: false,
            detail: "ACCEPTED — this is an IPC impersonation hole".into(),
        },
    });

    let recorded = auth.recorded();
    checks.push(Check {
        name: "the rejected attempt is logged",
        passed: recorded.len() == 1 && recorded[0].contains(EVIL) && recorded[0].contains(VICTIM),
        detail: if recorded.is_empty() {
            "nothing was logged".to_string()
        } else {
            format!("{} entry/entries; first: {}", recorded.len(), recorded[0])
        },
    });

    // A lying Hello: the message claims to be the Camera app.
    let lying = auth.verify_hello_claim(&client, CAMERA);
    checks.push(Check {
        name: "a Hello claiming another app id is refused",
        passed: matches!(lying, Err(IpcAuthError::WrongApp { .. })),
        detail: match &lying {
            Ok(_) => "ACCEPTED — the app id in a message is still being believed".into(),
            Err(e) => format!("refused: {e}"),
        },
    });

    // Control: telling the truth still works. Without this, "everything
    // is rejected" would look like a pass.
    let honest = auth.authorize_channel(&client, EVIL);
    checks.push(Check {
        name: "control: the channel's real owner is still admitted",
        passed: honest.is_ok(),
        detail: match &honest {
            Ok(p) => format!("admitted as {} (pid {})", p.identity.app_id, p.credentials.pid),
            Err(e) => format!("FAILED: {e}"),
        },
    });

    checks.push(Check {
        name: "control: successful authentications are not logged as rejections",
        passed: auth.recorded().len() == 2,
        detail: format!("{} rejection(s) recorded across 2 failed and 1 successful attempt", auth.recorded().len()),
    });

    // --- Part 2: the capability refinement. ---------------------------
    println!("Capabilities:");
    let issuer = CapabilityIssuer::new(b"acceptance-test key; App Manager reads 32 bytes from getrandom(2)".to_vec());
    let t0 = 1_000_000u64;
    let camera_cap = issuer.issue_at(CAMERA, Permission::Camera, 600, t0);
    println!("  issued to {CAMERA}: camera, ttl 600s, tag {}", camera_cap.tag_hex());

    checks.push(Check {
        name: "a genuine capability verifies for its holder",
        passed: issuer.verify_at(&camera_cap, CAMERA, t0 + 10).is_ok(),
        detail: "verified".into(),
    });

    let mut forged = camera_cap.clone();
    forged.permission = Permission::Microphone;
    checks.push(Check {
        name: "widening a capability by editing it breaks the tag",
        passed: issuer.verify_at(&forged, CAMERA, t0 + 10) == Err(CapabilityError::BadTag),
        detail: "camera -> microphone rejected as a forgery".into(),
    });

    let stolen = issuer.verify_at(&camera_cap, EVIL, t0 + 10);
    checks.push(Check {
        name: "a stolen capability is useless to another app",
        passed: stolen == Err(CapabilityError::WrongApp),
        detail: format!("{EVIL} presenting {CAMERA}'s token: {stolen:?}"),
    });

    let delegated = issuer.delegate_at(&camera_cap, CAMERA, MESSAGES, 30, t0);
    checks.push(match &delegated {
        Ok(child) => Check {
            name: "delegation attenuates: same permission, shorter life, one less hop",
            passed: child.permission == camera_cap.permission
                && child.expires_at <= camera_cap.expires_at
                && child.delegations_left < camera_cap.delegations_left,
            detail: format!(
                "{MESSAGES} holds camera until {} (parent until {}), {} further delegation(s) allowed",
                child.expires_at, camera_cap.expires_at, child.delegations_left
            ),
        },
        Err(e) => Check {
            name: "delegation attenuates: same permission, shorter life, one less hop",
            passed: false,
            detail: format!("delegation failed: {e}"),
        },
    });

    checks.push(Check {
        name: "a delegation cannot outlive its parent",
        passed: issuer.delegate_at(&camera_cap, CAMERA, MESSAGES, 100_000, t0)
            == Err(CapabilityError::ExpiryExtension),
        detail: "a 100000s child of a 600s parent was refused".into(),
    });

    checks.push(Check {
        name: "expiry is enforced",
        passed: matches!(issuer.verify_at(&camera_cap, CAMERA, t0 + 601), Err(CapabilityError::Expired { .. })),
        detail: "the same token is refused one second past its expiry".into(),
    });

    let mut revoking = CapabilityIssuer::new(b"acceptance-test key; App Manager reads 32 bytes from getrandom(2)".to_vec());
    let doomed = revoking.issue_at(CAMERA, Permission::Camera, 600, t0);
    revoking.revoke_all();
    checks.push(Check {
        name: "revocation invalidates outstanding capabilities immediately",
        passed: revoking.verify_at(&doomed, CAMERA, t0 + 10) == Err(CapabilityError::Revoked),
        detail: "an unexpired token minted before the epoch bump is refused".into(),
    });

    // --- Verdict. -----------------------------------------------------
    println!("\nChecks:");
    let mut failures = 0;
    for check in &checks {
        if check.passed {
            println!("  [PASS] {}\n         {}", check.name, check.detail);
        } else {
            failures += 1;
            println!("  [FAIL] {}\n         {}", check.name, check.detail);
        }
    }

    println!();
    if failures == 0 {
        println!("Day 42 acceptance: PASS ({} checks)", checks.len());
        ExitCode::SUCCESS
    } else {
        println!("Day 42 acceptance: FAIL ({failures} of {} checks failed)", checks.len());
        ExitCode::FAILURE
    }
}
