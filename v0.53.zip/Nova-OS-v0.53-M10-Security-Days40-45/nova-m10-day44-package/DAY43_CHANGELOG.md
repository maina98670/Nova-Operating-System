# Nova OS Day 43 — Signed packages + package verification

M10 (Security), v0.53. Continues directly from the Day 42 package.

## Definition of Done

> An unsigned or tampered `.npkg` is rejected at install time with a clear error; a correctly signed package installs normally.

## New in this package

- `libs/nova-package-sign`
- `tools/nova-m10-day43-package-signing-acceptance-test`
- `docs/M10-SECURITY-DAY43.md`
- `docs/package-signing-v1.md`

## Unchanged

Everything from the previous package is carried forward as-is, except
for the workspace member list and the retrofits named above. No earlier
day's behaviour was replaced.
