# M10 — Day 43: Signed packages + package verification

**Focus.** Package signing in the toolchain from M6, verification at
install time.

**Delivered.** `libs/nova-package-sign` — a signature trailer appended to
an unmodified `.npkg` (so every Day 22 package stays parseable), signed
over a domain-separated digest that includes the key id, verified against
a device keystore. `nova keygen` and `nova sign` in the SDK CLI;
`nova install` now verifies before it unpacks, and refuses unsigned
packages unless explicitly overridden.

**DoD.** *An unsigned or tampered `.npkg` is rejected at install time
with a clear error; a correctly signed package installs normally.*
`tools/nova-m10-day43-package-signing-acceptance-test` runs every case
through the real install gate and confirms a rejected package leaves
nothing on disk — including the case that matters most: a still-valid
package with a substituted binary and the genuine signature re-attached.

**Honest note.** The scheme is symmetric. It proves integrity and key
possession, not publisher identity to a third party. That is sufficient
for install-time verification today and insufficient for M11's
repository; `docs/package-signing-v1.md` records it with an owner.
