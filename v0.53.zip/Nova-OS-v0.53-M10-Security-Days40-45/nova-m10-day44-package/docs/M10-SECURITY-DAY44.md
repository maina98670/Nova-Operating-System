# M10 — Day 44: Secure-boot strategy + security logging

**Focus.** Document (and implement where the hardware allows) a
secure-boot approach; log security-relevant events distinctly through
M4's logging subsystem.

**Delivered.**
* `libs/nova-seclog` — a separate security event channel: its own file,
  its own query API (by kind, principal, severity, time, outcome), built
  on `nova-log`'s record conventions and `nova-fsmgr`'s append path
  rather than beside them. Hash-chained, so an altered or deleted record
  is detectable and locatable.
* `docs/secure-boot-strategy-v1.md` — the five-stage chain of trust,
  what Nova enforces today (stage 4 only, and it is real), what waits
  for M12's device, rollback protection, and recovery.
* Retrofit wiring: Day 40's `Enforcer` and Day 42's `Authenticator` now
  route their refusals into the security channel.

**DoD.** *Security events are queryable separately from general
application logs; the secure-boot strategy document exists even if full
hardware enforcement waits for M12's specific device.* Both checked by
`tools/nova-m10-day44-security-logging-acceptance-test`, which produces
its events from real Day 40 and Day 42 violations rather than inventing
them, and confirms the document contains the sections it needs to be
worth having.

**Honest note.** The chain gives evidence of tampering, not prevention.
Root can truncate the tail and re-chain what remains; detecting that
needs an anchor Nova does not control.
