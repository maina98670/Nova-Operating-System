# Nova package signing, v1

Day 43 (M10, v0.53). Implemented in `libs/nova-package-sign`.

`nova-package-format`'s own documentation said signing was M11's job.
The Build Guide moved it here, and that was the right call: M11 builds a
package *repository*, and a repository whose packages cannot be verified
is Section 20's "app ecosystem before security is mature" risk with a
schedule attached.

## Wire format

A signature is a trailer appended to an unmodified `.npkg`. Nothing about
Day 22's format changes, and `nova_package_format::unpack` never learns
that signatures exist.

```text
<unmodified .npkg bytes>          <- the payload the signature covers
algorithm    1 byte               1 = HMAC-SHA256, 2 = Ed25519 (reserved)
key_id_len   1 byte
key_id       key_id_len bytes     UTF-8, e.g. "nova-dev-2026"
sig_len      2 bytes  LE
sig          sig_len bytes
block_len    4 bytes  LE          whole trailer, including this field and the magic
magic        8 bytes  = "NPKGSIG1"
```

Read backwards from the end: the magic is at a fixed offset from EOF and
`block_len` sits beside it, so "is this signed?" costs 12 bytes and no
parsing.

Signed bytes are **not** the raw package. They are:

```text
"nova-package-signature-v1" || u32_le(len(key_id)) || key_id || SHA-256(payload)
```

Two properties come from that shape, and both were bugs waiting to happen
without it:

* The domain prefix means a tag minted for a package can never be
  mistaken for a tag minted for a capability (`nova-capability` uses its
  own prefix) even under the same key.
* The key id is *inside* the signed data, so a genuine signature cannot
  be relabelled as coming from a different, trusted key. There is a test
  for exactly this attack.

## Trust model

The algorithm is **HMAC-SHA256: symmetric**. Verification proves two
things, honestly:

1. the bytes have not changed since signing, and
2. whoever signed held the key named by `key_id`.

It does **not** prove publisher identity to a third party, because anyone
who can verify can also sign. The device holds the same bytes the build
machine does. `nova keygen` writes the two halves to separate files and
says so on stdout, and the keystore is written `0600`, because in this
scheme the keystore is a secret.

For Nova today that boundary is real and sufficient: the attack it stops
is a tampered or substituted package arriving at install time, and it
stops it.

It is **not** sufficient for M11. A repository has mutually distrusting
publishers, and a device must be able to verify a publisher's signature
without being able to forge one. That needs a public-key scheme.

### Ed25519: reserved, not implemented

Algorithm id 2 is reserved in the format so the trailer does not have to
change when this lands. A package claiming it today is rejected with
`UnsupportedAlgorithm` — never treated as unsigned, never accepted.

Why it is not implemented here, plainly: `nova-crypto` is hand-written
and dependency-free, which is defensible for SHA-256 and HMAC (short,
fully specified, published test vectors) and not defensible for
constant-time curve arithmetic. An unreviewed Ed25519 written under
schedule pressure would be worse than the symmetric scheme it replaced,
because it would *look* like the stronger thing.

**Owner: M11 (Package Ecosystem, Days 46-49).** M11 cannot ship a
repository without it. The choice there is a reviewed implementation or a
vetted dependency, and that is a decision to make with the repository's
requirements in hand, not in advance.

## Developer workflow

Day 43 changes a workflow that used to work, so the error message from
`nova install` points here rather than just failing.

```bash
nova keygen --key-id nova-dev-2026 --out ~/.nova/signing.key
nova build my_app
nova package my_app
nova sign my_app.npkg --key ~/.nova/signing.key
nova install my_app.npkg --keystore ~/.nova/signing.key.trusted.tsv
```

`nova install --allow-unsigned` exists and prints a warning every time.
It is for bisecting a build problem, not for daily use; on a real device
image it should not be reachable, and M15's update system must never
invoke it.

## What signing does not do

* It says nothing about what the app *does* once installed. A genuinely
  signed malicious app is still malicious — Days 40-42's sandbox is what
  bounds that, not this.
* It does not protect a package already on disk. Verification happens at
  install; an attacker who can rewrite `/apps/<id>/bin/*` afterwards has
  already defeated Day 40's ownership model, which is the layer that
  should stop them.
* It provides no freshness guarantee. See "Rollback protection" in
  `secure-boot-strategy-v1.md`.
