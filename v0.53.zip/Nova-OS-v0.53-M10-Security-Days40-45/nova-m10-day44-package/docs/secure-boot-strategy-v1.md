# Nova secure-boot strategy, v1

Day 44 (M10, v0.53). Status: **strategy documented; enforcement partial.**
The Day 44 row says so explicitly — "document (and where feasible on the
target hardware, implement) a secure-boot approach" — because there is no
target hardware yet. M12 chooses the reference device; until it does, the
parts of this chain that depend on a specific bootloader and a specific
key-storage mechanism cannot be implemented, only specified.

This document says which parts are which. Nothing below is described as
working unless it works today.

## Chain of trust

Each stage verifies the next before handing control to it. A stage that
cannot verify the next one stops; it does not continue with a warning.

| # | Stage | Verifies | Where the verification key lives | Status |
|---|-------|----------|----------------------------------|--------|
| 0 | SoC boot ROM | the bootloader | fused into the SoC | device-specific, M12 |
| 1 | Bootloader | kernel + DTB | bootloader-held public key | device-specific, M12 |
| 2 | Linux kernel | the initramfs / rootfs image | kernel keyring (dm-verity root hash) | device-specific, M12 |
| 3 | Nova init | the `/system` partition | root hash from stage 2 | design fixed, M12 to enable |
| 4 | Nova App Manager | every installed `.npkg` | `/etc/nova/keys/trusted.tsv` | **implemented, Day 43** |

Stage 4 is the only one that is real today, and it is real: `nova install`
refuses an unsigned or altered package before touching the filesystem, and
`nova-m10-day43-package-signing-acceptance-test` demonstrates it against a
substituted binary carrying a genuine signature.

## What Nova can enforce today

* **Package authenticity at install time** (stage 4). Day 43.
* **No new privileges for anything Nova launches.** Day 41 sets
  `PR_SET_NO_NEW_PRIVS` before installing a seccomp filter, so a setuid
  binary inside a sandbox cannot be a way back out.
* **A tamper-evident record of verification failures.** Day 44's
  `SecurityEventKind::SecureBootFailure` exists and is `Critical` by
  default; nothing emits it yet, because nothing below stage 4 verifies
  anything yet. It is present so the plumbing does not have to change
  when M12 wires up stages 0-3.

Stating this plainly: on a development machine or in QEMU today, Nova
boots an unverified kernel from an unverified image. Every claim above
stage 4 is a design, not a protection.

## What waits for M12

* Fusing or provisioning a verification key on the reference device, and
  whether that device's bootloader can be locked at all. Some phones in
  the 1GB-2GB class Section 21 targets ship with bootloaders that cannot
  be re-locked with a third-party key. **If the device chosen in M12 is
  one of those, stages 0-1 are not achievable on it** and this document
  will need to say so rather than the project quietly pretending
  otherwise. That is a selection criterion for M12, recorded here so it
  is considered before the device is bought, not after.
* dm-verity for `/system`, including where the root hash is stored and
  who signs it.
* Whether Nova ships with verified boot enforcing or logging-only on
  first hardware. Logging-only is the honest starting point: an enforcing
  chain that nobody has yet booted through is a very effective way to
  brick a reference device.

## Rollback protection

A signature proves a package is genuine. It does not prove it is
*current* — a correctly signed, genuinely-Nova, six-months-old package
with a known vulnerability verifies perfectly.

Design (not yet implemented): a monotonic version counter per app,
persisted alongside the identity table, refusing an install whose version
is lower than the recorded one unless the user explicitly downgrades from
Settings. The counter must be written somewhere an app cannot reach —
`/var/lib/nova` is owned by the system identity (Day 40), which is the
necessary condition already in place.

Owner: M15 (Power, Recovery & Update System), which is where update
policy lives. Referenced here so it is not lost between milestones.

## Recovery

Secure boot and recovery pull against each other: the stricter the chain,
the more ways there are to make a device that will not boot and cannot be
fixed. Section 20's risk list names this directly ("no recovery/rollback
path for experimental phone builds").

Requirements this strategy imposes on M15's recovery work:

1. A recovery path that does not depend on the main `/system` image
   verifying — otherwise a failed update is unrecoverable.
2. A documented, deliberate way for a developer to run an unverified
   build on their own device, which is *visibly* different from a
   verified one (Nova's About screen must report it). A debug mode that
   looks identical to a production one is how developer builds end up in
   users' hands.
3. Recovery-mode entry must itself be logged to the security log, since
   "someone entered recovery" is exactly the event an investigation needs.

## Open questions, honestly listed

* Key storage on a device without a TEE or secure element — likely for
  this price class. The fallback is a key in the `/system` image, which
  protects against a remote attacker and not against someone holding the
  phone.
* Whether Nova's package keys should be per-vendor or one Nova key. M11's
  repository forces this decision, and it needs Ed25519 first (see
  `package-signing-v1.md`).
