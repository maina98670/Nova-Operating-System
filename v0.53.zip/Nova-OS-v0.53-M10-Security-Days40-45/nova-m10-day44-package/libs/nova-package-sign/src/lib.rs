//! `.npkg` signing and install-time verification — M10 Day 43.
//!
//! `nova-package-format`'s own module doc says it plainly: "No
//! checksum, no signature — package integrity/signing is M11's job."
//! The Build Guide moved that forward to here, and it was right to:
//! M11 builds a package *repository*, and shipping a repository before
//! the packages it serves can be verified is the "app ecosystem before
//! security is mature" risk from Section 20's list.
//!
//! ## What is added
//!
//! A signature block appended to an existing `.npkg`. Appending rather
//! than changing the format means every `.npkg` produced by Day 22's
//! `nova package` is still a valid, parseable package — a signed
//! package is an unsigned one plus a trailer, and `unpack` never has to
//! learn about signatures.
//!
//! ```text
//! <unmodified .npkg bytes>            <- the payload the signature covers
//! algorithm    1 byte
//! key_id_len   1 byte
//! key_id       key_id_len bytes       (UTF-8, e.g. "nova-dev-2026")
//! sig_len      2 bytes  LE
//! sig          sig_len bytes
//! block_len    4 bytes  LE            (whole trailer, including this field and the magic)
//! magic        8 bytes  = b"NPKGSIG1"
//! ```
//!
//! The trailer is read backwards from the end of the file, which is why
//! `block_len` sits next to the magic: with a fixed-position magic at
//! the very end, "is this signed?" is answerable by reading 12 bytes,
//! without parsing the package at all.
//!
//! ## The trust model, stated rather than implied
//!
//! The signature is **HMAC-SHA256**: symmetric. Verifying a package
//! proves two things honestly — the bytes have not been altered since
//! signing, and whoever signed it held the key named by `key_id`. It
//! does **not** prove publisher identity to a third party, because
//! anyone who can verify can also sign. For Nova today that is a real
//! and sufficient boundary: the key lives on the build machine, the
//! device holds it only to verify, and the attack it stops — a tampered
//! or substituted package arriving at install time — is stopped.
//!
//! It is not sufficient for M11's repository, where mutually distrusting
//! publishers need signatures a device can verify without being able to
//! forge. That needs Ed25519 (or equivalent), and the honest reason it
//! is not here is in `nova-crypto`'s module doc: hand-writing
//! constant-time curve arithmetic, unreviewed, would be worse than
//! naming the gap. [`SignatureAlgorithm::Ed25519`] is reserved in the
//! format so the trailer does not have to change when it arrives;
//! `docs/package-signing-v1.md` and `docs/security-model-v1.md` both
//! carry this as a named, owned limitation.

use nova_crypto::{constant_time_eq, from_hex, hmac_sha256, sha256, to_hex};
use std::collections::BTreeMap;
use std::fs;
use std::io::Read;
use std::os::unix::fs::PermissionsExt;
use std::path::Path;

pub const SIGNATURE_MAGIC: &[u8; 8] = b"NPKGSIG1";
/// Domain separation: a tag computed for a package can never be
/// mistaken for a tag computed for a capability (`nova-capability`
/// prefixes its own bytes differently), even under the same key.
const SIGNING_DOMAIN: &[u8] = b"nova-package-signature-v1";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum SignatureAlgorithm {
    HmacSha256 = 1,
    /// Reserved, not implemented. Present so the wire format is stable
    /// across the change rather than versioned again later. A package
    /// claiming this algorithm is rejected with
    /// [`PackageVerifyError::UnsupportedAlgorithm`], never treated as
    /// unsigned and never silently accepted.
    Ed25519 = 2,
}

impl SignatureAlgorithm {
    fn from_u8(v: u8) -> Option<Self> {
        match v {
            1 => Some(SignatureAlgorithm::HmacSha256),
            2 => Some(SignatureAlgorithm::Ed25519),
            _ => None,
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            SignatureAlgorithm::HmacSha256 => "hmac-sha256",
            SignatureAlgorithm::Ed25519 => "ed25519 (reserved, not implemented)",
        }
    }
}

#[derive(Debug)]
pub enum PackageVerifyError {
    /// No signature trailer at all. Kept distinct from a *bad*
    /// signature because the two mean different things to whoever is
    /// reading the error: one is a package that was never signed, the
    /// other is a package that was signed and then altered.
    Unsigned,
    /// There is a trailer, but it does not parse. Treated as hostile,
    /// not as unsigned.
    MalformedSignature(&'static str),
    UnsupportedAlgorithm(u8),
    /// Signed by a key this device does not trust.
    UntrustedKey(String),
    /// The key is trusted and the bytes do not match it.
    BadSignature { key_id: String },
    /// The signature verified, but what it covers is not a package.
    NotAPackage(String),
    Io(String),
}

impl std::fmt::Display for PackageVerifyError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PackageVerifyError::Unsigned => write!(
                f,
                "package is not signed (no NPKGSIG1 trailer). Nova refuses unsigned packages at install time"
            ),
            PackageVerifyError::MalformedSignature(why) => {
                write!(f, "package signature block is malformed: {why}")
            }
            PackageVerifyError::UnsupportedAlgorithm(a) => {
                write!(f, "package is signed with unsupported algorithm id {a}")
            }
            PackageVerifyError::UntrustedKey(k) => {
                write!(f, "package is signed by key '{k}', which is not in this device's keystore")
            }
            PackageVerifyError::BadSignature { key_id } => write!(
                f,
                "package signature does not match key '{key_id}' — the package has been altered since it was signed"
            ),
            PackageVerifyError::NotAPackage(e) => write!(f, "signature verified but the contents are not a .npkg: {e}"),
            PackageVerifyError::Io(e) => write!(f, "io: {e}"),
        }
    }
}

impl std::error::Error for PackageVerifyError {}

/// A secret used to sign. Never written to a device image; lives on the
/// build machine.
#[derive(Clone)]
pub struct SigningKey {
    pub key_id: String,
    secret: Vec<u8>,
}

impl std::fmt::Debug for SigningKey {
    /// The secret is deliberately not in the `Debug` output. A key that
    /// ends up in a log because someone debug-printed a struct is a
    /// mundane and very common way to lose one.
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "SigningKey {{ key_id: {:?}, secret: <{} bytes redacted> }}", self.key_id, self.secret.len())
    }
}

impl SigningKey {
    pub fn new(key_id: impl Into<String>, secret: Vec<u8>) -> Self {
        SigningKey { key_id: key_id.into(), secret }
    }

    /// 32 bytes from `/dev/urandom`. Read directly rather than through
    /// a crate: this is the one place Nova needs randomness outside the
    /// kernel's own use of it, and the file interface is the same
    /// interface `getrandom(2)` is a faster path to.
    pub fn generate(key_id: impl Into<String>) -> std::io::Result<Self> {
        let mut secret = vec![0u8; 32];
        let mut f = fs::File::open("/dev/urandom")?;
        f.read_exact(&mut secret)?;
        Ok(SigningKey { key_id: key_id.into(), secret })
    }

    pub fn from_hex(key_id: impl Into<String>, hex: &str) -> Option<Self> {
        Some(SigningKey { key_id: key_id.into(), secret: from_hex(hex.trim())? })
    }

    pub fn secret_hex(&self) -> String {
        to_hex(&self.secret)
    }

    pub fn public_half(&self) -> TrustedKey {
        // Symmetric: the "public half" is the same bytes. This method
        // exists to make the asymmetry-shaped API available now, so
        // switching to Ed25519 later changes this function's body
        // rather than every caller.
        TrustedKey { key_id: self.key_id.clone(), material: self.secret.clone() }
    }
}

#[derive(Debug, Clone)]
pub struct TrustedKey {
    pub key_id: String,
    material: Vec<u8>,
}

/// The set of keys a device will accept packages from.
#[derive(Debug, Default, Clone)]
pub struct Keystore {
    keys: BTreeMap<String, Vec<u8>>,
}

impl Keystore {
    pub fn new() -> Self {
        Keystore { keys: BTreeMap::new() }
    }

    pub fn trust(&mut self, key: TrustedKey) {
        self.keys.insert(key.key_id, key.material);
    }

    pub fn key_ids(&self) -> Vec<String> {
        self.keys.keys().cloned().collect()
    }

    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }

    /// Loads `key_id<TAB>hex` lines. Same tab-separated convention as
    /// the rest of Nova's on-disk state.
    pub fn load(path: &Path) -> Result<Self, PackageVerifyError> {
        let text = fs::read_to_string(path).map_err(|e| PackageVerifyError::Io(e.to_string()))?;
        let mut store = Keystore::new();
        for (i, line) in text.lines().enumerate() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let mut parts = line.split('\t');
            let (Some(id), Some(hex)) = (parts.next(), parts.next()) else {
                return Err(PackageVerifyError::Io(format!("{}: line {} is not key_id<TAB>hex", path.display(), i + 1)));
            };
            let material = from_hex(hex)
                .ok_or_else(|| PackageVerifyError::Io(format!("{}: line {} has non-hex key material", path.display(), i + 1)))?;
            store.keys.insert(id.to_string(), material);
        }
        Ok(store)
    }

    pub fn save(&self, path: &Path) -> Result<(), PackageVerifyError> {
        let mut out = String::from("# Nova trusted package-signing keys: key_id<TAB>hex\n");
        for (id, material) in &self.keys {
            out.push_str(id);
            out.push('\t');
            out.push_str(&to_hex(material));
            out.push('\n');
        }
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| PackageVerifyError::Io(e.to_string()))?;
        }
        fs::write(path, out).map_err(|e| PackageVerifyError::Io(e.to_string()))?;
        // Symmetric keys: the verification material is also the signing
        // material, so the keystore is a secret and is written 0600.
        // When this becomes Ed25519 this line can relax; until then,
        // shipping it world-readable would be the whole trust model
        // leaking out through a file mode.
        let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o600));
        Ok(())
    }
}

/// The bytes a signature is computed over: a domain tag, the key id
/// (length-prefixed), and the payload digest. The key id is inside the
/// signed data so a valid signature cannot be relabelled as coming from
/// a different key.
fn signing_input(key_id: &str, payload: &[u8]) -> Vec<u8> {
    let digest = sha256(payload);
    let mut input = Vec::with_capacity(SIGNING_DOMAIN.len() + 4 + key_id.len() + digest.len());
    input.extend_from_slice(SIGNING_DOMAIN);
    input.extend_from_slice(&(key_id.len() as u32).to_le_bytes());
    input.extend_from_slice(key_id.as_bytes());
    input.extend_from_slice(&digest);
    input
}

/// Appends a signature trailer to `package`.
///
/// Signing an already-signed package replaces the existing trailer
/// rather than nesting one inside another — nesting would mean the
/// outer signature covering the inner one, and "which signature is
/// authoritative" is not a question a package format should be able
/// to raise.
pub fn sign(package: &[u8], key: &SigningKey) -> Vec<u8> {
    let payload = match split_signature(package) {
        Ok((payload, _)) => payload,
        Err(_) => package,
    };

    let tag = hmac_sha256(&key.secret, &signing_input(&key.key_id, payload));

    let key_id_bytes = key.key_id.as_bytes();
    let mut out = Vec::with_capacity(payload.len() + key_id_bytes.len() + tag.len() + 16);
    out.extend_from_slice(payload);

    let trailer_start = out.len();
    out.push(SignatureAlgorithm::HmacSha256 as u8);
    out.push(key_id_bytes.len() as u8);
    out.extend_from_slice(key_id_bytes);
    out.extend_from_slice(&(tag.len() as u16).to_le_bytes());
    out.extend_from_slice(&tag);
    let block_len = (out.len() - trailer_start + 4 + SIGNATURE_MAGIC.len()) as u32;
    out.extend_from_slice(&block_len.to_le_bytes());
    out.extend_from_slice(SIGNATURE_MAGIC);
    out
}

#[derive(Debug, Clone)]
pub struct Signature {
    pub algorithm: SignatureAlgorithm,
    pub key_id: String,
    pub tag: Vec<u8>,
}

/// True if there is a well-formed trailer at the end. Cheap enough to
/// call before reading a whole package.
pub fn is_signed(data: &[u8]) -> bool {
    split_signature(data).is_ok()
}

fn split_signature(data: &[u8]) -> Result<(&[u8], Signature), PackageVerifyError> {
    let magic_len = SIGNATURE_MAGIC.len();
    if data.len() < magic_len + 4 {
        return Err(PackageVerifyError::Unsigned);
    }
    if &data[data.len() - magic_len..] != SIGNATURE_MAGIC {
        return Err(PackageVerifyError::Unsigned);
    }
    let len_at = data.len() - magic_len - 4;
    let block_len = u32::from_le_bytes([data[len_at], data[len_at + 1], data[len_at + 2], data[len_at + 3]]) as usize;
    if block_len < magic_len + 4 + 4 || block_len > data.len() {
        return Err(PackageVerifyError::MalformedSignature("trailer length is out of range"));
    }

    let start = data.len() - block_len;
    let payload = &data[..start];
    let mut pos = start;

    let algorithm = SignatureAlgorithm::from_u8(data[pos])
        .ok_or(PackageVerifyError::UnsupportedAlgorithm(data[pos]))?;
    pos += 1;

    let key_id_len = data[pos] as usize;
    pos += 1;
    if pos + key_id_len > len_at {
        return Err(PackageVerifyError::MalformedSignature("key id runs past the trailer"));
    }
    let key_id = std::str::from_utf8(&data[pos..pos + key_id_len])
        .map_err(|_| PackageVerifyError::MalformedSignature("key id is not UTF-8"))?
        .to_string();
    pos += key_id_len;

    if pos + 2 > len_at {
        return Err(PackageVerifyError::MalformedSignature("signature length runs past the trailer"));
    }
    let sig_len = u16::from_le_bytes([data[pos], data[pos + 1]]) as usize;
    pos += 2;
    if pos + sig_len != len_at {
        return Err(PackageVerifyError::MalformedSignature("signature length does not match the trailer size"));
    }
    let tag = data[pos..pos + sig_len].to_vec();

    Ok((payload, Signature { algorithm, key_id, tag }))
}

/// Reads the signature without checking it. For `nova inspect`-style
/// reporting only — never as a substitute for [`verify`].
pub fn describe(data: &[u8]) -> Result<Signature, PackageVerifyError> {
    split_signature(data).map(|(_, sig)| sig)
}

#[derive(Debug, Clone)]
pub struct VerifiedPackage {
    /// The original, unmodified `.npkg` bytes, ready for
    /// `nova_package_format::unpack`.
    pub payload: Vec<u8>,
    pub key_id: String,
    pub algorithm: SignatureAlgorithm,
}

/// Verifies a signed package against the device's keystore.
///
/// Note the order and what each step refuses:
/// a missing trailer is `Unsigned`; an unknown key is `UntrustedKey`
/// *before* any comparison; a mismatch is `BadSignature`. Returning one
/// generic "invalid package" for all three would be less useful to the
/// person holding the failing package and no safer — none of these
/// distinctions tell an attacker anything they did not already know
/// about their own file.
pub fn verify(data: &[u8], keystore: &Keystore) -> Result<VerifiedPackage, PackageVerifyError> {
    let (payload, signature) = split_signature(data)?;

    if signature.algorithm != SignatureAlgorithm::HmacSha256 {
        return Err(PackageVerifyError::UnsupportedAlgorithm(signature.algorithm as u8));
    }

    let Some(material) = keystore.keys.get(&signature.key_id) else {
        return Err(PackageVerifyError::UntrustedKey(signature.key_id));
    };

    let expected = hmac_sha256(material, &signing_input(&signature.key_id, payload));
    if !constant_time_eq(&expected, &signature.tag) {
        return Err(PackageVerifyError::BadSignature { key_id: signature.key_id });
    }

    Ok(VerifiedPackage { payload: payload.to_vec(), key_id: signature.key_id, algorithm: signature.algorithm })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn package() -> Vec<u8> {
        // A real .npkg, built by the real packer.
        nova_package_format::pack(
            b"id = \"org.nova.test\"\nname = \"Test\"\nentry_point = \"bin/test\"\n",
            b"\x7fELF fake binary contents",
        )
    }

    fn keyed() -> (SigningKey, Keystore) {
        let key = SigningKey::new("nova-dev-2026", b"a 32-byte-ish test signing secret".to_vec());
        let mut store = Keystore::new();
        store.trust(key.public_half());
        (key, store)
    }

    /// The literal Day 43 DoD, the positive half.
    #[test]
    fn day43_a_correctly_signed_package_verifies_and_unpacks() {
        let (key, store) = keyed();
        let signed = sign(&package(), &key);

        let verified = verify(&signed, &store).expect("must verify");
        assert_eq!(verified.key_id, "nova-dev-2026");
        // And what comes out is byte-identical to the original package.
        assert_eq!(verified.payload, package());
        let (manifest, binary) = nova_package_format::unpack(&verified.payload).expect("must unpack");
        assert!(String::from_utf8_lossy(&manifest).contains("org.nova.test"));
        assert_eq!(binary, b"\x7fELF fake binary contents");
    }

    /// The literal Day 43 DoD, the negative halves.
    #[test]
    fn day43_an_unsigned_package_is_rejected() {
        let (_key, store) = keyed();
        assert!(matches!(verify(&package(), &store), Err(PackageVerifyError::Unsigned)));
    }

    #[test]
    fn day43_a_tampered_package_is_rejected() {
        let (key, store) = keyed();
        let signed = sign(&package(), &key);

        // Flip one byte of the payload — anywhere.
        for position in [0usize, 10, 40, 60] {
            if position >= signed.len() {
                continue;
            }
            let mut tampered = signed.clone();
            tampered[position] ^= 0x01;
            match verify(&tampered, &store) {
                Err(PackageVerifyError::BadSignature { .. })
                | Err(PackageVerifyError::Unsigned)
                | Err(PackageVerifyError::MalformedSignature(_))
                | Err(PackageVerifyError::UnsupportedAlgorithm(_))
                | Err(PackageVerifyError::UntrustedKey(_)) => {}
                Ok(_) => panic!("a package with byte {position} flipped still verified"),
                Err(e) => panic!("unexpected error for byte {position}: {e}"),
            }
        }
    }

    /// The interesting tamper: replace the *binary* while keeping a
    /// well-formed package. This is the real attack — a package that
    /// still unpacks perfectly and installs a different program.
    #[test]
    fn a_substituted_binary_is_caught() {
        let (key, store) = keyed();
        let signed = sign(&package(), &key);
        let (_, sig) = split_signature(&signed).unwrap();

        let malicious = nova_package_format::pack(
            b"id = \"org.nova.test\"\nname = \"Test\"\nentry_point = \"bin/test\"\n",
            b"\x7fELF MALICIOUS payload!!!!",
        );
        // Re-attach the original, genuine signature to the new payload.
        let mut forged = malicious;
        forged.push(SignatureAlgorithm::HmacSha256 as u8);
        forged.push(sig.key_id.len() as u8);
        forged.extend_from_slice(sig.key_id.as_bytes());
        forged.extend_from_slice(&(sig.tag.len() as u16).to_le_bytes());
        forged.extend_from_slice(&sig.tag);
        let block_len = (1 + 1 + sig.key_id.len() + 2 + sig.tag.len() + 4 + SIGNATURE_MAGIC.len()) as u32;
        forged.extend_from_slice(&block_len.to_le_bytes());
        forged.extend_from_slice(SIGNATURE_MAGIC);

        assert!(
            matches!(verify(&forged, &store), Err(PackageVerifyError::BadSignature { .. })),
            "a genuine signature re-attached to different contents must not verify"
        );
    }

    #[test]
    fn a_package_signed_by_an_untrusted_key_is_rejected() {
        let (_key, store) = keyed();
        let stranger = SigningKey::new("someone-elses-key", b"not in this device's keystore".to_vec());
        let signed = sign(&package(), &stranger);
        match verify(&signed, &store) {
            Err(PackageVerifyError::UntrustedKey(id)) => assert_eq!(id, "someone-elses-key"),
            other => panic!("expected UntrustedKey, got {other:?}"),
        }
    }

    /// Relabelling: take a genuine signature and claim a different key
    /// id. Only works if the key id isn't inside the signed data.
    #[test]
    fn a_signature_cannot_be_relabelled_to_another_key_id() {
        // Two labels over the *same* secret, so the only difference
        // between them is the key id itself.
        let key_a = SigningKey::new("key-a", b"shared secret material".to_vec());
        let key_b = SigningKey::new("key-b", b"shared secret material".to_vec());
        let mut store = Keystore::new();
        store.trust(key_b.public_half());

        let signed_as_a = sign(&package(), &key_a);
        let signed_as_b = sign(&package(), &key_b);
        assert_ne!(
            describe(&signed_as_a).unwrap().tag,
            describe(&signed_as_b).unwrap().tag,
            "the key id must be covered by the signature"
        );

        // Now the actual attack: take a's signed package and rewrite
        // the label to "key-b" (same length, so the trailer stays
        // well-formed). The device trusts key-b, so if the key id were
        // outside the signed data this would verify.
        let mut relabelled = signed_as_a.clone();
        let label_at = package().len() + 2;
        relabelled[label_at..label_at + 5].copy_from_slice(b"key-b");
        assert!(
            matches!(verify(&relabelled, &store), Err(PackageVerifyError::BadSignature { .. })),
            "relabelling a signature to a trusted key id must not make it verify"
        );
    }

    #[test]
    fn signing_twice_replaces_rather_than_nests() {
        let (key, store) = keyed();
        let once = sign(&package(), &key);
        let twice = sign(&once, &key);
        assert_eq!(once, twice, "re-signing must be idempotent, not nested");
        assert_eq!(verify(&twice, &store).unwrap().payload, package());
    }

    #[test]
    fn the_reserved_algorithm_is_refused_not_ignored() {
        let (key, store) = keyed();
        let mut signed = sign(&package(), &key);
        let payload_len = package().len();
        signed[payload_len] = SignatureAlgorithm::Ed25519 as u8;
        assert!(matches!(verify(&signed, &store), Err(PackageVerifyError::UnsupportedAlgorithm(2))));
    }

    #[test]
    fn garbage_that_ends_in_the_magic_is_malformed_not_unsigned() {
        let mut data = vec![0xffu8; 64];
        data.extend_from_slice(&9_999_999u32.to_le_bytes());
        data.extend_from_slice(SIGNATURE_MAGIC);
        assert!(matches!(verify(&data, &Keystore::new()), Err(PackageVerifyError::MalformedSignature(_))));
    }

    #[test]
    fn is_signed_distinguishes_the_two_cases() {
        let (key, _) = keyed();
        assert!(!is_signed(&package()));
        assert!(is_signed(&sign(&package(), &key)));
    }

    #[test]
    fn keystore_round_trips_through_a_file() {
        let (key, _) = keyed();
        let path = std::env::temp_dir().join(format!("nova-keystore-{}.tsv", std::process::id()));
        let mut store = Keystore::new();
        store.trust(key.public_half());
        store.save(&path).unwrap();

        let loaded = Keystore::load(&path).unwrap();
        assert_eq!(loaded.key_ids(), vec!["nova-dev-2026".to_string()]);
        assert!(verify(&sign(&package(), &key), &loaded).is_ok());
        let _ = fs::remove_file(&path);
    }

    #[test]
    fn a_signing_key_does_not_print_its_secret() {
        let key = SigningKey::new("k", b"super secret".to_vec());
        let rendered = format!("{key:?}");
        assert!(!rendered.contains("super secret"), "Debug must not leak key material");
        assert!(rendered.contains("redacted"));
    }
}
