//! Security event logging — M10 Day 44.
//!
//! Day 42 already logged rejected IPC connections: through `nova-log`,
//! at WARNING, into the same stream as every other message any Nova
//! subsystem emits. That satisfied Day 42's "and the attempt is logged"
//! and is not enough for Day 44, whose DoD is specific: security events
//! must be **queryable separately from general application logs**.
//!
//! Separately matters for a practical reason. A failed permission check
//! is one line among thousands in a general log, and the question
//! someone actually asks after an incident — "what did this app try to
//! do that it wasn't allowed to?" — should not require grepping a log
//! whose volume is dominated by lifecycle chatter. It also matters for
//! retention: the general log can be rotated aggressively on a 1GB
//! device (Section 21), and the security log should not disappear with
//! it.
//!
//! ## Built on M4's logging subsystem, not beside it
//!
//! The Day 44 row says "through M4's logging subsystem", and this crate
//! takes that literally: persistence goes through `nova_fsmgr`'s
//! `append_file`, the record format is the same tab-separated,
//! escape-on-write convention `nova-log` uses, and [`SecurityLog::mirror_to`]
//! can copy a one-line summary into the general log for anyone reading
//! that instead. What is *not* shared is the file and the query API —
//! that is the separation the DoD asks for.
//!
//! ## Tamper evidence
//!
//! Each record carries the hash of the record before it. Altering or
//! deleting any record in the middle of the file breaks the chain, and
//! [`SecurityLog::verify_chain`] finds exactly where.
//!
//! What this gives, honestly: **evidence of tampering**, not prevention
//! of it. Anything running as root can truncate the file from the end
//! and re-chain what remains, and nothing in user space can stop that.
//! Detecting a truncated tail needs the chain head anchored somewhere
//! the attacker doesn't control — a remote collector, or hardware-backed
//! storage on the M12 reference device. Recorded in
//! `docs/security-model-v1.md` as an open item with a milestone, rather
//! than left for someone to assume the chain does more than it does.

use nova_crypto::{sha256, to_hex};
use nova_fsmgr::{append_file, read_file};
use nova_log::{LogLevel, Logger};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

/// Truncated to 16 bytes. 128 bits is far beyond what is needed to make
/// a second-preimage attack on a log record impractical, and halving
/// the per-record overhead matters on a device where the security log
/// is expected to be long-lived (Section 21's budget, reaching even
/// here).
pub const CHAIN_HASH_LEN: usize = 16;

/// The default location. A sibling of the general log, deliberately —
/// same directory, different file, different retention.
pub fn default_path() -> PathBuf {
    Path::new(nova_fsmgr::paths::LOG).join("security.log")
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SecurityEventKind {
    /// A capability or permission check said no. (Day 15, Day 42.)
    PermissionDenied,
    /// A sandbox boundary was tested: path traversal, symlink escape, a
    /// seccomp violation. (Day 40, Day 41.)
    SandboxViolation,
    /// An `.npkg` was refused at install time. (Day 43.)
    PackageRejected,
    /// An IPC peer could not be authenticated, or was the wrong peer.
    /// (Day 42.)
    IpcAuthFailure,
    /// A process attempted to gain privileges it was not granted.
    PrivilegeEscalation,
    /// The identity table disagreed with itself, or a uid appeared that
    /// Nova did not allocate. (Day 40.)
    IdentityAnomaly,
    /// Boot-chain verification failed or was skipped. (Day 44's
    /// secure-boot strategy; enforced on real hardware from M12.)
    SecureBootFailure,
    /// A service was found running with more privilege than its audited
    /// task list requires. (Day 45.)
    PrivilegeAuditFinding,
}

impl SecurityEventKind {
    pub fn as_str(self) -> &'static str {
        match self {
            SecurityEventKind::PermissionDenied => "PERMISSION_DENIED",
            SecurityEventKind::SandboxViolation => "SANDBOX_VIOLATION",
            SecurityEventKind::PackageRejected => "PACKAGE_REJECTED",
            SecurityEventKind::IpcAuthFailure => "IPC_AUTH_FAILURE",
            SecurityEventKind::PrivilegeEscalation => "PRIVILEGE_ESCALATION",
            SecurityEventKind::IdentityAnomaly => "IDENTITY_ANOMALY",
            SecurityEventKind::SecureBootFailure => "SECURE_BOOT_FAILURE",
            SecurityEventKind::PrivilegeAuditFinding => "PRIVILEGE_AUDIT_FINDING",
        }
    }

    pub fn from_str(s: &str) -> Option<Self> {
        Some(match s {
            "PERMISSION_DENIED" => SecurityEventKind::PermissionDenied,
            "SANDBOX_VIOLATION" => SecurityEventKind::SandboxViolation,
            "PACKAGE_REJECTED" => SecurityEventKind::PackageRejected,
            "IPC_AUTH_FAILURE" => SecurityEventKind::IpcAuthFailure,
            "PRIVILEGE_ESCALATION" => SecurityEventKind::PrivilegeEscalation,
            "IDENTITY_ANOMALY" => SecurityEventKind::IdentityAnomaly,
            "SECURE_BOOT_FAILURE" => SecurityEventKind::SecureBootFailure,
            "PRIVILEGE_AUDIT_FINDING" => SecurityEventKind::PrivilegeAuditFinding,
            _ => return None,
        })
    }

    /// Whether an event of this kind, by itself, should wake someone up.
    /// A denied permission is routine — it is the sandbox working. A
    /// failed boot verification is not.
    pub fn default_severity(self) -> LogLevel {
        match self {
            SecurityEventKind::PermissionDenied => LogLevel::Info,
            SecurityEventKind::SandboxViolation
            | SecurityEventKind::IpcAuthFailure
            | SecurityEventKind::PackageRejected
            | SecurityEventKind::PrivilegeAuditFinding => LogLevel::Warning,
            SecurityEventKind::PrivilegeEscalation | SecurityEventKind::IdentityAnomaly => LogLevel::Error,
            SecurityEventKind::SecureBootFailure => LogLevel::Critical,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Outcome {
    /// Nova stopped it.
    Blocked,
    /// Nova noticed it and did not stop it. Recorded distinctly because
    /// a log full of `Blocked` and a log full of `Allowed` describe very
    /// different systems.
    Allowed,
    /// Observed during an audit rather than at the moment of an attempt.
    Detected,
}

impl Outcome {
    pub fn as_str(self) -> &'static str {
        match self {
            Outcome::Blocked => "BLOCKED",
            Outcome::Allowed => "ALLOWED",
            Outcome::Detected => "DETECTED",
        }
    }

    fn from_str(s: &str) -> Option<Self> {
        Some(match s {
            "BLOCKED" => Outcome::Blocked,
            "ALLOWED" => Outcome::Allowed,
            "DETECTED" => Outcome::Detected,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SecurityEvent {
    pub timestamp_secs: u64,
    pub kind: SecurityEventKind,
    pub severity: LogLevel,
    /// Who: an app id, a service name, or `uid:NNNN` when the principal
    /// could not be resolved to a name — which is itself information.
    pub principal: String,
    pub outcome: Outcome,
    pub detail: String,
}

impl SecurityEvent {
    pub fn new(kind: SecurityEventKind, principal: impl Into<String>, outcome: Outcome, detail: impl Into<String>) -> Self {
        SecurityEvent {
            timestamp_secs: now_secs(),
            kind,
            severity: kind.default_severity(),
            principal: principal.into(),
            outcome,
            detail: detail.into(),
        }
    }

    pub fn at(mut self, timestamp_secs: u64) -> Self {
        self.timestamp_secs = timestamp_secs;
        self
    }

    pub fn with_severity(mut self, severity: LogLevel) -> Self {
        self.severity = severity;
        self
    }

    pub fn permission_denied(principal: impl Into<String>, detail: impl Into<String>) -> Self {
        SecurityEvent::new(SecurityEventKind::PermissionDenied, principal, Outcome::Blocked, detail)
    }

    pub fn sandbox_violation(principal: impl Into<String>, detail: impl Into<String>) -> Self {
        SecurityEvent::new(SecurityEventKind::SandboxViolation, principal, Outcome::Blocked, detail)
    }

    pub fn package_rejected(principal: impl Into<String>, detail: impl Into<String>) -> Self {
        SecurityEvent::new(SecurityEventKind::PackageRejected, principal, Outcome::Blocked, detail)
    }

    pub fn ipc_auth_failure(principal: impl Into<String>, detail: impl Into<String>) -> Self {
        SecurityEvent::new(SecurityEventKind::IpcAuthFailure, principal, Outcome::Blocked, detail)
    }

    /// The bytes the chain hash covers. Every field, in a fixed order,
    /// with the same escaping used on disk — so a record that reads back
    /// identically hashes identically, and one that doesn't, doesn't.
    fn canonical(&self) -> String {
        format!(
            "{}\t{}\t{}\t{}\t{}\t{}",
            self.timestamp_secs,
            self.kind.as_str(),
            level_str(self.severity),
            escape(&self.principal),
            self.outcome.as_str(),
            escape(&self.detail)
        )
    }

    /// A single human-readable line, used when mirroring into the
    /// general log.
    pub fn summary(&self) -> String {
        format!("[{}] {} {} — {}", self.kind.as_str(), self.principal, self.outcome.as_str(), self.detail)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SecurityRecord {
    pub event: SecurityEvent,
    /// Hash of the preceding record; all zeroes for the first.
    pub prev_hash: String,
    pub hash: String,
}

#[derive(Debug)]
pub enum SecLogError {
    Io(String),
    /// A line in the file could not be parsed. Never skipped silently —
    /// an unparseable line in a security log is itself a finding.
    Malformed { line: usize, why: String },
}

impl std::fmt::Display for SecLogError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SecLogError::Io(e) => write!(f, "io: {e}"),
            SecLogError::Malformed { line, why } => write!(f, "security log line {line} is malformed: {why}"),
        }
    }
}

impl std::error::Error for SecLogError {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ChainStatus {
    Intact { records: usize },
    /// The chain breaks at this record — everything before it is
    /// consistent, this one is not.
    Broken { at_record: usize, expected_prev: String, found_prev: String },
    /// A record's own hash does not match its contents.
    Altered { at_record: usize },
}

const ZERO_HASH: &str = "00000000000000000000000000000000";

/// Append-only, hash-chained security event log.
pub struct SecurityLog {
    path: Option<PathBuf>,
    records: Vec<SecurityRecord>,
    last_hash: String,
    mirror: Option<Logger>,
}

impl SecurityLog {
    /// In-memory only. Used by tests, and by any component that wants
    /// the query API without a file behind it.
    pub fn in_memory() -> Self {
        SecurityLog { path: None, records: Vec::new(), last_hash: ZERO_HASH.to_string(), mirror: None }
    }

    /// Opens (or starts) the persisted log, loading what is already
    /// there so the chain continues across restarts instead of starting
    /// over — a chain that resets every boot would be trivially
    /// defeated by rebooting.
    pub fn open(path: impl Into<PathBuf>) -> Result<Self, SecLogError> {
        let path = path.into();
        let mut log = SecurityLog::in_memory();
        log.path = Some(path.clone());
        if path.exists() {
            log.records = load(&path)?;
            log.last_hash = log.records.last().map(|r| r.hash.clone()).unwrap_or_else(|| ZERO_HASH.to_string());
        }
        Ok(log)
    }

    /// Also writes a one-line summary to the general log.
    ///
    /// Off by default: the DoD asks for separate queryability, and
    /// mirroring everything by default would put the volume back where
    /// it was. Nova's init turns this on for `Error` and above only, so
    /// someone reading the general log still sees that something
    /// happened and where to look.
    pub fn mirror_to(mut self, logger: Logger) -> Self {
        self.mirror = Some(logger);
        self
    }

    pub fn record(&mut self, event: SecurityEvent) -> Result<&SecurityRecord, SecLogError> {
        let prev_hash = self.last_hash.clone();
        let hash = chain_hash(&prev_hash, &event.canonical());

        if let Some(path) = &self.path {
            let line = format!("{}\t{}\t{}\n", event.canonical(), prev_hash, hash);
            append_file(path, line.as_bytes()).map_err(|e| SecLogError::Io(e.to_string()))?;
        }
        if let Some(mirror) = &mut self.mirror {
            mirror.log(event.severity, "nova-security", &event.summary());
        }

        self.last_hash = hash.clone();
        self.records.push(SecurityRecord { event, prev_hash, hash });
        Ok(self.records.last().expect("just pushed"))
    }

    pub fn all(&self) -> &[SecurityRecord] {
        &self.records
    }

    pub fn len(&self) -> usize {
        self.records.len()
    }

    pub fn is_empty(&self) -> bool {
        self.records.is_empty()
    }

    // --- The query API. This, plus the separate file, is what "queryable
    // --- separately from general application logs" means concretely.

    pub fn by_kind(&self, kind: SecurityEventKind) -> Vec<&SecurityRecord> {
        self.records.iter().filter(|r| r.event.kind == kind).collect()
    }

    pub fn by_principal(&self, principal: &str) -> Vec<&SecurityRecord> {
        self.records.iter().filter(|r| r.event.principal == principal).collect()
    }

    pub fn at_least(&self, severity: LogLevel) -> Vec<&SecurityRecord> {
        self.records.iter().filter(|r| r.event.severity >= severity).collect()
    }

    pub fn since(&self, timestamp_secs: u64) -> Vec<&SecurityRecord> {
        self.records.iter().filter(|r| r.event.timestamp_secs >= timestamp_secs).collect()
    }

    pub fn blocked(&self) -> Vec<&SecurityRecord> {
        self.records.iter().filter(|r| r.event.outcome == Outcome::Blocked).collect()
    }

    /// Recomputes the whole chain.
    pub fn verify_chain(&self) -> ChainStatus {
        verify_records(&self.records)
    }

    /// Re-reads the file from disk and verifies it — the check that
    /// matters, since the in-memory copy is by definition consistent
    /// with itself.
    pub fn verify_on_disk(&self) -> Result<ChainStatus, SecLogError> {
        let Some(path) = &self.path else {
            return Ok(self.verify_chain());
        };
        if !path.exists() {
            return Ok(ChainStatus::Intact { records: 0 });
        }
        Ok(verify_records(&load(path)?))
    }
}

fn verify_records(records: &[SecurityRecord]) -> ChainStatus {
    let mut expected_prev = ZERO_HASH.to_string();
    for (i, record) in records.iter().enumerate() {
        if record.prev_hash != expected_prev {
            return ChainStatus::Broken {
                at_record: i,
                expected_prev,
                found_prev: record.prev_hash.clone(),
            };
        }
        if chain_hash(&record.prev_hash, &record.event.canonical()) != record.hash {
            return ChainStatus::Altered { at_record: i };
        }
        expected_prev = record.hash.clone();
    }
    ChainStatus::Intact { records: records.len() }
}

fn chain_hash(prev_hash: &str, canonical: &str) -> String {
    let mut input = Vec::with_capacity(prev_hash.len() + canonical.len() + 1);
    input.extend_from_slice(prev_hash.as_bytes());
    input.push(b'\n');
    input.extend_from_slice(canonical.as_bytes());
    to_hex(&sha256(&input)[..CHAIN_HASH_LEN])
}

fn load(path: &Path) -> Result<Vec<SecurityRecord>, SecLogError> {
    let bytes = read_file(path).map_err(|e| SecLogError::Io(e.to_string()))?;
    let text = String::from_utf8_lossy(&bytes);
    let mut out = Vec::new();
    for (i, line) in text.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        out.push(parse_line(line).map_err(|why| SecLogError::Malformed { line: i + 1, why })?);
    }
    Ok(out)
}

fn parse_line(line: &str) -> Result<SecurityRecord, String> {
    let parts: Vec<&str> = line.split('\t').collect();
    if parts.len() != 8 {
        return Err(format!("expected 8 tab-separated fields, found {}", parts.len()));
    }
    let timestamp_secs: u64 = parts[0].parse().map_err(|_| "timestamp is not a number".to_string())?;
    let kind = SecurityEventKind::from_str(parts[1]).ok_or_else(|| format!("unknown event kind '{}'", parts[1]))?;
    let severity = level_from_str(parts[2]).ok_or_else(|| format!("unknown severity '{}'", parts[2]))?;
    let outcome = Outcome::from_str(parts[4]).ok_or_else(|| format!("unknown outcome '{}'", parts[4]))?;
    Ok(SecurityRecord {
        event: SecurityEvent {
            timestamp_secs,
            kind,
            severity,
            principal: unescape(parts[3]),
            outcome,
            detail: unescape(parts[5]),
        },
        prev_hash: parts[6].to_string(),
        hash: parts[7].to_string(),
    })
}

fn escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('\t', "\\t").replace('\n', "\\n")
}

fn unescape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\' {
            match chars.next() {
                Some('t') => out.push('\t'),
                Some('n') => out.push('\n'),
                Some('\\') => out.push('\\'),
                Some(other) => {
                    out.push('\\');
                    out.push(other);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn level_str(level: LogLevel) -> &'static str {
    match level {
        LogLevel::Debug => "DEBUG",
        LogLevel::Info => "INFO",
        LogLevel::Warning => "WARNING",
        LogLevel::Error => "ERROR",
        LogLevel::Critical => "CRITICAL",
    }
}

fn level_from_str(s: &str) -> Option<LogLevel> {
    Some(match s {
        "DEBUG" => LogLevel::Debug,
        "INFO" => LogLevel::Info,
        "WARNING" => LogLevel::Warning,
        "ERROR" => LogLevel::Error,
        "CRITICAL" => LogLevel::Critical,
        _ => return None,
    })
}

fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

/// Lets Day 40's `Enforcer` report a refused filesystem access without
/// `nova-identity` having to depend on this crate.
///
/// The trait is declared in `nova-identity` (the layer that detects the
/// violation) and implemented here (the layer that records it), so the
/// dependency points one way only: the detector knows nothing about
/// logging, and the log knows nothing about filesystem enforcement.
impl nova_identity::SecurityObserver for SecurityLog {
    fn violation(&mut self, principal: &str, detail: &str) {
        // A failure to write the security log must not turn a *refused*
        // access into a crash in the caller. The refusal already
        // happened; losing the record of it is bad, and panicking in
        // App Manager's filesystem path would be worse.
        let _ = self.record(SecurityEvent::sandbox_violation(principal, detail));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    fn tmp(name: &str) -> PathBuf {
        let p = std::env::temp_dir().join(format!("nova-seclog-{}-{}.log", std::process::id(), name));
        let _ = fs::remove_file(&p);
        p
    }

    /// The literal Day 44 DoD: security events are queryable separately
    /// from general application logs.
    #[test]
    fn day44_security_events_are_queryable_separately() {
        let general_path = tmp("general");
        let security_path = tmp("security");

        // The general log carries ordinary application chatter...
        let mut general = Logger::with_persistence(general_path.clone());
        general.info("org.nova.messages", "app moved to foreground");
        general.info("nova-svcmgr", "service nova-netd started");

        // ...and the security log carries only security events.
        let mut security = SecurityLog::open(&security_path).unwrap();
        security.record(SecurityEvent::permission_denied("org.nova.games", "requested camera without declaring it")).unwrap();
        security.record(SecurityEvent::ipc_auth_failure("org.nova.evil", "connected to org.nova.contacts' channel")).unwrap();
        security.record(SecurityEvent::package_rejected("suspicious.npkg", "signature does not match key 'nova-dev-2026'")).unwrap();

        // Two different files.
        assert_ne!(general_path, security_path);
        let general_text = String::from_utf8_lossy(&fs::read(&general_path).unwrap()).to_string();
        let security_text = String::from_utf8_lossy(&fs::read(&security_path).unwrap()).to_string();
        assert!(!general_text.contains("IPC_AUTH_FAILURE"), "security events must not be buried in the general log");
        assert!(!security_text.contains("moved to foreground"), "application chatter must not dilute the security log");

        // And a query API that answers the question someone actually asks.
        assert_eq!(security.by_principal("org.nova.evil").len(), 1);
        assert_eq!(security.by_kind(SecurityEventKind::PackageRejected).len(), 1);
        assert_eq!(security.at_least(LogLevel::Warning).len(), 2, "the denied permission is Info, the other two are Warning");
        assert_eq!(security.blocked().len(), 3);

        let _ = fs::remove_file(&general_path);
        let _ = fs::remove_file(&security_path);
    }

    #[test]
    fn records_survive_a_restart_and_the_chain_continues() {
        let path = tmp("restart");
        {
            let mut log = SecurityLog::open(&path).unwrap();
            log.record(SecurityEvent::permission_denied("a", "first")).unwrap();
            log.record(SecurityEvent::permission_denied("b", "second")).unwrap();
        }
        let mut reopened = SecurityLog::open(&path).unwrap();
        assert_eq!(reopened.len(), 2, "existing records must be loaded, not started over");
        reopened.record(SecurityEvent::permission_denied("c", "third")).unwrap();

        assert_eq!(reopened.verify_chain(), ChainStatus::Intact { records: 3 });
        assert_eq!(reopened.verify_on_disk().unwrap(), ChainStatus::Intact { records: 3 });
        let _ = fs::remove_file(&path);
    }

    /// Tamper evidence, demonstrated rather than asserted: rewrite one
    /// record on disk and confirm the chain reports exactly where.
    #[test]
    fn an_altered_record_is_detected() {
        let path = tmp("altered");
        let mut log = SecurityLog::open(&path).unwrap();
        log.record(SecurityEvent::permission_denied("org.nova.a", "denied camera").at(1000)).unwrap();
        log.record(SecurityEvent::sandbox_violation("org.nova.b", "symlink escape attempt").at(1001)).unwrap();
        log.record(SecurityEvent::permission_denied("org.nova.c", "denied contacts").at(1002)).unwrap();

        // Someone edits the middle record to hide what app B did.
        let text = fs::read_to_string(&path).unwrap();
        let doctored = text.replace("symlink escape attempt", "routine file access!!");
        fs::write(&path, doctored).unwrap();

        match log.verify_on_disk().unwrap() {
            ChainStatus::Altered { at_record } => assert_eq!(at_record, 1),
            other => panic!("tampering went undetected: {other:?}"),
        }
        let _ = fs::remove_file(&path);
    }

    #[test]
    fn a_deleted_record_is_detected() {
        let path = tmp("deleted");
        let mut log = SecurityLog::open(&path).unwrap();
        for i in 0..4u64 {
            log.record(SecurityEvent::permission_denied(format!("app{i}"), "denied").at(1000 + i)).unwrap();
        }
        let text = fs::read_to_string(&path).unwrap();
        let kept: Vec<&str> = text.lines().enumerate().filter(|(i, _)| *i != 1).map(|(_, l)| l).collect();
        fs::write(&path, kept.join("\n") + "\n").unwrap();

        match log.verify_on_disk().unwrap() {
            ChainStatus::Broken { at_record, .. } => assert_eq!(at_record, 1),
            other => panic!("a deleted record went undetected: {other:?}"),
        }
        let _ = fs::remove_file(&path);
    }

    #[test]
    fn records_round_trip_including_awkward_characters() {
        let path = tmp("escape");
        let mut log = SecurityLog::open(&path).unwrap();
        log.record(SecurityEvent::sandbox_violation("org.nova.a", "tried to open\ta\npath\\with separators"))
            .unwrap();
        let reopened = SecurityLog::open(&path).unwrap();
        assert_eq!(reopened.len(), 1);
        assert_eq!(reopened.all()[0].event.detail, "tried to open\ta\npath\\with separators");
        assert_eq!(reopened.verify_chain(), ChainStatus::Intact { records: 1 });
        let _ = fs::remove_file(&path);
    }

    #[test]
    fn mirroring_is_off_unless_asked_for() {
        let mut quiet = SecurityLog::in_memory();
        quiet.record(SecurityEvent::permission_denied("a", "x")).unwrap();
        assert!(quiet.mirror.is_none());

        let mut loud = SecurityLog::in_memory().mirror_to(Logger::new());
        loud.record(SecurityEvent::permission_denied("a", "x")).unwrap();
        assert_eq!(loud.mirror.as_ref().unwrap().all().len(), 1);
        assert!(loud.mirror.as_ref().unwrap().all()[0].message.contains("PERMISSION_DENIED"));
    }

    #[test]
    fn severity_defaults_reflect_how_alarming_each_kind_is() {
        assert_eq!(SecurityEventKind::PermissionDenied.default_severity(), LogLevel::Info);
        assert_eq!(SecurityEventKind::SandboxViolation.default_severity(), LogLevel::Warning);
        assert_eq!(SecurityEventKind::SecureBootFailure.default_severity(), LogLevel::Critical);
    }

    #[test]
    fn a_malformed_line_is_an_error_not_a_skipped_line() {
        let path = tmp("malformed");
        fs::write(&path, "not\ta\tvalid\trecord\n").unwrap();
        assert!(matches!(SecurityLog::open(&path), Err(SecLogError::Malformed { line: 1, .. })));
        let _ = fs::remove_file(&path);
    }
}
