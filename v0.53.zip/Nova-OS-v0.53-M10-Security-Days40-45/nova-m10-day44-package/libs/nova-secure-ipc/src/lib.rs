//! Authenticated IPC endpoints — M10 Day 42.
//!
//! Day 11's protocol trusts the socket. Any process that can reach
//! `/run/nova/app-manager.sock` — or any per-app channel — can connect
//! and then *claim* an identity in its `Hello` message. Nothing checks
//! the claim. On a phone with one user, that means any app can
//! impersonate any other app to any Nova service, and the permission
//! model built on top is decorative.
//!
//! The Day 42 row's second half is exactly this: "authenticate the
//! endpoints of every IPC channel, not just trust whoever connects to
//! the socket."
//!
//! ## How the claim is checked
//!
//! `SO_PEERCRED` asks the kernel who is on the other end of a Unix
//! socket. The kernel answers with the peer's pid, uid and gid,
//! recorded at `connect(2)` time. The app cannot influence that answer
//! — it is not part of any message, it cannot be forged by sending
//! different bytes, and it does not change if the peer later tries to
//! change identity.
//!
//! That uid is then resolved through Day 40's [`IdentityRegistry`],
//! which is the only reason Day 40 had to allocate *stable, persisted*
//! uids rather than just a convenient numbering: the uid is the link
//! between "who connected" and "which installed app that is".
//!
//! ## What this does not do
//!
//! It authenticates the *process*, not the code inside it. If an app's
//! own binary is compromised, its connections remain genuine
//! connections from that app — that is what Day 43's package signing
//! and Day 44's secure-boot strategy address, at a different layer.
//! It also says nothing about confidentiality: a Unix socket's bytes
//! are visible to root, and Nova does not encrypt local IPC. Both are
//! recorded in `docs/security-model-v1.md`.

use nova_identity::{Identity, IdentityRegistry, Uid};
use nova_log::Logger;
use nova_seclog::{SecurityEvent, SecurityLog};
use std::cell::RefCell;
use std::io;
use std::os::unix::io::AsRawFd;
use std::os::unix::net::UnixStream;

/// What the kernel says about the far end of a socket.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PeerCredentials {
    pub pid: i32,
    pub uid: u32,
    pub gid: u32,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct Ucred {
    pid: libc::pid_t,
    uid: libc::uid_t,
    gid: libc::gid_t,
}

#[derive(Debug)]
pub enum IpcAuthError {
    /// The kernel would not report credentials for this socket. Happens
    /// for socket families where `SO_PEERCRED` has no meaning — which,
    /// for Nova, means someone handed us something that is not an app
    /// channel.
    NoCredentials(io::Error),
    /// The peer's uid belongs to no identity Nova knows about.
    UnknownPeer { uid: u32, pid: i32 },
    /// The peer is genuine, but it is not the app this channel belongs
    /// to. This is the impersonation attempt the Day 42 DoD names.
    WrongApp { claimed: String, actual: String, pid: i32 },
    /// The peer is a system identity where an app was expected, or the
    /// reverse.
    WrongKind { app_id: String, pid: i32 },
}

impl std::fmt::Display for IpcAuthError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IpcAuthError::NoCredentials(e) => write!(f, "peer credentials unavailable: {e}"),
            IpcAuthError::UnknownPeer { uid, pid } => {
                write!(f, "connection from unknown uid {uid} (pid {pid}) rejected")
            }
            IpcAuthError::WrongApp { claimed, actual, pid } => {
                write!(f, "pid {pid} is {actual} but connected to {claimed}'s channel; rejected")
            }
            IpcAuthError::WrongKind { app_id, pid } => {
                write!(f, "pid {pid} ({app_id}) is the wrong kind of principal for this channel")
            }
        }
    }
}

impl std::error::Error for IpcAuthError {}

impl IpcAuthError {
    /// Who to file this rejection against.
    ///
    /// The *actual* peer, never the claimed one — filing an
    /// impersonation attempt under the victim's name would be worse
    /// than not filing it. When the peer resolves to no known app, the
    /// uid itself is the principal, which is information rather than a
    /// placeholder.
    pub fn principal(&self) -> String {
        match self {
            IpcAuthError::NoCredentials(_) => "unknown".to_string(),
            IpcAuthError::UnknownPeer { uid, .. } => format!("uid:{uid}"),
            IpcAuthError::WrongApp { actual, .. } => actual.clone(),
            IpcAuthError::WrongKind { app_id, .. } => app_id.clone(),
        }
    }

    /// A one-line, log-shaped summary. Day 44 records every one of
    /// these as a security event; having the string built here keeps
    /// the wording identical between the error path and the log.
    pub fn audit_line(&self) -> String {
        self.to_string()
    }
}

/// Reads `SO_PEERCRED` from a connected Unix socket.
pub fn peer_credentials(stream: &UnixStream) -> Result<PeerCredentials, IpcAuthError> {
    let mut cred = Ucred { pid: 0, uid: 0, gid: 0 };
    let mut len = std::mem::size_of::<Ucred>() as libc::socklen_t;
    // SAFETY: `cred` is a correctly sized, locally owned buffer and
    // `len` is its true size; getsockopt writes at most `len` bytes and
    // updates `len` to what it wrote.
    let rc = unsafe {
        libc::getsockopt(
            stream.as_raw_fd(),
            libc::SOL_SOCKET,
            libc::SO_PEERCRED,
            &mut cred as *mut Ucred as *mut libc::c_void,
            &mut len,
        )
    };
    if rc != 0 {
        return Err(IpcAuthError::NoCredentials(io::Error::last_os_error()));
    }
    Ok(PeerCredentials { pid: cred.pid as i32, uid: cred.uid as u32, gid: cred.gid as u32 })
}

/// The identity behind an accepted connection, established by the
/// kernel rather than claimed in a message.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AuthenticatedPeer {
    pub identity: Identity,
    pub credentials: PeerCredentials,
}

/// Authenticates connections against Day 40's identity table.
///
/// Held by every Nova service that accepts a socket: App Manager, the
/// compositor, and any per-app channel endpoint.
pub struct Authenticator<'a> {
    registry: &'a IdentityRegistry,
    /// Every rejection below is recorded, not just returned. The Day 42
    /// DoD asks for both — "rejected **and** the attempt is logged" —
    /// and a rejection that leaves no trace is invisible to anyone
    /// investigating later.
    ///
    /// `RefCell` because authentication is a `&self` operation on a
    /// service's hot path and threading `&mut` through every accept
    /// call would reshape App Manager's loop around a logging detail.
    logger: RefCell<Option<Logger>>,
    /// Day 44: the dedicated security channel. Separate from `logger`
    /// on purpose — the DoD asks for security events to be queryable
    /// *separately* from general application logs, and writing to both
    /// is how a reader of either is not left blind.
    security_log: RefCell<Option<SecurityLog>>,
}

impl<'a> Authenticator<'a> {
    pub fn new(registry: &'a IdentityRegistry) -> Self {
        Authenticator { registry, logger: RefCell::new(None), security_log: RefCell::new(None) }
    }

    /// Attaches M4's logging subsystem (Day 7). Day 44 replaces this
    /// with the dedicated security channel, which is queryable
    /// separately from general application logs; until then, rejections
    /// land in the normal log at WARNING, which is where someone would
    /// actually look.
    pub fn with_logger(self, logger: Logger) -> Self {
        *self.logger.borrow_mut() = Some(logger);
        self
    }

    /// Day 44: attaches the security event channel.
    pub fn with_security_log(self, log: SecurityLog) -> Self {
        *self.security_log.borrow_mut() = Some(log);
        self
    }

    /// Hands the security log back, for a caller that wants to query or
    /// merge it. Consumes the authenticator because a log that is still
    /// being written to from two places is a log nobody can reason
    /// about.
    pub fn into_security_log(self) -> Option<SecurityLog> {
        self.security_log.into_inner()
    }

    fn record(&self, err: &IpcAuthError) {
        if let Some(logger) = self.logger.borrow_mut().as_mut() {
            logger.warning("nova-secure-ipc", &err.audit_line());
        }
        if let Some(log) = self.security_log.borrow_mut().as_mut() {
            // Best-effort, like every other logging path in this OS: a
            // full disk must not turn a correctly refused connection
            // into a crash in App Manager's accept loop.
            let _ = log.record(SecurityEvent::ipc_auth_failure(err.principal(), err.audit_line()));
        }
    }

    /// The rejection lines recorded so far, for tests and for the Day
    /// 42 acceptance harness.
    pub fn recorded(&self) -> Vec<String> {
        self.logger
            .borrow()
            .as_ref()
            .map(|l| l.all().iter().map(|e| e.message.clone()).collect())
            .unwrap_or_default()
    }

    /// "Who is this?" — no expectation, just resolution. Used by App
    /// Manager's listening socket, where any installed app may
    /// legitimately connect.
    pub fn authenticate(&self, stream: &UnixStream) -> Result<AuthenticatedPeer, IpcAuthError> {
        let credentials = match peer_credentials(stream) {
            Ok(c) => c,
            Err(e) => {
                self.record(&e);
                return Err(e);
            }
        };
        match self.registry.by_uid(Uid(credentials.uid)) {
            Some(identity) => Ok(AuthenticatedPeer { identity, credentials }),
            None => {
                let err = IpcAuthError::UnknownPeer { uid: credentials.uid, pid: credentials.pid };
                self.record(&err);
                Err(err)
            }
        }
    }

    /// "Is this specifically `expected_app_id`?" — used by a per-app
    /// channel, where exactly one app is the legitimate peer.
    ///
    /// This is the function the Day 42 Definition of Done is about: an
    /// unauthorized process attempting to connect to another app's IPC
    /// channel is rejected here, and the returned error is what Day 44
    /// logs.
    pub fn authorize_channel(
        &self,
        stream: &UnixStream,
        expected_app_id: &str,
    ) -> Result<AuthenticatedPeer, IpcAuthError> {
        let peer = self.authenticate(stream)?;
        if peer.identity.app_id != expected_app_id {
            let err = IpcAuthError::WrongApp {
                claimed: expected_app_id.to_string(),
                actual: peer.identity.app_id.clone(),
                pid: peer.credentials.pid,
            };
            self.record(&err);
            return Err(err);
        }
        Ok(peer)
    }

    /// For channels only Nova's own services may use (the Service
    /// Manager control socket, the security log sink from Day 44).
    pub fn authorize_system_channel(&self, stream: &UnixStream) -> Result<AuthenticatedPeer, IpcAuthError> {
        let peer = self.authenticate(stream)?;
        if !peer.identity.is_system() {
            let err =
                IpcAuthError::WrongKind { app_id: peer.identity.app_id.clone(), pid: peer.credentials.pid };
            self.record(&err);
            return Err(err);
        }
        Ok(peer)
    }

    /// Cross-checks a `Hello` message's self-declared app id against
    /// the kernel's answer.
    ///
    /// Day 11's protocol keeps carrying the app id in the message, and
    /// that stays — it is useful, and changing the wire format now
    /// would break every app built in M5-M7. What changes is that the
    /// claim is no longer *believed*: it is compared, and a mismatch is
    /// a rejection rather than a note.
    pub fn verify_hello_claim(
        &self,
        stream: &UnixStream,
        claimed_app_id: &str,
    ) -> Result<AuthenticatedPeer, IpcAuthError> {
        let peer = self.authenticate(stream)?;
        if peer.identity.app_id != claimed_app_id {
            let err = IpcAuthError::WrongApp {
                claimed: claimed_app_id.to_string(),
                actual: peer.identity.app_id.clone(),
                pid: peer.credentials.pid,
            };
            self.record(&err);
            return Err(err);
        }
        Ok(peer)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn our_uid() -> u32 {
        // SAFETY: getuid cannot fail and touches no memory.
        unsafe { libc::getuid() }
    }

    /// Real sockets, real kernel credentials — `UnixStream::pair` gives
    /// two genuinely connected endpoints, so `SO_PEERCRED` is exercised
    /// for real rather than stubbed.
    #[test]
    fn peer_credentials_come_from_the_kernel() {
        let (a, _b) = UnixStream::pair().expect("socketpair");
        let cred = peer_credentials(&a).expect("SO_PEERCRED");
        assert_eq!(cred.uid, our_uid());
        assert_eq!(cred.pid, std::process::id() as i32);
    }

    #[test]
    fn a_known_peer_authenticates() {
        let mut registry = IdentityRegistry::new();
        registry.reserve("org.nova.test", our_uid()).unwrap();
        let (a, _b) = UnixStream::pair().unwrap();

        let auth = Authenticator::new(&registry);
        let peer = auth.authenticate(&a).expect("should authenticate");
        assert_eq!(peer.identity.app_id, "org.nova.test");
    }

    /// The literal Day 42 DoD: an unauthorized process connecting to
    /// another app's channel is rejected.
    #[test]
    fn day42_connecting_to_another_apps_channel_is_rejected() {
        let mut registry = IdentityRegistry::new();
        registry.reserve("org.nova.evil", our_uid()).unwrap();
        registry.allocate("org.nova.victim").unwrap();
        let (a, _b) = UnixStream::pair().unwrap();

        let auth = Authenticator::new(&registry);
        let err = auth.authorize_channel(&a, "org.nova.victim").expect_err("must be rejected");
        match &err {
            IpcAuthError::WrongApp { claimed, actual, .. } => {
                assert_eq!(claimed, "org.nova.victim");
                assert_eq!(actual, "org.nova.evil");
            }
            other => panic!("expected WrongApp, got {other}"),
        }
        // And the rejection is expressible as a single log line, which
        // is what Day 44 records.
        assert!(err.audit_line().contains("org.nova.victim"));
    }

    #[test]
    fn a_lying_hello_does_not_change_who_the_kernel_says_you_are() {
        let mut registry = IdentityRegistry::new();
        registry.reserve("org.nova.evil", our_uid()).unwrap();
        let (a, _b) = UnixStream::pair().unwrap();

        let auth = Authenticator::new(&registry);
        // The app *says* it is the Camera app. The kernel disagrees.
        let err = auth.verify_hello_claim(&a, "org.nova.camera").expect_err("must be rejected");
        assert!(matches!(err, IpcAuthError::WrongApp { .. }));
        // Told the truth: accepted.
        assert!(auth.verify_hello_claim(&a, "org.nova.evil").is_ok());
    }

    /// The second half of the Day 42 DoD: "and the attempt is logged."
    #[test]
    fn day42_the_rejected_attempt_is_logged() {
        let mut registry = IdentityRegistry::new();
        registry.reserve("org.nova.evil", our_uid()).unwrap();
        registry.allocate("org.nova.victim").unwrap();
        let (a, _b) = UnixStream::pair().unwrap();

        let auth = Authenticator::new(&registry).with_logger(Logger::new());
        assert!(auth.authorize_channel(&a, "org.nova.victim").is_err());

        let recorded = auth.recorded();
        assert_eq!(recorded.len(), 1, "exactly one rejection should have been recorded");
        assert!(recorded[0].contains("org.nova.evil"), "the log must name who actually connected");
        assert!(recorded[0].contains("org.nova.victim"), "and whose channel they went for");
    }

    #[test]
    fn a_successful_authentication_is_not_logged_as_a_rejection() {
        let mut registry = IdentityRegistry::new();
        registry.reserve("org.nova.test", our_uid()).unwrap();
        let (a, _b) = UnixStream::pair().unwrap();
        let auth = Authenticator::new(&registry).with_logger(Logger::new());
        assert!(auth.authorize_channel(&a, "org.nova.test").is_ok());
        assert!(auth.recorded().is_empty());
    }

    /// Day 44 retrofit: the same rejection also reaches the security
    /// channel, filed against the app that actually connected.
    #[test]
    fn day44_rejections_reach_the_security_channel() {
        let mut registry = IdentityRegistry::new();
        registry.reserve("org.nova.evil", our_uid()).unwrap();
        registry.allocate("org.nova.victim").unwrap();
        let (a, _b) = UnixStream::pair().unwrap();

        let auth = Authenticator::new(&registry).with_security_log(SecurityLog::in_memory());
        assert!(auth.authorize_channel(&a, "org.nova.victim").is_err());

        let log = auth.into_security_log().unwrap();
        assert_eq!(log.len(), 1);
        assert_eq!(log.all()[0].event.principal, "org.nova.evil", "filed against the impersonator, not the victim");
    }

    #[test]
    fn an_unregistered_uid_is_refused_rather_than_defaulted() {
        let registry = IdentityRegistry::new(); // empty
        let (a, _b) = UnixStream::pair().unwrap();
        let auth = Authenticator::new(&registry);
        assert!(matches!(auth.authenticate(&a), Err(IpcAuthError::UnknownPeer { .. })));
    }

    #[test]
    fn an_app_cannot_use_a_system_only_channel() {
        let mut registry = IdentityRegistry::new();
        // Deliberately reserved inside the app range, so it is an App.
        registry.reserve("org.nova.app", nova_identity::APP_UID_BASE).unwrap();
        registry.reserve("org.nova.caller", our_uid()).unwrap();
        let (a, _b) = UnixStream::pair().unwrap();
        let auth = Authenticator::new(&registry);

        let result = auth.authorize_system_channel(&a);
        // Our own uid is outside the app range in every realistic test
        // environment, so this is a System identity and should pass; if
        // the tests are somehow run as a uid inside 20000-29999, it is
        // an App and must be refused. Both outcomes are correct —
        // what must never happen is an App being let through.
        match result {
            Ok(peer) => assert!(peer.identity.is_system()),
            Err(IpcAuthError::WrongKind { .. }) => {
                assert!((nova_identity::APP_UID_BASE..=nova_identity::APP_UID_MAX).contains(&our_uid()));
            }
            Err(other) => panic!("unexpected error: {other}"),
        }
    }
}
