#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 43 (M10 Security): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 43: unit tests ==="
cargo test -p nova-package-sign

echo
echo "=== nova-m10-day43-package-signing-acceptance-test ==="
cargo run -p nova-m10-day43-package-signing-acceptance-test

echo
echo "Day 43 build + tests + acceptance completed."
