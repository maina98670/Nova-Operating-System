#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 44 (M10 Security): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 44: unit tests ==="
cargo test -p nova-seclog -p nova-secure-ipc

echo
echo "=== nova-m10-day44-security-logging-acceptance-test ==="
cargo run -p nova-m10-day44-security-logging-acceptance-test

echo
echo "Day 44 build + tests + acceptance completed."
