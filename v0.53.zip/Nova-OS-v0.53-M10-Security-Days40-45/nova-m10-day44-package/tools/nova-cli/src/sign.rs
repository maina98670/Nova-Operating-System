//! `nova keygen` and `nova sign` — M10 Day 43.
//!
//! Day 22's loop was `create -> build -> package -> install -> run`.
//! From Day 43 on, `install` refuses an unsigned package, so the loop
//! gains one step: `package -> sign -> install`. That is a deliberate
//! change to a developer workflow that used to work, and the error
//! `install` prints says so and points here, rather than just failing.
//!
//! ```text
//! nova keygen --key-id nova-dev-2026 --out ~/.nova/signing.key
//! nova sign my_app.npkg --key ~/.nova/signing.key
//! nova install my_app.npkg --keystore /etc/nova/keys/trusted.tsv
//! ```
//!
//! `keygen` writes two files, and the split is the point: the private
//! key file stays on the build machine, and `<out>.trusted.tsv` is the
//! keystore fragment that goes on the device. Today their contents are
//! the same bytes, because the signature scheme is symmetric — that is
//! exactly the limitation `nova-package-sign`'s module doc records, and
//! keeping the two files separate now means the workflow does not have
//! to change when the scheme does.

use nova_package_sign::{describe, sign as sign_bytes, Keystore, SigningKey};
use std::fs;
use std::path::PathBuf;
use std::process::ExitCode;

pub fn keygen(args: &[String]) -> ExitCode {
    let mut key_id: Option<String> = None;
    let mut out: Option<PathBuf> = None;

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--key-id" => {
                i += 1;
                key_id = args.get(i).cloned();
            }
            "--out" => {
                i += 1;
                out = args.get(i).map(PathBuf::from);
            }
            other => {
                eprintln!("nova keygen: unrecognized argument '{other}'");
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    let Some(key_id) = key_id else {
        eprintln!("nova keygen: missing --key-id\nusage: nova keygen --key-id <id> [--out <file>]");
        return ExitCode::FAILURE;
    };
    let out = out.unwrap_or_else(|| PathBuf::from(format!("{key_id}.key")));

    let key = match SigningKey::generate(&key_id) {
        Ok(k) => k,
        Err(e) => {
            eprintln!("nova keygen: couldn't read randomness from /dev/urandom: {e}");
            return ExitCode::FAILURE;
        }
    };

    if let Err(e) = fs::write(&out, format!("{}\t{}\n", key.key_id, key.secret_hex())) {
        eprintln!("nova keygen: couldn't write {}: {e}", out.display());
        return ExitCode::FAILURE;
    }
    // The signing key is a secret. Written 0600 from the start rather
    // than created world-readable and tightened a moment later.
    let _ = fs::set_permissions(&out, std::os::unix::fs::PermissionsExt::from_mode(0o600));

    let trusted_path = PathBuf::from(format!("{}.trusted.tsv", out.display()));
    let mut store = Keystore::new();
    store.trust(key.public_half());
    if let Err(e) = store.save(&trusted_path) {
        eprintln!("nova keygen: couldn't write {}: {e}", trusted_path.display());
        return ExitCode::FAILURE;
    }

    println!("Generated signing key '{key_id}'");
    println!("  private key:       {}   (keep this on the build machine)", out.display());
    println!("  keystore fragment: {}   (install this on the device)", trusted_path.display());
    println!();
    println!("Note: Nova's package signatures are HMAC-SHA256, which is symmetric — the two");
    println!("files above currently contain the same key material. Treat BOTH as secrets.");
    println!("See docs/package-signing-v1.md for why, and what changes when Ed25519 lands.");
    ExitCode::SUCCESS
}

pub fn run(args: &[String]) -> ExitCode {
    let mut package_path: Option<PathBuf> = None;
    let mut key_path: Option<PathBuf> = None;
    let mut out: Option<PathBuf> = None;

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--key" => {
                i += 1;
                key_path = args.get(i).map(PathBuf::from);
            }
            "--out" => {
                i += 1;
                out = args.get(i).map(PathBuf::from);
            }
            other if !other.starts_with('-') && package_path.is_none() => {
                package_path = Some(PathBuf::from(other));
            }
            other => {
                eprintln!("nova sign: unrecognized argument '{other}'");
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    let Some(package_path) = package_path else {
        eprintln!("nova sign: missing <package.npkg>\nusage: nova sign <package.npkg> --key <key-file> [--out <file>]");
        return ExitCode::FAILURE;
    };
    let Some(key_path) = key_path else {
        eprintln!("nova sign: missing --key <key-file>  (create one with `nova keygen`)");
        return ExitCode::FAILURE;
    };

    let key = match read_signing_key(&key_path) {
        Ok(k) => k,
        Err(e) => {
            eprintln!("nova sign: {e}");
            return ExitCode::FAILURE;
        }
    };

    let package = match fs::read(&package_path) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("nova sign: couldn't read {}: {e}", package_path.display());
            return ExitCode::FAILURE;
        }
    };

    // Refuse to sign something that isn't a package. Signing arbitrary
    // bytes would make the signature mean less than it appears to.
    if let Err(e) = nova_package_format::unpack(&package) {
        // A previously signed package won't unpack directly; strip and
        // retry before giving up.
        let stripped = describe(&package).is_ok();
        if !stripped {
            eprintln!("nova sign: {} is not a valid .npkg file: {e}", package_path.display());
            return ExitCode::FAILURE;
        }
    }

    let signed = sign_bytes(&package, &key);
    let out_path = out.unwrap_or_else(|| package_path.clone());
    if let Err(e) = fs::write(&out_path, &signed) {
        eprintln!("nova sign: couldn't write {}: {e}", out_path.display());
        return ExitCode::FAILURE;
    }

    let sig = describe(&signed).expect("just-written signature must parse");
    println!("Signed {}", out_path.display());
    println!("  key id:    {}", sig.key_id);
    println!("  algorithm: {}", sig.algorithm.name());
    println!("  size:      {} bytes ({} of signature trailer)", signed.len(), signed.len() - package.len());
    println!();
    println!("Next: nova install {}", out_path.display());
    ExitCode::SUCCESS
}

fn read_signing_key(path: &PathBuf) -> Result<SigningKey, String> {
    let text = fs::read_to_string(path).map_err(|e| format!("couldn't read {}: {e}", path.display()))?;
    let line = text.lines().find(|l| !l.trim().is_empty() && !l.starts_with('#'));
    let Some(line) = line else {
        return Err(format!("{} is empty", path.display()));
    };
    let mut parts = line.split('\t');
    let (Some(id), Some(hex)) = (parts.next(), parts.next()) else {
        return Err(format!("{} is not in key_id<TAB>hex format", path.display()));
    };
    SigningKey::from_hex(id, hex).ok_or_else(|| format!("{} has non-hex key material", path.display()))
}
