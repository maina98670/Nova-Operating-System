//! Day 43 acceptance test — the literal Definition of Done:
//!
//! > An unsigned or tampered `.npkg` is rejected at install time with a
//! > clear error; a correctly signed package installs normally.
//!
//! "At install time" is taken at its word: this test does not call
//! `verify` in isolation and call it done. It builds a real package with
//! `nova_package_format::pack`, signs it, and runs each case through the
//! same `install_package` gate the `nova install` subcommand uses —
//! writing to a real temporary apps directory and checking what ended up
//! on disk afterwards.
//!
//! The case that matters most is the fourth: a package that is still a
//! perfectly valid `.npkg`, still unpacks, still has the right manifest,
//! and contains a different binary. That one installs fine on Day 22 and
//! must not install here.

use nova_package_sign::{sign, Keystore, PackageVerifyError, SigningKey};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

const MANIFEST: &[u8] = b"id = \"org.nova.signtest\"\nname = \"Sign Test\"\nentry_point = \"bin/signtest\"\nversion = \"1.0.0\"\n";
const GENUINE_BINARY: &[u8] = b"\x7fELF genuine application binary";
const MALICIOUS_BINARY: &[u8] = b"\x7fELF malicious replacement!!!!";

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 43 acceptance: signed packages ===\n");

    let root = std::env::temp_dir().join(format!("nova-day43-acceptance-{}", std::process::id()));
    let _ = fs::remove_dir_all(&root);
    fs::create_dir_all(&root).expect("create test root");

    let key = SigningKey::generate("nova-dev-2026").expect("generate a signing key from /dev/urandom");
    let mut keystore = Keystore::new();
    keystore.trust(key.public_half());
    println!("Device keystore trusts: {:?}", keystore.key_ids());

    let genuine = nova_package_format::pack(MANIFEST, GENUINE_BINARY);
    let signed = sign(&genuine, &key);
    println!("Package: {} bytes unsigned, {} bytes signed\n", genuine.len(), signed.len());

    let mut checks: Vec<Check> = Vec::new();

    // --- 1. The happy path. ------------------------------------------
    let apps = root.join("apps-ok");
    let installed = install_package(&signed, &keystore, &apps);
    let binary_on_disk = fs::read(apps.join("org.nova.signtest/bin/signtest")).ok();
    checks.push(Check {
        name: "a correctly signed package installs normally",
        passed: installed.is_ok() && binary_on_disk.as_deref() == Some(GENUINE_BINARY),
        detail: match &installed {
            Ok(dir) => format!("installed to {}, binary matches the signed contents", dir.display()),
            Err(e) => format!("FAILED: {e}"),
        },
    });

    // --- 2. Unsigned. ------------------------------------------------
    let apps = root.join("apps-unsigned");
    let result = install_package(&genuine, &keystore, &apps);
    checks.push(rejection_check("an unsigned package is rejected", &result, "not signed", &apps));

    // --- 3. Tampered: one byte of the payload flipped. ----------------
    let apps = root.join("apps-flipped");
    let mut flipped = signed.clone();
    let victim_byte = genuine.len() - 4;
    flipped[victim_byte] ^= 0x20;
    let result = install_package(&flipped, &keystore, &apps);
    checks.push(rejection_check("a tampered package is rejected", &result, "altered since it was signed", &apps));

    // --- 4. Substituted binary, genuine signature re-attached. --------
    let apps = root.join("apps-substituted");
    let substituted = splice_signature(&nova_package_format::pack(MANIFEST, MALICIOUS_BINARY), &signed, &genuine);
    // It really is still a valid package — that is the point.
    let unpacks = nova_package_format::unpack(&substituted[..substituted.len() - (signed.len() - genuine.len())]).is_ok();
    let result = install_package(&substituted, &keystore, &apps);
    let mut check = rejection_check("a substituted binary with a re-attached signature is rejected", &result, "altered since it was signed", &apps);
    check.detail = format!("{} (the substituted file is still a structurally valid .npkg: {unpacks})", check.detail);
    checks.push(check);

    // --- 5. Signed by a key this device does not trust. ---------------
    let apps = root.join("apps-untrusted");
    let stranger = SigningKey::generate("some-other-vendor").expect("generate");
    let result = install_package(&sign(&genuine, &stranger), &keystore, &apps);
    checks.push(rejection_check("a package from an untrusted key is rejected", &result, "not in this device's keystore", &apps));

    // --- 6. The errors are clear enough to act on. --------------------
    let unsigned_msg = install_package(&genuine, &keystore, &root.join("apps-msg1")).unwrap_err().to_string();
    let tampered_msg = install_package(&flipped, &keystore, &root.join("apps-msg2")).unwrap_err().to_string();
    checks.push(Check {
        name: "unsigned and tampered produce different, specific errors",
        passed: unsigned_msg != tampered_msg
            && unsigned_msg.contains("not signed")
            && tampered_msg.contains("altered"),
        detail: format!("unsigned: \"{unsigned_msg}\"\n         tampered: \"{tampered_msg}\""),
    });

    println!("Checks:");
    let mut failures = 0;
    for check in &checks {
        if check.passed {
            println!("  [PASS] {}\n         {}", check.name, check.detail);
        } else {
            failures += 1;
            println!("  [FAIL] {}\n         {}", check.name, check.detail);
        }
    }

    let _ = fs::remove_dir_all(&root);

    println!();
    if failures == 0 {
        println!("Day 43 acceptance: PASS ({} checks)", checks.len());
        ExitCode::SUCCESS
    } else {
        println!("Day 43 acceptance: FAIL ({failures} of {} checks failed)", checks.len());
        ExitCode::FAILURE
    }
}

/// The install gate: verify first, and only then touch the filesystem.
///
/// Ordering is the substance of this function. Unpacking first and
/// verifying afterwards would mean a rejected package had already been
/// parsed — and, in a less careful implementation, already written to
/// disk and then deleted, which is not the same thing as never having
/// been installed.
fn install_package(data: &[u8], keystore: &Keystore, apps_dir: &Path) -> Result<PathBuf, PackageVerifyError> {
    let verified = nova_package_sign::verify(data, keystore)?;

    let (manifest, binary) =
        nova_package_format::unpack(&verified.payload).map_err(|e| PackageVerifyError::NotAPackage(e.to_string()))?;

    let manifest_text = String::from_utf8_lossy(&manifest).to_string();
    let id = manifest_text
        .lines()
        .find_map(|l| l.strip_prefix("id = ").map(|v| v.trim().trim_matches('"').to_string()))
        .ok_or_else(|| PackageVerifyError::NotAPackage("manifest has no id".to_string()))?;

    let dest = apps_dir.join(&id);
    fs::create_dir_all(dest.join("bin")).map_err(|e| PackageVerifyError::Io(e.to_string()))?;
    fs::write(dest.join("nova-app.toml"), &manifest).map_err(|e| PackageVerifyError::Io(e.to_string()))?;
    fs::write(dest.join("bin/signtest"), &binary).map_err(|e| PackageVerifyError::Io(e.to_string()))?;
    Ok(dest)
}

/// A rejection only counts if nothing was written. "It errored" and
/// "nothing was installed" are different claims, and the second is the
/// one the DoD makes.
fn rejection_check(
    name: &'static str,
    result: &Result<PathBuf, PackageVerifyError>,
    expected_fragment: &str,
    apps_dir: &Path,
) -> Check {
    match result {
        Ok(dir) => Check { name, passed: false, detail: format!("INSTALLED to {} — this is a supply-chain hole", dir.display()) },
        Err(e) => {
            let message = e.to_string();
            let nothing_written = !apps_dir.exists() || fs::read_dir(apps_dir).map(|mut d| d.next().is_none()).unwrap_or(true);
            Check {
                name,
                passed: message.contains(expected_fragment) && nothing_written,
                detail: format!("rejected: {message} | nothing written to disk: {nothing_written}"),
            }
        }
    }
}

/// Re-attaches the genuine signature trailer from `signed` onto a
/// different payload — the forgery the fourth check is about.
fn splice_signature(new_payload: &[u8], signed: &[u8], original_payload: &[u8]) -> Vec<u8> {
    let trailer = &signed[original_payload.len()..];
    let mut out = new_payload.to_vec();
    out.extend_from_slice(trailer);
    out
}
