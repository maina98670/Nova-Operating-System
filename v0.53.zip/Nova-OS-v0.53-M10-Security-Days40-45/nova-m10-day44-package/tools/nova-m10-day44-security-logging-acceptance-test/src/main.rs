//! Day 44 acceptance test — the literal Definition of Done:
//!
//! > Security events are queryable separately from general application
//! > logs; the secure-boot strategy document exists even if full
//! > hardware enforcement waits for M12's specific device.
//!
//! Both clauses are checked. The second is checked the only way a
//! document can be: the file is opened, and the sections the strategy
//! has to contain to be worth anything are confirmed present. A
//! document that exists but says nothing would otherwise pass.
//!
//! The events written here are not invented for the test. They are
//! produced by the real Day 40 enforcer refusing a real symlink escape
//! and the real Day 42 authenticator refusing a real cross-app socket —
//! routed into the security log through the retrofit wiring Day 44 adds.

use nova_identity::{Access, Enforcer, IdentityRegistry};
use nova_log::{LogLevel, Logger};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_seclog::{ChainStatus, SecurityEvent, SecurityEventKind, SecurityLog};
use nova_secure_ipc::Authenticator;
use std::fs;
use std::os::unix::net::UnixStream;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 44 acceptance: security logging & secure-boot strategy ===\n");

    let root = std::env::temp_dir().join(format!("nova-day44-acceptance-{}", std::process::id()));
    let _ = fs::remove_dir_all(&root);
    fs::create_dir_all(&root).expect("create test root");

    let general_log_path = root.join("nova.log");
    let security_log_path = root.join("security.log");

    let mut general = Logger::with_persistence(general_log_path.clone());
    general.info("nova-svcmgr", "service nova-netd started");
    general.info("org.nova.messages", "app moved to foreground");
    general.debug("nova-compositor", "surface committed");

    let mut security = SecurityLog::open(&security_log_path).expect("open security log");
    let mut checks: Vec<Check> = Vec::new();

    // --- A real Day 40 violation, recorded. ---------------------------
    let enforcer = Enforcer::new(root.join("apps"));
    let mut registry = IdentityRegistry::new();
    let alpha = registry.allocate("org.nova.alpha").unwrap();
    let beta = registry.allocate("org.nova.beta").unwrap();
    enforcer.provision(&alpha).unwrap();
    let beta_root = enforcer.provision(&beta).unwrap();
    fs::write(beta_root.join("secret.txt"), b"beta's private data").unwrap();
    std::os::unix::fs::symlink(&beta_root, enforcer.app_root(&alpha).join("neighbour")).unwrap();

    let policy = SandboxPolicy::new("org.nova.alpha", PermissionSet::empty(), PermissionSet::empty()).unwrap();
    let refused = enforcer.authorize_observed(
        &policy,
        &alpha,
        "neighbour/secret.txt",
        Access::Read,
        &mut security,
    );
    checks.push(Check {
        name: "a real filesystem escape attempt is refused and recorded",
        passed: refused.is_err() && security.by_kind(SecurityEventKind::SandboxViolation).len() == 1,
        detail: match &refused {
            Err(e) => format!("refused ({e}); {} sandbox violation(s) in the security log", security.by_kind(SecurityEventKind::SandboxViolation).len()),
            Ok(p) => format!("ACCESS GRANTED to {} — nothing to log", p.display()),
        },
    });

    // --- A real Day 42 IPC rejection, recorded. -----------------------
    // SAFETY: getuid cannot fail and touches no memory.
    let uid = unsafe { libc::getuid() };
    let mut ipc_registry = IdentityRegistry::new();
    ipc_registry.reserve("org.nova.evil", uid).unwrap();
    ipc_registry.allocate("org.nova.contacts").unwrap();
    let (client, _server) = UnixStream::pair().unwrap();

    let auth = Authenticator::new(&ipc_registry).with_security_log(SecurityLog::in_memory());
    let rejected = auth.authorize_channel(&client, "org.nova.contacts");
    let ipc_log = auth.into_security_log().expect("the authenticator was given a security log");
    let ipc_events = ipc_log.by_kind(SecurityEventKind::IpcAuthFailure).len();
    checks.push(Check {
        name: "a real IPC impersonation attempt is refused and recorded",
        passed: rejected.is_err() && ipc_events == 1,
        detail: format!("rejected: {}; {ipc_events} IPC_AUTH_FAILURE event(s)", rejected.err().map(|e| e.to_string()).unwrap_or_else(|| "NOT REJECTED".into())),
    });

    // Fold the IPC events into the main security log so the rest of the
    // checks see one channel, the way Nova's init would.
    for record in ipc_log.all() {
        security.record(record.event.clone()).unwrap();
    }
    security.record(SecurityEvent::package_rejected("suspicious.npkg", "signature does not match key 'nova-dev-2026'")).unwrap();
    security.record(SecurityEvent::permission_denied("org.nova.games", "requested camera without declaring it")).unwrap();

    // --- The DoD's first clause. --------------------------------------
    let general_text = fs::read_to_string(&general_log_path).unwrap_or_default();
    let security_text = fs::read_to_string(&security_log_path).unwrap_or_default();

    checks.push(Check {
        name: "security events live in their own file, not the general log",
        passed: !general_text.contains("SANDBOX_VIOLATION")
            && !general_text.contains("IPC_AUTH_FAILURE")
            && security_text.contains("SANDBOX_VIOLATION")
            && !security_text.contains("moved to foreground"),
        detail: format!(
            "{} ({} bytes) vs {} ({} bytes)",
            general_log_path.display(),
            general_text.len(),
            security_log_path.display(),
            security_text.len()
        ),
    });

    checks.push(Check {
        name: "security events are queryable by kind, principal and severity",
        passed: security.by_kind(SecurityEventKind::PackageRejected).len() == 1
            && security.by_principal("org.nova.games").len() == 1
            && security.at_least(LogLevel::Warning).len() == 3
            && security.blocked().len() == security.len(),
        detail: format!(
            "{} event(s): {} sandbox, {} ipc, {} package, {} permission; {} at WARNING or above",
            security.len(),
            security.by_kind(SecurityEventKind::SandboxViolation).len(),
            security.by_kind(SecurityEventKind::IpcAuthFailure).len(),
            security.by_kind(SecurityEventKind::PackageRejected).len(),
            security.by_kind(SecurityEventKind::PermissionDenied).len(),
            security.at_least(LogLevel::Warning).len()
        ),
    });

    // --- Tamper evidence. ---------------------------------------------
    let before = security.verify_on_disk().expect("verify");
    let doctored = fs::read_to_string(&security_log_path)
        .unwrap()
        .replace("requested camera without declaring it", "routine camera use, nothing to see");
    fs::write(&security_log_path, doctored).unwrap();
    let after = security.verify_on_disk().expect("verify");

    checks.push(Check {
        name: "editing a record on disk is detected",
        passed: matches!(before, ChainStatus::Intact { .. }) && !matches!(after, ChainStatus::Intact { .. }),
        detail: format!("before: {before:?}; after editing one line: {after:?}"),
    });

    // --- The DoD's second clause: the document. -----------------------
    let doc = find_doc("secure-boot-strategy-v1.md");
    checks.push(match &doc {
        Some((path, text)) => {
            let required = [
                "Chain of trust",
                "What Nova can enforce today",
                "What waits for M12",
                "Rollback protection",
                "Recovery",
            ];
            let missing: Vec<&str> = required.iter().copied().filter(|s| !text.contains(s)).collect();
            Check {
                name: "the secure-boot strategy document exists and covers the chain end to end",
                passed: missing.is_empty(),
                detail: if missing.is_empty() {
                    format!("{} ({} bytes), all required sections present", path.display(), text.len())
                } else {
                    format!("{} is missing: {}", path.display(), missing.join(", "))
                },
            }
        }
        None => Check {
            name: "the secure-boot strategy document exists and covers the chain end to end",
            passed: false,
            detail: "docs/secure-boot-strategy-v1.md not found (run this from the package root)".into(),
        },
    });

    println!("Checks:");
    let mut failures = 0;
    for check in &checks {
        if check.passed {
            println!("  [PASS] {}\n         {}", check.name, check.detail);
        } else {
            failures += 1;
            println!("  [FAIL] {}\n         {}", check.name, check.detail);
        }
    }

    let _ = fs::remove_dir_all(&root);

    println!();
    if failures == 0 {
        println!("Day 44 acceptance: PASS ({} checks)", checks.len());
        ExitCode::SUCCESS
    } else {
        println!("Day 44 acceptance: FAIL ({failures} of {} checks failed)", checks.len());
        ExitCode::FAILURE
    }
}

/// Looks for a doc relative to the current directory and a few levels
/// up, so the test works whether it is run from the package root (the
/// normal `cargo run` case) or from `target/debug`.
fn find_doc(name: &str) -> Option<(PathBuf, String)> {
    let mut dir = std::env::current_dir().ok()?;
    for _ in 0..5 {
        let candidate = dir.join("docs").join(name);
        if let Ok(text) = fs::read_to_string(&candidate) {
            return Some((candidate, text));
        }
        if !dir.pop() {
            break;
        }
    }
    let _ = Path::new(name);
    None
}
