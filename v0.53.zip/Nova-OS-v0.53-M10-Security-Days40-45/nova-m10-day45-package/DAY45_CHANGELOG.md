# Nova OS Day 45 — Least-privilege services audit, acceptance, tag

M10 (Security), v0.53. Continues directly from the Day 44 package.

## Definition of Done

> No core service runs with broader permissions than its own audited task list requires; the security model doc is complete enough for an external reviewer to assess. Tag M10.

## New in this package

- `libs/nova-privilege-audit`
- `tools/nova-m10-day45-acceptance-test`
- `docs/M10-SECURITY-DAY45.md`
- `docs/security-model-v1.md`
- `docs/M10-TAG.md`

## Unchanged

Everything from the previous package is carried forward as-is, except
for the workspace member list and the retrofits named above. No earlier
day's behaviour was replaced.
