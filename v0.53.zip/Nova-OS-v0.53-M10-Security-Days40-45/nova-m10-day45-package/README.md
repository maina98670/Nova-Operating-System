# Nova OS — Day 45 Package: Least-privilege services audit, acceptance, tag

M10 — Security (v0.53, Days 40-45). Continues directly from the Day 44 package.

**Assembled without running any build or test** — files only. Nothing
here has been compiled or executed in this pass. Run
`nova-m10-day45-build_and_run.sh` yourself to actually confirm it.

## Day 45 goal

Per the Complete Build Guide's M10 table.

**Definition of Done:** No core service runs with broader permissions than its own audited task list requires; the security model doc is complete enough for an external reviewer to assess. Tag M10.

## What's new

- `libs/nova-privilege-audit`
- `tools/nova-m10-day45-acceptance-test`
- `docs/M10-SECURITY-DAY45.md`
- `docs/security-model-v1.md`
- `docs/M10-TAG.md`

## Run

```bash
./nova-m10-day45-build_and_run.sh
```

## This is the milestone tag

`nova-m10-day45-acceptance-test` is both Day 45's acceptance test and
M10's integration test: it re-runs the load-bearing property from each of
Days 40-44 as well as the audit, because a milestone tag that only proved
its last day would be worth less than it looks.

It deliberately does **not** re-run Day 41's live escape test, which needs
privileges this process may not have. That runs separately, and the
summary at the end of the test says so.

## Status

Unverified until the build, unit tests and acceptance test above actually
pass — none of that was run in this pass.
