# M10 — Day 45: Least-privilege services audit, acceptance, tag

**Focus.** Audit every M4/M5 core service and confirm each runs with the
minimum permissions it actually needs; complete the security model
documentation; tag M10.

**Delivered.** `libs/nova-privilege-audit` — the audit as code. Each
service declares what it is granted and, separately, which of its own
tasks needs each privilege and why. Granted-without-a-task fails;
needed-but-not-granted fails; a justification with no task named fails.
`observe`/`reconcile` compare a declaration against a running process's
real uid and `CapEff` from `/proc`, so a declaration nobody checks
against reality cannot drift silently.

Result: seven services, zero failures, none running as root. Two standing
notes — no core service is itself sandboxed, and nova-app-manager is
where privilege concentrates in this design.

**DoD.** *No core service runs with broader permissions than its own
audited task list requires; the security model doc is complete enough for
an external reviewer to assess. Tag M10.*
`tools/nova-m10-day45-acceptance-test` checks both, re-runs the
load-bearing property from each of Days 40-44, and confirms every
security document exists and covers what it must.

**Documents.** `docs/security-model-v1.md` (threat model, five trust
boundaries, the audit table, ten known limitations each with an owner),
`docs/M10-TAG.md`.
