# Nova OS security model, v1

M10 (Days 40-45, v0.53). This is the document the Day 45 Definition of
Done asks for: "complete enough for an external reviewer to assess."

An external reviewer's first question is always the same — *what are you
claiming, and what are you not?* So the limitations section is not an
appendix here. It is the point of the document.

---

## Threat model

Nova targets a single-user phone in the 1GB-2GB RAM class (Section 21).
That shapes what is worth defending against.

### In scope

| Adversary | What they can do | Primary defence |
|---|---|---|
| A malicious or compromised **installed app** | run arbitrary code as its own uid | Days 40-42: per-app uid, namespaces, seccomp, authenticated IPC |
| A **curious app** reading where it shouldn't | craft paths, follow symlinks, connect to other apps' sockets | Day 40's real-path containment, Day 42's `SO_PEERCRED` |
| A **tampered package** in transit or on a memory card | substitute a binary inside a valid `.npkg` | Day 43's install-time signature verification |
| An app **escalating privilege** | setuid binaries, `ptrace`, `mount` | `PR_SET_NO_NEW_PRIVS`, seccomp allowlist |
| Someone **covering their tracks** after any of the above | edit or delete security log entries | Day 44's hash-chained log |

### Out of scope, deliberately

* **An attacker with physical access and time.** No TEE is assumed; the
  reference device is not chosen yet (M12) and this price class often has
  no secure element.
* **Root.** Anything running as uid 0 defeats everything in this
  document. Nova's answer is that no core service runs as root (Day 45's
  audit enforces it), not that root is contained.
* **The kernel.** Nova runs on Linux by design through M17 (Section 22).
  A kernel vulnerability is a Nova vulnerability.
* **Network confidentiality.** M8 built the stack; TLS policy is not an
  M10 deliverable and is not claimed.

---

## Trust boundaries

Five boundaries, each with the code that enforces it and the day it was
built:

1. **App ↔ app filesystem.** `nova-identity`'s `Enforcer` (Day 40). Four
   gates: lexical scoping, real-path resolution, containment against the
   canonical app root, ownership and mode. Symlink escape is refused by
   gate 2, which is the gate M5 did not have.
2. **App ↔ kernel.** `nova-isolation` (Day 41). Mount, PID, network, IPC
   and UTS namespaces plus a seccomp allowlist, derived from the app's
   own manifest. Fails closed.
3. **App ↔ Nova service.** `nova-secure-ipc` (Day 42). The peer's uid
   comes from the kernel via `SO_PEERCRED`, never from the message. A
   `Hello` claiming another app id is rejected, not believed.
4. **App ↔ specific grant.** `nova-capability` (Day 42). Unforgeable,
   expiring, attenuable tokens for cases where "be the Camera app" is
   too much authority.
5. **Device ↔ package supply.** `nova-package-sign` (Day 43). Verified
   before anything is unpacked or written.

Everything above is *user-space Nova code plus kernel enforcement*. Where
kernel enforcement is not actually active — because the process lacked
`CAP_CHOWN` or `CAP_SYS_ADMIN` — Nova reports that (`OwnershipOutcome::NotPermitted`,
`IsolationError::NamespaceDenied`) rather than proceeding as if it were.

---

## Least-privilege audit

Day 45's audit is code (`libs/nova-privilege-audit`), not prose, so it
cannot go stale silently. Every core service declares what it is granted
and, separately, which of its own tasks requires each privilege. Anything
granted without a task behind it fails the audit; anything needed but not
granted fails too.

Current result — seven services, zero failures:

| Service | uid | Privileges held | Why |
|---|---|---|---|
| nova-app-manager | 1000 | CAP_CHOWN, CAP_SETUID/SETGID, CAP_SYS_ADMIN, spawn, write `/apps` | apply per-app ownership; drop into an app's uid; unshare its namespaces; install packages |
| nova-svcmgr | 1000 | spawn, CAP_KILL | start/restart services; stop one it did not fork |
| nova-procmgrd | 1000 | spawn, CAP_KILL | supervise processes; SIGTERM escalating to SIGKILL |
| nova-netd | 1000 | CAP_NET_ADMIN, sockets | interfaces, addresses, routes; DHCP/DNS/TCP |
| nova-compositor | 1000 | raw device nodes | open display and input devices directly |
| nova-shell | 1000 | *(none)* | it is a client of everything else |
| nova-seclogd | 1000 | write system paths | append to a log apps must not be able to write |

Standing notes (not failures, but real):

* **No core service is itself sandboxed.** Day 41's namespaces and
  seccomp apply to apps only. App Manager needs `CAP_SYS_ADMIN` to
  create sandboxes, which makes sandboxing *it* a genuinely harder
  problem, but the others have no such excuse. Owner: M13/M14.
* **nova-app-manager is the concentration of privilege in this design.**
  Four of the six privileges in the table are its. Splitting the
  installer from the launcher would reduce that; it has not been done.

The audit also reconciles a declaration against a *running* process's
real uid and `CapEff` from `/proc`, so a declaration nobody checks
against reality cannot silently drift.

---

## Known limitations

Listed with an owner, because a limitation without one is a wish.

| # | Limitation | Consequence | Owner |
|---|---|---|---|
| 1 | Package signatures are **symmetric** (HMAC-SHA256) | proves integrity and key possession, not publisher identity to a third party | **M11** — a repository cannot ship without Ed25519; see `package-signing-v1.md` |
| 2 | `nova-crypto` is hand-written and unaudited | correct against published vectors; not reviewed, not hardened against timing analysis beyond `constant_time_eq` | M11 alongside #1 |
| 3 | The security log's hash chain gives **evidence**, not prevention | root can truncate the tail and re-chain; detecting that needs an anchor Nova does not control | M13 (device) / a remote collector |
| 4 | Capability expiry uses **wall-clock time** | moving the clock back revives an expired token | M15 (time and update policy) |
| 5 | **No rollback protection** on packages | a correctly signed, old, vulnerable package installs cleanly | M15 |
| 6 | Secure boot stages 0-3 are **specified, not implemented** | Nova boots an unverified kernel today | M12, device-dependent; see `secure-boot-strategy-v1.md` |
| 7 | Core services are **not sandboxed** | a compromised service has its full privilege set | M13/M14 |
| 8 | Kernel-enforced file ownership requires `CAP_CHOWN` | in a developer shell, Nova's checks run but the kernel's second, independent check does not | environmental; reported, never assumed |
| 9 | IPC is **authenticated, not confidential** | root can read local socket traffic | accepted; re-examine if a threat model change makes it matter |
| 10 | The M5 apps still use **ambient permissions** | capabilities are additive and not yet adopted by Settings/Contacts/Messages/Dialer/Camera | M14 |

---

## How to re-check every claim here

```bash
cargo test -p nova-identity -p nova-isolation -p nova-crypto \
           -p nova-capability -p nova-secure-ipc -p nova-package-sign \
           -p nova-seclog -p nova-privilege-audit

cargo run -p nova-m10-day40-identity-acceptance-test
cargo run -p nova-m10-day41-sandbox-hardening-acceptance-test   # needs namespace privileges
cargo run -p nova-m10-day42-secure-ipc-acceptance-test
cargo run -p nova-m10-day43-package-signing-acceptance-test
cargo run -p nova-m10-day44-security-logging-acceptance-test
cargo run -p nova-m10-day45-acceptance-test
```

Every table in this document traces to one of those. If a claim here has
no test behind it, it is in the limitations table instead.
