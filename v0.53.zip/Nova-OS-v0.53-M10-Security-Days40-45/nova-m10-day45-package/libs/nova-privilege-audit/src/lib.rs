//! Least-privilege audit of Nova's core services — M10 Day 45.
//!
//! The Day 45 task is "audit every M4/M5 core service and confirm each
//! runs with the minimum permissions it actually needs", and the DoD is
//! "no core service runs with broader permissions than its own audited
//! task list requires."
//!
//! An audit that lives in a document goes stale the first time someone
//! adds a capability to a service. So the audit is code: each service
//! declares what it is *granted* and, separately, what each of its own
//! tasks *needs* and why. Anything granted without a task behind it is
//! a finding. The document (`docs/security-model-v1.md`) then quotes
//! this crate's output rather than describing it from memory.
//!
//! Two layers, deliberately:
//!
//! * [`audit`] checks the **declared** model — granted versus needed.
//!   This is what runs in CI and what the M10 acceptance test asserts.
//! * [`observe`] reads a **running** process's real uid and effective
//!   capability set out of `/proc/<pid>/status` and reconciles it
//!   against the declaration. A declaration nobody checks against
//!   reality is the exact failure mode this crate exists to avoid, so
//!   the reconciliation is here rather than assumed.

use std::collections::BTreeSet;
use std::fs;
use std::path::PathBuf;

/// The privileges Nova cares about at this layer. Not a complete map of
/// Linux capabilities — a longer list nobody maintains is worse than a
/// short one that matches what Nova's services actually do.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Privilege {
    /// Runs as uid 0.
    Root,
    /// `CAP_CHOWN` — needed to apply Day 40's per-app file ownership.
    Chown,
    /// `CAP_SYS_ADMIN` — needed for Day 41's `unshare` of mount/PID
    /// namespaces.
    SysAdmin,
    /// `CAP_NET_ADMIN` — interface and routing configuration.
    NetAdmin,
    /// `CAP_KILL` — signalling processes it does not own.
    Kill,
    /// `CAP_SETUID`/`CAP_SETGID` — dropping into an app's identity
    /// before exec.
    SetUidGid,
    /// Write access to `/system` and `/apps`.
    WriteSystemPaths,
    /// May read any app's data directory.
    ReadAllAppData,
    /// May open raw device nodes (`/dev/video*`, `/dev/input/*`).
    RawDeviceAccess,
    /// May create network sockets.
    NetworkSockets,
    /// May spawn processes.
    SpawnProcesses,
}

impl Privilege {
    pub fn name(self) -> &'static str {
        match self {
            Privilege::Root => "root (uid 0)",
            Privilege::Chown => "CAP_CHOWN",
            Privilege::SysAdmin => "CAP_SYS_ADMIN",
            Privilege::NetAdmin => "CAP_NET_ADMIN",
            Privilege::Kill => "CAP_KILL",
            Privilege::SetUidGid => "CAP_SETUID/CAP_SETGID",
            Privilege::WriteSystemPaths => "write /system and /apps",
            Privilege::ReadAllAppData => "read all app data",
            Privilege::RawDeviceAccess => "raw device nodes",
            Privilege::NetworkSockets => "network sockets",
            Privilege::SpawnProcesses => "spawn processes",
        }
    }

    /// The Linux capability bit, where one exists. Used by [`observe`]
    /// to compare a declaration against `CapEff`.
    fn cap_bit(self) -> Option<u64> {
        // Values from the kernel's `capability.h`.
        Some(match self {
            Privilege::Chown => 1 << 0,     // CAP_CHOWN
            Privilege::Kill => 1 << 5,      // CAP_KILL
            Privilege::SetUidGid => 1 << 7, // CAP_SETUID (CAP_SETGID is bit 6; both are checked)
            Privilege::NetAdmin => 1 << 12, // CAP_NET_ADMIN
            Privilege::SysAdmin => 1 << 21, // CAP_SYS_ADMIN
            _ => return None,
        })
    }
}

/// One task a service performs, and the privilege it needs to perform
/// it. The justification is a required field, not a comment: a
/// privilege whose justification is empty is itself a finding, which
/// makes "we're not sure why this is here" impossible to leave in
/// silently.
#[derive(Debug, Clone)]
pub struct Justification {
    pub privilege: Privilege,
    pub task: String,
}

impl Justification {
    pub fn new(privilege: Privilege, task: impl Into<String>) -> Self {
        Justification { privilege, task: task.into() }
    }
}

#[derive(Debug, Clone)]
pub struct ServiceProfile {
    pub name: String,
    /// The uid Nova's init starts this service as.
    pub uid: u32,
    /// What the service is actually given.
    pub granted: Vec<Privilege>,
    /// What its own task list requires, with the task named.
    pub needs: Vec<Justification>,
    /// Whether the service itself runs inside Day 41's namespaces.
    pub isolated: bool,
    /// Whether a seccomp filter is applied to it.
    pub seccomp: bool,
}

impl ServiceProfile {
    pub fn granted_set(&self) -> BTreeSet<Privilege> {
        self.granted.iter().copied().collect()
    }

    pub fn needed_set(&self) -> BTreeSet<Privilege> {
        self.needs.iter().map(|j| j.privilege).collect()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity {
    /// Worth knowing; does not fail the audit.
    Note,
    /// Fails the audit. Day 45's DoD is not met while any of these
    /// exist.
    Fail,
}

#[derive(Debug, Clone)]
pub struct Finding {
    pub service: String,
    pub severity: Severity,
    pub issue: String,
}

#[derive(Debug, Clone, Default)]
pub struct AuditReport {
    pub findings: Vec<Finding>,
    pub services_audited: usize,
}

impl AuditReport {
    /// The literal DoD question: does any service hold more than its
    /// task list requires?
    pub fn passes(&self) -> bool {
        !self.findings.iter().any(|f| f.severity == Severity::Fail)
    }

    pub fn failures(&self) -> Vec<&Finding> {
        self.findings.iter().filter(|f| f.severity == Severity::Fail).collect()
    }

    pub fn notes(&self) -> Vec<&Finding> {
        self.findings.iter().filter(|f| f.severity == Severity::Note).collect()
    }

    pub fn render(&self) -> String {
        let mut out = format!("{} service(s) audited\n", self.services_audited);
        if self.findings.is_empty() {
            out.push_str("  no findings\n");
        }
        for f in &self.findings {
            let tag = match f.severity {
                Severity::Fail => "FAIL",
                Severity::Note => "note",
            };
            out.push_str(&format!("  [{tag}] {}: {}\n", f.service, f.issue));
        }
        out
    }
}

/// Audits the declared privilege model of one service.
pub fn audit_service(profile: &ServiceProfile) -> Vec<Finding> {
    let mut findings = Vec::new();
    let granted = profile.granted_set();
    let needed = profile.needed_set();

    for privilege in granted.difference(&needed) {
        findings.push(Finding {
            service: profile.name.clone(),
            severity: Severity::Fail,
            issue: format!("holds {} with no task in its own list requiring it", privilege.name()),
        });
    }

    // The reverse is a finding too, and a more dangerous one to leave
    // undetected: a service whose task list says it needs something it
    // was not granted will fail at runtime, in production, at whatever
    // moment that task first runs.
    for privilege in needed.difference(&granted) {
        let task = profile
            .needs
            .iter()
            .find(|j| j.privilege == *privilege)
            .map(|j| j.task.clone())
            .unwrap_or_default();
        findings.push(Finding {
            service: profile.name.clone(),
            severity: Severity::Fail,
            issue: format!("needs {} for \"{task}\" but is not granted it", privilege.name()),
        });
    }

    for justification in &profile.needs {
        if justification.task.trim().is_empty() {
            findings.push(Finding {
                service: profile.name.clone(),
                severity: Severity::Fail,
                issue: format!("{} is claimed as needed with no task named", justification.privilege.name()),
            });
        }
    }

    if profile.uid == 0 && !granted.contains(&Privilege::Root) {
        findings.push(Finding {
            service: profile.name.clone(),
            severity: Severity::Fail,
            issue: "runs as uid 0 without declaring Privilege::Root".to_string(),
        });
    }

    if granted.contains(&Privilege::Root) {
        findings.push(Finding {
            service: profile.name.clone(),
            severity: Severity::Note,
            issue: "runs as root; every capability it holds is therefore unbounded in practice".to_string(),
        });
    }

    if !profile.seccomp {
        findings.push(Finding {
            service: profile.name.clone(),
            severity: Severity::Note,
            issue: "no seccomp filter applied (apps get one from Day 41; core services do not yet)".to_string(),
        });
    }

    findings
}

pub fn audit(profiles: &[ServiceProfile]) -> AuditReport {
    let mut report = AuditReport { findings: Vec::new(), services_audited: profiles.len() };
    for profile in profiles {
        report.findings.extend(audit_service(profile));
    }
    report
}

/// Nova's core services, as M4 and M5 actually built them.
///
/// This is the audit's subject matter, written down once. Each entry's
/// `needs` list points at a real task from a real day — if a service's
/// job changes, this list is where the change has to be argued for.
///
/// Honest note on scope: in this repository these are libraries plus
/// the tools that drive them, not yet a set of daemons started by an
/// init with per-service uids. The profile below is the privilege model
/// as designed and as M12's device bring-up will configure it. That is
/// why [`observe`] exists — so the declaration can be checked against
/// what a process is really running with, the moment there is a real
/// process to check.
pub fn nova_core_services() -> Vec<ServiceProfile> {
    vec![
        ServiceProfile {
            name: "nova-app-manager".to_string(),
            uid: nova_identity::SYSTEM_UID,
            granted: vec![
                Privilege::Chown,
                Privilege::SetUidGid,
                Privilege::SysAdmin,
                Privilege::SpawnProcesses,
                Privilege::WriteSystemPaths,
            ],
            needs: vec![
                Justification::new(Privilege::Chown, "Day 40: apply per-app file ownership at install"),
                Justification::new(Privilege::SetUidGid, "Day 41: drop into the app's uid before exec"),
                Justification::new(Privilege::SysAdmin, "Day 41: unshare mount/PID/network namespaces for each app"),
                Justification::new(Privilege::SpawnProcesses, "Day 13: launch apps through Service Manager"),
                Justification::new(Privilege::WriteSystemPaths, "Day 22: write /apps/<id> at install time"),
            ],
            isolated: false,
            seccomp: false,
        },
        ServiceProfile {
            name: "nova-svcmgr".to_string(),
            uid: nova_identity::SYSTEM_UID,
            granted: vec![Privilege::SpawnProcesses, Privilege::Kill],
            needs: vec![
                Justification::new(Privilege::SpawnProcesses, "Day 6: start services and restart them per RestartPolicy"),
                Justification::new(Privilege::Kill, "Day 6: stop a service it did not itself fork"),
            ],
            isolated: false,
            seccomp: false,
        },
        ServiceProfile {
            name: "nova-procmgrd".to_string(),
            uid: nova_identity::SYSTEM_UID,
            granted: vec![Privilege::SpawnProcesses, Privilege::Kill],
            needs: vec![
                Justification::new(Privilege::SpawnProcesses, "Day 2: spawn and supervise processes"),
                Justification::new(Privilege::Kill, "Day 2: terminate with SIGTERM, escalate to SIGKILL"),
            ],
            isolated: false,
            seccomp: false,
        },
        ServiceProfile {
            name: "nova-netd".to_string(),
            uid: nova_identity::SYSTEM_UID,
            granted: vec![Privilege::NetAdmin, Privilege::NetworkSockets],
            needs: vec![
                Justification::new(Privilege::NetAdmin, "Day 29-31: bring interfaces up, set addresses and routes"),
                Justification::new(Privilege::NetworkSockets, "Day 31-32: DHCP/DNS and TCP connections"),
            ],
            isolated: false,
            seccomp: false,
        },
        ServiceProfile {
            name: "nova-compositor".to_string(),
            uid: nova_identity::SYSTEM_UID,
            granted: vec![Privilege::RawDeviceAccess],
            needs: vec![Justification::new(
                Privilege::RawDeviceAccess,
                "Day 23/27: open the display and input device nodes directly",
            )],
            isolated: false,
            seccomp: false,
        },
        ServiceProfile {
            name: "nova-shell".to_string(),
            uid: nova_identity::SYSTEM_UID,
            granted: vec![],
            needs: vec![],
            isolated: false,
            seccomp: false,
        },
        ServiceProfile {
            name: "nova-seclogd".to_string(),
            uid: nova_identity::SYSTEM_UID,
            granted: vec![Privilege::WriteSystemPaths],
            needs: vec![Justification::new(
                Privilege::WriteSystemPaths,
                "Day 44: append to /var/log/nova/security.log, which apps must not be able to write",
            )],
            isolated: false,
            seccomp: false,
        },
    ]
}

// --- Reconciling a declaration against a running process -------------

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ObservedProcess {
    pub pid: i32,
    pub uid: u32,
    /// `CapEff` from `/proc/<pid>/status`.
    pub effective_caps: u64,
}

#[derive(Debug)]
pub enum ObserveError {
    Io(String),
    Malformed(&'static str),
}

impl std::fmt::Display for ObserveError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ObserveError::Io(e) => write!(f, "io: {e}"),
            ObserveError::Malformed(w) => write!(f, "/proc status is malformed: {w}"),
        }
    }
}

impl std::error::Error for ObserveError {}

/// Reads a running process's real uid and effective capabilities from
/// `/proc`, the same way `nova-procmgr` reads process state — the
/// kernel's own answer, never a value Nova tracked separately and hoped
/// stayed true.
pub fn observe(pid: i32) -> Result<ObservedProcess, ObserveError> {
    let path = PathBuf::from(format!("/proc/{pid}/status"));
    let text = fs::read_to_string(&path).map_err(|e| ObserveError::Io(e.to_string()))?;

    let mut uid = None;
    let mut caps = None;
    for line in text.lines() {
        if let Some(rest) = line.strip_prefix("Uid:") {
            // "Uid:\treal\teffective\tsaved\tfs" — the effective uid is
            // what matters for what this process can do right now.
            let fields: Vec<&str> = rest.split_whitespace().collect();
            if fields.len() >= 2 {
                uid = fields[1].parse::<u32>().ok();
            }
        } else if let Some(rest) = line.strip_prefix("CapEff:") {
            caps = u64::from_str_radix(rest.trim(), 16).ok();
        }
    }

    match (uid, caps) {
        (Some(uid), Some(effective_caps)) => Ok(ObservedProcess { pid, uid, effective_caps }),
        (None, _) => Err(ObserveError::Malformed("no Uid: line")),
        (_, None) => Err(ObserveError::Malformed("no CapEff: line")),
    }
}

/// Compares what a process really holds against what its profile says
/// it should.
pub fn reconcile(profile: &ServiceProfile, observed: &ObservedProcess) -> Vec<Finding> {
    let mut findings = Vec::new();

    if observed.uid != profile.uid {
        findings.push(Finding {
            service: profile.name.clone(),
            severity: Severity::Fail,
            issue: format!("declared uid {} but pid {} is running as uid {}", profile.uid, observed.pid, observed.uid),
        });
    }

    let granted = profile.granted_set();
    for privilege in [
        Privilege::Chown,
        Privilege::Kill,
        Privilege::SetUidGid,
        Privilege::NetAdmin,
        Privilege::SysAdmin,
    ] {
        let Some(bit) = privilege.cap_bit() else { continue };
        let held = observed.effective_caps & bit != 0;
        if held && !granted.contains(&privilege) {
            findings.push(Finding {
                service: profile.name.clone(),
                severity: Severity::Fail,
                issue: format!("pid {} effectively holds {} but the profile does not grant it", observed.pid, privilege.name()),
            });
        }
    }

    // Root holds everything regardless of what CapEff says about
    // individual bits, so saying "no excess capabilities" about a
    // root process would be technically true and substantively wrong.
    if observed.uid == 0 && !granted.contains(&Privilege::Root) {
        findings.push(Finding {
            service: profile.name.clone(),
            severity: Severity::Fail,
            issue: format!("pid {} is running as root, which the profile does not declare", observed.pid),
        });
    }

    findings
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The literal Day 45 DoD, checked against the real inventory: no
    /// core service holds more than its own task list requires.
    #[test]
    fn day45_no_core_service_exceeds_its_task_list() {
        let report = audit(&nova_core_services());
        assert!(
            report.passes(),
            "least-privilege audit failed:\n{}",
            report.failures().iter().map(|f| format!("  {}: {}", f.service, f.issue)).collect::<Vec<_>>().join("\n")
        );
        assert_eq!(report.services_audited, 7);
    }

    #[test]
    fn no_core_service_runs_as_root() {
        for profile in nova_core_services() {
            assert_ne!(profile.uid, 0, "{} runs as root", profile.name);
            assert!(!profile.granted.contains(&Privilege::Root), "{} is granted root", profile.name);
        }
    }

    /// The audit has to be able to fail, or passing means nothing.
    #[test]
    fn an_excess_privilege_is_caught() {
        let mut profile = nova_core_services().into_iter().find(|p| p.name == "nova-shell").unwrap();
        profile.granted.push(Privilege::ReadAllAppData);

        let findings = audit_service(&profile);
        assert!(
            findings.iter().any(|f| f.severity == Severity::Fail && f.issue.contains("read all app data")),
            "granting the shell the ability to read every app's data must be a failure"
        );
    }

    #[test]
    fn a_missing_grant_is_caught_too() {
        let mut profile = nova_core_services().into_iter().find(|p| p.name == "nova-netd").unwrap();
        profile.granted.retain(|p| *p != Privilege::NetAdmin);
        let findings = audit_service(&profile);
        assert!(findings.iter().any(|f| f.severity == Severity::Fail && f.issue.contains("but is not granted it")));
    }

    #[test]
    fn an_unjustified_privilege_cannot_be_hidden_behind_an_empty_task() {
        let profile = ServiceProfile {
            name: "nova-test".into(),
            uid: 1000,
            granted: vec![Privilege::SysAdmin],
            needs: vec![Justification::new(Privilege::SysAdmin, "   ")],
            isolated: false,
            seccomp: false,
        };
        let findings = audit_service(&profile);
        assert!(findings.iter().any(|f| f.severity == Severity::Fail && f.issue.contains("no task named")));
    }

    #[test]
    fn a_root_process_is_caught_by_reconciliation() {
        let profile = nova_core_services().into_iter().find(|p| p.name == "nova-shell").unwrap();
        let observed = ObservedProcess { pid: 1234, uid: 0, effective_caps: u64::MAX };
        let findings = reconcile(&profile, &observed);
        assert!(findings.iter().any(|f| f.issue.contains("running as root")));
        assert!(findings.iter().any(|f| f.issue.contains("declared uid")));
    }

    #[test]
    fn a_matching_process_reconciles_cleanly() {
        let profile = nova_core_services().into_iter().find(|p| p.name == "nova-shell").unwrap();
        let observed = ObservedProcess { pid: 1234, uid: nova_identity::SYSTEM_UID, effective_caps: 0 };
        assert!(reconcile(&profile, &observed).is_empty());
    }

    /// `observe` really reads `/proc`. Run against this test process,
    /// where the expected answer is independently knowable.
    #[test]
    fn observe_reads_the_real_proc_status() {
        let pid = std::process::id() as i32;
        let observed = observe(pid).expect("/proc/self/status should be readable");
        assert_eq!(observed.pid, pid);
        // SAFETY: geteuid cannot fail and touches no memory.
        assert_eq!(observed.uid, unsafe { libc::geteuid() });
    }
}
