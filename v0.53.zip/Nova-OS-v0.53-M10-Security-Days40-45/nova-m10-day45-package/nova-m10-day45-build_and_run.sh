#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 45 (M10 Security): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 45: unit tests ==="
cargo test -p nova-privilege-audit -p nova-identity -p nova-isolation -p nova-crypto -p nova-capability -p nova-secure-ipc -p nova-package-sign -p nova-seclog

echo
echo "=== nova-m10-day40-identity-acceptance-test ==="
cargo run -p nova-m10-day40-identity-acceptance-test

echo
echo "=== nova-m10-day41-sandbox-hardening-acceptance-test ==="
echo "This one launches a real hostile binary and needs namespace privileges."
echo "Run as root, or on a kernel with unprivileged user namespaces enabled."
cargo run -p nova-m10-day41-sandbox-hardening-acceptance-test

echo
echo "=== nova-m10-day42-secure-ipc-acceptance-test ==="
cargo run -p nova-m10-day42-secure-ipc-acceptance-test

echo
echo "=== nova-m10-day43-package-signing-acceptance-test ==="
cargo run -p nova-m10-day43-package-signing-acceptance-test

echo
echo "=== nova-m10-day44-security-logging-acceptance-test ==="
cargo run -p nova-m10-day44-security-logging-acceptance-test

echo
echo "=== nova-m10-day45-acceptance-test ==="
cargo run -p nova-m10-day45-acceptance-test

echo
echo "Day 45 build + tests + acceptance completed."
echo
echo "If everything above passed, tag the repo (see docs/M10-TAG.md):"
echo "  git tag -a v0.53 -m \"M10: Security\""
echo "  git push origin v0.53"
