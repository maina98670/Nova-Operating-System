//! Day 45 acceptance test — the literal Definition of Done:
//!
//! > No core service runs with broader permissions than its own audited
//! > task list requires; the security model doc is complete enough for
//! > an external reviewer to assess. Tag M10.
//!
//! Day 45 closes M10, so this is also the milestone's integration test.
//! It re-establishes, in one run, that each of Days 40-45 still holds —
//! because that is what a milestone tag claims, and a tag that only
//! proves the last day's work is worth less than it looks.
//!
//! What it does **not** do is re-run Day 41's live sandbox escape test.
//! That one needs namespace privileges this process may not have, and
//! quietly downgrading it here to "the spec looks right" while printing
//! PASS would be exactly the kind of claim this project keeps refusing
//! to make. Day 41's own test is a separate, required step in
//! `nova-m10-day45-build_and_run.sh`, and the summary below says so.

use nova_capability::{CapabilityError, CapabilityIssuer};
use nova_crypto::{sha256, to_hex};
use nova_identity::{Access, Enforcer, IdentityRegistry};
use nova_ipc::Permission;
use nova_isolation::{Arch, IsolationSpec};
use nova_package_sign::{sign, Keystore, PackageVerifyError, SigningKey};
use nova_privilege_audit::{audit, nova_core_services, observe, reconcile, Privilege};
use nova_sandbox::{PermissionSet, SandboxPolicy};
use nova_seclog::{ChainStatus, SecurityEvent, SecurityEventKind, SecurityLog};
use std::fs;
use std::path::PathBuf;
use std::process::ExitCode;

struct Check {
    day: u8,
    name: String,
    passed: bool,
    detail: String,
}

fn check(day: u8, name: &str, passed: bool, detail: impl Into<String>) -> Check {
    Check { day, name: name.to_string(), passed, detail: detail.into() }
}

fn main() -> ExitCode {
    println!("=== Nova OS M10 (Security) acceptance — Days 40-45 ===\n");

    let root = std::env::temp_dir().join(format!("nova-m10-acceptance-{}", std::process::id()));
    let _ = fs::remove_dir_all(&root);
    fs::create_dir_all(&root).expect("create test root");
    let mut checks: Vec<Check> = Vec::new();

    // ---------------- Day 45: the least-privilege audit ---------------
    let services = nova_core_services();
    let report = audit(&services);
    println!("{}", report.render());

    checks.push(check(
        45,
        "no core service holds a privilege its own task list does not require",
        report.passes(),
        format!(
            "{} service(s), {} failure(s), {} note(s)",
            report.services_audited,
            report.failures().len(),
            report.notes().len()
        ),
    ));

    checks.push(check(
        45,
        "no core service runs as root",
        services.iter().all(|s| s.uid != 0 && !s.granted.contains(&Privilege::Root)),
        services.iter().map(|s| format!("{}={}", s.name, s.uid)).collect::<Vec<_>>().join(" "),
    ));

    // The audit must be capable of failing, or its passing is noise.
    let mut over_privileged = services.iter().find(|s| s.name == "nova-shell").cloned().expect("nova-shell profile");
    over_privileged.granted.push(Privilege::SysAdmin);
    checks.push(check(
        45,
        "control: an over-privileged service is caught by the audit",
        !audit(&[over_privileged]).passes(),
        "granting the shell CAP_SYS_ADMIN fails the audit",
    ));

    // And the declaration is checked against a real process, not just
    // against itself.
    let self_observed = observe(std::process::id() as i32);
    checks.push(match &self_observed {
        Ok(observed) => {
            let shell = services.iter().find(|s| s.name == "nova-shell").unwrap();
            let findings = reconcile(shell, observed);
            check(
                45,
                "a running process's real uid and CapEff are readable and reconcilable",
                true,
                format!(
                    "pid {} runs as uid {} with CapEff {:#x}; reconciled against nova-shell's profile: {} finding(s)",
                    observed.pid,
                    observed.uid,
                    observed.effective_caps,
                    findings.len()
                ),
            )
        }
        Err(e) => check(45, "a running process's real uid and CapEff are readable and reconcilable", false, format!("{e}")),
    });

    // ---------------- Day 40: identity & filesystem -------------------
    let enforcer = Enforcer::new(root.join("apps"));
    let mut registry = IdentityRegistry::open(root.join("identities.tsv")).unwrap();
    let alpha = registry.allocate("org.nova.alpha").unwrap();
    let beta = registry.allocate("org.nova.beta").unwrap();
    enforcer.provision(&alpha).unwrap();
    let beta_root = enforcer.provision(&beta).unwrap();
    fs::write(beta_root.join("secret.txt"), b"beta's private data").unwrap();
    std::os::unix::fs::symlink(&beta_root, enforcer.app_root(&alpha).join("neighbour")).unwrap();

    let alpha_policy = SandboxPolicy::new("org.nova.alpha", PermissionSet::empty(), PermissionSet::empty()).unwrap();
    let traversal = enforcer.authorize(&alpha_policy, &alpha, "../org.nova.beta/secret.txt", Access::Read);
    let symlink = enforcer.authorize(&alpha_policy, &alpha, "neighbour/secret.txt", Access::Read);
    let own = enforcer.write(&alpha_policy, &alpha, "notes.txt", b"alpha's own").and_then(|_| {
        enforcer.read(&alpha_policy, &alpha, "notes.txt")
    });
    checks.push(check(
        40,
        "distinct identities, and neither traversal nor symlink crosses between them",
        traversal.is_err() && symlink.is_err() && own.is_ok() && alpha.uid != beta.uid,
        format!("uid {} vs {}; both cross-app attempts refused; own data still reachable", alpha.uid, beta.uid),
    ));

    checks.push(check(
        40,
        "app uids are stable across a restart",
        IdentityRegistry::open(root.join("identities.tsv")).unwrap().get("org.nova.alpha").unwrap().uid == alpha.uid,
        format!("{} keeps uid {} after reloading the table", alpha.app_id, alpha.uid),
    ));

    // ---------------- Day 41: isolation, statically checked -----------
    let arch = Arch::host();
    checks.push(match arch {
        Some(arch) => {
            let no_net = IsolationSpec::from_policy(
                &SandboxPolicy::new("org.nova.alpha", PermissionSet::from_permissions([Permission::Storage]), PermissionSet::empty()).unwrap(),
                &alpha,
                arch,
            );
            let with_net = IsolationSpec::from_policy(
                &SandboxPolicy::new("org.nova.alpha", PermissionSet::from_permissions([Permission::Network]), PermissionSet::empty()).unwrap(),
                &alpha,
                arch,
            );
            let filter = no_net.seccomp.compile();
            let n = no_net.seccomp.allowed().len();
            let shape_ok = filter.as_ref().map(|p| p.len() == n + 6).unwrap_or(false);
            check(
                41,
                "isolation is derived from the manifest, and exec/mount are never allowed",
                no_net.net_ns
                    && !no_net.seccomp.allows_socket()
                    && !with_net.net_ns
                    && with_net.seccomp.allows_socket()
                    && !with_net.seccomp.allows_exec()
                    && !with_net.seccomp.allows_mount()
                    && shape_ok,
                format!(
                    "without Permission::Network: {} namespaces, {} syscalls, socket() denied; with it: socket() allowed, exec/mount still denied; filter compiles to {} instructions",
                    no_net.requested().len(),
                    n,
                    filter.map(|p| p.len()).unwrap_or(0)
                ),
            )
        }
        None => check(41, "isolation is derived from the manifest, and exec/mount are never allowed", false, format!("unsupported host arch {}", std::env::consts::ARCH)),
    });

    // ---------------- Day 42: crypto, capabilities, IPC ---------------
    checks.push(check(
        42,
        "SHA-256 still matches its published test vector",
        to_hex(&sha256(b"abc")) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        "FIPS 180-4 one-block vector",
    ));

    let issuer = CapabilityIssuer::new(b"m10 acceptance key".to_vec());
    let cap = issuer.issue_at("org.nova.camera", Permission::Camera, 600, 1_000_000);
    let mut forged = cap.clone();
    forged.permission = Permission::Microphone;
    checks.push(check(
        42,
        "capabilities cannot be forged, widened, stolen or outlived",
        issuer.verify_at(&cap, "org.nova.camera", 1_000_010).is_ok()
            && issuer.verify_at(&forged, "org.nova.camera", 1_000_010) == Err(CapabilityError::BadTag)
            && issuer.verify_at(&cap, "org.nova.evil", 1_000_010) == Err(CapabilityError::WrongApp)
            && matches!(issuer.verify_at(&cap, "org.nova.camera", 1_000_601), Err(CapabilityError::Expired { .. }))
            && issuer.delegate_at(&cap, "org.nova.camera", "org.nova.messages", 99_999, 1_000_000)
                == Err(CapabilityError::ExpiryExtension),
        "forge, steal, widen, expire and extend all refused; the genuine token verifies",
    ));

    // ---------------- Day 43: package signing -------------------------
    let key = SigningKey::generate("nova-dev-2026").expect("signing key");
    let mut keystore = Keystore::new();
    keystore.trust(key.public_half());
    let package = nova_package_format::pack(b"id = \"org.nova.signtest\"\nentry_point = \"bin/x\"\n", b"\x7fELF genuine");
    let signed = sign(&package, &key);
    let mut tampered = signed.clone();
    tampered[4] ^= 0x10;
    let stranger = SigningKey::generate("other-vendor").expect("signing key");

    checks.push(check(
        43,
        "signed packages verify; unsigned, tampered and untrusted ones do not",
        nova_package_sign::verify(&signed, &keystore).is_ok()
            && matches!(nova_package_sign::verify(&package, &keystore), Err(PackageVerifyError::Unsigned))
            && matches!(nova_package_sign::verify(&tampered, &keystore), Err(PackageVerifyError::BadSignature { .. }))
            && matches!(
                nova_package_sign::verify(&sign(&package, &stranger), &keystore),
                Err(PackageVerifyError::UntrustedKey(_))
            ),
        "four cases, four distinct outcomes",
    ));

    // ---------------- Day 44: security logging ------------------------
    let security_path = root.join("security.log");
    let mut security = SecurityLog::open(&security_path).unwrap();
    security.record(SecurityEvent::sandbox_violation("org.nova.alpha", "symlink escape refused")).unwrap();
    security.record(SecurityEvent::ipc_auth_failure("org.nova.evil", "wrong channel")).unwrap();
    security.record(SecurityEvent::package_rejected("bad.npkg", "untrusted key")).unwrap();
    let intact = security.verify_on_disk().unwrap();

    let doctored = fs::read_to_string(&security_path).unwrap().replace("symlink escape refused", "nothing happened!!!");
    fs::write(&security_path, doctored).unwrap();
    let broken = security.verify_on_disk().unwrap();

    checks.push(check(
        44,
        "security events are separately queryable and tamper-evident",
        security.by_kind(SecurityEventKind::PackageRejected).len() == 1
            && security.by_principal("org.nova.evil").len() == 1
            && matches!(intact, ChainStatus::Intact { records: 3 })
            && !matches!(broken, ChainStatus::Intact { .. }),
        format!("chain before: {intact:?}; after one edited line: {broken:?}"),
    ));

    // ---------------- Day 45: the documents ---------------------------
    for (doc, required) in [
        ("security-model-v1.md", vec!["Threat model", "Trust boundaries", "Known limitations", "Least-privilege audit"]),
        ("secure-boot-strategy-v1.md", vec!["Chain of trust", "What waits for M12", "Rollback protection"]),
        ("package-signing-v1.md", vec!["Wire format", "Trust model", "Ed25519"]),
        ("M10-TAG.md", vec!["Day 40", "Day 45", "v0.53"]),
    ] {
        let found = find_doc(doc);
        checks.push(match found {
            Some((path, text)) => {
                let missing: Vec<&str> = required.iter().copied().filter(|s| !text.contains(s)).collect();
                check(
                    45,
                    &format!("docs/{doc} exists and covers what it must"),
                    missing.is_empty(),
                    if missing.is_empty() {
                        format!("{} ({} bytes)", path.display(), text.len())
                    } else {
                        format!("missing sections: {}", missing.join(", "))
                    },
                )
            }
            None => check(45, &format!("docs/{doc} exists and covers what it must"), false, "not found (run from the package root)"),
        });
    }

    // ---------------- Verdict ----------------------------------------
    println!("Checks:");
    let mut failures = 0;
    for c in &checks {
        if c.passed {
            println!("  [PASS] (Day {}) {}\n         {}", c.day, c.name, c.detail);
        } else {
            failures += 1;
            println!("  [FAIL] (Day {}) {}\n         {}", c.day, c.name, c.detail);
        }
    }

    let _ = fs::remove_dir_all(&root);

    println!();
    println!("Not covered by this test, and required before tagging M10:");
    println!("  * Day 41's live sandbox escape test — needs namespace privileges, so it runs");
    println!("    separately: cargo run -p nova-m10-day41-sandbox-hardening-acceptance-test");
    println!("  * Kernel-enforced file ownership — needs CAP_CHOWN; without it Nova's own");
    println!("    checks are exercised but the kernel's second, independent enforcement is not.");
    println!("  * Secure boot on real hardware — M12, by design (see docs/secure-boot-strategy-v1.md).");
    println!();

    if failures == 0 {
        println!("M10 acceptance: PASS ({} checks across Days 40-45)", checks.len());
        println!("Tag with: git tag -a v0.53 -m \"M10: Security\"   (see docs/M10-TAG.md)");
        ExitCode::SUCCESS
    } else {
        println!("M10 acceptance: FAIL ({failures} of {} checks failed) — do not tag v0.53", checks.len());
        ExitCode::FAILURE
    }
}

fn find_doc(name: &str) -> Option<(PathBuf, String)> {
    let mut dir = std::env::current_dir().ok()?;
    for _ in 0..5 {
        let candidate = dir.join("docs").join(name);
        if let Ok(text) = fs::read_to_string(&candidate) {
            return Some((candidate, text));
        }
        if !dir.pop() {
            break;
        }
    }
    None
}
