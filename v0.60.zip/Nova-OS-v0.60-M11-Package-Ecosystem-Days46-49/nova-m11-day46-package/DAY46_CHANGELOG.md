# Nova OS Day 46 — nova-pack CLI, package metadata and versioning

M11 (Package Ecosystem), v0.60. Continues directly from the Day 45 package.

## Definition of Done

> `nova-pack install/remove/update/list` as the user-facing package manager, distinct from the developer-facing `nova install` from M6. Package metadata and semantic versioning support. `nova-pack install`, `list`, and `remove` all work correctly against a local test package repository.

## New in this package

- `libs/nova-pack-meta`
- `tools/nova-pack` (library + `nova-pack` binary)
- `tools/nova-m11-day46-acceptance-test`
- `docs/M11-PACKAGE-DAY46.md`

## Retrofits to earlier days

This is the first M11 package built with a working Rust toolchain
available, and building it surfaced six defects in code that had been
shipped but never compiled. All six are fixed here rather than carried
forward; each is described in `docs/M11-RETROFITS.md`.

## Unchanged

Everything else from the previous package is carried forward as-is,
except for the workspace member list. No earlier day's behaviour was
replaced.
