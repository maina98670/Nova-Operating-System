# M11 Day 46 — `nova-pack` CLI, package metadata, versioning

**Definition of Done:** `nova-pack install`, `list`, and `remove` all work
correctly against a local test package repository.

## What was built

| Component | What it is |
| --- | --- |
| `libs/nova-pack-meta` | Semantic versions and version requirements; `PackageMeta` derived from package bytes; the installed-package database. |
| `tools/nova-pack` (lib) | The engine: sources, candidate selection, install, remove, update. |
| `tools/nova-pack` (bin) | The CLI a user or a settings screen drives. |
| `tools/nova-m11-day46-acceptance-test` | 15 checks against the filesystem and the database. |

## Why a second install path exists at all

`nova install` (M6 Day 22) is an SDK command: point it at a file, it
unpacks the file. It keeps no record, cannot remove anything, and has no
idea where a package came from. That is correct for a developer pushing
a build to the device in front of them and wrong for everything else.

`nova-pack` is the user-facing half — closer to `apt` than to `dpkg -i`.
The two share M6's package format and M10's signature verification and
nothing else.

**The new path is not a softer path.** `nova install` carries an
`--allow-unsigned` flag for debugging a build. `nova-pack` does not have
one and will not get one. An install path that can be talked out of
checking a signature is the M10 guarantee quietly expiring, and the Day
47 DoD names this risk explicitly.

## Version semantics

Four requirement forms: `*`, `1.2.3`, `>=1.2.3`, `^1.2.3`.

Two choices worth stating because they differ from Cargo, which is the
tool most Nova developers will be comparing against:

- **A bare `1.2.3` is exact, not caret.** A developer who writes down
  one version usually means the one version they tested against.
  A manifest that means "compatible" can say `^1.2.3` in one character.
- **`^0.x.y` respects the zero-major rule.** Every Nova crate is 0.x
  today; treating `0.4.1 → 0.5.0` as compatible would make caret
  requirements meaningless for the entire current package set.

Pre-releases sort below their release (`1.2.0-beta.1 < 1.2.0`), and
pre-release tags compare component-wise with numbers compared as numbers
— `beta.9 < beta.10`, which plain string comparison gets backwards.

## Where metadata comes from

Always the package bytes. The recorded SHA-256 covers the **signed**
file — the bytes that would actually be transferred — not the payload
inside it. A repository index restates metadata; `nova-pack` checks the
index against the package rather than believing it. A listing says where
to look, never what arrived.

## On-disk layout

```text
<root>/apps/<id>/nova-app.toml         installed manifest
<root>/apps/<id>/bin/<binary>          installed executable, mode 0755
<root>/var/lib/nova/pack/installed.db  what is installed
<root>/var/lib/nova/pack/sources.list  where packages come from
<root>/etc/nova/keys/trusted.tsv       M10's keystore, unchanged
```

Everything resolves under one root, so a test, an image build and a real
device run the same code against different roots. Nothing writes outside
the root it was given.

The database is a blank-line-separated flat record format, matching
`nova-log` and the identity registry — greppable on a device with no
debugger. It is rewritten whole via temp-file-and-rename, because the
one thing that must not happen is a half-written database after power
loss mid-install. Unknown keys in a record are skipped rather than
treated as corruption, so a database written by a newer Nova does not
brick an older one.

## Ordering decisions that matter

**Install:** read → verify signature → derive metadata → *then* touch
`/apps`. A package that fails any earlier step was never installed,
rather than installed and then cleaned up.

**Remove:** files first, then the database record. If the process dies
between them, what is left is a database claiming something is installed
that is not — which Day 48's `verify` detects. The other order would
leave files nothing knows about, which nothing can ever detect.

## What Day 46 does not do

- **Dependencies are recorded, not enforced.** `depends` is parsed from
  the manifest and stored; nothing yet refuses an install with an unmet
  dependency, and nothing yet refuses a removal that would break a
  dependent. Day 47.
- **No post-install integrity checking or rollback.** The database
  records no per-file hashes yet and keeps no previous package. Day 48.
- **Sources are scanned, not indexed.** A source is a directory of
  `.npkg` files. Day 49 defines the index format a real store would
  serve, and keeps scanning as the fallback.
- **Signatures are still symmetric** (M10's HMAC-SHA256). They prove
  integrity and key possession, not publisher identity to a third party.
  Day 49.
