# M11 retrofits — six defects found by compiling code that had never been compiled

Every package up to v0.53 carries the same honest warning: *"This package
was assembled without a Rust toolchain. Nothing in it has been compiled
or run."* M11 is the first milestone assembled with a toolchain
available. The first thing done with it was to build and test the v0.53
tree exactly as shipped.

It did not build. Six defects, listed here in the order the compiler and
then the test runner found them. All six are fixed in the Day 46 package
and every later M11 package; none of them is a new M11 feature.

This document exists because "we found six bugs the moment we compiled
it" is a fact about the whole project's method, not a footnote to one
day's work.

---

## 1. `nova-package-format` did not compile — missing lifetime

```text
error[E0106]: missing lifetime specifier
  --> libs/nova-package-format/src/lib.rs:95
```

`read_bytes(data: &[u8], …, field: &'static str) -> Result<&[u8], _>`:
with two input lifetimes and no elision rule to pick between them, the
return lifetime is ambiguous. Fixed by naming it: `read_bytes<'a>(data:
&'a [u8], …) -> Result<&'a [u8], _>`.

This is in the crate the entire package format depends on. Nothing
downstream of it — `nova install`, `nova package`, M10's signing — could
have compiled either.

## 2. `nova-shell` used a crate it never declared

```text
error[E0432]: unresolved import `nova_window_api`
```

`tools/nova-shell/src/main.rs` imports `nova_window_api::Window` and is
generic over `nova_window_api::WaylandBackend`, but its `Cargo.toml`
listed five dependencies and that was not one of them. Added.

## 3. `org.nova.windowtest` had a non-exhaustive match

```text
error[E0004]: non-exhaustive patterns: `Err(InputError::Disconnected(_))` not covered
```

The Day 19 test app matched `Err(InputError::NotYetAvailable)` and
`Ok(_)` and stopped there. `InputError` gained a `Disconnected` variant
later and this call site was never revisited. Handled explicitly — and
as a failure, because a disconnected input source before M7 exists is
just as much a regression as an event arriving early.

## 4. `nova-config`: `load_or_default` returned zeroes, not the defaults

The first test failure rather than compile error, and the most serious
of the six.

`load_or_default` returns `T::default()` when a config file is missing.
The example config type derived `Default` while declaring
`#[serde(default = "default_max_connections")]` on its fields. Those are
two unrelated mechanisms: `#[derive(Default)]` produces `0` and `""` and
never consults the serde attributes.

The effect on a real device: a service with **no** config file gets
zeroes, while a service with an **empty** config file gets the intended
defaults. Same intent, opposite results, no error either way.

Fixed by writing `Default` by hand to delegate to the same functions the
serde attributes name, and by documenting the rule on `load_or_default`
itself so the next config type does not repeat it.

## 5. `nova-storage-api`: every app's first write failed

Five test failures, all `ENOENT`.

Day 26 moved this crate off `SandboxPolicy::write_scoped` onto
`nova_fsmgr` directly, to satisfy the Day 26 DoD that storage really go
through M4's Filesystem Manager. `write_scoped` created parent
directories; `nova_fsmgr::write_file` does not, and nothing else in the
install path ever created an app's data root.

So `StorageApi::open` succeeded, `scoped_path` resolved correctly, and
the write failed with "No such file or directory" — for every app, on
its first ever write. Fixed by creating the app data root in `open` and
creating key parents in `write`. Both are inside a path `scoped_path`
has already proven to be within the sandbox, so neither can create a
directory outside it.

## 6. `nova-identity`: `apply_ownership` only chowned one inode

Surfaced by Day 40's own acceptance test, which failed its final control
check: *beta cannot read its own file*.

`apply_ownership` called `chown(2)` on exactly the path it was handed.
`provision` calls it on a freshly created, empty app data root — and
every file an app will ever own arrives afterwards. The result is a
correctly-owned root full of files owned by the installing process, and
Nova's own ownership gate then denies the app access to its own data.

Fixed by recursing into directories before chowning the directory
itself. A per-file chown at write time would have been the wrong fix: it
trusts whoever is writing. Ownership is a property of the subtree, so it
is applied to the subtree.

The Day 40 test had a second, smaller bug of its own: it planted beta's
secret file *after* calling `apply_ownership`, so even a correct
recursive chown would have missed it. The fixture now plants the file
first. A test whose control checks fail proves nothing, however many of
its negative checks pass.

---

## What this changes about reading the earlier packages

Days 1–45 were written carefully and reviewed carefully, and they still
contained a crate that could not compile, a service-config path that
silently zeroed every default, a storage API that failed on first use,
and an ownership call that left apps locked out of their own data. Three
of the six would have been caught by `cargo build` alone.

The guide's own Definition-of-Done discipline is not what failed here —
the DoDs are good. What failed is that they were never *run*. From M11
on, every day's package is built and its acceptance test executed before
the package is written, and the release notes say which checks passed on
which machine rather than asking the reader to run them.
