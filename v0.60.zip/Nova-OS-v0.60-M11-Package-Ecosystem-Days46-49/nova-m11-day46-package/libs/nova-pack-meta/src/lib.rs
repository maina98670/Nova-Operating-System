//! Nova OS M11 Day 46 — package metadata, versioning, and the
//! installed-package database.
//!
//! M6's `nova install` (Day 22) is a developer tool: it takes a file
//! path, unpacks it, and writes it into `/apps`. It keeps no record of
//! what it did. That is fine for "build my app and push it to the
//! device I am holding" and useless for everything a package manager
//! has to answer afterwards — what is installed, at which version, who
//! signed it, what depends on it, and what the files on disk are
//! supposed to look like.
//!
//! This crate is that record, plus the version arithmetic every other
//! M11 crate needs.
//!
//! ## Where metadata comes from
//! Always from the package bytes. [`PackageMeta::from_npkg`] parses the
//! manifest that is actually inside the `.npkg`, hashes the bytes that
//! were actually handed over, and reads the key id out of the actual
//! signature trailer. A repository index (Day 49) restates all three,
//! and `nova-pack` checks the index against the package rather than
//! believing it — a listing is a hint about where to look, never a
//! source of truth about what arrived.
//!
//! ## The database format
//! Blank-line-separated records of `key: value` lines, the same
//! hand-rolled flat format `nova-log`, `nova-contacts` and the identity
//! registry use, for the same reason: it is small, stable, diffable,
//! greppable when something has gone wrong on a device with no
//! debugger, and needs no parser beyond `split`. Unknown keys are
//! preserved-by-ignoring rather than treated as corruption, so a
//! database written by a newer Nova does not brick an older one.

use nova_crypto::{sha256, to_hex};
use serde::Deserialize;
use std::collections::BTreeMap;
use std::fmt;
use std::path::{Path, PathBuf};

// ---------------------------------------------------------------------
// Versions
// ---------------------------------------------------------------------

/// A semantic version: `major.minor.patch` with an optional
/// pre-release tag (`1.2.0-beta.1`).
///
/// Build metadata (`+sha.abc`) is deliberately not supported. Semver
/// says build metadata is ignored when comparing versions, which means
/// supporting it would create two distinct strings that order equal —
/// a package manager then has to answer "are these the same version?"
/// with "yes for ordering, no for equality", and every caller has to
/// know which one it meant. Nova's build ids go in the manifest's own
/// fields instead, where they are data rather than part of an identity.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Version {
    pub major: u64,
    pub minor: u64,
    pub patch: u64,
    /// `None` for a release. `Some("beta.1")` for `1.2.0-beta.1`.
    pub pre: Option<String>,
}

impl Version {
    pub fn new(major: u64, minor: u64, patch: u64) -> Self {
        Version { major, minor, patch, pre: None }
    }

    pub fn parse(s: &str) -> Result<Version, MetaError> {
        let s = s.trim();
        let (core, pre) = match s.split_once('-') {
            Some((core, pre)) if !pre.is_empty() => (core, Some(pre.to_string())),
            Some(_) => return Err(MetaError::BadVersion(s.to_string())),
            None => (s, None),
        };
        let mut parts = core.split('.');
        let mut next = |field: &str| -> Result<u64, MetaError> {
            parts
                .next()
                .filter(|p| !p.is_empty() && p.bytes().all(|b| b.is_ascii_digit()))
                .ok_or_else(|| MetaError::BadVersion(format!("{s} (missing or non-numeric {field})")))?
                .parse::<u64>()
                .map_err(|_| MetaError::BadVersion(s.to_string()))
        };
        let major = next("major")?;
        let minor = next("minor")?;
        let patch = next("patch")?;
        if parts.next().is_some() {
            return Err(MetaError::BadVersion(format!("{s} (more than three numeric components)")));
        }
        Ok(Version { major, minor, patch, pre })
    }

    /// The first version that is *not* compatible with this one under
    /// the caret rule. `^1.2.3` -> `2.0.0`; `^0.4.1` -> `0.5.0`;
    /// `^0.0.3` -> `0.0.4`.
    ///
    /// The 0.x special case is not decoration. Nova's own crates are
    /// all 0.x, and treating `0.4.1 -> 0.5.0` as a compatible upgrade
    /// would make caret requirements meaningless for every package the
    /// project currently ships.
    fn caret_upper_bound(&self) -> Version {
        if self.major > 0 {
            Version::new(self.major + 1, 0, 0)
        } else if self.minor > 0 {
            Version::new(0, self.minor + 1, 0)
        } else {
            Version::new(0, 0, self.patch + 1)
        }
    }
}

impl fmt::Display for Version {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}.{}.{}", self.major, self.minor, self.patch)?;
        if let Some(pre) = &self.pre {
            write!(f, "-{pre}")?;
        }
        Ok(())
    }
}

impl PartialOrd for Version {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Version {
    /// Numeric components first, then the semver rule that a
    /// pre-release sorts *below* the release it leads to: `1.2.0-beta`
    /// < `1.2.0`. Pre-release tags themselves are compared
    /// dot-component by dot-component, numeric components numerically
    /// (so `beta.9` < `beta.10`, which plain string comparison gets
    /// backwards).
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        use std::cmp::Ordering;
        (self.major, self.minor, self.patch)
            .cmp(&(other.major, other.minor, other.patch))
            .then_with(|| match (&self.pre, &other.pre) {
                (None, None) => Ordering::Equal,
                (None, Some(_)) => Ordering::Greater,
                (Some(_), None) => Ordering::Less,
                (Some(a), Some(b)) => compare_pre(a, b),
            })
    }
}

fn compare_pre(a: &str, b: &str) -> std::cmp::Ordering {
    use std::cmp::Ordering;
    let mut ai = a.split('.');
    let mut bi = b.split('.');
    loop {
        match (ai.next(), bi.next()) {
            (None, None) => return Ordering::Equal,
            (None, Some(_)) => return Ordering::Less,
            (Some(_), None) => return Ordering::Greater,
            (Some(x), Some(y)) => {
                let ord = match (x.parse::<u64>(), y.parse::<u64>()) {
                    (Ok(xn), Ok(yn)) => xn.cmp(&yn),
                    // A numeric identifier always has lower precedence
                    // than an alphanumeric one (semver 11.4.3).
                    (Ok(_), Err(_)) => Ordering::Less,
                    (Err(_), Ok(_)) => Ordering::Greater,
                    (Err(_), Err(_)) => x.cmp(y),
                };
                if ord != Ordering::Equal {
                    return ord;
                }
            }
        }
    }
}

/// A version requirement, as written in a dependency line.
///
/// Four forms, deliberately no more: `*`, `1.2.3`, `>=1.2.3`,
/// `^1.2.3`. A package manager for a phone does not need the full
/// Cargo requirement grammar, and every extra operator is another
/// thing a resolver has to get right and an app developer has to get
/// right in a manifest.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum VersionReq {
    Any,
    Exact(Version),
    AtLeast(Version),
    Compatible(Version),
}

impl VersionReq {
    pub fn parse(s: &str) -> Result<VersionReq, MetaError> {
        let s = s.trim();
        if s == "*" || s.is_empty() {
            return Ok(VersionReq::Any);
        }
        if let Some(rest) = s.strip_prefix(">=") {
            return Ok(VersionReq::AtLeast(Version::parse(rest)?));
        }
        if let Some(rest) = s.strip_prefix('^') {
            return Ok(VersionReq::Compatible(Version::parse(rest)?));
        }
        if let Some(rest) = s.strip_prefix('=') {
            return Ok(VersionReq::Exact(Version::parse(rest)?));
        }
        // A bare version is exact. Cargo reads a bare version as a
        // caret requirement; Nova does not, because "1.2.3" read as
        // "anything up to 2.0.0" surprises people who wrote down the
        // one version they tested against, and a manifest that means
        // caret can say so with one character.
        Ok(VersionReq::Exact(Version::parse(s)?))
    }

    pub fn matches(&self, v: &Version) -> bool {
        match self {
            VersionReq::Any => true,
            VersionReq::Exact(want) => v == want,
            VersionReq::AtLeast(min) => v >= min,
            VersionReq::Compatible(base) => v >= base && *v < base.caret_upper_bound(),
        }
    }
}

impl fmt::Display for VersionReq {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            VersionReq::Any => write!(f, "*"),
            VersionReq::Exact(v) => write!(f, "={v}"),
            VersionReq::AtLeast(v) => write!(f, ">={v}"),
            VersionReq::Compatible(v) => write!(f, "^{v}"),
        }
    }
}

/// One entry from a manifest's `depends` list.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Dependency {
    pub id: String,
    pub req: VersionReq,
}

impl Dependency {
    /// Parses `"org.nova.foo >= 1.2.0"` or `"org.nova.foo"`.
    pub fn parse(s: &str) -> Result<Dependency, MetaError> {
        let s = s.trim();
        let (id, req) = match s.find(char::is_whitespace) {
            Some(i) => (&s[..i], VersionReq::parse(&s[i..])?),
            None => (s, VersionReq::Any),
        };
        if id.is_empty() {
            return Err(MetaError::BadDependency(s.to_string()));
        }
        Ok(Dependency { id: id.to_string(), req })
    }
}

impl fmt::Display for Dependency {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match &self.req {
            VersionReq::Any => write!(f, "{}", self.id),
            other => write!(f, "{} {other}", self.id),
        }
    }
}

// ---------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------

#[derive(Debug)]
pub enum MetaError {
    BadVersion(String),
    BadDependency(String),
    /// The `.npkg` did not parse as a package at all.
    Format(String),
    /// The package parsed, but its `nova-app.toml` is missing a field
    /// M11 requires, or is not valid TOML.
    Manifest(String),
    Io(String),
    /// The database file exists but a record in it is unreadable. Kept
    /// distinct from `Io` because the response is different: an I/O
    /// error is retryable, a corrupt record needs a human or a
    /// rebuild-from-disk.
    Corrupt { path: PathBuf, detail: String },
}

impl fmt::Display for MetaError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            MetaError::BadVersion(s) => write!(f, "not a valid version: {s}"),
            MetaError::BadDependency(s) => write!(f, "not a valid dependency: {s}"),
            MetaError::Format(s) => write!(f, "not a valid .npkg: {s}"),
            MetaError::Manifest(s) => write!(f, "package manifest problem: {s}"),
            MetaError::Io(s) => write!(f, "I/O error: {s}"),
            MetaError::Corrupt { path, detail } => {
                write!(f, "installed-package database at {} is corrupt: {detail}", path.display())
            }
        }
    }
}

impl std::error::Error for MetaError {}

// ---------------------------------------------------------------------
// Manifest (the M11 view of nova-app.toml)
// ---------------------------------------------------------------------

/// The fields M11 reads out of `nova-app.toml`.
///
/// Deliberately a separate struct from `nova_app_manager::manifest::
/// AppManifest` rather than an extension of it. App Manager's struct is
/// about *launching* an app; this one is about *distributing* it, and
/// the two lists of fields are already different (App Manager needs
/// `entry_point` and `args`; a package manager needs `depends`). serde
/// ignores unknown fields on both sides, so one `nova-app.toml` file
/// feeds both structs and neither breaks when the other gains a field —
/// which is the whole reason this is a second struct instead of a
/// second required file.
#[derive(Debug, Clone, Deserialize)]
pub struct PackageManifest {
    pub id: String,
    pub name: String,
    pub version: String,
    pub entry_point: String,
    /// New in M11. Each entry is `"<id>"` or `"<id> <req>"`, e.g.
    /// `"org.nova.mediakit >= 1.1.0"`.
    #[serde(default)]
    pub depends: Vec<String>,
    #[serde(default)]
    pub required_permissions: Vec<String>,
    #[serde(default)]
    pub optional_permissions: Vec<String>,
}

// ---------------------------------------------------------------------
// PackageMeta
// ---------------------------------------------------------------------

/// Everything `nova-pack` knows about one package, all of it derived
/// from the package's own bytes.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PackageMeta {
    pub id: String,
    pub name: String,
    pub version: Version,
    pub entry_point: String,
    pub depends: Vec<Dependency>,
    pub required_permissions: Vec<String>,
    pub optional_permissions: Vec<String>,
    /// SHA-256 of the whole `.npkg` file *including* its signature
    /// trailer — the bytes that were actually transferred, which is
    /// what an integrity check on a download has to be about.
    pub sha256: String,
    pub size: u64,
    /// Key id from the signature trailer, or `None` for an unsigned
    /// package. `None` is not the same as "trusted with no key": every
    /// install path in M11 refuses `None` unless explicitly overridden.
    pub key_id: Option<String>,
}

impl PackageMeta {
    /// Derives metadata from package bytes.
    ///
    /// Does not verify the signature — that is `nova_package_sign::
    /// verify`'s job and it needs a keystore this crate has no business
    /// holding. This reads *which* key id is claimed, so a caller can
    /// report it; whether that claim is true is decided elsewhere, and
    /// `nova-pack` always decides it before calling this on a package
    /// it intends to install.
    pub fn from_npkg(bytes: &[u8]) -> Result<PackageMeta, MetaError> {
        let sha256_hex = to_hex(&sha256(bytes));
        let key_id = nova_package_sign::describe(bytes).ok().map(|s| s.key_id);

        // Strip the trailer, if any, before handing the payload to the
        // package parser: the parser is M6's and knows nothing about
        // M10's trailer.
        let payload = match nova_package_sign::describe(bytes) {
            Ok(_) => strip_trailer(bytes)?,
            Err(_) => bytes.to_vec(),
        };

        let (manifest_bytes, _binary) =
            nova_package_format::unpack(&payload).map_err(|e| MetaError::Format(e.to_string()))?;
        let manifest_text = String::from_utf8_lossy(&manifest_bytes).to_string();
        let manifest: PackageManifest =
            toml::from_str(&manifest_text).map_err(|e| MetaError::Manifest(e.to_string()))?;

        let mut depends = Vec::new();
        for d in &manifest.depends {
            depends.push(Dependency::parse(d)?);
        }

        Ok(PackageMeta {
            id: manifest.id,
            name: manifest.name,
            version: Version::parse(&manifest.version)?,
            entry_point: manifest.entry_point,
            depends,
            required_permissions: manifest.required_permissions,
            optional_permissions: manifest.optional_permissions,
            sha256: sha256_hex,
            size: bytes.len() as u64,
            key_id,
        })
    }

    /// The binary's file name as it lands in `<apps>/<id>/bin/`.
    pub fn binary_name(&self) -> String {
        Path::new(&self.entry_point)
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_else(|| self.id.clone())
    }
}

/// Removes an M10 signature trailer, returning the `.npkg` payload.
///
/// `nova_package_sign` keeps its splitter private (it only ever hands
/// back a payload it has *verified*, which is the right default). This
/// re-derives the payload length from the trailer's own length field
/// for the read-only metadata path, where no trust decision is being
/// made — and returns a plain error rather than a panic if the trailer
/// is malformed.
fn strip_trailer(bytes: &[u8]) -> Result<Vec<u8>, MetaError> {
    const MAGIC: &[u8; 8] = b"NPKGSIG1";
    if bytes.len() < MAGIC.len() + 4 || &bytes[bytes.len() - MAGIC.len()..] != MAGIC {
        return Ok(bytes.to_vec());
    }
    let len_at = bytes.len() - MAGIC.len() - 4;
    let block_len = u32::from_le_bytes(bytes[len_at..len_at + 4].try_into().unwrap()) as usize;
    if block_len > bytes.len() {
        return Err(MetaError::Format("signature trailer claims to be longer than the file".into()));
    }
    Ok(bytes[..bytes.len() - block_len].to_vec())
}

// ---------------------------------------------------------------------
// Installed-package database
// ---------------------------------------------------------------------

/// One file belonging to an installed package, recorded at install
/// time so Day 48 can tell later whether it still is what it was.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileRecord {
    /// Relative to `<apps>/<id>/`.
    pub path: String,
    pub sha256: String,
    pub size: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InstalledPackage {
    pub meta: PackageMeta,
    /// Unix seconds. Informational only — nothing in M11 makes a
    /// decision based on it, because a phone's clock before first
    /// network sync is not something to make decisions on.
    pub installed_at: u64,
    /// Files written by the install, with their hashes at that moment.
    pub files: Vec<FileRecord>,
    /// The version this one replaced, if it was an update. Day 48's
    /// rollback target, and the reason the previous `.npkg` is kept.
    pub previous_version: Option<Version>,
}

/// The installed-package database.
///
/// Held entirely in memory and rewritten whole on save. A phone
/// installs tens of packages, not tens of thousands; an append-log with
/// compaction would be more code and more failure modes for no gain at
/// this size. The write is atomic (temp file + rename) because the one
/// thing that genuinely must not happen is a half-written database
/// after a power loss mid-install.
#[derive(Debug, Clone)]
pub struct InstalledDb {
    path: PathBuf,
    entries: BTreeMap<String, InstalledPackage>,
}

impl InstalledDb {
    pub fn open(path: impl Into<PathBuf>) -> Result<InstalledDb, MetaError> {
        let path = path.into();
        if !path.exists() {
            return Ok(InstalledDb { path, entries: BTreeMap::new() });
        }
        let text = std::fs::read_to_string(&path).map_err(|e| MetaError::Io(e.to_string()))?;
        let entries = parse_db(&text, &path)?;
        Ok(InstalledDb { path, entries })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn get(&self, id: &str) -> Option<&InstalledPackage> {
        self.entries.get(id)
    }

    pub fn all(&self) -> impl Iterator<Item = &InstalledPackage> {
        self.entries.values()
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn insert(&mut self, pkg: InstalledPackage) {
        self.entries.insert(pkg.meta.id.clone(), pkg);
    }

    pub fn remove(&mut self, id: &str) -> Option<InstalledPackage> {
        self.entries.remove(id)
    }

    /// Every installed package that declares a dependency on `id`.
    /// Day 47 refuses a removal that would leave one of these unmet.
    pub fn dependents_of(&self, id: &str) -> Vec<&InstalledPackage> {
        self.entries.values().filter(|p| p.meta.depends.iter().any(|d| d.id == id)).collect()
    }

    pub fn save(&self) -> Result<(), MetaError> {
        if let Some(parent) = self.path.parent() {
            std::fs::create_dir_all(parent).map_err(|e| MetaError::Io(e.to_string()))?;
        }
        let mut out = String::new();
        out.push_str("# Nova OS installed-package database (nova-pack, M11).\n");
        out.push_str("# One blank-line-separated record per package. Do not hand-edit\n");
        out.push_str("# while nova-pack is running.\n\n");
        for pkg in self.entries.values() {
            out.push_str(&render_record(pkg));
            out.push('\n');
        }
        let tmp = self.path.with_extension("db.tmp");
        std::fs::write(&tmp, out.as_bytes()).map_err(|e| MetaError::Io(e.to_string()))?;
        std::fs::rename(&tmp, &self.path).map_err(|e| MetaError::Io(e.to_string()))?;
        Ok(())
    }
}

fn render_record(pkg: &InstalledPackage) -> String {
    let m = &pkg.meta;
    let mut s = String::new();
    s.push_str("[package]\n");
    s.push_str(&format!("id: {}\n", m.id));
    s.push_str(&format!("name: {}\n", m.name));
    s.push_str(&format!("version: {}\n", m.version));
    s.push_str(&format!("entry_point: {}\n", m.entry_point));
    if !m.depends.is_empty() {
        let list: Vec<String> = m.depends.iter().map(|d| d.to_string()).collect();
        s.push_str(&format!("depends: {}\n", list.join(", ")));
    }
    if !m.required_permissions.is_empty() {
        s.push_str(&format!("required_permissions: {}\n", m.required_permissions.join(", ")));
    }
    if !m.optional_permissions.is_empty() {
        s.push_str(&format!("optional_permissions: {}\n", m.optional_permissions.join(", ")));
    }
    s.push_str(&format!("sha256: {}\n", m.sha256));
    s.push_str(&format!("size: {}\n", m.size));
    if let Some(k) = &m.key_id {
        s.push_str(&format!("key_id: {k}\n"));
    }
    s.push_str(&format!("installed_at: {}\n", pkg.installed_at));
    if let Some(prev) = &pkg.previous_version {
        s.push_str(&format!("previous_version: {prev}\n"));
    }
    for f in &pkg.files {
        s.push_str(&format!("file: {} {} {}\n", f.path, f.sha256, f.size));
    }
    s
}

fn parse_db(text: &str, path: &Path) -> Result<BTreeMap<String, InstalledPackage>, MetaError> {
    let mut out = BTreeMap::new();
    for block in text.split("\n\n") {
        let block = block.trim();
        if block.is_empty() || block.lines().all(|l| l.trim_start().starts_with('#')) {
            continue;
        }
        let pkg = parse_record(block, path)?;
        out.insert(pkg.meta.id.clone(), pkg);
    }
    Ok(out)
}

fn parse_record(block: &str, path: &Path) -> Result<InstalledPackage, MetaError> {
    let mut id = None;
    let mut name = String::new();
    let mut version = None;
    let mut entry_point = String::new();
    let mut depends = Vec::new();
    let mut required_permissions = Vec::new();
    let mut optional_permissions = Vec::new();
    let mut sha256_hex = String::new();
    let mut size = 0u64;
    let mut key_id = None;
    let mut installed_at = 0u64;
    let mut previous_version = None;
    let mut files = Vec::new();

    let corrupt = |detail: String| MetaError::Corrupt { path: path.to_path_buf(), detail };

    for line in block.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') || line == "[package]" {
            continue;
        }
        let Some((key, value)) = line.split_once(':') else {
            return Err(corrupt(format!("line is not `key: value`: {line}")));
        };
        let value = value.trim();
        match key.trim() {
            "id" => id = Some(value.to_string()),
            "name" => name = value.to_string(),
            "version" => version = Some(Version::parse(value)?),
            "entry_point" => entry_point = value.to_string(),
            "depends" => {
                for part in value.split(',') {
                    if !part.trim().is_empty() {
                        depends.push(Dependency::parse(part)?);
                    }
                }
            }
            "required_permissions" => {
                required_permissions =
                    value.split(',').map(|p| p.trim().to_string()).filter(|p| !p.is_empty()).collect()
            }
            "optional_permissions" => {
                optional_permissions =
                    value.split(',').map(|p| p.trim().to_string()).filter(|p| !p.is_empty()).collect()
            }
            "sha256" => sha256_hex = value.to_string(),
            "size" => size = value.parse().map_err(|_| corrupt(format!("size is not a number: {value}")))?,
            "key_id" => key_id = Some(value.to_string()),
            "installed_at" => {
                installed_at = value.parse().map_err(|_| corrupt(format!("installed_at is not a number: {value}")))?
            }
            "previous_version" => previous_version = Some(Version::parse(value)?),
            "file" => {
                let parts: Vec<&str> = value.split_whitespace().collect();
                if parts.len() != 3 {
                    return Err(corrupt(format!("file record needs `path sha256 size`: {value}")));
                }
                files.push(FileRecord {
                    path: parts[0].to_string(),
                    sha256: parts[1].to_string(),
                    size: parts[2].parse().map_err(|_| corrupt(format!("file size is not a number: {}", parts[2])))?,
                });
            }
            // Forward compatibility: a key this version does not know
            // is skipped, not treated as corruption.
            _ => {}
        }
    }

    let id = id.ok_or_else(|| corrupt("record has no id".to_string()))?;
    let version = version.ok_or_else(|| corrupt(format!("record for {id} has no version")))?;

    Ok(InstalledPackage {
        meta: PackageMeta {
            id,
            name,
            version,
            entry_point,
            depends,
            required_permissions,
            optional_permissions,
            sha256: sha256_hex,
            size,
            key_id,
        },
        installed_at,
        files,
        previous_version,
    })
}

/// Unix seconds, or 0 if the clock is before the epoch (which would
/// mean a device with no RTC and no network, where a timestamp is
/// meaningless anyway).
pub fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_parses_and_orders() {
        assert_eq!(Version::parse("1.2.3").unwrap(), Version::new(1, 2, 3));
        assert!(Version::parse("1.2.3").unwrap() < Version::parse("1.3.0").unwrap());
        assert!(Version::parse("0.9.9").unwrap() < Version::parse("1.0.0").unwrap());
    }

    #[test]
    fn prerelease_sorts_below_its_release() {
        assert!(Version::parse("1.2.0-beta.1").unwrap() < Version::parse("1.2.0").unwrap());
        assert!(Version::parse("1.2.0-beta.9").unwrap() < Version::parse("1.2.0-beta.10").unwrap());
        assert!(Version::parse("1.2.0-alpha").unwrap() < Version::parse("1.2.0-beta").unwrap());
    }

    #[test]
    fn malformed_versions_are_rejected_not_guessed() {
        for bad in ["1.2", "1.2.3.4", "1.2.x", "", "v1.2.3", "1.2.3-"] {
            assert!(Version::parse(bad).is_err(), "{bad} should be rejected");
        }
    }

    #[test]
    fn caret_requirement_respects_zero_major() {
        let req = VersionReq::parse("^0.4.1").unwrap();
        assert!(req.matches(&Version::parse("0.4.9").unwrap()));
        assert!(!req.matches(&Version::parse("0.5.0").unwrap()));

        let req = VersionReq::parse("^1.4.1").unwrap();
        assert!(req.matches(&Version::parse("1.9.0").unwrap()));
        assert!(!req.matches(&Version::parse("2.0.0").unwrap()));
    }

    #[test]
    fn bare_version_requirement_is_exact_not_caret() {
        let req = VersionReq::parse("1.2.3").unwrap();
        assert!(req.matches(&Version::parse("1.2.3").unwrap()));
        assert!(!req.matches(&Version::parse("1.2.4").unwrap()));
    }

    #[test]
    fn at_least_and_any() {
        assert!(VersionReq::parse(">=1.2.0").unwrap().matches(&Version::parse("9.0.0").unwrap()));
        assert!(!VersionReq::parse(">=1.2.0").unwrap().matches(&Version::parse("1.1.9").unwrap()));
        assert!(VersionReq::parse("*").unwrap().matches(&Version::parse("0.0.1").unwrap()));
    }

    #[test]
    fn dependency_parses_both_forms() {
        let d = Dependency::parse("org.nova.foo >= 1.2.0").unwrap();
        assert_eq!(d.id, "org.nova.foo");
        assert_eq!(d.req, VersionReq::AtLeast(Version::new(1, 2, 0)));

        let d = Dependency::parse("org.nova.bar").unwrap();
        assert_eq!(d.req, VersionReq::Any);
    }

    fn test_package(id: &str, version: &str, depends: &str) -> Vec<u8> {
        let manifest = format!(
            "id = \"{id}\"\nname = \"Test\"\nversion = \"{version}\"\nentry_point = \"bin/test\"\ndepends = [{depends}]\nrequired_permissions = [\"storage\"]\n"
        );
        nova_package_format::pack(manifest.as_bytes(), b"\x7fELF-fake-binary")
    }

    #[test]
    fn meta_is_derived_from_the_package_bytes() {
        let pkg = test_package("org.nova.meta", "1.4.2", "\"org.nova.dep >= 1.0.0\"");
        let meta = PackageMeta::from_npkg(&pkg).unwrap();
        assert_eq!(meta.id, "org.nova.meta");
        assert_eq!(meta.version, Version::new(1, 4, 2));
        assert_eq!(meta.depends.len(), 1);
        assert_eq!(meta.size, pkg.len() as u64);
        assert_eq!(meta.sha256, to_hex(&sha256(&pkg)));
        assert_eq!(meta.key_id, None);
        assert_eq!(meta.binary_name(), "test");
    }

    #[test]
    fn meta_reads_the_key_id_out_of_a_signed_package() {
        let pkg = test_package("org.nova.signed", "1.0.0", "");
        let key = nova_package_sign::SigningKey::new("nova-test-key", vec![7u8; 32]);
        let signed = nova_package_sign::sign(&pkg, &key);

        let meta = PackageMeta::from_npkg(&signed).unwrap();
        assert_eq!(meta.key_id.as_deref(), Some("nova-test-key"));
        assert_eq!(meta.id, "org.nova.signed");
        // The hash covers the signed bytes, not the payload: this is
        // the hash of what would be downloaded.
        assert_eq!(meta.sha256, to_hex(&sha256(&signed)));
        assert_ne!(meta.sha256, to_hex(&sha256(&pkg)));
    }

    #[test]
    fn db_round_trips_through_the_file() {
        let dir = std::env::temp_dir().join(format!("nova-pack-meta-test-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("installed.db");
        let _ = std::fs::remove_file(&path);

        let pkg = test_package("org.nova.dbtest", "2.0.1", "\"org.nova.other ^1.0.0\"");
        let meta = PackageMeta::from_npkg(&pkg).unwrap();
        let mut db = InstalledDb::open(&path).unwrap();
        db.insert(InstalledPackage {
            meta: meta.clone(),
            installed_at: 1_750_000_000,
            files: vec![FileRecord { path: "bin/test".into(), sha256: "ab".into(), size: 3 }],
            previous_version: Some(Version::new(2, 0, 0)),
        });
        db.save().unwrap();

        let reloaded = InstalledDb::open(&path).unwrap();
        let got = reloaded.get("org.nova.dbtest").unwrap();
        assert_eq!(got.meta, meta);
        assert_eq!(got.installed_at, 1_750_000_000);
        assert_eq!(got.files.len(), 1);
        assert_eq!(got.previous_version, Some(Version::new(2, 0, 0)));

        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn db_reports_dependents() {
        let mut db = InstalledDb::open("/nonexistent/installed.db").unwrap();
        for (id, deps) in [("org.nova.a", "\"org.nova.lib >= 1.0.0\""), ("org.nova.b", "")] {
            let pkg = test_package(id, "1.0.0", deps);
            db.insert(InstalledPackage {
                meta: PackageMeta::from_npkg(&pkg).unwrap(),
                installed_at: 0,
                files: Vec::new(),
                previous_version: None,
            });
        }
        let dependents = db.dependents_of("org.nova.lib");
        assert_eq!(dependents.len(), 1);
        assert_eq!(dependents[0].meta.id, "org.nova.a");
    }

    #[test]
    fn unknown_keys_in_a_record_are_ignored_not_fatal() {
        let text = "[package]\nid: org.nova.future\nversion: 1.0.0\nsomething_new: hello\n";
        let parsed = parse_db(text, Path::new("/tmp/x")).unwrap();
        assert!(parsed.contains_key("org.nova.future"));
    }

    #[test]
    fn a_record_without_a_version_is_corrupt_not_defaulted() {
        let text = "[package]\nid: org.nova.broken\nname: Broken\n";
        assert!(matches!(parse_db(text, Path::new("/tmp/x")), Err(MetaError::Corrupt { .. })));
    }
}
