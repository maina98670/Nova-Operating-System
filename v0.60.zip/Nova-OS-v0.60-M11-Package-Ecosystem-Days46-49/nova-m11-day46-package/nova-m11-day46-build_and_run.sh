#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 46 (M11 Package Ecosystem): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 46: unit tests ==="
cargo test --workspace

echo
echo "=== nova-m11-day46-acceptance-test ==="
cargo run -p nova-m11-day46-acceptance-test

echo
echo "Day 46 build + tests + acceptance completed."
