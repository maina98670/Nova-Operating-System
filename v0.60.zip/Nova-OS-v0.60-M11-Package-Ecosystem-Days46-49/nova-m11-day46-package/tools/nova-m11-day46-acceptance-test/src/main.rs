//! Day 46 acceptance test — the literal Definition of Done:
//!
//! > `nova-pack install`, `list`, and `remove` all work correctly
//! > against a local test package repository.
//!
//! "Correctly" is read strictly here. Installing is not "the command
//! exited 0"; it is: the files are on disk, the binary is executable,
//! the database says so, `list` reports it, and removing it takes both
//! the files and the record away again. Each of those is checked
//! against the filesystem and the database, not against the tool's own
//! stdout.
//!
//! Everything in this test is real: real signed `.npkg` files produced
//! by M6's packer and M10's signer, a real repository directory, a real
//! keystore, a real install into a real `/apps` tree under a temporary
//! root.

use nova_pack::fixture::TestRoot;
use nova_pack::{InstallKind, PackError, PackManager};
use nova_pack_meta::{Version, VersionReq};
use std::process::ExitCode;

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn check(name: &'static str, passed: bool, detail: impl Into<String>) -> Check {
    Check { name, passed, detail: detail.into() }
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 46 acceptance: nova-pack against a local repository ===\n");

    let root = match TestRoot::new("day46") {
        Ok(r) => r,
        Err(e) => {
            eprintln!("could not build the test root: {e}");
            return ExitCode::FAILURE;
        }
    };

    // A small repository: one package at two versions, plus a second
    // package, so version selection has something to choose between.
    for (id, version) in
        [("org.nova.notes", "1.0.0"), ("org.nova.notes", "1.2.0"), ("org.nova.notes", "2.0.0"), ("org.nova.clock", "0.4.1")]
    {
        if let Err(e) = root.publish(id, version, &[], &["storage"]) {
            eprintln!("could not publish {id} {version}: {e}");
            return ExitCode::FAILURE;
        }
    }

    let mut m = match PackManager::open(root.layout()) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("could not open the package manager: {e}");
            return ExitCode::FAILURE;
        }
    };

    let mut checks: Vec<Check> = Vec::new();

    // --- Before anything: no sources, and that is an error, not an
    // --- empty result pretending everything is fine. -------------------
    let no_sources = m.install("org.nova.notes", &VersionReq::Any);
    checks.push(check(
        "installing with no sources configured fails loudly",
        matches!(no_sources, Err(PackError::NoSources)),
        match &no_sources {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED ANYWAY".to_string(),
        },
    ));

    m.add_source(&root.repo).expect("add source");
    let sources = m.sources().expect("read sources");
    checks.push(check(
        "a source can be added and read back",
        sources.len() == 1 && sources[0].location == root.repo,
        format!("{} source(s): {:?}", sources.len(), sources.iter().map(|s| s.location.display().to_string()).collect::<Vec<_>>()),
    ));

    // --- install: highest version wins when nothing is pinned. ---------
    let outcome = m.install("org.nova.notes", &VersionReq::Any);
    checks.push(check(
        "install with no version requirement takes the newest available",
        matches!(&outcome, Ok(o) if o.version == Version::new(2, 0, 0) && o.kind == InstallKind::Fresh),
        match &outcome {
            Ok(o) => format!("installed {} {} (kind: {:?}, key '{}')", o.id, o.version, o.kind, o.key_id),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // --- the files are actually there, and the binary is executable. ---
    let app_dir = m.layout().app_dir("org.nova.notes");
    let manifest = app_dir.join("nova-app.toml");
    let binary = app_dir.join("bin/notes");
    let mode_ok = std::fs::metadata(&binary)
        .map(|meta| {
            use std::os::unix::fs::PermissionsExt;
            meta.permissions().mode() & 0o111 != 0
        })
        .unwrap_or(false);
    checks.push(check(
        "install really wrote the manifest and an executable binary",
        manifest.is_file() && binary.is_file() && mode_ok,
        format!(
            "manifest: {} | binary: {} | executable bit: {mode_ok}",
            manifest.is_file(),
            binary.is_file()
        ),
    ));

    // --- list reflects the database, and the database reflects disk. ---
    let listed = m.installed();
    checks.push(check(
        "list reports exactly what was installed",
        listed.len() == 1 && listed[0].meta.id == "org.nova.notes" && listed[0].meta.version == Version::new(2, 0, 0),
        format!("{:?}", listed.iter().map(|p| format!("{} {}", p.meta.id, p.meta.version)).collect::<Vec<_>>()),
    ));

    // --- version requirements actually constrain the choice. -----------
    let pinned = m.install("org.nova.notes", &VersionReq::parse("^1.0.0").unwrap());
    checks.push(check(
        "a caret requirement picks the newest match, not the newest overall",
        matches!(&pinned, Ok(o) if o.version == Version::new(1, 2, 0)),
        match &pinned {
            Ok(o) => format!("^1.0.0 selected {} (2.0.0 was available and correctly not chosen)", o.version),
            Err(e) => format!("FAILED: {e}"),
        },
    ));
    checks.push(check(
        "reinstalling a different version is recorded as a downgrade",
        matches!(&pinned, Ok(o) if matches!(&o.kind, InstallKind::Downgrade { from } if *from == Version::new(2, 0, 0))),
        match &pinned {
            Ok(o) => format!("kind: {:?}", o.kind),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // --- an unsatisfiable requirement fails, and says so. --------------
    let impossible = m.install("org.nova.notes", &VersionReq::parse(">=9.0.0").unwrap());
    checks.push(check(
        "an unsatisfiable version requirement is refused with a clear error",
        matches!(impossible, Err(PackError::NotFound { .. })),
        match &impossible {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED SOMETHING ANYWAY".to_string(),
        },
    ));

    // --- update moves forward, and only forward. -----------------------
    let updated = m.update("org.nova.notes");
    checks.push(check(
        "update moves 1.2.0 up to the newest available version",
        matches!(&updated, Ok(Some(o)) if o.version == Version::new(2, 0, 0)),
        match &updated {
            Ok(Some(o)) => format!("1.2.0 -> {}", o.version),
            Ok(None) => "reported already up to date, which is wrong here".to_string(),
            Err(e) => format!("FAILED: {e}"),
        },
    ));
    let again = m.update("org.nova.notes");
    checks.push(check(
        "update on an already-current package is a no-op, not a reinstall",
        matches!(&again, Ok(None)),
        match &again {
            Ok(None) => "reported already up to date".to_string(),
            Ok(Some(o)) => format!("REINSTALLED {} unnecessarily", o.version),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // --- unsigned and untrusted packages never reach /apps. ------------
    let unsigned = nova_pack::fixture::package("org.nova.sneaky", "1.0.0", &[], &[]);
    let unsigned_result = m.install_bytes(&unsigned, "unsigned-test");
    let sneaky_dir = m.layout().app_dir("org.nova.sneaky");
    checks.push(check(
        "an unsigned package is refused and nothing is written",
        matches!(unsigned_result, Err(PackError::Verify(_))) && !sneaky_dir.exists(),
        match &unsigned_result {
            Err(e) => format!("refused: {e} | wrote anything: {}", sneaky_dir.exists()),
            Ok(_) => "INSTALLED AN UNSIGNED PACKAGE".to_string(),
        },
    ));

    let untrusted = root.sign_with_untrusted_key(&nova_pack::fixture::package("org.nova.vendor", "1.0.0", &[], &[]));
    let untrusted_result = m.install_bytes(&untrusted, "untrusted-test");
    checks.push(check(
        "a package signed by an untrusted key is refused",
        matches!(untrusted_result, Err(PackError::Verify(_))) && !m.layout().app_dir("org.nova.vendor").exists(),
        match &untrusted_result {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED A PACKAGE SIGNED BY AN UNKNOWN KEY".to_string(),
        },
    ));

    // --- remove takes away both halves. --------------------------------
    m.install("org.nova.clock", &VersionReq::Any).expect("install clock");
    let removed = m.remove("org.nova.notes");
    let files_gone = !m.layout().app_dir("org.nova.notes").exists();
    let record_gone = m.db().get("org.nova.notes").is_none();
    let other_survived = m.db().get("org.nova.clock").is_some();
    checks.push(check(
        "remove deletes the files and the database record, and nothing else",
        removed.is_ok() && files_gone && record_gone && other_survived,
        format!("files gone: {files_gone} | record gone: {record_gone} | other package untouched: {other_survived}"),
    ));

    let remove_twice = m.remove("org.nova.notes");
    checks.push(check(
        "removing something that is not installed is a clear error, not a silent success",
        matches!(remove_twice, Err(PackError::NotInstalled(_))),
        match &remove_twice {
            Err(e) => format!("refused: {e}"),
            Ok(()) => "reported success for a package that was not installed".to_string(),
        },
    ));

    // --- the database survives a restart. ------------------------------
    let reopened = PackManager::open(root.layout());
    checks.push(check(
        "the installed-package database survives reopening",
        matches!(&reopened, Ok(m2) if m2.db().get("org.nova.clock").is_some() && m2.db().len() == 1),
        match &reopened {
            Ok(m2) => format!("{} package(s) after reopen", m2.db().len()),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    report(checks, &root)
}

fn report(checks: Vec<Check>, root: &TestRoot) -> ExitCode {
    println!("Checks:");
    let mut failed = 0;
    for c in &checks {
        println!("  [{}] {}", if c.passed { "PASS" } else { "FAIL" }, c.name);
        println!("         {}", c.detail);
        if !c.passed {
            failed += 1;
        }
    }
    println!();
    if failed == 0 {
        println!("Day 46 acceptance: PASS ({} checks)", checks.len());
        println!("install, list, remove and update all verified against the filesystem and the");
        println!("database, not against the tool's own output.");
        root.cleanup();
        ExitCode::SUCCESS
    } else {
        println!("Day 46 acceptance: FAIL ({failed} of {} checks failed)", checks.len());
        println!("Test root left in place for inspection: {}", root.dir.display());
        ExitCode::FAILURE
    }
}
