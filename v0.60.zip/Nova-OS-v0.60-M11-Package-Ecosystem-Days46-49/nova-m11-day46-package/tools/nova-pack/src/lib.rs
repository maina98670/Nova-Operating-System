//! `nova-pack` — Nova OS's user-facing package manager (M11, Day 46).
//!
//! ## Why this exists next to `nova install`
//! M6's `nova install` (Day 22) is part of the SDK: a developer points
//! it at a `.npkg` they just built and it writes the contents into
//! `/apps`. It is the right tool for that job and it stays. What it is
//! not is a package manager — it keeps no record of what it installed,
//! has no notion of where a package came from, cannot remove anything,
//! and cannot tell you what is on the device.
//!
//! `nova-pack` is the other tool: the one a *user* (or, later, a
//! settings screen, or M15's update system) drives. The split is the
//! same one Debian draws between `dpkg -i` and `apt`, for the same
//! reason — the developer path and the fleet path have different
//! failure modes and should not be the same code path pretending to be
//! both.
//!
//! ## What it will not do
//! `nova-pack` never installs an unsigned or untrusted package. It
//! reuses M10 Day 43's verification unchanged rather than
//! reimplementing it, so this new install path cannot be the soft
//! route around the signature requirement — the exact failure mode the
//! Day 47 Definition of Done names. The `--allow-unsigned` escape
//! hatch that `nova install` carries for build debugging deliberately
//! does *not* exist here.
//!
//! ## Layout on disk
//! Everything is resolved under one root so a test, an image build, and
//! a running device are the same code against different roots.
//!
//! ```text
//! <root>/apps/<id>/nova-app.toml         the installed manifest
//! <root>/apps/<id>/bin/<binary>          the installed executable
//! <root>/var/lib/nova/pack/installed.db  what is installed
//! <root>/var/lib/nova/pack/sources.list  where packages come from
//! <root>/etc/nova/keys/trusted.tsv       M10's package keystore
//! ```

use nova_pack_meta::{
    now_secs, InstalledDb, InstalledPackage, MetaError, PackageMeta, Version, VersionReq,
};
use nova_package_sign::{Keystore, PackageVerifyError};
use nova_seclog::{SecurityEvent, SecurityLog};
use std::fmt;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

// ---------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------

/// Where everything lives, relative to one root.
#[derive(Debug, Clone)]
pub struct Layout {
    root: PathBuf,
}

impl Layout {
    /// A layout rooted at `root`. `Layout::new("/")` is the device.
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Layout { root: root.into() }
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Mirrors `nova_fsmgr::paths::APPS`.
    pub fn apps_dir(&self) -> PathBuf {
        self.root.join("apps")
    }

    pub fn app_dir(&self, id: &str) -> PathBuf {
        self.apps_dir().join(id)
    }

    pub fn state_dir(&self) -> PathBuf {
        self.root.join("var/lib/nova/pack")
    }

    pub fn db_path(&self) -> PathBuf {
        self.state_dir().join("installed.db")
    }

    pub fn sources_path(&self) -> PathBuf {
        self.state_dir().join("sources.list")
    }

    /// Mirrors `nova_fsmgr::paths::CONFIG`; M10 Day 43's keystore.
    pub fn keystore_path(&self) -> PathBuf {
        self.root.join("etc/nova/keys/trusted.tsv")
    }

    pub fn seclog_path(&self) -> PathBuf {
        self.root.join("var/log/nova/security.log")
    }
}

// ---------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------

#[derive(Debug)]
pub enum PackError {
    Io(String),
    Meta(MetaError),
    /// The package failed M10 verification. Carries the original error
    /// so the three distinct cases (unsigned / untrusted key / altered)
    /// stay distinct all the way to the user.
    Verify(PackageVerifyError),
    /// No keystore on this device. Separate from `Verify` because the
    /// fix is different: provision keys, don't re-download the package.
    NoKeystore(PathBuf),
    NotInstalled(String),
    /// Nothing in any configured source provides this package, or
    /// nothing that satisfies the requested version.
    NotFound { id: String, req: VersionReq },
    /// The bytes fetched from a source did not hash to what the source
    /// said they would.
    ChecksumMismatch { id: String, expected: String, actual: String },
    NoSources,
}

impl fmt::Display for PackError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            PackError::Io(e) => write!(f, "{e}"),
            PackError::Meta(e) => write!(f, "{e}"),
            PackError::Verify(e) => write!(f, "{e}"),
            PackError::NoKeystore(p) => write!(
                f,
                "no package keystore at {} — this device cannot verify any package. \
                 Provision one with `nova keygen` on the build machine and install its public half.",
                p.display()
            ),
            PackError::NotInstalled(id) => write!(f, "{id} is not installed"),
            PackError::NotFound { id, req } => {
                write!(f, "no package in any configured source provides {id} {req}")
            }
            PackError::ChecksumMismatch { id, expected, actual } => write!(
                f,
                "{id}: the bytes fetched do not match the checksum the source published \
                 (expected {expected}, got {actual}) — nothing was installed"
            ),
            PackError::NoSources => write!(
                f,
                "no package sources are configured — add one with `nova-pack add-source <dir>`"
            ),
        }
    }
}

impl std::error::Error for PackError {}

impl From<MetaError> for PackError {
    fn from(e: MetaError) -> Self {
        PackError::Meta(e)
    }
}

impl From<std::io::Error> for PackError {
    fn from(e: std::io::Error) -> Self {
        PackError::Io(e.to_string())
    }
}

// ---------------------------------------------------------------------
// Sources and repositories
// ---------------------------------------------------------------------

/// One configured package source. Today a local directory; Day 49 gives
/// it a documented index format, and a future networked store would
/// implement the same two operations (list candidates, fetch bytes)
/// over HTTP without the rest of this file changing.
#[derive(Debug, Clone)]
pub struct Source {
    pub location: PathBuf,
}

/// One package available from a source.
#[derive(Debug, Clone)]
pub struct Candidate {
    pub meta: PackageMeta,
    pub path: PathBuf,
}

impl Source {
    /// Every `.npkg` in the source directory, with metadata derived
    /// from each file's own bytes.
    ///
    /// Day 46 scans the directory. That is genuinely all a local test
    /// repository needs, and it has one honest property a hand-written
    /// index does not: it cannot disagree with reality. Day 49 adds the
    /// documented index format a real store would serve, and keeps this
    /// scan as the fallback for a source with no index.
    pub fn candidates(&self) -> Result<Vec<Candidate>, PackError> {
        let mut out = Vec::new();
        let entries = match fs::read_dir(&self.location) {
            Ok(e) => e,
            Err(e) => return Err(PackError::Io(format!("source {}: {e}", self.location.display()))),
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) != Some("npkg") {
                continue;
            }
            let bytes = fs::read(&path)?;
            match PackageMeta::from_npkg(&bytes) {
                Ok(meta) => out.push(Candidate { meta, path }),
                // A source is allowed to contain junk; it is not
                // allowed to make the whole source unusable. Skipped
                // files are reported by the caller, not silently
                // swallowed here — see `PackManager::scan_problems`.
                Err(_) => continue,
            }
        }
        Ok(out)
    }
}

// ---------------------------------------------------------------------
// Outcomes
// ---------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InstallKind {
    Fresh,
    Upgrade { from: Version },
    Downgrade { from: Version },
    Reinstall,
}

#[derive(Debug, Clone)]
pub struct InstallOutcome {
    pub id: String,
    pub version: Version,
    pub kind: InstallKind,
    pub key_id: String,
    pub files: Vec<String>,
}

// ---------------------------------------------------------------------
// The manager
// ---------------------------------------------------------------------

pub struct PackManager {
    layout: Layout,
    db: InstalledDb,
    keystore: Keystore,
    seclog: Option<SecurityLog>,
}

impl PackManager {
    /// Opens the database and the device keystore.
    ///
    /// A missing keystore is an error at open time, not at install
    /// time. There is nothing useful `nova-pack` can do on a device
    /// with no trusted keys, and finding that out before a user picks a
    /// package is better than finding it out after.
    pub fn open(layout: Layout) -> Result<PackManager, PackError> {
        let db = InstalledDb::open(layout.db_path())?;
        let keystore_path = layout.keystore_path();
        let keystore = match Keystore::load(&keystore_path) {
            Ok(k) => k,
            Err(_) => return Err(PackError::NoKeystore(keystore_path)),
        };
        if keystore.is_empty() {
            return Err(PackError::NoKeystore(keystore_path));
        }
        let seclog = SecurityLog::open(layout.seclog_path()).ok();
        Ok(PackManager { layout, db, keystore, seclog })
    }

    pub fn layout(&self) -> &Layout {
        &self.layout
    }

    pub fn db(&self) -> &InstalledDb {
        &self.db
    }

    pub fn installed(&self) -> Vec<&InstalledPackage> {
        self.db.all().collect()
    }

    // --- sources ------------------------------------------------------

    pub fn sources(&self) -> Result<Vec<Source>, PackError> {
        let path = self.layout.sources_path();
        if !path.exists() {
            return Ok(Vec::new());
        }
        let text = fs::read_to_string(&path)?;
        Ok(text
            .lines()
            .map(str::trim)
            .filter(|l| !l.is_empty() && !l.starts_with('#'))
            .map(|l| Source { location: PathBuf::from(l) })
            .collect())
    }

    pub fn add_source(&self, location: impl AsRef<Path>) -> Result<(), PackError> {
        let path = self.layout.sources_path();
        fs::create_dir_all(path.parent().unwrap())?;
        let mut text = if path.exists() { fs::read_to_string(&path)? } else { String::new() };
        let line = location.as_ref().display().to_string();
        if text.lines().any(|l| l.trim() == line) {
            return Ok(());
        }
        if !text.is_empty() && !text.ends_with('\n') {
            text.push('\n');
        }
        text.push_str(&line);
        text.push('\n');
        fs::write(&path, text)?;
        Ok(())
    }

    /// The best candidate for `id` matching `req` across every source:
    /// the highest version that satisfies the requirement.
    pub fn best_candidate(&self, id: &str, req: &VersionReq) -> Result<Candidate, PackError> {
        let sources = self.sources()?;
        if sources.is_empty() {
            return Err(PackError::NoSources);
        }
        let mut best: Option<Candidate> = None;
        for source in sources {
            for cand in source.candidates()? {
                if cand.meta.id != id || !req.matches(&cand.meta.version) {
                    continue;
                }
                let better = match &best {
                    None => true,
                    Some(b) => cand.meta.version > b.meta.version,
                };
                if better {
                    best = Some(cand);
                }
            }
        }
        best.ok_or_else(|| PackError::NotFound { id: id.to_string(), req: req.clone() })
    }

    // --- install ------------------------------------------------------

    /// Installs a package from a file on disk.
    ///
    /// Order is the whole point of this function:
    ///
    /// 1. read the bytes,
    /// 2. verify the signature against the device keystore (M10),
    /// 3. derive metadata from the verified bytes,
    /// 4. only then touch `/apps`.
    ///
    /// A package that fails at any step before 4 is one that was never
    /// installed, rather than one that was installed and then cleaned
    /// up. Rejections are written to the security log (M10 Day 44)
    /// before the error is returned, so a device that refuses a package
    /// leaves evidence of having refused it.
    pub fn install_file(&mut self, path: &Path) -> Result<InstallOutcome, PackError> {
        let bytes = fs::read(path).map_err(|e| PackError::Io(format!("{}: {e}", path.display())))?;
        self.install_bytes(&bytes, &path.display().to_string())
    }

    pub fn install_bytes(&mut self, bytes: &[u8], origin: &str) -> Result<InstallOutcome, PackError> {
        let verified = match nova_package_sign::verify(bytes, &self.keystore) {
            Ok(v) => v,
            Err(e) => {
                self.record_rejection(origin, &e.to_string());
                return Err(PackError::Verify(e));
            }
        };

        // Metadata comes from the full signed bytes (so the recorded
        // hash is the hash of the artifact), but only after the
        // signature over them has been checked.
        let meta = PackageMeta::from_npkg(bytes)?;
        let key_id = verified.key_id.clone();

        let kind = match self.db.get(&meta.id).map(|p| p.meta.version.clone()) {
            None => InstallKind::Fresh,
            Some(v) if v < meta.version => InstallKind::Upgrade { from: v },
            Some(v) if v > meta.version => InstallKind::Downgrade { from: v },
            Some(_) => InstallKind::Reinstall,
        };
        let previous_version = match &kind {
            InstallKind::Fresh => None,
            InstallKind::Upgrade { from } | InstallKind::Downgrade { from } => Some(from.clone()),
            InstallKind::Reinstall => Some(meta.version.clone()),
        };

        let files = self.write_payload(&meta, &verified.payload)?;

        self.db.insert(InstalledPackage {
            meta: meta.clone(),
            installed_at: now_secs(),
            files: Vec::new(),
            previous_version,
        });
        self.db.save()?;

        Ok(InstallOutcome { id: meta.id, version: meta.version, kind, key_id, files })
    }

    /// Installs by id from the configured sources.
    pub fn install(&mut self, id: &str, req: &VersionReq) -> Result<InstallOutcome, PackError> {
        let cand = self.best_candidate(id, req)?;
        let bytes = fs::read(&cand.path)?;

        // The source told us a hash when it listed the candidate;
        // check the bytes we actually read against it before doing
        // anything else with them. Today the source is a local
        // directory and this can only fail if the file changed between
        // listing and reading — which is exactly the race a networked
        // store makes routine, so the check is written now rather than
        // retrofitted when it starts mattering.
        let actual = nova_crypto::to_hex(&nova_crypto::sha256(&bytes));
        if actual != cand.meta.sha256 {
            return Err(PackError::ChecksumMismatch {
                id: id.to_string(),
                expected: cand.meta.sha256.clone(),
                actual,
            });
        }
        self.install_bytes(&bytes, &cand.path.display().to_string())
    }

    fn write_payload(&self, meta: &PackageMeta, payload: &[u8]) -> Result<Vec<String>, PackError> {
        let (manifest_bytes, binary_bytes) =
            nova_package_format::unpack(payload).map_err(|e| PackError::Meta(MetaError::Format(e.to_string())))?;

        let dir = self.layout.app_dir(&meta.id);
        let bin_dir = dir.join("bin");
        fs::create_dir_all(&bin_dir)?;

        let manifest_rel = "nova-app.toml".to_string();
        fs::write(dir.join(&manifest_rel), &manifest_bytes)?;

        let bin_rel = format!("bin/{}", meta.binary_name());
        let bin_path = dir.join(&bin_rel);
        fs::write(&bin_path, &binary_bytes)?;
        let mut perms = fs::metadata(&bin_path)?.permissions();
        perms.set_mode(0o755);
        fs::set_permissions(&bin_path, perms)?;

        Ok(vec![manifest_rel, bin_rel])
    }

    // --- remove -------------------------------------------------------

    /// Removes an installed package: its files, then its database
    /// record.
    ///
    /// Files first. If the process dies between the two, what is left
    /// is a database claiming something is installed that is not —
    /// which `verify` (Day 48) detects and reports. The other order
    /// would leave files on disk that nothing knows about, which
    /// nothing can ever detect.
    pub fn remove(&mut self, id: &str) -> Result<(), PackError> {
        if self.db.get(id).is_none() {
            return Err(PackError::NotInstalled(id.to_string()));
        }
        let dir = self.layout.app_dir(id);
        if dir.exists() {
            fs::remove_dir_all(&dir)?;
        }
        self.db.remove(id);
        self.db.save()?;
        Ok(())
    }

    // --- update -------------------------------------------------------

    /// Installs the newest version any source offers, if it is newer
    /// than what is installed.
    pub fn update(&mut self, id: &str) -> Result<Option<InstallOutcome>, PackError> {
        let current = self
            .db
            .get(id)
            .ok_or_else(|| PackError::NotInstalled(id.to_string()))?
            .meta
            .version
            .clone();
        let cand = self.best_candidate(id, &VersionReq::Any)?;
        if cand.meta.version <= current {
            return Ok(None);
        }
        let bytes = fs::read(&cand.path)?;
        Ok(Some(self.install_bytes(&bytes, &cand.path.display().to_string())?))
    }

    /// Every installed package for which a source offers something
    /// newer.
    pub fn updatable(&self) -> Result<Vec<(String, Version, Version)>, PackError> {
        let mut out = Vec::new();
        for pkg in self.db.all() {
            if let Ok(cand) = self.best_candidate(&pkg.meta.id, &VersionReq::Any) {
                if cand.meta.version > pkg.meta.version {
                    out.push((pkg.meta.id.clone(), pkg.meta.version.clone(), cand.meta.version));
                }
            }
        }
        Ok(out)
    }

    // --- security log -------------------------------------------------

    fn record_rejection(&mut self, origin: &str, detail: &str) {
        if let Some(log) = self.seclog.as_mut() {
            let _ = log.record(SecurityEvent::package_rejected(origin, detail));
        }
    }
}

// ---------------------------------------------------------------------
// Test support
// ---------------------------------------------------------------------

/// Builders for real packages, real keys and a real root directory.
///
/// Shipped in the library rather than copied into each acceptance test
/// so that all four M11 days exercise the same fixtures — a test that
/// builds its own subtly different package is a test that can pass
/// while the product is broken.
///
/// Nothing here is a mock. `package()` produces bytes that
/// `nova_package_format::unpack` parses, `sign()` produces a trailer
/// `nova_package_sign::verify` accepts, and `TestRoot` is a real
/// directory tree.
pub mod fixture {
    use super::*;
    use nova_package_sign::SigningKey;

    /// A real `.npkg` for `id` at `version`, declaring `depends` and
    /// `permissions`.
    pub fn package(id: &str, version: &str, depends: &[&str], permissions: &[&str]) -> Vec<u8> {
        let dep_list: Vec<String> = depends.iter().map(|d| format!("\"{d}\"")).collect();
        let perm_list: Vec<String> = permissions.iter().map(|p| format!("\"{p}\"")).collect();
        let manifest = format!(
            "id = \"{id}\"\n\
             name = \"{id}\"\n\
             version = \"{version}\"\n\
             entry_point = \"bin/{bin}\"\n\
             depends = [{deps}]\n\
             required_permissions = [{perms}]\n",
            bin = id.rsplit('.').next().unwrap_or("app"),
            deps = dep_list.join(", "),
            perms = perm_list.join(", "),
        );
        // A fake but structurally honest binary: the installer writes
        // whatever bytes it is given and marks them executable, so the
        // content only needs to be stable and non-empty.
        let binary = format!("#!/bin/sh\necho {id} {version}\n");
        nova_package_format::pack(manifest.as_bytes(), binary.as_bytes())
    }

    /// A temporary device root, with a keystore trusting one key.
    pub struct TestRoot {
        pub dir: PathBuf,
        pub repo: PathBuf,
        pub key: SigningKey,
    }

    impl TestRoot {
        pub fn new(tag: &str) -> Result<TestRoot, PackError> {
            let dir = std::env::temp_dir().join(format!("nova-m11-{tag}-{}", std::process::id()));
            let _ = fs::remove_dir_all(&dir);
            let repo = dir.join("repo");
            fs::create_dir_all(&repo)?;
            fs::create_dir_all(dir.join("etc/nova/keys"))?;
            fs::create_dir_all(dir.join("var/log/nova"))?;

            let key = SigningKey::new("nova-store-2026", vec![0x5a; 32]);
            let mut keystore = Keystore::new();
            keystore.trust(key.public_half());
            keystore
                .save(&Layout::new(&dir).keystore_path())
                .map_err(|e| PackError::Io(e.to_string()))?;

            Ok(TestRoot { dir, repo, key })
        }

        pub fn layout(&self) -> Layout {
            Layout::new(&self.dir)
        }

        /// Signs `bytes` with a key the device does *not* trust.
        pub fn sign_with_untrusted_key(&self, bytes: &[u8]) -> Vec<u8> {
            let other = SigningKey::new("some-other-vendor", vec![0x11; 32]);
            nova_package_sign::sign(bytes, &other)
        }

        /// Publishes a signed package into the repository directory.
        pub fn publish(&self, id: &str, version: &str, depends: &[&str], permissions: &[&str]) -> Result<PathBuf, PackError> {
            let signed = nova_package_sign::sign(&package(id, version, depends, permissions), &self.key);
            let path = self.repo.join(format!("{id}-{version}.npkg"));
            fs::write(&path, &signed)?;
            Ok(path)
        }

        pub fn cleanup(&self) {
            let _ = fs::remove_dir_all(&self.dir);
        }
    }
}
