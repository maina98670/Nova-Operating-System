//! `nova-pack` — the command-line front end to the package manager.
//!
//! Thin by design: every decision lives in `lib.rs` so that the
//! acceptance tests exercise the same code the CLI does, rather than a
//! test-only reimplementation of it.
//!
//! ```text
//! nova-pack [--root <dir>] <command>
//!
//!   list                          what is installed
//!   info <id>                     one package in detail
//!   sources                       configured package sources
//!   add-source <dir>              add one
//!   available [<id>]              what the sources offer
//!   install <id>[@<req>]|<file>   install, from a source or a file
//!   remove <id>                   uninstall
//!   update [<id>]                 update one package, or report all
//! ```
//!
//! `--root` exists so the same binary drives a device (`--root /`,
//! the default), an image being built, or a temporary directory in a
//! test. Nothing in the tool writes outside the root it was given.

use nova_pack::{InstallKind, Layout, PackError, PackManager};
use nova_pack_meta::VersionReq;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().collect();
    let mut root = std::env::var("NOVA_ROOT").unwrap_or_else(|_| "/".to_string());

    let mut rest: Vec<String> = Vec::new();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--root" => {
                i += 1;
                match args.get(i) {
                    Some(v) => root = v.clone(),
                    None => {
                        eprintln!("nova-pack: --root needs a directory");
                        return ExitCode::FAILURE;
                    }
                }
            }
            other => rest.push(other.to_string()),
        }
        i += 1;
    }

    let layout = Layout::new(&root);
    match rest.first().map(String::as_str) {
        Some("list") => with_manager(layout, |m| cmd_list(m)),
        Some("info") => with_manager(layout, |m| cmd_info(m, rest.get(1))),
        Some("sources") => with_manager(layout, |m| cmd_sources(m)),
        Some("add-source") => with_manager(layout, |m| cmd_add_source(m, rest.get(1))),
        Some("available") => with_manager(layout, |m| cmd_available(m, rest.get(1))),
        Some("install") => with_manager(layout, |m| cmd_install(m, rest.get(1))),
        Some("remove") => with_manager(layout, |m| cmd_remove(m, rest.get(1))),
        Some("update") => with_manager(layout, |m| cmd_update(m, rest.get(1))),
        Some("-h") | Some("--help") | None => {
            print_usage();
            ExitCode::SUCCESS
        }
        Some(other) => {
            eprintln!("nova-pack: unknown command '{other}'");
            print_usage();
            ExitCode::FAILURE
        }
    }
}

fn with_manager(layout: Layout, f: impl FnOnce(&mut PackManager) -> ExitCode) -> ExitCode {
    match PackManager::open(layout) {
        Ok(mut m) => f(&mut m),
        Err(e) => {
            eprintln!("nova-pack: {e}");
            ExitCode::FAILURE
        }
    }
}

fn fail(e: PackError) -> ExitCode {
    eprintln!("nova-pack: {e}");
    ExitCode::FAILURE
}

fn cmd_list(m: &mut PackManager) -> ExitCode {
    let installed = m.installed();
    if installed.is_empty() {
        println!("No packages installed.");
        return ExitCode::SUCCESS;
    }
    println!("{:<34} {:<12} {}", "PACKAGE", "VERSION", "SIGNED BY");
    for pkg in installed {
        println!(
            "{:<34} {:<12} {}",
            pkg.meta.id,
            pkg.meta.version.to_string(),
            pkg.meta.key_id.as_deref().unwrap_or("-")
        );
    }
    ExitCode::SUCCESS
}

fn cmd_info(m: &mut PackManager, id: Option<&String>) -> ExitCode {
    let Some(id) = id else {
        eprintln!("nova-pack info: missing <id>");
        return ExitCode::FAILURE;
    };
    let Some(pkg) = m.db().get(id) else {
        return fail(PackError::NotInstalled(id.clone()));
    };
    println!("id:          {}", pkg.meta.id);
    println!("name:        {}", pkg.meta.name);
    println!("version:     {}", pkg.meta.version);
    println!("signed by:   {}", pkg.meta.key_id.as_deref().unwrap_or("-"));
    println!("size:        {} bytes", pkg.meta.size);
    println!("sha256:      {}", pkg.meta.sha256);
    if !pkg.meta.depends.is_empty() {
        let list: Vec<String> = pkg.meta.depends.iter().map(|d| d.to_string()).collect();
        println!("depends:     {}", list.join(", "));
    }
    if !pkg.meta.required_permissions.is_empty() {
        println!("permissions: {}", pkg.meta.required_permissions.join(", "));
    }
    ExitCode::SUCCESS
}

fn cmd_sources(m: &mut PackManager) -> ExitCode {
    match m.sources() {
        Ok(s) if s.is_empty() => {
            println!("No sources configured. Add one with: nova-pack add-source <dir>");
            ExitCode::SUCCESS
        }
        Ok(s) => {
            for source in s {
                println!("{}", source.location.display());
            }
            ExitCode::SUCCESS
        }
        Err(e) => fail(e),
    }
}

fn cmd_add_source(m: &mut PackManager, dir: Option<&String>) -> ExitCode {
    let Some(dir) = dir else {
        eprintln!("nova-pack add-source: missing <dir>");
        return ExitCode::FAILURE;
    };
    match m.add_source(dir) {
        Ok(()) => {
            println!("Added source {dir}");
            ExitCode::SUCCESS
        }
        Err(e) => fail(e),
    }
}

fn cmd_available(m: &mut PackManager, id: Option<&String>) -> ExitCode {
    let sources = match m.sources() {
        Ok(s) => s,
        Err(e) => return fail(e),
    };
    let mut rows = Vec::new();
    for source in sources {
        match source.candidates() {
            Ok(cands) => {
                for c in cands {
                    if id.map(|want| want != &c.meta.id).unwrap_or(false) {
                        continue;
                    }
                    rows.push((c.meta.id, c.meta.version.to_string(), c.path));
                }
            }
            Err(e) => eprintln!("nova-pack: {e}"),
        }
    }
    if rows.is_empty() {
        println!("Nothing available.");
        return ExitCode::SUCCESS;
    }
    rows.sort();
    for (id, version, path) in rows {
        println!("{id:<34} {version:<12} {}", path.display());
    }
    ExitCode::SUCCESS
}

fn cmd_install(m: &mut PackManager, target: Option<&String>) -> ExitCode {
    let Some(target) = target else {
        eprintln!("nova-pack install: missing <id>[@<req>] or <file.npkg>");
        return ExitCode::FAILURE;
    };

    let result = if target.ends_with(".npkg") && Path::new(target).exists() {
        m.install_file(&PathBuf::from(target))
    } else {
        let (id, req) = match target.split_once('@') {
            Some((id, req)) => match VersionReq::parse(req) {
                Ok(r) => (id.to_string(), r),
                Err(e) => {
                    eprintln!("nova-pack install: {e}");
                    return ExitCode::FAILURE;
                }
            },
            None => (target.clone(), VersionReq::Any),
        };
        m.install(&id, &req)
    };

    match result {
        Ok(outcome) => {
            let verb = match &outcome.kind {
                InstallKind::Fresh => "Installed".to_string(),
                InstallKind::Upgrade { from } => format!("Upgraded from {from} to"),
                InstallKind::Downgrade { from } => format!("Downgraded from {from} to"),
                InstallKind::Reinstall => "Reinstalled".to_string(),
            };
            println!("{verb} {} {}", outcome.id, outcome.version);
            println!("  signature verified: key '{}'", outcome.key_id);
            for f in &outcome.files {
                println!("  {f}");
            }
            ExitCode::SUCCESS
        }
        Err(e) => fail(e),
    }
}

fn cmd_remove(m: &mut PackManager, id: Option<&String>) -> ExitCode {
    let Some(id) = id else {
        eprintln!("nova-pack remove: missing <id>");
        return ExitCode::FAILURE;
    };
    match m.remove(id) {
        Ok(()) => {
            println!("Removed {id}");
            ExitCode::SUCCESS
        }
        Err(e) => fail(e),
    }
}

fn cmd_update(m: &mut PackManager, id: Option<&String>) -> ExitCode {
    match id {
        Some(id) => match m.update(id) {
            Ok(Some(outcome)) => {
                println!("Updated {} to {}", outcome.id, outcome.version);
                ExitCode::SUCCESS
            }
            Ok(None) => {
                println!("{id} is already up to date.");
                ExitCode::SUCCESS
            }
            Err(e) => fail(e),
        },
        None => match m.updatable() {
            Ok(list) if list.is_empty() => {
                println!("Everything is up to date.");
                ExitCode::SUCCESS
            }
            Ok(list) => {
                println!("Updates available:");
                for (id, from, to) in list {
                    println!("  {id}  {from} -> {to}");
                }
                println!("\nRun `nova-pack update <id>` to apply one.");
                ExitCode::SUCCESS
            }
            Err(e) => fail(e),
        },
    }
}

fn print_usage() {
    eprintln!(
        "nova-pack — Nova OS package manager (M11)

USAGE:
    nova-pack [--root <dir>] <command>

COMMANDS:
    list                            what is installed
    info <id>                       one package in detail
    sources                         configured package sources
    add-source <dir>                add a package source
    available [<id>]                what the sources offer
    install <id>[@<req>] | <file>   install from a source or a file
    remove <id>                     uninstall
    update [<id>]                   update one package, or list updates

Version requirements: 1.2.3 (exact), >=1.2.3, ^1.2.3, * (any).

nova-pack never installs an unsigned or untrusted package. There is no
--allow-unsigned here; that flag exists only on the SDK's `nova install`,
for debugging a build."
    );
}
