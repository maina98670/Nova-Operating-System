# Nova OS Day 47 — Dependencies, permissions and signing through nova-pack

M11 (Package Ecosystem), v0.60. Continues directly from the Day 46 package.

## Definition of Done

> Dependency resolution between packages. Confirm permission declarations (M5) and signing (M10) are both enforced through `nova-pack`, not bypassable through this new install path.

## New in this package

- `libs/nova-pack-deps`
- `tools/nova-m11-day47-acceptance-test`
- `docs/M11-PACKAGE-DAY47.md`

## Changed

- `tools/nova-pack`: installs now resolve a complete dependency plan
  before writing anything; `remove` refuses to break an installed
  dependent unless `--force` is given; every install path funnels
  through one verify-validate-write function.

## Unchanged

Everything else from the previous package is carried forward as-is.
