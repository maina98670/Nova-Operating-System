# Nova OS Day 48 — Integrity verification and rollback

M11 (Package Ecosystem), v0.60. Continues directly from the Day 47 package.

## Definition of Done

> Post-install integrity verification (checksums, not just signature-at-install-time). Rollback to the previous version of a package after a failed update. A deliberately corrupted installed package is detected on next check; rolling back a bad update restores the previous working version without manual file surgery.

## New in this package

- `libs/nova-pack-integrity`
- `tools/nova-m11-day48-acceptance-test`
- `docs/M11-PACKAGE-DAY48.md`

## Changed

- `tools/nova-pack`: installs record a SHA-256 for every file written and
  keep the installed `.npkg` in a rollback store; `nova-pack verify` and
  `nova-pack rollback` added to the CLI; removal forgets a package's
  stored rollback copies.

## Unchanged

Everything else from the previous package is carried forward as-is.
