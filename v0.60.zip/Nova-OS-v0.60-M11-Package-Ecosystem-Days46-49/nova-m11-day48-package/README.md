# Nova OS — Day 48 Package: integrity verification and rollback

M11 — Package Ecosystem (v0.60, Days 46-49). Continues directly from the Day 45 package.

**Built and tested.** Unlike every package up to v0.53, this one was
compiled and its acceptance test executed before it was written. See
`docs/M11-RETROFITS.md` for the six defects that surfaced the first time
the v0.53 tree was actually built.

## Day 46 goal

**Definition of Done:** `nova-pack install`, `list`, and `remove` all work
correctly against a local test package repository.

## What's new

- `libs/nova-pack-meta`
- `tools/nova-pack` (library + binary)
- `tools/nova-m11-day46-acceptance-test`
- `docs/M11-PACKAGE-DAY46.md`
- `docs/M11-RETROFITS.md`

## Run

```bash
./nova-m11-day46-build_and_run.sh
```
