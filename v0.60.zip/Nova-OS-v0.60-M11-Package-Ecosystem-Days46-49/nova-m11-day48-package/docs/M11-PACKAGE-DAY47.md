# M11 Day 47 — Dependencies, and the checks this path must not skip

**Definition of Done:** Installing a package with an unmet dependency fails
with a clear error rather than installing a broken app; permission/signature
checks from M5/M10 both fire correctly through `nova-pack`, not bypassable
through this new install path.

## Resolution is a separate, pure step

`nova-pack-deps` takes what is installed and what is available and returns
either a complete ordered plan or an error. It touches no files. `nova-pack`
writes nothing until it holds a plan.

That ordering is the DoD. Installing as far as the graph allows and then
reporting the rest leaves the user holding a device in a state neither they
nor the package manager planned for — worse than a refusal, because it is
unrecoverable without understanding the internals.

The plan is post-order: a package appears only after everything it depends
on, so executing the plan in order never installs something before its
dependencies.

## What the resolver does and does not do

It walks the graph depth-first and takes the highest available version
satisfying each requirement. It reports rather than resolves:

| Situation | Result |
| --- | --- |
| Dependency not in any source | `Unmet { NotAvailable }`, naming the package |
| Dependency exists, no version matches | `Unmet { NoMatchingVersion }`, listing what does exist |
| Two packages need incompatible versions of a third | `Conflict`, naming both requirers |
| Graph has a cycle | `Cycle`, printing the chain in order |
| Dependency already installed and acceptable | left alone, not reinstalled |
| Dependency installed but too old | planned as an upgrade |

**No backtracking.** If the highest-matching choice later conflicts, the
conflict is reported, not worked around by trying other combinations.

That is a deliberate limit and the honest reason is worth stating: a
backtracking resolver is where package managers acquire their hardest bugs
and their worst error messages. A phone with a curated package set does not
need one. The trigger for replacing it is written down rather than left to
be rediscovered: if legitimate installs start failing here, the answer is a
proper solver, not heuristics bolted onto this one.

`check_removal` refuses a removal that would leave an installed package with
an unmet dependency. `remove --force` exists because "I know, do it anyway"
is real on a device its owner is debugging, and because the alternative —
users hand-editing `installed.db` to escape a refusal — is worse than an
explicit flag.

The check is against what remaining packages *declare*, not what they turn
out to need at runtime. A package manager cannot know the latter; pretending
otherwise would be confident wrongness rather than an honest limit.

## The part that matters more: the new path is not a softer path

A second install path is a way around the first path's checks unless it is
deliberately not. Every install in `nova-pack` funnels through one private
function that verifies, validates, then writes. That makes "no path skips
verification" a structural property of the code rather than a promise in a
document.

Verified through `nova-pack`'s own install path, by the acceptance test:

- unsigned package → refused, nothing written
- signed by a key not in this device's keystore → refused
- **genuinely signed, then altered, with the original signature reattached**
  → refused. This is the case that matters: what an attacker with a
  legitimate package and no key would actually try.
- permission name not in `nova-ipc`'s fixed set → refused before anything is
  written. M5 checks this at manifest-load time; checking it again at install
  time is what stops an unvalidatable manifest reaching `/apps` by this route.

Every refusal is written to M10 Day 44's security log and is queryable there
by kind, with the hash chain still intact. A device that refuses a package
leaves evidence of having refused it.

Verification happens **before** dependency resolution. Pulling in three
dependencies for a package that is about to be rejected is work done on
behalf of a package the device has already decided not to trust.

## Still open after Day 47

- No post-install integrity check: nothing yet detects a package altered on
  disk *after* a successful install. Day 48.
- No rollback: a bad update cannot be undone. Day 48.
- Signatures remain symmetric. Day 49.
