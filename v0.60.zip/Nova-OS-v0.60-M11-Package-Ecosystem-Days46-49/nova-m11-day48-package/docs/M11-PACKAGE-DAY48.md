# M11 Day 48 — Integrity verification and rollback

**Definition of Done:** A deliberately corrupted installed package is
detected on next check; rolling back a bad update restores the previous
working version without manual file surgery.

## Why a signature is not enough

M10 Day 43 verifies a signature at install time. That answers one question —
*did these bytes come from a key this device trusts?* — and answers it once,
at one moment.

What changes an installed file **after** that check has already passed: a
failed write during power loss, a dying eMMC block, a filesystem that
silently returned success, a privileged process overwriting a binary. None
of those forge a signature. None are detectable by re-checking one.

So the install records a SHA-256 for every file it writes, and `nova-pack
verify` re-hashes them later.

The hashes are taken from the files **on disk after the write**, not from
the bytes in memory. A filesystem that mangled or truncated the write is
then caught by the first verify, rather than blamed on whatever touched the
file next.

## Three outcomes, not a boolean

| Result | Meaning |
| --- | --- |
| `Intact { files_checked }` | every recorded file hashes to what it did at install |
| `Damaged { modified, missing }` | named files changed, named files gone — separately |
| `NotRecorded` | nothing was recorded, so nothing was checked |

`NotRecorded` exists because "we checked nothing and found nothing wrong" is
not the same as "nothing is wrong", and collapsing the two into `true` is
how a verification tool comes to report success on a device it never
examined.

Size is compared as well as hash, but only as a cheap cross-check — never as
a substitute. A single flipped byte does not change a file's size. That is
the exact corruption the acceptance test injects.

## What detection means, honestly

Detection, not prevention. A `Damaged` result says the copy on disk is not
the copy that was installed. It does not say who changed it or when, and a
sufficiently privileged attacker who can change a file can also change the
recorded hash — `installed.db` is an ordinary file.

Making that harder is a secure-boot and read-only-rootfs problem, owned by
M12 and M15. It is named here rather than papered over.

## Rollback

The rollback store keeps the exact `.npkg` bytes of each installed version
under `<root>/var/lib/nova/pack/rollback/<id>/<version>.npkg`.

- **Stored after a successful write, never before.** A store holding a
  version that never installed successfully is a trap, not a safety net.
- **Two versions kept per package.** Current and previous is what rollback
  needs. Keeping more is a nicer story and a worse trade on a device whose
  storage constraints are the reason Nova exists.
- **Rollback is a reinstall from stored bytes**, through the same
  verify-validate-write path as any other install. A rollback that skipped
  verification would be a way to install anything at all, by first writing
  it into the rollback store. The acceptance test proves this by corrupting
  a stored package and confirming the rollback is refused.
- **Rollback is an undo, not a ratchet.** After rolling back from 1.1.0 to
  1.0.0, the recorded previous version becomes 1.1.0, so a second rollback
  returns there instead of looping on 1.0.0 forever.
- **Removing a package forgets its stored copies.** Keeping rollback copies
  of something the user uninstalled is storage spent on a version they will
  never restore.

## Relationship to M15's OTA rollback

This is package-level rollback: one app, one `.npkg`. M15 Day 74's OTA
rollback is image-level and is a different mechanism with a different
failure mode — a device that cannot boot cannot run `nova-pack` at all.
M15 builds on this, it is not replaced by it.
