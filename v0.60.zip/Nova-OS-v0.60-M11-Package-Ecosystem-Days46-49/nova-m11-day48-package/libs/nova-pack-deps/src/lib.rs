//! Nova OS M11 Day 47 — dependency resolution.
//!
//! The Day 47 Definition of Done is specific about what "correct"
//! means here: *installing a package with an unmet dependency fails
//! with a clear error rather than installing a broken app.* Failing
//! **before** anything is written is the whole point — a half-installed
//! dependency graph is worse than a refused install, because the user
//! is now holding a device in a state neither they nor the package
//! manager planned for.
//!
//! So resolution is a separate, pure, filesystem-free step. It takes
//! what is installed and what is available, and returns either a
//! complete ordered plan or an error naming exactly what is missing.
//! `nova-pack` writes nothing until it holds a plan.
//!
//! ## What this resolver is not
//! It is not a SAT solver and does not backtrack. It walks the
//! dependency graph depth-first and, for each dependency, takes the
//! highest available version that satisfies the requirement. If that
//! choice later conflicts with another requirement on the same
//! package, the conflict is **reported**, not silently resolved by
//! trying a different combination.
//!
//! That is a deliberate limit, and the honest reason is that
//! backtracking resolvers are where package managers go to acquire
//! their hardest bugs and their worst error messages. A phone with a
//! curated package set does not need one. If Nova's package ecosystem
//! ever grows dense enough that legitimate installs fail here, the
//! replacement is a proper solver — not a pile of heuristics bolted
//! onto this one. That trigger is written down in
//! `docs/package-format-v1.md` rather than left for someone to
//! rediscover.

use nova_pack_meta::{Dependency, InstalledDb, PackageMeta, Version};
use std::collections::{BTreeMap, BTreeSet};
use std::fmt;

/// Where candidate packages come from. Implemented by `nova-pack` over
/// its configured sources; implemented by tests over a fixed list.
pub trait Provider {
    /// Every version of `id` available to install, in any order.
    fn versions(&self, id: &str) -> Vec<PackageMeta>;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum UnmetReason {
    /// No source offers this package at all.
    NotAvailable,
    /// The package exists, but no version of it satisfies the
    /// requirement. Carries what *is* available, because "not found"
    /// with no further detail is the error message that sends people
    /// to a search engine.
    NoMatchingVersion { available: Vec<Version> },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DepError {
    Unmet { package: String, dep: Dependency, reason: UnmetReason },
    /// Two packages in one plan need incompatible versions of a third.
    Conflict { id: String, wanted_by: Vec<(String, Dependency)>, chosen: Version },
    /// The dependency graph has a cycle. Carries the cycle itself, in
    /// order, so the person reading the error can see which link to
    /// break.
    Cycle(Vec<String>),
    /// Removing `id` would leave these installed packages with an
    /// unmet dependency.
    WouldBreak { id: String, dependents: Vec<String> },
}

impl fmt::Display for DepError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DepError::Unmet { package, dep, reason } => match reason {
                UnmetReason::NotAvailable => write!(
                    f,
                    "{package} depends on {dep}, and no configured source provides {} at all. \
                     Nothing was installed.",
                    dep.id
                ),
                UnmetReason::NoMatchingVersion { available } => {
                    let list: Vec<String> = available.iter().map(|v| v.to_string()).collect();
                    write!(
                        f,
                        "{package} depends on {dep}, but the only versions available are {}. \
                         Nothing was installed.",
                        list.join(", ")
                    )
                }
            },
            DepError::Conflict { id, wanted_by, chosen } => {
                let list: Vec<String> =
                    wanted_by.iter().map(|(who, dep)| format!("{who} needs {dep}")).collect();
                write!(
                    f,
                    "conflicting requirements on {id} (this plan selected {chosen}): {}. \
                     Nothing was installed.",
                    list.join("; ")
                )
            }
            DepError::Cycle(chain) => {
                write!(f, "dependency cycle: {}. Nothing was installed.", chain.join(" -> "))
            }
            DepError::WouldBreak { id, dependents } => write!(
                f,
                "{id} is required by {} — removing it would leave {} broken. \
                 Remove {} first, or nothing at all.",
                dependents.join(", "),
                if dependents.len() == 1 { "that package" } else { "those packages" },
                if dependents.len() == 1 { "it" } else { "them" }
            ),
        }
    }
}

impl std::error::Error for DepError {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StepReason {
    /// The package the user actually asked for.
    Requested,
    /// Pulled in as a dependency of another package in the plan.
    DependencyOf(String),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PlanStep {
    pub meta: PackageMeta,
    pub reason: StepReason,
}

/// An ordered install plan: dependencies before the things that need
/// them, and every step already known to be available.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct Plan {
    pub steps: Vec<PlanStep>,
}

impl Plan {
    pub fn is_empty(&self) -> bool {
        self.steps.is_empty()
    }

    pub fn ids(&self) -> Vec<String> {
        self.steps.iter().map(|s| s.meta.id.clone()).collect()
    }
}

/// Builds the install plan for `target`.
///
/// Dependencies already satisfied by an installed package are not
/// reinstalled — they simply do not appear in the plan. A dependency
/// that is installed at a version the requirement rejects **is**
/// planned, as an upgrade.
pub fn plan_install(
    target: &PackageMeta,
    provider: &dyn Provider,
    installed: &InstalledDb,
) -> Result<Plan, DepError> {
    let mut ctx = Resolve {
        provider,
        installed,
        chosen: BTreeMap::new(),
        wanted_by: BTreeMap::new(),
        order: Vec::new(),
        on_stack: Vec::new(),
        done: BTreeSet::new(),
    };
    ctx.visit(target.clone(), StepReason::Requested)?;

    let steps = ctx
        .order
        .iter()
        .map(|id| PlanStep {
            meta: ctx.chosen.get(id).expect("every ordered id was chosen").clone(),
            reason: ctx.reason_for(id, &target.id),
        })
        .collect();
    Ok(Plan { steps })
}

struct Resolve<'a> {
    provider: &'a dyn Provider,
    installed: &'a InstalledDb,
    chosen: BTreeMap<String, PackageMeta>,
    wanted_by: BTreeMap<String, Vec<(String, Dependency)>>,
    /// Post-order: a package is appended only after everything it
    /// depends on, so installing in this order never installs
    /// something before its dependencies.
    order: Vec<String>,
    on_stack: Vec<String>,
    done: BTreeSet<String>,
}

impl<'a> Resolve<'a> {
    fn reason_for(&self, id: &str, target_id: &str) -> StepReason {
        if id == target_id {
            return StepReason::Requested;
        }
        match self.wanted_by.get(id).and_then(|v| v.first()) {
            Some((who, _)) => StepReason::DependencyOf(who.clone()),
            None => StepReason::Requested,
        }
    }

    fn visit(&mut self, meta: PackageMeta, _reason: StepReason) -> Result<(), DepError> {
        let id = meta.id.clone();

        if self.on_stack.contains(&id) {
            let mut chain: Vec<String> = self.on_stack.clone();
            chain.push(id);
            let start = chain.iter().position(|c| *c == chain[chain.len() - 1]).unwrap_or(0);
            return Err(DepError::Cycle(chain[start..].to_vec()));
        }
        if self.done.contains(&id) {
            return Ok(());
        }

        self.on_stack.push(id.clone());
        self.chosen.insert(id.clone(), meta.clone());

        for dep in &meta.depends {
            self.wanted_by.entry(dep.id.clone()).or_default().push((id.clone(), dep.clone()));

            // A dependency that is still on the stack is a cycle,
            // and has to be caught here rather than one level down:
            // the already-chosen shortcut below would otherwise treat
            // the half-resolved package as satisfied and emit a plan
            // that installs a package before the dependency it needs.
            if self.on_stack.contains(&dep.id) {
                let start = self.on_stack.iter().position(|c| *c == dep.id).unwrap_or(0);
                let mut chain: Vec<String> = self.on_stack[start..].to_vec();
                chain.push(dep.id.clone());
                return Err(DepError::Cycle(chain));
            }

            // Already chosen in this plan? Then the choice has to
            // satisfy this requirement too, or the plan is
            // contradictory.
            if let Some(already) = self.chosen.get(&dep.id).cloned() {
                if !dep.req.matches(&already.version) {
                    return Err(DepError::Conflict {
                        id: dep.id.clone(),
                        wanted_by: self.wanted_by.get(&dep.id).cloned().unwrap_or_default(),
                        chosen: already.version.clone(),
                    });
                }
                continue;
            }

            // Already installed at an acceptable version? Leave it
            // alone. A package manager that reinstalls satisfied
            // dependencies is a package manager that breaks working
            // software for no reason.
            if let Some(inst) = self.installed.get(&dep.id) {
                if dep.req.matches(&inst.meta.version) {
                    continue;
                }
            }

            let available = self.provider.versions(&dep.id);
            if available.is_empty() {
                return Err(DepError::Unmet {
                    package: id.clone(),
                    dep: dep.clone(),
                    reason: UnmetReason::NotAvailable,
                });
            }
            let best = available
                .iter()
                .filter(|m| dep.req.matches(&m.version))
                .max_by(|a, b| a.version.cmp(&b.version))
                .cloned();
            let Some(best) = best else {
                let mut versions: Vec<Version> = available.iter().map(|m| m.version.clone()).collect();
                versions.sort();
                return Err(DepError::Unmet {
                    package: id.clone(),
                    dep: dep.clone(),
                    reason: UnmetReason::NoMatchingVersion { available: versions },
                });
            };

            self.visit(best, StepReason::DependencyOf(id.clone()))?;
        }

        self.on_stack.pop();
        self.done.insert(id.clone());
        self.order.push(id);
        Ok(())
    }
}

/// Refuses a removal that would break an installed package.
///
/// The check is against what the remaining packages *declare*, not
/// against what they turn out to need at runtime — a package manager
/// cannot know the latter, and pretending otherwise would be the kind
/// of confident wrongness that is worse than an honest limit.
pub fn check_removal(id: &str, installed: &InstalledDb) -> Result<(), DepError> {
    let dependents: Vec<String> = installed
        .dependents_of(id)
        .iter()
        .map(|p| p.meta.id.clone())
        .filter(|dep_id| dep_id != id)
        .collect();
    if dependents.is_empty() {
        Ok(())
    } else {
        Err(DepError::WouldBreak { id: id.to_string(), dependents })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_pack_meta::VersionReq;

    struct FakeProvider {
        packages: Vec<PackageMeta>,
    }

    impl Provider for FakeProvider {
        fn versions(&self, id: &str) -> Vec<PackageMeta> {
            self.packages.iter().filter(|p| p.id == id).cloned().collect()
        }
    }

    fn meta(id: &str, version: &str, depends: &[&str]) -> PackageMeta {
        let bytes = nova_package_test_pack(id, version, depends);
        PackageMeta::from_npkg(&bytes).unwrap()
    }

    /// Builds a real `.npkg` so the metadata under test is metadata
    /// that came out of a real package, not a struct literal that
    /// happens to look like one.
    fn nova_package_test_pack(id: &str, version: &str, depends: &[&str]) -> Vec<u8> {
        let deps: Vec<String> = depends.iter().map(|d| format!("\"{d}\"")).collect();
        let manifest = format!(
            "id = \"{id}\"\nname = \"{id}\"\nversion = \"{version}\"\nentry_point = \"bin/x\"\ndepends = [{}]\n",
            deps.join(", ")
        );
        // A tiny inline copy of the packer's wire format would be a
        // second implementation to keep in sync, so this calls the
        // real one through nova-pack-meta's own dependency.
        nova_pack_meta_pack(manifest.as_bytes())
    }

    fn nova_pack_meta_pack(manifest: &[u8]) -> Vec<u8> {
        // nova-package-format is already a dependency of
        // nova-pack-meta; re-export is not worth a public API change,
        // so the format is reproduced here in the one place a test
        // needs it. Kept to the documented wire format.
        let mut out = Vec::new();
        out.extend_from_slice(b"NPKG");
        out.push(1);
        out.extend_from_slice(&(manifest.len() as u32).to_le_bytes());
        out.extend_from_slice(manifest);
        out.extend_from_slice(&0u32.to_le_bytes());
        out
    }

    fn empty_db() -> InstalledDb {
        InstalledDb::open("/nonexistent/nova-pack-deps-test.db").unwrap()
    }

    #[test]
    fn a_package_with_no_dependencies_plans_to_itself() {
        let target = meta("org.nova.solo", "1.0.0", &[]);
        let provider = FakeProvider { packages: vec![] };
        let plan = plan_install(&target, &provider, &empty_db()).unwrap();
        assert_eq!(plan.ids(), vec!["org.nova.solo"]);
    }

    #[test]
    fn dependencies_come_before_dependents() {
        let target = meta("org.nova.app", "1.0.0", &["org.nova.lib >= 1.0.0"]);
        let provider = FakeProvider {
            packages: vec![meta("org.nova.lib", "1.4.0", &["org.nova.base >= 0.1.0"]), meta("org.nova.base", "0.2.0", &[])],
        };
        let plan = plan_install(&target, &provider, &empty_db()).unwrap();
        assert_eq!(plan.ids(), vec!["org.nova.base", "org.nova.lib", "org.nova.app"]);
    }

    #[test]
    fn the_highest_matching_version_is_chosen() {
        let target = meta("org.nova.app", "1.0.0", &["org.nova.lib ^1.0.0"]);
        let provider = FakeProvider {
            packages: vec![meta("org.nova.lib", "1.0.0", &[]), meta("org.nova.lib", "1.9.3", &[]), meta("org.nova.lib", "2.0.0", &[])],
        };
        let plan = plan_install(&target, &provider, &empty_db()).unwrap();
        let lib = plan.steps.iter().find(|s| s.meta.id == "org.nova.lib").unwrap();
        assert_eq!(lib.meta.version.to_string(), "1.9.3");
        assert_eq!(lib.reason, StepReason::DependencyOf("org.nova.app".to_string()));
    }

    #[test]
    fn a_missing_dependency_is_an_error_naming_the_dependency() {
        let target = meta("org.nova.app", "1.0.0", &["org.nova.absent >= 1.0.0"]);
        let provider = FakeProvider { packages: vec![] };
        let err = plan_install(&target, &provider, &empty_db()).unwrap_err();
        assert!(matches!(&err, DepError::Unmet { reason: UnmetReason::NotAvailable, .. }));
        let msg = err.to_string();
        assert!(msg.contains("org.nova.absent"), "{msg}");
        assert!(msg.contains("Nothing was installed"), "{msg}");
    }

    #[test]
    fn a_dependency_with_no_matching_version_reports_what_is_available() {
        let target = meta("org.nova.app", "1.0.0", &["org.nova.lib >= 5.0.0"]);
        let provider =
            FakeProvider { packages: vec![meta("org.nova.lib", "1.0.0", &[]), meta("org.nova.lib", "2.3.0", &[])] };
        let err = plan_install(&target, &provider, &empty_db()).unwrap_err();
        let msg = err.to_string();
        assert!(msg.contains("1.0.0") && msg.contains("2.3.0"), "{msg}");
    }

    #[test]
    fn a_cycle_is_reported_as_a_cycle_not_a_stack_overflow() {
        let target = meta("org.nova.a", "1.0.0", &["org.nova.b"]);
        let provider =
            FakeProvider { packages: vec![meta("org.nova.b", "1.0.0", &["org.nova.a"]), meta("org.nova.a", "1.0.0", &["org.nova.b"])] };
        let err = plan_install(&target, &provider, &empty_db()).unwrap_err();
        assert!(matches!(err, DepError::Cycle(_)), "{err}");
        assert!(err.to_string().contains("org.nova.a"), "{err}");
    }

    #[test]
    fn an_already_satisfied_dependency_is_not_reinstalled() {
        let mut db = empty_db();
        let lib = meta("org.nova.lib", "1.5.0", &[]);
        db.insert(nova_pack_meta::InstalledPackage {
            meta: lib.clone(),
            installed_at: 0,
            files: Vec::new(),
            previous_version: None,
        });

        let target = meta("org.nova.app", "1.0.0", &["org.nova.lib >= 1.0.0"]);
        let provider = FakeProvider { packages: vec![meta("org.nova.lib", "1.9.0", &[])] };
        let plan = plan_install(&target, &provider, &db).unwrap();
        assert_eq!(plan.ids(), vec!["org.nova.app"], "the satisfied dependency should be left alone");
    }

    #[test]
    fn an_installed_but_too_old_dependency_is_upgraded() {
        let mut db = empty_db();
        db.insert(nova_pack_meta::InstalledPackage {
            meta: meta("org.nova.lib", "1.0.0", &[]),
            installed_at: 0,
            files: Vec::new(),
            previous_version: None,
        });

        let target = meta("org.nova.app", "1.0.0", &["org.nova.lib >= 1.5.0"]);
        let provider = FakeProvider { packages: vec![meta("org.nova.lib", "1.6.0", &[])] };
        let plan = plan_install(&target, &provider, &db).unwrap();
        assert_eq!(plan.ids(), vec!["org.nova.lib", "org.nova.app"]);
    }

    #[test]
    fn conflicting_requirements_are_reported_not_silently_resolved() {
        // app -> lib ^1.0.0, and app -> other -> lib ^2.0.0.
        let target = meta("org.nova.app", "1.0.0", &["org.nova.lib ^1.0.0", "org.nova.other >= 1.0.0"]);
        let provider = FakeProvider {
            packages: vec![
                meta("org.nova.lib", "1.2.0", &[]),
                meta("org.nova.lib", "2.0.0", &[]),
                meta("org.nova.other", "1.0.0", &["org.nova.lib ^2.0.0"]),
            ],
        };
        let err = plan_install(&target, &provider, &empty_db()).unwrap_err();
        assert!(matches!(err, DepError::Conflict { .. }), "{err}");
    }

    #[test]
    fn removal_is_refused_while_something_depends_on_it() {
        let mut db = empty_db();
        for (id, deps) in [("org.nova.app", vec!["org.nova.lib >= 1.0.0"]), ("org.nova.lib", vec![])] {
            db.insert(nova_pack_meta::InstalledPackage {
                meta: meta(id, "1.0.0", &deps),
                installed_at: 0,
                files: Vec::new(),
                previous_version: None,
            });
        }
        let err = check_removal("org.nova.lib", &db).unwrap_err();
        assert!(matches!(&err, DepError::WouldBreak { dependents, .. } if dependents == &["org.nova.app"]));
        assert!(check_removal("org.nova.app", &db).is_ok());
    }

    #[test]
    fn version_requirements_still_mean_what_meta_says_they_mean() {
        // Guards against the resolver quietly reimplementing matching.
        assert!(VersionReq::parse("^1.0.0").unwrap().matches(&Version::new(1, 9, 0)));
        assert!(!VersionReq::parse("^1.0.0").unwrap().matches(&Version::new(2, 0, 0)));
    }
}
