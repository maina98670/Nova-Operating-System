//! Nova OS M11 Day 48 — post-install integrity verification and
//! rollback.
//!
//! ## Why a signature is not enough
//! M10 Day 43 verifies a signature at install time. That answers one
//! question — *did these bytes come from a key this device trusts?* —
//! and answers it only once, at the moment of installation. It says
//! nothing about the file sitting in `/apps` three weeks later.
//!
//! Things that change an installed file after install-time
//! verification has already passed: a failed write during a power loss,
//! a dying eMMC block, a filesystem that silently returned success, a
//! process with enough privilege to overwrite a binary. None of those
//! involve forging a signature, and none of them are detectable by
//! re-checking one.
//!
//! So the Day 48 DoD asks for checksums recorded at install and checked
//! later: *a deliberately corrupted installed package is detected on
//! next check*. That is what this crate does.
//!
//! ## What a detected corruption means, honestly
//! Detection, not prevention. A `Modified` result tells the user (or
//! M15's update system) that the copy on disk is not the copy that was
//! installed. It does not say who changed it or when, and a sufficiently
//! privileged attacker who changes a file can also change the recorded
//! hash — the database is an ordinary file. Making that harder is a
//! secure-boot and read-only-rootfs problem, owned by M12 and M15, and
//! is named in `docs/package-format-v1.md` rather than papered over
//! here.
//!
//! ## Rollback
//! The rollback store keeps the `.npkg` of each installed version, so
//! restoring the previous version is a reinstall from bytes the device
//! already verified once — not a reconstruction of files from a diff,
//! and not a network fetch that a device with a broken update may be in
//! no state to perform.

use nova_crypto::{sha256, to_hex};
use nova_pack_meta::{FileRecord, Version};
use std::fmt;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug)]
pub enum IntegrityError {
    Io(String),
    /// Asked to roll back to a version whose package is not in the
    /// store.
    NoStoredPackage { id: String, version: Version },
}

impl fmt::Display for IntegrityError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            IntegrityError::Io(e) => write!(f, "{e}"),
            IntegrityError::NoStoredPackage { id, version } => write!(
                f,
                "no stored package for {id} {version} — this device cannot roll back to a \
                 version it never kept. Reinstall from a source instead."
            ),
        }
    }
}

impl std::error::Error for IntegrityError {}

impl From<std::io::Error> for IntegrityError {
    fn from(e: std::io::Error) -> Self {
        IntegrityError::Io(e.to_string())
    }
}

/// What a check found. Deliberately not a bool: "something is wrong"
/// and "which file, and in what way" are different amounts of
/// information, and the second is what makes the result actionable.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IntegrityReport {
    Intact {
        files_checked: usize,
    },
    Damaged {
        /// Files whose content no longer hashes to what was recorded.
        modified: Vec<String>,
        /// Files that were installed and are now gone.
        missing: Vec<String>,
    },
    /// The package is in the database but nothing recorded which files
    /// it installed — a record written before Day 48, or by a tool
    /// that did not record them. Reported as its own state rather than
    /// as "intact", because "we checked nothing and found nothing
    /// wrong" is not the same as "nothing is wrong".
    NotRecorded,
}

impl IntegrityReport {
    pub fn is_intact(&self) -> bool {
        matches!(self, IntegrityReport::Intact { .. })
    }
}

impl fmt::Display for IntegrityReport {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            IntegrityReport::Intact { files_checked } => {
                write!(f, "intact ({files_checked} file(s) checked)")
            }
            IntegrityReport::Damaged { modified, missing } => {
                let mut parts = Vec::new();
                if !modified.is_empty() {
                    parts.push(format!("modified: {}", modified.join(", ")));
                }
                if !missing.is_empty() {
                    parts.push(format!("missing: {}", missing.join(", ")));
                }
                write!(f, "DAMAGED — {}", parts.join("; "))
            }
            IntegrityReport::NotRecorded => {
                write!(f, "no file hashes were recorded for this package, so nothing could be checked")
            }
        }
    }
}

/// Hashes each file at `app_dir/<rel>` and returns the records to store.
pub fn record_files(app_dir: &Path, relative_paths: &[String]) -> Result<Vec<FileRecord>, IntegrityError> {
    let mut out = Vec::new();
    for rel in relative_paths {
        let path = app_dir.join(rel);
        let bytes = fs::read(&path).map_err(|e| IntegrityError::Io(format!("{}: {e}", path.display())))?;
        out.push(FileRecord { path: rel.clone(), sha256: to_hex(&sha256(&bytes)), size: bytes.len() as u64 });
    }
    Ok(out)
}

/// Re-hashes what is on disk and compares it to what was recorded.
pub fn verify_files(app_dir: &Path, records: &[FileRecord]) -> IntegrityReport {
    if records.is_empty() {
        return IntegrityReport::NotRecorded;
    }
    let mut modified = Vec::new();
    let mut missing = Vec::new();

    for rec in records {
        let path = app_dir.join(&rec.path);
        match fs::read(&path) {
            Err(_) => missing.push(rec.path.clone()),
            Ok(bytes) => {
                // Size is checked too, but only as a cheap cross-check
                // on the hash, never as a substitute for it: an
                // in-place single-byte flip does not change the size,
                // which is exactly the corruption a size check misses
                // and a hash catches.
                if to_hex(&sha256(&bytes)) != rec.sha256 || bytes.len() as u64 != rec.size {
                    modified.push(rec.path.clone());
                }
            }
        }
    }

    if modified.is_empty() && missing.is_empty() {
        IntegrityReport::Intact { files_checked: records.len() }
    } else {
        IntegrityReport::Damaged { modified, missing }
    }
}

// ---------------------------------------------------------------------
// Rollback store
// ---------------------------------------------------------------------

/// Keeps the `.npkg` of installed versions so a bad update can be
/// undone without a network.
pub struct RollbackStore {
    dir: PathBuf,
    /// How many versions of one package to keep. Two — the current one
    /// and the one before it — is what rollback actually needs. Keeping
    /// more would be a nicer story and a worse trade on a device whose
    /// storage is the reason Nova exists.
    keep: usize,
}

impl RollbackStore {
    pub fn new(dir: impl Into<PathBuf>) -> Self {
        RollbackStore { dir: dir.into(), keep: 2 }
    }

    pub fn with_keep(mut self, keep: usize) -> Self {
        self.keep = keep.max(1);
        self
    }

    fn package_dir(&self, id: &str) -> PathBuf {
        self.dir.join(id)
    }

    fn package_path(&self, id: &str, version: &Version) -> PathBuf {
        self.package_dir(id).join(format!("{version}.npkg"))
    }

    /// Stores the exact bytes that were installed, then prunes.
    pub fn store(&self, id: &str, version: &Version, bytes: &[u8]) -> Result<(), IntegrityError> {
        let dir = self.package_dir(id);
        fs::create_dir_all(&dir)?;
        fs::write(self.package_path(id, version), bytes)?;
        self.prune(id)?;
        Ok(())
    }

    pub fn has(&self, id: &str, version: &Version) -> bool {
        self.package_path(id, version).is_file()
    }

    pub fn load(&self, id: &str, version: &Version) -> Result<Vec<u8>, IntegrityError> {
        let path = self.package_path(id, version);
        if !path.is_file() {
            return Err(IntegrityError::NoStoredPackage { id: id.to_string(), version: version.clone() });
        }
        Ok(fs::read(path)?)
    }

    /// Every stored version of `id`, newest first.
    pub fn versions(&self, id: &str) -> Vec<Version> {
        let mut out: Vec<Version> = match fs::read_dir(self.package_dir(id)) {
            Ok(entries) => entries
                .flatten()
                .filter_map(|e| {
                    let name = e.file_name().to_string_lossy().to_string();
                    name.strip_suffix(".npkg").and_then(|v| Version::parse(v).ok())
                })
                .collect(),
            Err(_) => Vec::new(),
        };
        out.sort();
        out.reverse();
        out
    }

    /// Drops everything older than the newest `keep` versions.
    fn prune(&self, id: &str) -> Result<(), IntegrityError> {
        let versions = self.versions(id);
        for old in versions.iter().skip(self.keep) {
            let _ = fs::remove_file(self.package_path(id, old));
        }
        Ok(())
    }

    /// Forgets a package entirely — called when it is uninstalled,
    /// since keeping rollback copies of something the user removed is
    /// storage spent on a version they will never restore.
    pub fn forget(&self, id: &str) -> Result<(), IntegrityError> {
        let dir = self.package_dir(id);
        if dir.exists() {
            fs::remove_dir_all(dir)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_dir(tag: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("nova-pack-integrity-{tag}-{}", std::process::id()));
        let _ = fs::remove_dir_all(&d);
        fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn intact_files_verify_as_intact() {
        let dir = temp_dir("intact");
        fs::create_dir_all(dir.join("bin")).unwrap();
        fs::write(dir.join("nova-app.toml"), b"id = \"x\"").unwrap();
        fs::write(dir.join("bin/x"), b"binary").unwrap();

        let records = record_files(&dir, &["nova-app.toml".into(), "bin/x".into()]).unwrap();
        assert_eq!(verify_files(&dir, &records), IntegrityReport::Intact { files_checked: 2 });
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn a_single_flipped_byte_is_detected() {
        let dir = temp_dir("flip");
        fs::write(dir.join("f"), b"hello world").unwrap();
        let records = record_files(&dir, &["f".into()]).unwrap();

        // Same length, one byte different: the case a size check misses.
        fs::write(dir.join("f"), b"hello w0rld").unwrap();
        match verify_files(&dir, &records) {
            IntegrityReport::Damaged { modified, missing } => {
                assert_eq!(modified, vec!["f".to_string()]);
                assert!(missing.is_empty());
            }
            other => panic!("expected Damaged, got {other:?}"),
        }
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn a_deleted_file_is_reported_as_missing_not_modified() {
        let dir = temp_dir("missing");
        fs::write(dir.join("f"), b"data").unwrap();
        let records = record_files(&dir, &["f".into()]).unwrap();
        fs::remove_file(dir.join("f")).unwrap();

        match verify_files(&dir, &records) {
            IntegrityReport::Damaged { modified, missing } => {
                assert!(modified.is_empty());
                assert_eq!(missing, vec!["f".to_string()]);
            }
            other => panic!("expected Damaged, got {other:?}"),
        }
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn no_records_is_its_own_state_not_a_pass() {
        let dir = temp_dir("norecords");
        assert_eq!(verify_files(&dir, &[]), IntegrityReport::NotRecorded);
        assert!(!IntegrityReport::NotRecorded.is_intact());
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn the_store_round_trips_exact_bytes() {
        let dir = temp_dir("store");
        let store = RollbackStore::new(&dir);
        let v = Version::new(1, 2, 3);
        store.store("org.nova.x", &v, b"package-bytes").unwrap();
        assert!(store.has("org.nova.x", &v));
        assert_eq!(store.load("org.nova.x", &v).unwrap(), b"package-bytes");
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn the_store_keeps_two_versions_and_prunes_the_rest() {
        let dir = temp_dir("prune");
        let store = RollbackStore::new(&dir);
        for v in ["1.0.0", "1.1.0", "1.2.0", "1.3.0"] {
            store.store("org.nova.x", &Version::parse(v).unwrap(), v.as_bytes()).unwrap();
        }
        let kept = store.versions("org.nova.x");
        assert_eq!(kept.len(), 2, "kept: {kept:?}");
        assert_eq!(kept[0], Version::new(1, 3, 0));
        assert_eq!(kept[1], Version::new(1, 2, 0));
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn rolling_back_to_a_version_never_stored_is_a_clear_error() {
        let dir = temp_dir("norollback");
        let store = RollbackStore::new(&dir);
        let err = store.load("org.nova.x", &Version::new(9, 9, 9)).unwrap_err();
        assert!(err.to_string().contains("cannot roll back"), "{err}");
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn forgetting_a_package_removes_its_stored_versions() {
        let dir = temp_dir("forget");
        let store = RollbackStore::new(&dir);
        store.store("org.nova.x", &Version::new(1, 0, 0), b"bytes").unwrap();
        store.forget("org.nova.x").unwrap();
        assert!(store.versions("org.nova.x").is_empty());
        fs::remove_dir_all(&dir).unwrap();
    }
}
