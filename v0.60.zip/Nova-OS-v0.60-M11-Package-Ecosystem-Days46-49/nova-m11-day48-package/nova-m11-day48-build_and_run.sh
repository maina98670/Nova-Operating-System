#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 48 (M11 Package Ecosystem): build ==="
cargo build --workspace

echo
echo "=== Nova OS Day 48: unit tests ==="
cargo test --workspace

echo
echo "=== nova-m11-day46-acceptance-test ==="
cargo run -p nova-m11-day46-acceptance-test

echo
echo "=== nova-m11-day47-acceptance-test ==="
cargo run -p nova-m11-day47-acceptance-test

echo
echo "=== nova-m11-day48-acceptance-test ==="
cargo run -p nova-m11-day48-acceptance-test

echo
echo "Day 48 build + tests + acceptance completed."
