//! Day 47 acceptance test — the literal Definition of Done:
//!
//! > Installing a package with an unmet dependency fails with a clear
//! > error rather than installing a broken app; permission/signature
//! > checks from M5/M10 both fire correctly through `nova-pack`.
//!
//! Two halves, and the second one is the one worth being paranoid
//! about. A new install path is a new way around the old path's
//! checks unless it is deliberately not, so the checks here are not
//! "does a bad package get rejected" in the abstract — they are "does
//! *this* code path reject the same three things M10 Day 43 rejected,
//! including the case that actually matters: a package whose binary
//! was swapped and whose genuine signature was reattached."
//!
//! Real packages, real signatures, real filesystem, throughout.

use nova_pack::fixture::TestRoot;
use nova_pack::{PackError, PackManager};
use nova_pack_deps::DepError;
use nova_pack_meta::VersionReq;
use nova_seclog::{SecurityEventKind, SecurityLog};
use std::process::ExitCode;

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn check(name: &'static str, passed: bool, detail: impl Into<String>) -> Check {
    Check { name, passed, detail: detail.into() }
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 47 acceptance: dependencies, permissions, signatures ===\n");

    let root = match TestRoot::new("day47") {
        Ok(r) => r,
        Err(e) => {
            eprintln!("could not build the test root: {e}");
            return ExitCode::FAILURE;
        }
    };

    // A small dependency graph:
    //   org.nova.editor 1.0.0  -> org.nova.textkit >= 1.1.0
    //   org.nova.textkit 1.2.0 -> org.nova.base ^0.3.0
    //   org.nova.base 0.3.4
    // plus a package whose dependency is nowhere to be found.
    let published = [
        ("org.nova.base", "0.3.4", vec![]),
        ("org.nova.textkit", "1.2.0", vec!["org.nova.base ^0.3.0"]),
        ("org.nova.editor", "1.0.0", vec!["org.nova.textkit >= 1.1.0"]),
        ("org.nova.orphan", "1.0.0", vec!["org.nova.missing >= 1.0.0"]),
        ("org.nova.picky", "1.0.0", vec!["org.nova.base >= 9.0.0"]),
    ];
    for (id, version, deps) in &published {
        if let Err(e) = root.publish(id, version, deps, &["storage"]) {
            eprintln!("could not publish {id}: {e}");
            return ExitCode::FAILURE;
        }
    }

    let mut m = match PackManager::open(root.layout()) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("could not open the package manager: {e}");
            return ExitCode::FAILURE;
        }
    };
    m.add_source(&root.repo).expect("add source");

    let mut checks: Vec<Check> = Vec::new();

    // --- 1. A dependency chain installs, in dependency order. ----------
    let outcome = m.install("org.nova.editor", &VersionReq::Any);
    let all_installed = ["org.nova.base", "org.nova.textkit", "org.nova.editor"]
        .iter()
        .all(|id| m.db().get(id).is_some());
    checks.push(check(
        "installing one package pulls in its whole dependency chain",
        outcome.is_ok() && all_installed,
        match &outcome {
            Ok(o) => format!(
                "requested {} {}; installed now: {:?}",
                o.id,
                o.version,
                m.installed().iter().map(|p| p.meta.id.clone()).collect::<Vec<_>>()
            ),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // Dependencies must exist on disk, not just in the database.
    let base_binary = m.layout().app_dir("org.nova.base").join("bin/base");
    checks.push(check(
        "a dependency is really installed, not just recorded",
        base_binary.is_file(),
        format!("{} exists: {}", base_binary.display(), base_binary.is_file()),
    ));

    // --- 2. An unmet dependency stops everything. ----------------------
    let unmet = m.install("org.nova.orphan", &VersionReq::Any);
    let orphan_dir = m.layout().app_dir("org.nova.orphan");
    checks.push(check(
        "a package with an unmet dependency is refused, and nothing is written",
        matches!(&unmet, Err(PackError::Dep(DepError::Unmet { .. }))) && !orphan_dir.exists(),
        match &unmet {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED A BROKEN APP".to_string(),
        },
    ));
    checks.push(check(
        "the unmet-dependency error names the missing package",
        matches!(&unmet, Err(e) if e.to_string().contains("org.nova.missing")),
        match &unmet {
            Err(e) => format!("message: {e}"),
            Ok(_) => "no error at all".to_string(),
        },
    ));

    // --- 3. A dependency that exists but at no acceptable version. -----
    let picky = m.install("org.nova.picky", &VersionReq::Any);
    checks.push(check(
        "an unsatisfiable version requirement reports what versions do exist",
        matches!(&picky, Err(e) if e.to_string().contains("0.3.4")),
        match &picky {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED ANYWAY".to_string(),
        },
    ));

    // --- 4. Removal that would break a dependent is refused. -----------
    let break_it = m.remove("org.nova.textkit");
    checks.push(check(
        "removing a package something depends on is refused",
        matches!(&break_it, Err(PackError::Dep(DepError::WouldBreak { .. })))
            && m.db().get("org.nova.textkit").is_some(),
        match &break_it {
            Err(e) => format!("refused: {e}"),
            Ok(()) => "REMOVED IT AND BROKE THE EDITOR".to_string(),
        },
    ));

    let leaf = m.remove("org.nova.editor");
    let then_lib = m.remove("org.nova.textkit");
    checks.push(check(
        "removing the dependent first then frees the dependency",
        leaf.is_ok() && then_lib.is_ok(),
        format!("editor removed: {:?} | textkit removed: {:?}", leaf.is_ok(), then_lib.is_ok()),
    ));

    // --- 5. Forced removal is possible, and explicit. ------------------
    m.install("org.nova.editor", &VersionReq::Any).expect("reinstall editor");
    let forced = m.remove_forced("org.nova.textkit");
    checks.push(check(
        "forced removal works but is a separate, named operation",
        forced.is_ok() && m.db().get("org.nova.textkit").is_none(),
        format!("forced removal succeeded: {}", forced.is_ok()),
    ));
    m.remove_forced("org.nova.editor").ok();

    // --- 6. M5's permission check fires through this path. -------------
    let bogus = nova_package_sign::sign(
        &nova_pack::fixture::package("org.nova.bogusperm", "1.0.0", &[], &["teleportation"]),
        &root.key,
    );
    let bogus_result = m.install_bytes(&bogus, "bogus-permission-test");
    checks.push(check(
        "a package declaring a permission nova-ipc does not define is refused",
        matches!(&bogus_result, Err(PackError::UnknownPermission { .. }))
            && !m.layout().app_dir("org.nova.bogusperm").exists(),
        match &bogus_result {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED A PACKAGE WITH A MEANINGLESS PERMISSION".to_string(),
        },
    ));

    let good_perms = nova_package_sign::sign(
        &nova_pack::fixture::package("org.nova.goodperm", "1.0.0", &[], &["storage", "network"]),
        &root.key,
    );
    let good_result = m.install_bytes(&good_perms, "good-permission-test");
    checks.push(check(
        "control: a package declaring real permissions still installs",
        good_result.is_ok(),
        match &good_result {
            Ok(o) => format!("installed {} {}", o.id, o.version),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // --- 7. M10's three signature failures all fire through this path. -
    let unsigned = nova_pack::fixture::package("org.nova.unsigned", "1.0.0", &[], &[]);
    checks.push(check(
        "unsigned: refused",
        matches!(m.install_bytes(&unsigned, "unsigned"), Err(PackError::Verify(_))),
        "no NPKGSIG1 trailer".to_string(),
    ));

    let untrusted = root.sign_with_untrusted_key(&nova_pack::fixture::package("org.nova.untrusted", "1.0.0", &[], &[]));
    checks.push(check(
        "signed by an untrusted key: refused",
        matches!(m.install_bytes(&untrusted, "untrusted"), Err(PackError::Verify(_))),
        "key not in this device's keystore".to_string(),
    ));

    // The case that actually matters: a genuinely signed package whose
    // payload is then altered, with the original signature left in
    // place. This is what an attacker with a legitimate package and no
    // key would try.
    let genuine = nova_package_sign::sign(&nova_pack::fixture::package("org.nova.tamper", "1.0.0", &[], &[]), &root.key);
    let mut tampered = genuine.clone();
    // Flip a byte in the payload, well before the trailer.
    let target_byte = 40.min(tampered.len().saturating_sub(64));
    tampered[target_byte] ^= 0xff;
    let tampered_result = m.install_bytes(&tampered, "tampered");
    checks.push(check(
        "genuinely signed but altered afterwards: refused, and nothing written",
        matches!(&tampered_result, Err(PackError::Verify(_))) && !m.layout().app_dir("org.nova.tamper").exists(),
        match &tampered_result {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED AN ALTERED PACKAGE".to_string(),
        },
    ));

    // --- 8. The refusals are in the security log. ----------------------
    // Queried through M10's own API rather than by grepping the file:
    // the DoD M10 Day 44 set was that security events are *queryable*
    // separately, so the check exercises that, and gets the
    // hash-chain verification for free.
    let seclog_path = m.layout().seclog_path();
    let (rejections, chain) = match SecurityLog::open(&seclog_path) {
        Ok(log) => (log.by_kind(SecurityEventKind::PackageRejected).len(), format!("{:?}", log.verify_chain())),
        Err(e) => (0, format!("could not open: {e}")),
    };
    checks.push(check(
        "every refusal is queryable in the M10 security log, chain intact",
        rejections >= 4 && chain.contains("Intact"),
        format!("{rejections} PACKAGE_REJECTED record(s) in {}; chain: {chain}", seclog_path.display()),
    ));

    report(checks, &root)
}

fn report(checks: Vec<Check>, root: &TestRoot) -> ExitCode {
    println!("Checks:");
    let mut failed = 0;
    for c in &checks {
        println!("  [{}] {}", if c.passed { "PASS" } else { "FAIL" }, c.name);
        println!("         {}", c.detail);
        if !c.passed {
            failed += 1;
        }
    }
    println!();
    if failed == 0 {
        println!("Day 47 acceptance: PASS ({} checks)", checks.len());
        println!("Dependencies resolve or the install is refused whole; M5's permission check and");
        println!("all three of M10's signature failures fire through nova-pack's own install path.");
        root.cleanup();
        ExitCode::SUCCESS
    } else {
        println!("Day 47 acceptance: FAIL ({failed} of {} checks failed)", checks.len());
        println!("Test root left in place for inspection: {}", root.dir.display());
        ExitCode::FAILURE
    }
}
