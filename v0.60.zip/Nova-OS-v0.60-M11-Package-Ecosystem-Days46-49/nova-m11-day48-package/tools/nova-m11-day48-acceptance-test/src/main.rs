//! Day 48 acceptance test — the literal Definition of Done:
//!
//! > A deliberately corrupted installed package is detected on next
//! > check; rolling back a bad update restores the previous working
//! > version without manual file surgery.
//!
//! Both halves are done for real. The corruption is a real byte
//! written into a real installed binary on disk, not a simulated
//! hash mismatch. The rollback is a real reinstall of the real
//! previous `.npkg`, and what it restored is checked by hashing the
//! file afterwards — not by trusting the tool's report of its own
//! success.
//!
//! "Without manual file surgery" is read as part of the DoD, so the
//! test asserts the *whole* recovery is one call: no deleting
//! directories by hand, no editing the database, no reinstall from a
//! source.

use nova_pack::fixture::TestRoot;
use nova_pack::{PackError, PackManager};
use nova_pack_integrity::IntegrityReport;
use nova_pack_meta::{Version, VersionReq};
use std::fs;
use std::process::ExitCode;

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn check(name: &'static str, passed: bool, detail: impl Into<String>) -> Check {
    Check { name, passed, detail: detail.into() }
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 48 acceptance: integrity verification and rollback ===\n");

    let root = match TestRoot::new("day48") {
        Ok(r) => r,
        Err(e) => {
            eprintln!("could not build the test root: {e}");
            return ExitCode::FAILURE;
        }
    };

    for (id, version) in [("org.nova.reader", "1.0.0"), ("org.nova.reader", "1.1.0"), ("org.nova.quiet", "1.0.0")] {
        if let Err(e) = root.publish(id, version, &[], &["storage"]) {
            eprintln!("could not publish {id} {version}: {e}");
            return ExitCode::FAILURE;
        }
    }

    let mut m = match PackManager::open(root.layout()) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("could not open the package manager: {e}");
            return ExitCode::FAILURE;
        }
    };
    m.add_source(&root.repo).expect("add source");

    let mut checks: Vec<Check> = Vec::new();

    // --- 1. A fresh install verifies. ----------------------------------
    m.install("org.nova.reader", &VersionReq::parse("1.0.0").unwrap()).expect("install 1.0.0");
    m.install("org.nova.quiet", &VersionReq::Any).expect("install quiet");
    let report = m.verify("org.nova.reader").expect("verify");
    checks.push(check(
        "a freshly installed package verifies as intact",
        matches!(report, IntegrityReport::Intact { files_checked } if files_checked == 2),
        format!("{report}"),
    ));

    // --- 2. Corrupting an installed file is detected. -------------------
    let binary = m.layout().app_dir("org.nova.reader").join("bin/reader");
    let original = fs::read(&binary).expect("read installed binary");
    let mut corrupted = original.clone();
    // A single flipped byte, same length: the corruption a size check
    // would miss entirely.
    corrupted[original.len() / 2] ^= 0x01;
    fs::write(&binary, &corrupted).expect("corrupt the binary");

    let report = m.verify("org.nova.reader").expect("verify after corruption");
    checks.push(check(
        "a single flipped byte in an installed binary is detected",
        matches!(&report, IntegrityReport::Damaged { modified, .. } if modified.contains(&"bin/reader".to_string())),
        format!("{report}"),
    ));
    checks.push(check(
        "corruption in one package does not implicate another",
        m.verify("org.nova.quiet").map(|r| r.is_intact()).unwrap_or(false),
        format!("org.nova.quiet: {}", m.verify("org.nova.quiet").expect("verify quiet")),
    ));

    // --- 3. A deleted file is reported as missing, not modified. -------
    let manifest = m.layout().app_dir("org.nova.reader").join("nova-app.toml");
    let manifest_bytes = fs::read(&manifest).expect("read manifest");
    fs::remove_file(&manifest).expect("delete manifest");
    let report = m.verify("org.nova.reader").expect("verify after deletion");
    checks.push(check(
        "a deleted file is reported as missing, distinctly from modified",
        matches!(&report, IntegrityReport::Damaged { missing, modified }
            if missing.contains(&"nova-app.toml".to_string()) && modified.contains(&"bin/reader".to_string())),
        format!("{report}"),
    ));
    fs::write(&manifest, &manifest_bytes).expect("restore manifest");

    // --- 4. Reinstalling repairs, and verify agrees. -------------------
    m.install("org.nova.reader", &VersionReq::parse("1.0.0").unwrap()).expect("reinstall 1.0.0");
    checks.push(check(
        "reinstalling repairs the damage",
        m.verify("org.nova.reader").map(|r| r.is_intact()).unwrap_or(false),
        format!("{}", m.verify("org.nova.reader").expect("verify")),
    ));

    // --- 5. A bad update, and a rollback that actually restores. --------
    m.update("org.nova.reader").expect("update").expect("an update was available");
    let at_11 = m.db().get("org.nova.reader").map(|p| p.meta.version.clone());
    checks.push(check(
        "the update moved the package to 1.1.0",
        at_11 == Some(Version::new(1, 1, 0)),
        format!("installed version now: {at_11:?}"),
    ));

    // Simulate the update turning out to be bad by damaging what it
    // installed — from the user's point of view, a broken update and a
    // corrupted one need the same recovery.
    let new_binary = m.layout().app_dir("org.nova.reader").join("bin/reader");
    let mut broken = fs::read(&new_binary).expect("read 1.1.0 binary");
    broken.truncate(broken.len() / 2);
    fs::write(&new_binary, &broken).expect("break the update");
    checks.push(check(
        "the broken update is detected before rollback",
        !m.verify("org.nova.reader").expect("verify").is_intact(),
        format!("{}", m.verify("org.nova.reader").expect("verify")),
    ));

    let rolled = m.rollback("org.nova.reader");
    checks.push(check(
        "rollback restores the previous version in one operation",
        matches!(&rolled, Ok(o) if o.version == Version::new(1, 0, 0)),
        match &rolled {
            Ok(o) => format!("now at {} (signature re-verified against key '{}')", o.version, o.key_id),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // The restored files are checked against disk, not against the
    // tool's own claim of success.
    let restored = fs::read(m.layout().app_dir("org.nova.reader").join("bin/reader")).unwrap_or_default();
    checks.push(check(
        "the restored files on disk are byte-for-byte the 1.0.0 files",
        restored == original,
        format!("restored {} bytes; identical to the original 1.0.0 binary: {}", restored.len(), restored == original),
    ));
    checks.push(check(
        "the rolled-back package verifies as intact",
        m.verify("org.nova.reader").map(|r| r.is_intact()).unwrap_or(false),
        format!("{}", m.verify("org.nova.reader").expect("verify")),
    ));

    // --- 6. Rollback is an undo, not a one-way ratchet. ----------------
    let forward = m.rollback("org.nova.reader");
    checks.push(check(
        "rolling back again returns to 1.1.0 rather than looping on 1.0.0",
        matches!(&forward, Ok(o) if o.version == Version::new(1, 1, 0)),
        match &forward {
            Ok(o) => format!("now at {}", o.version),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // --- 7. Rollback with nothing to roll back to says so. -------------
    let nothing = m.rollback("org.nova.quiet");
    checks.push(check(
        "rolling back a package installed only once is a clear error",
        matches!(nothing, Err(PackError::NothingToRollBackTo(_))),
        match &nothing {
            Err(e) => format!("refused: {e}"),
            Ok(o) => format!("ROLLED BACK TO {} FROM NOWHERE", o.version),
        },
    ));

    // --- 8. Rollback goes through verification like any install. -------
    // Corrupt the stored rollback package itself; restoring it must
    // fail rather than install unverified bytes.
    let stored = m.layout().rollback_dir().join("org.nova.reader/1.0.0.npkg");
    if let Ok(mut bytes) = fs::read(&stored) {
        bytes[20] ^= 0xff;
        fs::write(&stored, &bytes).expect("corrupt the stored package");
    }
    let tampered_rollback = m.rollback("org.nova.reader");
    checks.push(check(
        "a tampered rollback package is refused, not installed unverified",
        matches!(tampered_rollback, Err(PackError::Verify(_))),
        match &tampered_rollback {
            Err(e) => format!("refused: {e}"),
            Ok(o) => format!("INSTALLED TAMPERED BYTES AS {}", o.version),
        },
    ));

    // --- 9. Removing a package forgets its rollback copies. ------------
    m.remove("org.nova.quiet").expect("remove quiet");
    checks.push(check(
        "removing a package drops its stored rollback copies",
        m.rollback_versions("org.nova.quiet").is_empty(),
        format!("stored versions after removal: {:?}", m.rollback_versions("org.nova.quiet")),
    ));

    report_all(checks, &root)
}

fn report_all(checks: Vec<Check>, root: &TestRoot) -> ExitCode {
    println!("Checks:");
    let mut failed = 0;
    for c in &checks {
        println!("  [{}] {}", if c.passed { "PASS" } else { "FAIL" }, c.name);
        println!("         {}", c.detail);
        if !c.passed {
            failed += 1;
        }
    }
    println!();
    if failed == 0 {
        println!("Day 48 acceptance: PASS ({} checks)", checks.len());
        println!("Corruption is detected by re-hashing real files; rollback restores real bytes and");
        println!("is itself subject to signature verification.");
        root.cleanup();
        ExitCode::SUCCESS
    } else {
        println!("Day 48 acceptance: FAIL ({failed} of {} checks failed)", checks.len());
        println!("Test root left in place for inspection: {}", root.dir.display());
        ExitCode::FAILURE
    }
}
