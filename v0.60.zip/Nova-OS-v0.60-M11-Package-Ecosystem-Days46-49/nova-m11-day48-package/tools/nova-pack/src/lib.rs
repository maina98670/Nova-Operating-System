//! `nova-pack` — Nova OS's user-facing package manager (M11, Day 46).
//!
//! ## Why this exists next to `nova install`
//! M6's `nova install` (Day 22) is part of the SDK: a developer points
//! it at a `.npkg` they just built and it writes the contents into
//! `/apps`. It is the right tool for that job and it stays. What it is
//! not is a package manager — it keeps no record of what it installed,
//! has no notion of where a package came from, cannot remove anything,
//! and cannot tell you what is on the device.
//!
//! `nova-pack` is the other tool: the one a *user* (or, later, a
//! settings screen, or M15's update system) drives. The split is the
//! same one Debian draws between `dpkg -i` and `apt`, for the same
//! reason — the developer path and the fleet path have different
//! failure modes and should not be the same code path pretending to be
//! both.
//!
//! ## What it will not do
//! `nova-pack` never installs an unsigned or untrusted package. It
//! reuses M10 Day 43's verification unchanged rather than
//! reimplementing it, so this new install path cannot be the soft
//! route around the signature requirement — the exact failure mode the
//! Day 47 Definition of Done names. The `--allow-unsigned` escape
//! hatch that `nova install` carries for build debugging deliberately
//! does *not* exist here.
//!
//! ## Layout on disk
//! Everything is resolved under one root so a test, an image build, and
//! a running device are the same code against different roots.
//!
//! ```text
//! <root>/apps/<id>/nova-app.toml         the installed manifest
//! <root>/apps/<id>/bin/<binary>          the installed executable
//! <root>/var/lib/nova/pack/installed.db  what is installed
//! <root>/var/lib/nova/pack/sources.list  where packages come from
//! <root>/etc/nova/keys/trusted.tsv       M10's package keystore
//! ```

use nova_ipc::Permission;
use nova_pack_deps::{check_removal, plan_install, DepError, Plan, Provider, StepReason};
use nova_pack_integrity::{record_files, verify_files, IntegrityError, IntegrityReport, RollbackStore};
use nova_pack_meta::{
    now_secs, InstalledDb, InstalledPackage, MetaError, PackageMeta, Version, VersionReq,
};
use nova_package_sign::{Keystore, PackageVerifyError};
use nova_seclog::{SecurityEvent, SecurityLog};
use std::fmt;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

// ---------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------

/// Where everything lives, relative to one root.
#[derive(Debug, Clone)]
pub struct Layout {
    root: PathBuf,
}

impl Layout {
    /// A layout rooted at `root`. `Layout::new("/")` is the device.
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Layout { root: root.into() }
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Mirrors `nova_fsmgr::paths::APPS`.
    pub fn apps_dir(&self) -> PathBuf {
        self.root.join("apps")
    }

    pub fn app_dir(&self, id: &str) -> PathBuf {
        self.apps_dir().join(id)
    }

    pub fn state_dir(&self) -> PathBuf {
        self.root.join("var/lib/nova/pack")
    }

    pub fn db_path(&self) -> PathBuf {
        self.state_dir().join("installed.db")
    }

    pub fn sources_path(&self) -> PathBuf {
        self.state_dir().join("sources.list")
    }

    /// Where the previous versions of installed packages are kept, so
    /// a failed update can be undone without a network. M11 Day 48.
    pub fn rollback_dir(&self) -> PathBuf {
        self.state_dir().join("rollback")
    }

    /// Mirrors `nova_fsmgr::paths::CONFIG`; M10 Day 43's keystore.
    pub fn keystore_path(&self) -> PathBuf {
        self.root.join("etc/nova/keys/trusted.tsv")
    }

    pub fn seclog_path(&self) -> PathBuf {
        self.root.join("var/log/nova/security.log")
    }
}

// ---------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------

#[derive(Debug)]
pub enum PackError {
    Io(String),
    Meta(MetaError),
    /// The package failed M10 verification. Carries the original error
    /// so the three distinct cases (unsigned / untrusted key / altered)
    /// stay distinct all the way to the user.
    Verify(PackageVerifyError),
    /// No keystore on this device. Separate from `Verify` because the
    /// fix is different: provision keys, don't re-download the package.
    NoKeystore(PathBuf),
    NotInstalled(String),
    /// Nothing in any configured source provides this package, or
    /// nothing that satisfies the requested version.
    NotFound { id: String, req: VersionReq },
    /// The bytes fetched from a source did not hash to what the source
    /// said they would.
    ChecksumMismatch { id: String, expected: String, actual: String },
    NoSources,
    /// Dependency resolution refused the install or the removal. M11
    /// Day 47.
    Dep(DepError),
    /// The package declares a permission that is not in `nova-ipc`'s
    /// fixed set. M5 validated this at manifest-load time; `nova-pack`
    /// validates it again at install time, because an install path
    /// that skips the check is a way to get an unvalidatable manifest
    /// onto the device.
    UnknownPermission { id: String, name: String },
    /// Integrity checking or the rollback store failed. M11 Day 48.
    Integrity(IntegrityError),
    /// Asked to roll back a package that has no previous version on
    /// this device.
    NothingToRollBackTo(String),
}

impl fmt::Display for PackError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            PackError::Io(e) => write!(f, "{e}"),
            PackError::Meta(e) => write!(f, "{e}"),
            PackError::Verify(e) => write!(f, "{e}"),
            PackError::NoKeystore(p) => write!(
                f,
                "no package keystore at {} — this device cannot verify any package. \
                 Provision one with `nova keygen` on the build machine and install its public half.",
                p.display()
            ),
            PackError::NotInstalled(id) => write!(f, "{id} is not installed"),
            PackError::NotFound { id, req } => {
                write!(f, "no package in any configured source provides {id} {req}")
            }
            PackError::ChecksumMismatch { id, expected, actual } => write!(
                f,
                "{id}: the bytes fetched do not match the checksum the source published \
                 (expected {expected}, got {actual}) — nothing was installed"
            ),
            PackError::NoSources => write!(
                f,
                "no package sources are configured — add one with `nova-pack add-source <dir>`"
            ),
            PackError::Dep(e) => write!(f, "{e}"),
            PackError::Integrity(e) => write!(f, "{e}"),
            PackError::NothingToRollBackTo(id) => write!(
                f,
                "{id} has no previous version on this device — it has only ever been installed once, \
                 or the previous version has been pruned from the rollback store"
            ),
            PackError::UnknownPermission { id, name } => write!(
                f,
                "{id} declares the permission \"{name}\", which is not one of nova-ipc's fixed \
                 permission set. Nothing was installed."
            ),
        }
    }
}

impl std::error::Error for PackError {}

impl From<MetaError> for PackError {
    fn from(e: MetaError) -> Self {
        PackError::Meta(e)
    }
}

impl From<IntegrityError> for PackError {
    fn from(e: IntegrityError) -> Self {
        PackError::Integrity(e)
    }
}

impl From<DepError> for PackError {
    fn from(e: DepError) -> Self {
        PackError::Dep(e)
    }
}

impl From<std::io::Error> for PackError {
    fn from(e: std::io::Error) -> Self {
        PackError::Io(e.to_string())
    }
}

// ---------------------------------------------------------------------
// Sources and repositories
// ---------------------------------------------------------------------

/// One configured package source. Today a local directory; Day 49 gives
/// it a documented index format, and a future networked store would
/// implement the same two operations (list candidates, fetch bytes)
/// over HTTP without the rest of this file changing.
#[derive(Debug, Clone)]
pub struct Source {
    pub location: PathBuf,
}

/// One package available from a source.
#[derive(Debug, Clone)]
pub struct Candidate {
    pub meta: PackageMeta,
    pub path: PathBuf,
}

/// A snapshot of everything the configured sources offer.
pub struct Catalog {
    pub candidates: Vec<Candidate>,
}

impl Catalog {
    pub fn find(&self, id: &str, version: &Version) -> Option<&Candidate> {
        self.candidates.iter().find(|c| c.meta.id == id && c.meta.version == *version)
    }
}

impl Provider for Catalog {
    fn versions(&self, id: &str) -> Vec<PackageMeta> {
        self.candidates.iter().filter(|c| c.meta.id == id).map(|c| c.meta.clone()).collect()
    }
}

impl Source {
    /// Every `.npkg` in the source directory, with metadata derived
    /// from each file's own bytes.
    ///
    /// Day 46 scans the directory. That is genuinely all a local test
    /// repository needs, and it has one honest property a hand-written
    /// index does not: it cannot disagree with reality. Day 49 adds the
    /// documented index format a real store would serve, and keeps this
    /// scan as the fallback for a source with no index.
    pub fn candidates(&self) -> Result<Vec<Candidate>, PackError> {
        let mut out = Vec::new();
        let entries = match fs::read_dir(&self.location) {
            Ok(e) => e,
            Err(e) => return Err(PackError::Io(format!("source {}: {e}", self.location.display()))),
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) != Some("npkg") {
                continue;
            }
            let bytes = fs::read(&path)?;
            match PackageMeta::from_npkg(&bytes) {
                Ok(meta) => out.push(Candidate { meta, path }),
                // A source is allowed to contain junk; it is not
                // allowed to make the whole source unusable. Skipped
                // files are reported by the caller, not silently
                // swallowed here — see `PackManager::scan_problems`.
                Err(_) => continue,
            }
        }
        Ok(out)
    }
}

// ---------------------------------------------------------------------
// Outcomes
// ---------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InstallKind {
    Fresh,
    Upgrade { from: Version },
    Downgrade { from: Version },
    Reinstall,
}

#[derive(Debug, Clone)]
pub struct InstallOutcome {
    pub id: String,
    pub version: Version,
    pub kind: InstallKind,
    pub key_id: String,
    pub files: Vec<String>,
}

// ---------------------------------------------------------------------
// The manager
// ---------------------------------------------------------------------

pub struct PackManager {
    layout: Layout,
    db: InstalledDb,
    keystore: Keystore,
    seclog: Option<SecurityLog>,
    rollback: RollbackStore,
}

impl PackManager {
    /// Opens the database and the device keystore.
    ///
    /// A missing keystore is an error at open time, not at install
    /// time. There is nothing useful `nova-pack` can do on a device
    /// with no trusted keys, and finding that out before a user picks a
    /// package is better than finding it out after.
    pub fn open(layout: Layout) -> Result<PackManager, PackError> {
        let db = InstalledDb::open(layout.db_path())?;
        let keystore_path = layout.keystore_path();
        let keystore = match Keystore::load(&keystore_path) {
            Ok(k) => k,
            Err(_) => return Err(PackError::NoKeystore(keystore_path)),
        };
        if keystore.is_empty() {
            return Err(PackError::NoKeystore(keystore_path));
        }
        let seclog = SecurityLog::open(layout.seclog_path()).ok();
        let rollback = RollbackStore::new(layout.rollback_dir());
        Ok(PackManager { layout, db, keystore, seclog, rollback })
    }

    pub fn layout(&self) -> &Layout {
        &self.layout
    }

    pub fn db(&self) -> &InstalledDb {
        &self.db
    }

    pub fn installed(&self) -> Vec<&InstalledPackage> {
        self.db.all().collect()
    }

    // --- sources ------------------------------------------------------

    pub fn sources(&self) -> Result<Vec<Source>, PackError> {
        let path = self.layout.sources_path();
        if !path.exists() {
            return Ok(Vec::new());
        }
        let text = fs::read_to_string(&path)?;
        Ok(text
            .lines()
            .map(str::trim)
            .filter(|l| !l.is_empty() && !l.starts_with('#'))
            .map(|l| Source { location: PathBuf::from(l) })
            .collect())
    }

    pub fn add_source(&self, location: impl AsRef<Path>) -> Result<(), PackError> {
        let path = self.layout.sources_path();
        fs::create_dir_all(path.parent().unwrap())?;
        let mut text = if path.exists() { fs::read_to_string(&path)? } else { String::new() };
        let line = location.as_ref().display().to_string();
        if text.lines().any(|l| l.trim() == line) {
            return Ok(());
        }
        if !text.is_empty() && !text.ends_with('\n') {
            text.push('\n');
        }
        text.push_str(&line);
        text.push('\n');
        fs::write(&path, text)?;
        Ok(())
    }

    /// Every candidate every configured source offers, read once.
    ///
    /// Resolution asks about a package repeatedly (once per
    /// requirement that mentions it), and re-scanning the sources each
    /// time would be both slow and, worse, inconsistent — a plan built
    /// from a set of candidates that changed halfway through is a plan
    /// that can be internally contradictory. One snapshot, one plan.
    pub fn catalog(&self) -> Result<Catalog, PackError> {
        let sources = self.sources()?;
        if sources.is_empty() {
            return Err(PackError::NoSources);
        }
        let mut candidates = Vec::new();
        for source in sources {
            candidates.extend(source.candidates()?);
        }
        Ok(Catalog { candidates })
    }

    /// The best candidate for `id` matching `req` across every source:
    /// the highest version that satisfies the requirement.
    pub fn best_candidate(&self, id: &str, req: &VersionReq) -> Result<Candidate, PackError> {
        let sources = self.sources()?;
        if sources.is_empty() {
            return Err(PackError::NoSources);
        }
        let mut best: Option<Candidate> = None;
        for source in sources {
            for cand in source.candidates()? {
                if cand.meta.id != id || !req.matches(&cand.meta.version) {
                    continue;
                }
                let better = match &best {
                    None => true,
                    Some(b) => cand.meta.version > b.meta.version,
                };
                if better {
                    best = Some(cand);
                }
            }
        }
        best.ok_or_else(|| PackError::NotFound { id: id.to_string(), req: req.clone() })
    }

    // --- install ------------------------------------------------------

    /// Installs a package from a file on disk.
    ///
    /// Order is the whole point of this function:
    ///
    /// 1. read the bytes,
    /// 2. verify the signature against the device keystore (M10),
    /// 3. derive metadata from the verified bytes,
    /// 4. only then touch `/apps`.
    ///
    /// A package that fails at any step before 4 is one that was never
    /// installed, rather than one that was installed and then cleaned
    /// up. Rejections are written to the security log (M10 Day 44)
    /// before the error is returned, so a device that refuses a package
    /// leaves evidence of having refused it.
    pub fn install_file(&mut self, path: &Path) -> Result<InstallOutcome, PackError> {
        let bytes = fs::read(path).map_err(|e| PackError::Io(format!("{}: {e}", path.display())))?;
        self.install_bytes(&bytes, &path.display().to_string())
    }

    /// Installs package bytes the caller already holds, dependencies
    /// and all.
    pub fn install_bytes(&mut self, bytes: &[u8], origin: &str) -> Result<InstallOutcome, PackError> {
        self.install_file_with_deps(bytes, origin)
    }

    /// M10 verification, with the rejection written to the security
    /// log before the error is returned.
    fn verify_or_reject(
        &mut self,
        bytes: &[u8],
        origin: &str,
    ) -> Result<nova_package_sign::VerifiedPackage, PackError> {
        match nova_package_sign::verify(bytes, &self.keystore) {
            Ok(v) => Ok(v),
            Err(e) => {
                self.record_rejection(origin, &e.to_string());
                Err(PackError::Verify(e))
            }
        }
    }

    /// Day 47: every permission a package declares must be one
    /// `nova-ipc` actually defines.
    ///
    /// M5 already checks this when App Manager loads a manifest. It is
    /// checked again here, at install time, for a reason the Day 47 DoD
    /// states directly: a new install path must not be a way around the
    /// old path's checks. A manifest whose permission names are
    /// meaningless reaches `/apps` only if this install path lets it.
    fn validate_permissions(&mut self, meta: &PackageMeta) -> Result<(), PackError> {
        for name in meta.required_permissions.iter().chain(meta.optional_permissions.iter()) {
            if Permission::from_name(name).is_none() {
                let err = PackError::UnknownPermission { id: meta.id.clone(), name: name.clone() };
                self.record_rejection(&meta.id, &err.to_string());
                return Err(err);
            }
        }
        Ok(())
    }

    /// Verify, validate, write, record — for exactly one package, with
    /// no dependency resolution of its own. Every install path funnels
    /// through here, which is what makes "no path skips verification"
    /// a structural property rather than a promise.
    fn install_verified(&mut self, bytes: &[u8], origin: &str) -> Result<InstallOutcome, PackError> {
        let verified = self.verify_or_reject(bytes, origin)?;

        // Metadata comes from the full signed bytes (so the recorded
        // hash is the hash of the artifact), but only after the
        // signature over them has been checked.
        let meta = PackageMeta::from_npkg(bytes)?;
        self.validate_permissions(&meta)?;
        let key_id = verified.key_id.clone();

        let kind = match self.db.get(&meta.id).map(|p| p.meta.version.clone()) {
            None => InstallKind::Fresh,
            Some(v) if v < meta.version => InstallKind::Upgrade { from: v },
            Some(v) if v > meta.version => InstallKind::Downgrade { from: v },
            Some(_) => InstallKind::Reinstall,
        };
        let previous_version = match &kind {
            InstallKind::Fresh => None,
            InstallKind::Upgrade { from } | InstallKind::Downgrade { from } => Some(from.clone()),
            InstallKind::Reinstall => Some(meta.version.clone()),
        };

        let files = self.write_payload(&meta, &verified.payload)?;

        // Day 48: record what was written, as it was written. The
        // hashes are taken from the files on disk after the write
        // rather than from the bytes in memory, so that a filesystem
        // that mangled or truncated the write is caught by the very
        // first verify rather than blamed on whatever touched the file
        // next.
        let file_records = record_files(&self.layout.app_dir(&meta.id), &files)?;

        // Keep the exact package bytes so this version can be restored
        // later. Stored after a successful write, not before: a
        // rollback store holding a version that never installed
        // successfully is a trap, not a safety net.
        self.rollback.store(&meta.id, &meta.version, bytes)?;

        self.db.insert(InstalledPackage {
            meta: meta.clone(),
            installed_at: now_secs(),
            files: file_records,
            previous_version,
        });
        self.db.save()?;

        Ok(InstallOutcome { id: meta.id, version: meta.version, kind, key_id, files })
    }

    /// Installs by id from the configured sources, with its
    /// dependencies.
    ///
    /// Resolution happens first and completely (Day 47): the plan is
    /// built, checked, and only then executed. An unmet or cyclic
    /// dependency means nothing is written at all — not the target,
    /// not the dependencies that did resolve. The alternative,
    /// installing as far as the graph allows and reporting the rest,
    /// leaves the user holding a device in a state nobody planned.
    pub fn install(&mut self, id: &str, req: &VersionReq) -> Result<InstallOutcome, PackError> {
        let catalog = self.catalog()?;
        let target = self
            .best_candidate_in(&catalog, id, req)
            .ok_or_else(|| PackError::NotFound { id: id.to_string(), req: req.clone() })?
            .meta
            .clone();

        let plan = plan_install(&target, &catalog, self.db())?;
        self.execute(plan, &catalog)
    }

    /// Runs a resolved plan: dependencies first, target last. Returns
    /// the outcome of the requested package.
    fn execute(&mut self, plan: Plan, catalog: &Catalog) -> Result<InstallOutcome, PackError> {
        let mut last: Option<InstallOutcome> = None;
        let mut requested: Option<InstallOutcome> = None;

        for step in &plan.steps {
            let cand = catalog.find(&step.meta.id, &step.meta.version).ok_or_else(|| PackError::NotFound {
                id: step.meta.id.clone(),
                req: VersionReq::Exact(step.meta.version.clone()),
            })?;
            let bytes = fs::read(&cand.path)?;
            let actual = nova_crypto::to_hex(&nova_crypto::sha256(&bytes));
            if actual != cand.meta.sha256 {
                return Err(PackError::ChecksumMismatch {
                    id: cand.meta.id.clone(),
                    expected: cand.meta.sha256.clone(),
                    actual,
                });
            }
            let outcome = self.install_verified(&bytes, &cand.path.display().to_string())?;
            if step.reason == StepReason::Requested {
                requested = Some(outcome.clone());
            }
            last = Some(outcome);
        }

        requested.or(last).ok_or(PackError::NoSources)
    }

    fn best_candidate_in<'c>(&self, catalog: &'c Catalog, id: &str, req: &VersionReq) -> Option<&'c Candidate> {
        catalog
            .candidates
            .iter()
            .filter(|c| c.meta.id == id && req.matches(&c.meta.version))
            .max_by(|a, b| a.meta.version.cmp(&b.meta.version))
    }

    /// Installs one already-selected package file, resolving its
    /// dependencies from the configured sources first.
    ///
    /// This is the path a user takes with a `.npkg` in hand. The
    /// package still gets a dependency check — a sideloaded package
    /// with an unmet dependency is exactly as broken as one from a
    /// source, and the Day 47 DoD's "not bypassable through this new
    /// install path" applies to dependencies as much as to signatures.
    /// Its dependencies do have to come from a source, because a
    /// single file cannot carry them.
    fn install_file_with_deps(&mut self, bytes: &[u8], origin: &str) -> Result<InstallOutcome, PackError> {
        // Verify and validate before resolving anything. Pulling in
        // three dependencies for a package that is about to be
        // rejected would be work done on behalf of a package the
        // device has already decided not to trust.
        let _ = self.verify_or_reject(bytes, origin)?;
        let meta = PackageMeta::from_npkg(bytes)?;
        self.validate_permissions(&meta)?;

        if !meta.depends.is_empty() {
            let catalog = self.catalog()?;
            let plan = plan_install(&meta, &catalog, self.db())?;
            // Everything in the plan except the target itself comes
            // from a source; the target is the file in hand.
            for step in plan.steps.iter().filter(|s| s.reason != StepReason::Requested) {
                let cand = catalog.find(&step.meta.id, &step.meta.version).ok_or_else(|| PackError::NotFound {
                    id: step.meta.id.clone(),
                    req: VersionReq::Exact(step.meta.version.clone()),
                })?;
                let dep_bytes = fs::read(&cand.path)?;
                self.install_verified(&dep_bytes, &cand.path.display().to_string())?;
            }
        }

        self.install_verified(bytes, origin)
    }

    fn write_payload(&self, meta: &PackageMeta, payload: &[u8]) -> Result<Vec<String>, PackError> {
        let (manifest_bytes, binary_bytes) =
            nova_package_format::unpack(payload).map_err(|e| PackError::Meta(MetaError::Format(e.to_string())))?;

        let dir = self.layout.app_dir(&meta.id);
        let bin_dir = dir.join("bin");
        fs::create_dir_all(&bin_dir)?;

        let manifest_rel = "nova-app.toml".to_string();
        fs::write(dir.join(&manifest_rel), &manifest_bytes)?;

        let bin_rel = format!("bin/{}", meta.binary_name());
        let bin_path = dir.join(&bin_rel);
        fs::write(&bin_path, &binary_bytes)?;
        let mut perms = fs::metadata(&bin_path)?.permissions();
        perms.set_mode(0o755);
        fs::set_permissions(&bin_path, perms)?;

        Ok(vec![manifest_rel, bin_rel])
    }

    // --- remove -------------------------------------------------------

    /// Removes an installed package: its files, then its database
    /// record.
    ///
    /// Files first. If the process dies between the two, what is left
    /// is a database claiming something is installed that is not —
    /// which `verify` (Day 48) detects and reports. The other order
    /// would leave files on disk that nothing knows about, which
    /// nothing can ever detect.
    pub fn remove(&mut self, id: &str) -> Result<(), PackError> {
        self.remove_inner(id, false)
    }

    /// Removes even if something installed depends on it. Exists
    /// because "I know, do it anyway" is a real need on a device whose
    /// owner is debugging it — and because the alternative, users
    /// hand-editing `installed.db` to escape a refusal, is worse than
    /// an explicit flag.
    pub fn remove_forced(&mut self, id: &str) -> Result<(), PackError> {
        self.remove_inner(id, true)
    }

    fn remove_inner(&mut self, id: &str, force: bool) -> Result<(), PackError> {
        if self.db.get(id).is_none() {
            return Err(PackError::NotInstalled(id.to_string()));
        }
        if !force {
            check_removal(id, &self.db)?;
        }
        let dir = self.layout.app_dir(id);
        if dir.exists() {
            fs::remove_dir_all(&dir)?;
        }
        self.db.remove(id);
        self.db.save()?;
        // Rollback copies of something the user removed are storage
        // spent on a version they will never restore.
        self.rollback.forget(id)?;
        Ok(())
    }

    // --- integrity and rollback (Day 48) -------------------------------

    /// Re-hashes one installed package's files against what was
    /// recorded at install time.
    pub fn verify(&self, id: &str) -> Result<IntegrityReport, PackError> {
        let pkg = self.db.get(id).ok_or_else(|| PackError::NotInstalled(id.to_string()))?;
        Ok(verify_files(&self.layout.app_dir(id), &pkg.files))
    }

    /// Every installed package, checked. Returned in database order so
    /// two runs on an unchanged device produce identical output —
    /// which is what makes this usable from a script.
    pub fn verify_all(&self) -> Vec<(String, IntegrityReport)> {
        self.db
            .all()
            .map(|pkg| (pkg.meta.id.clone(), verify_files(&self.layout.app_dir(&pkg.meta.id), &pkg.files)))
            .collect()
    }

    /// Which versions of `id` this device could roll back to.
    pub fn rollback_versions(&self, id: &str) -> Vec<Version> {
        self.rollback.versions(id)
    }

    /// Restores the version this package replaced.
    ///
    /// Implemented as a reinstall from the stored `.npkg`, which means
    /// it goes through the same verify-validate-write path as any other
    /// install. A rollback that skipped verification would be a way to
    /// install anything at all by first writing it into the rollback
    /// store.
    pub fn rollback(&mut self, id: &str) -> Result<InstallOutcome, PackError> {
        let pkg = self.db.get(id).ok_or_else(|| PackError::NotInstalled(id.to_string()))?;
        let current = pkg.meta.version.clone();
        let target = pkg
            .previous_version
            .clone()
            .filter(|v| *v != current)
            .or_else(|| self.rollback.versions(id).into_iter().find(|v| *v != current))
            .ok_or_else(|| PackError::NothingToRollBackTo(id.to_string()))?;

        let bytes = self.rollback.load(id, &target)?;
        let outcome = self.install_verified(&bytes, &format!("rollback:{id}@{target}"))?;

        // After rolling back from B to A, the recorded "previous" is B
        // — so a second rollback returns to B rather than looping on A
        // forever. Rollback is an undo, not a one-way ratchet.
        if let Some(entry) = self.db.remove(id) {
            self.db.insert(InstalledPackage { previous_version: Some(current), ..entry });
            self.db.save()?;
        }
        Ok(outcome)
    }

    // --- update -------------------------------------------------------

    /// Installs the newest version any source offers, if it is newer
    /// than what is installed.
    pub fn update(&mut self, id: &str) -> Result<Option<InstallOutcome>, PackError> {
        let current = self
            .db
            .get(id)
            .ok_or_else(|| PackError::NotInstalled(id.to_string()))?
            .meta
            .version
            .clone();
        let cand = self.best_candidate(id, &VersionReq::Any)?;
        if cand.meta.version <= current {
            return Ok(None);
        }
        let bytes = fs::read(&cand.path)?;
        Ok(Some(self.install_bytes(&bytes, &cand.path.display().to_string())?))
    }

    /// Every installed package for which a source offers something
    /// newer.
    pub fn updatable(&self) -> Result<Vec<(String, Version, Version)>, PackError> {
        let mut out = Vec::new();
        for pkg in self.db.all() {
            if let Ok(cand) = self.best_candidate(&pkg.meta.id, &VersionReq::Any) {
                if cand.meta.version > pkg.meta.version {
                    out.push((pkg.meta.id.clone(), pkg.meta.version.clone(), cand.meta.version));
                }
            }
        }
        Ok(out)
    }

    // --- security log -------------------------------------------------

    fn record_rejection(&mut self, origin: &str, detail: &str) {
        if let Some(log) = self.seclog.as_mut() {
            let _ = log.record(SecurityEvent::package_rejected(origin, detail));
        }
    }
}

// ---------------------------------------------------------------------
// Test support
// ---------------------------------------------------------------------

/// Builders for real packages, real keys and a real root directory.
///
/// Shipped in the library rather than copied into each acceptance test
/// so that all four M11 days exercise the same fixtures — a test that
/// builds its own subtly different package is a test that can pass
/// while the product is broken.
///
/// Nothing here is a mock. `package()` produces bytes that
/// `nova_package_format::unpack` parses, `sign()` produces a trailer
/// `nova_package_sign::verify` accepts, and `TestRoot` is a real
/// directory tree.
pub mod fixture {
    use super::*;
    use nova_package_sign::SigningKey;

    /// A real `.npkg` for `id` at `version`, declaring `depends` and
    /// `permissions`.
    pub fn package(id: &str, version: &str, depends: &[&str], permissions: &[&str]) -> Vec<u8> {
        let dep_list: Vec<String> = depends.iter().map(|d| format!("\"{d}\"")).collect();
        let perm_list: Vec<String> = permissions.iter().map(|p| format!("\"{p}\"")).collect();
        let manifest = format!(
            "id = \"{id}\"\n\
             name = \"{id}\"\n\
             version = \"{version}\"\n\
             entry_point = \"bin/{bin}\"\n\
             depends = [{deps}]\n\
             required_permissions = [{perms}]\n",
            bin = id.rsplit('.').next().unwrap_or("app"),
            deps = dep_list.join(", "),
            perms = perm_list.join(", "),
        );
        // A fake but structurally honest binary: the installer writes
        // whatever bytes it is given and marks them executable, so the
        // content only needs to be stable and non-empty.
        let binary = format!("#!/bin/sh\necho {id} {version}\n");
        nova_package_format::pack(manifest.as_bytes(), binary.as_bytes())
    }

    /// A temporary device root, with a keystore trusting one key.
    pub struct TestRoot {
        pub dir: PathBuf,
        pub repo: PathBuf,
        pub key: SigningKey,
    }

    impl TestRoot {
        pub fn new(tag: &str) -> Result<TestRoot, PackError> {
            let dir = std::env::temp_dir().join(format!("nova-m11-{tag}-{}", std::process::id()));
            let _ = fs::remove_dir_all(&dir);
            let repo = dir.join("repo");
            fs::create_dir_all(&repo)?;
            fs::create_dir_all(dir.join("etc/nova/keys"))?;
            fs::create_dir_all(dir.join("var/log/nova"))?;

            let key = SigningKey::new("nova-store-2026", vec![0x5a; 32]);
            let mut keystore = Keystore::new();
            keystore.trust(key.public_half());
            keystore
                .save(&Layout::new(&dir).keystore_path())
                .map_err(|e| PackError::Io(e.to_string()))?;

            Ok(TestRoot { dir, repo, key })
        }

        pub fn layout(&self) -> Layout {
            Layout::new(&self.dir)
        }

        /// Signs `bytes` with a key the device does *not* trust.
        pub fn sign_with_untrusted_key(&self, bytes: &[u8]) -> Vec<u8> {
            let other = SigningKey::new("some-other-vendor", vec![0x11; 32]);
            nova_package_sign::sign(bytes, &other)
        }

        /// Publishes a signed package into the repository directory.
        pub fn publish(&self, id: &str, version: &str, depends: &[&str], permissions: &[&str]) -> Result<PathBuf, PackError> {
            let signed = nova_package_sign::sign(&package(id, version, depends, permissions), &self.key);
            let path = self.repo.join(format!("{id}-{version}.npkg"));
            fs::write(&path, &signed)?;
            Ok(path)
        }

        pub fn cleanup(&self) {
            let _ = fs::remove_dir_all(&self.dir);
        }
    }
}
