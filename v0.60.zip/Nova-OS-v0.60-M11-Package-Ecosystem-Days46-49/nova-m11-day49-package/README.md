# Nova OS — Day 49 Package: repository metadata format, M11 tag (v0.60)

M11 — Package Ecosystem (v0.60, Days 46-49). Continues directly from the
Day 48 package. This is the M11 milestone package.

**Built and tested before being written.** `cargo build --workspace` and
`cargo test --workspace` both exit 0 on this package (154 unit tests), and
all four days' acceptance tests pass. Six defects found compiling the
inherited v0.53 tree are fixed and documented in `docs/M11-RETROFITS.md`.

## M11 Definition of Done

- `nova-pack install/list/remove` work against a local test repository — **Day 46**
- Dependency resolution refuses an unmet dependency before writing anything;
  M5 permissions and M10 signatures enforced through this path — **Day 47**
- Post-install integrity checking detects corruption; rollback restores the
  previous version without manual file surgery — **Day 48**
- A documented, signed repository metadata format works as a `nova-pack`
  source; M11 tagged — **Day 49**

## What's new since Day 45 (v0.53)

- `libs/nova-pack-meta`, `libs/nova-pack-deps`, `libs/nova-pack-integrity`,
  `libs/nova-sign-ed25519`, `libs/nova-pack-repo`
- `tools/nova-pack` — the user-facing package manager (distinct from M6's
  developer-facing `nova install`)
- `tools/nova-m11-day{46,47,48,49}-acceptance-test`
- `docs/M11-PACKAGE-DAY{46,47,48,49}.md`, `docs/M11-RETROFITS.md`,
  `docs/package-format-v1.md`, `docs/M11-TAG.md`

## Run

```bash
./nova-m11-day49-build_and_run.sh
```

## Tag

```bash
git tag -a v0.60 -m "M11: Package Ecosystem (Days 46-49)"
```

See `docs/M11-TAG.md` for the full acceptance summary and what M11
deliberately left open for later milestones (`docs/package-format-v1.md`).
