//! Nova OS M11 Day 49 — the repository metadata format.
//!
//! The Day 49 Definition of Done asks for the format a future store
//! would serve — index, versions, signatures — *without* standing up a
//! public store, per the Roadmap's explicit caution about doing that
//! too early. So this crate defines and implements the format, and
//! `nova-pack` consumes it from a local directory. Serving the same
//! bytes over HTTP later changes how they are fetched and nothing
//! about what they mean.
//!
//! ## The format
//! Two files at the root of a repository:
//!
//! ```text
//! nova-repo.index       the listing
//! nova-repo.index.sig   an Ed25519 signature over the listing's bytes
//! ```
//!
//! The index is the same flat `key: value` record format as the
//! installed-package database, for the same reasons — and one more that
//! matters here: a signed document has to have exactly one byte-level
//! representation, or signing it is meaningless. A format with no
//! ambiguity to normalise away is easier to get that right with than a
//! format whose parsers disagree about whitespace.
//!
//! ```text
//! nova-repo-index: 1
//! repo: nova-test-repo
//! generated_at: 1750000000
//!
//! [package]
//! id: org.nova.notes
//! version: 2.0.0
//! file: org.nova.notes-2.0.0.npkg
//! sha256: 4f3c...
//! size: 2411
//! key_id: nova-store-2026
//! depends: org.nova.textkit >= 1.1.0
//! required_permissions: storage
//! ```
//!
//! One record per *package version*, not per package: a repository
//! offering three versions of one app has three records, which is what
//! makes version selection (and therefore rollback to an older
//! published version) possible at all.
//!
//! ## What the signature covers, and what it is worth
//! The signature is over the exact bytes of `nova-repo.index`. Since
//! each record carries the SHA-256 of its `.npkg`, signing the index
//! transitively covers every package the repository offers.
//!
//! That gives a real chain: the device trusts a repository public key,
//! the index verifies against it, and each package is checked against
//! the hash in the index before installation. What it does **not** give
//! is publisher identity proven by the publisher — the repository
//! asserts who signed what. Per-package Ed25519 signatures are the fix
//! and are listed as an open item with an owning milestone in
//! `docs/package-format-v1.md` rather than implied to be done.
//!
//! ## An unsigned index is not a usable index
//! `load_verified` requires a signature from a trusted key. There is no
//! "warn and continue" path, because a warning on a phone is something
//! nobody sees. A repository directory with no index at all is a
//! different case — `nova-pack` falls back to scanning it, and says so
//! — because a directory of packages the user assembled locally was
//! never claiming to be a published repository.

use nova_pack_meta::{Dependency, PackageMeta, Version};
use nova_sign_ed25519::{RepoKeyring, RepoSigningKey, SignError, ALGORITHM_NAME};
use std::fmt;
use std::fs;
use std::path::{Path, PathBuf};

pub const INDEX_FILE: &str = "nova-repo.index";
pub const SIGNATURE_FILE: &str = "nova-repo.index.sig";
pub const FORMAT_VERSION: u32 = 1;

#[derive(Debug)]
pub enum RepoError {
    Io(String),
    /// The index file is present but unreadable as an index.
    Malformed { path: PathBuf, detail: String },
    /// A format version this build does not understand. Refused rather
    /// than best-effort parsed: a partially understood index is a
    /// listing with silently missing packages.
    UnsupportedVersion(u32),
    /// There is an index but no signature beside it.
    Unsigned(PathBuf),
    Signature(SignError),
    /// The repository has no index at all.
    NoIndex(PathBuf),
}

impl fmt::Display for RepoError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RepoError::Io(e) => write!(f, "{e}"),
            RepoError::Malformed { path, detail } => {
                write!(f, "repository index at {} is malformed: {detail}", path.display())
            }
            RepoError::UnsupportedVersion(v) => write!(
                f,
                "repository index format version {v} is newer than this device understands \
                 (supported: {FORMAT_VERSION}). Update Nova rather than reading it partially."
            ),
            RepoError::Unsigned(p) => write!(
                f,
                "{} has no signature beside it. Nova does not read an unsigned repository index.",
                p.display()
            ),
            RepoError::Signature(e) => write!(f, "repository index signature: {e}"),
            RepoError::NoIndex(p) => write!(f, "no {INDEX_FILE} in {}", p.display()),
        }
    }
}

impl std::error::Error for RepoError {}

impl From<std::io::Error> for RepoError {
    fn from(e: std::io::Error) -> Self {
        RepoError::Io(e.to_string())
    }
}

impl From<SignError> for RepoError {
    fn from(e: SignError) -> Self {
        RepoError::Signature(e)
    }
}

/// One published package version.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RepoEntry {
    pub meta: PackageMeta,
    /// File name relative to the repository root.
    pub file: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RepoIndex {
    pub name: String,
    pub generated_at: u64,
    pub entries: Vec<RepoEntry>,
}

impl RepoIndex {
    /// Builds an index by reading every `.npkg` in `dir`.
    ///
    /// Metadata comes from each package's own bytes, so a published
    /// index cannot disagree with the packages it lists at the moment
    /// it is created. (It can go stale afterwards, which is why
    /// `nova-pack` re-checks the hash of what it actually fetched
    /// rather than trusting the listing.)
    pub fn build(name: impl Into<String>, dir: &Path) -> Result<RepoIndex, RepoError> {
        let mut entries = Vec::new();
        for entry in fs::read_dir(dir)? .flatten() {
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) != Some("npkg") {
                continue;
            }
            let bytes = fs::read(&path)?;
            let Ok(meta) = PackageMeta::from_npkg(&bytes) else {
                // A file that is not a readable package is not listed.
                // Listing it would publish an entry no device could
                // install.
                continue;
            };
            entries.push(RepoEntry {
                meta,
                file: path.file_name().unwrap_or_default().to_string_lossy().to_string(),
            });
        }
        // Sorted, so that rebuilding an unchanged repository produces
        // byte-identical bytes and therefore an unchanged signature.
        entries.sort_by(|a, b| (&a.meta.id, &a.meta.version).cmp(&(&b.meta.id, &b.meta.version)));
        Ok(RepoIndex { name: name.into(), generated_at: nova_pack_meta::now_secs(), entries })
    }

    /// The canonical text of this index. This is what gets signed.
    pub fn to_text(&self) -> String {
        let mut s = String::new();
        s.push_str(&format!("nova-repo-index: {FORMAT_VERSION}\n"));
        s.push_str(&format!("repo: {}\n", self.name));
        s.push_str(&format!("generated_at: {}\n", self.generated_at));
        for e in &self.entries {
            s.push_str("\n[package]\n");
            s.push_str(&format!("id: {}\n", e.meta.id));
            s.push_str(&format!("name: {}\n", e.meta.name));
            s.push_str(&format!("version: {}\n", e.meta.version));
            s.push_str(&format!("file: {}\n", e.file));
            s.push_str(&format!("sha256: {}\n", e.meta.sha256));
            s.push_str(&format!("size: {}\n", e.meta.size));
            if let Some(k) = &e.meta.key_id {
                s.push_str(&format!("key_id: {k}\n"));
            }
            s.push_str(&format!("entry_point: {}\n", e.meta.entry_point));
            if !e.meta.depends.is_empty() {
                let list: Vec<String> = e.meta.depends.iter().map(|d| d.to_string()).collect();
                s.push_str(&format!("depends: {}\n", list.join(", ")));
            }
            if !e.meta.required_permissions.is_empty() {
                s.push_str(&format!("required_permissions: {}\n", e.meta.required_permissions.join(", ")));
            }
            if !e.meta.optional_permissions.is_empty() {
                s.push_str(&format!("optional_permissions: {}\n", e.meta.optional_permissions.join(", ")));
            }
        }
        s
    }

    pub fn parse(text: &str, path: &Path) -> Result<RepoIndex, RepoError> {
        let malformed = |detail: String| RepoError::Malformed { path: path.to_path_buf(), detail };

        let mut blocks = text.split("\n\n");
        let header = blocks.next().unwrap_or("");
        let mut name = String::new();
        let mut generated_at = 0u64;
        let mut saw_version = false;
        for line in header.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let Some((k, v)) = line.split_once(':') else {
                return Err(malformed(format!("header line is not `key: value`: {line}")));
            };
            let v = v.trim();
            match k.trim() {
                "nova-repo-index" => {
                    let version: u32 = v.parse().map_err(|_| malformed(format!("bad format version: {v}")))?;
                    if version != FORMAT_VERSION {
                        return Err(RepoError::UnsupportedVersion(version));
                    }
                    saw_version = true;
                }
                "repo" => name = v.to_string(),
                "generated_at" => generated_at = v.parse().unwrap_or(0),
                _ => {}
            }
        }
        if !saw_version {
            return Err(malformed("missing `nova-repo-index:` header".to_string()));
        }

        let mut entries = Vec::new();
        for block in blocks {
            let block = block.trim();
            if block.is_empty() {
                continue;
            }
            entries.push(parse_entry(block, path)?);
        }
        Ok(RepoIndex { name, generated_at, entries })
    }

    /// Writes `nova-repo.index` and its signature into `dir`.
    pub fn publish(&self, dir: &Path, key: &RepoSigningKey) -> Result<(), RepoError> {
        let text = self.to_text();
        fs::write(dir.join(INDEX_FILE), text.as_bytes())?;
        let sig = key.sign(text.as_bytes());
        let sig_text = format!(
            "nova-repo-sig: {FORMAT_VERSION}\nkey_id: {}\nalgorithm: {ALGORITHM_NAME}\nsignature: {sig}\n",
            key.key_id
        );
        fs::write(dir.join(SIGNATURE_FILE), sig_text.as_bytes())?;
        Ok(())
    }

    /// Reads and verifies a repository's index.
    ///
    /// Verification is not optional and there is no warn-and-continue
    /// path. A warning on a phone is something nobody sees.
    pub fn load_verified(dir: &Path, keyring: &RepoKeyring) -> Result<RepoIndex, RepoError> {
        let index_path = dir.join(INDEX_FILE);
        if !index_path.is_file() {
            return Err(RepoError::NoIndex(dir.to_path_buf()));
        }
        let sig_path = dir.join(SIGNATURE_FILE);
        if !sig_path.is_file() {
            return Err(RepoError::Unsigned(index_path));
        }

        let bytes = fs::read(&index_path)?;
        let sig_text = fs::read_to_string(&sig_path)?;
        let (key_id, algorithm, signature) = parse_signature(&sig_text, &sig_path)?;

        if algorithm != ALGORITHM_NAME {
            return Err(RepoError::Malformed {
                path: sig_path,
                detail: format!("unsupported signature algorithm '{algorithm}' (expected {ALGORITHM_NAME})"),
            });
        }
        keyring.verify(&key_id, &bytes, &signature)?;

        RepoIndex::parse(&String::from_utf8_lossy(&bytes), &index_path)
    }

    pub fn versions_of(&self, id: &str) -> Vec<&RepoEntry> {
        self.entries.iter().filter(|e| e.meta.id == id).collect()
    }
}

fn parse_signature(text: &str, path: &Path) -> Result<(String, String, String), RepoError> {
    let mut key_id = None;
    let mut algorithm = None;
    let mut signature = None;
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((k, v)) = line.split_once(':') else { continue };
        match k.trim() {
            "key_id" => key_id = Some(v.trim().to_string()),
            "algorithm" => algorithm = Some(v.trim().to_string()),
            "signature" => signature = Some(v.trim().to_string()),
            _ => {}
        }
    }
    match (key_id, algorithm, signature) {
        (Some(k), Some(a), Some(s)) => Ok((k, a, s)),
        _ => Err(RepoError::Malformed {
            path: path.to_path_buf(),
            detail: "signature file needs key_id, algorithm and signature".to_string(),
        }),
    }
}

fn parse_entry(block: &str, path: &Path) -> Result<RepoEntry, RepoError> {
    let malformed = |detail: String| RepoError::Malformed { path: path.to_path_buf(), detail };

    let mut id = None;
    let mut name = String::new();
    let mut version = None;
    let mut file = None;
    let mut sha256 = String::new();
    let mut size = 0u64;
    let mut key_id = None;
    let mut entry_point = String::new();
    let mut depends = Vec::new();
    let mut required_permissions = Vec::new();
    let mut optional_permissions = Vec::new();

    for line in block.lines() {
        let line = line.trim();
        if line.is_empty() || line == "[package]" || line.starts_with('#') {
            continue;
        }
        let Some((k, v)) = line.split_once(':') else {
            return Err(malformed(format!("entry line is not `key: value`: {line}")));
        };
        let v = v.trim();
        match k.trim() {
            "id" => id = Some(v.to_string()),
            "name" => name = v.to_string(),
            "version" => {
                version = Some(Version::parse(v).map_err(|e| malformed(e.to_string()))?)
            }
            "file" => file = Some(v.to_string()),
            "sha256" => sha256 = v.to_string(),
            "size" => size = v.parse().unwrap_or(0),
            "key_id" => key_id = Some(v.to_string()),
            "entry_point" => entry_point = v.to_string(),
            "depends" => {
                for part in v.split(',').filter(|p| !p.trim().is_empty()) {
                    depends.push(Dependency::parse(part).map_err(|e| malformed(e.to_string()))?);
                }
            }
            "required_permissions" => {
                required_permissions = v.split(',').map(|p| p.trim().to_string()).filter(|p| !p.is_empty()).collect()
            }
            "optional_permissions" => {
                optional_permissions = v.split(',').map(|p| p.trim().to_string()).filter(|p| !p.is_empty()).collect()
            }
            _ => {}
        }
    }

    let id = id.ok_or_else(|| malformed("entry has no id".to_string()))?;
    let version = version.ok_or_else(|| malformed(format!("entry for {id} has no version")))?;
    let file = file.ok_or_else(|| malformed(format!("entry for {id} has no file")))?;

    Ok(RepoEntry {
        meta: PackageMeta {
            id,
            name,
            version,
            entry_point,
            depends,
            required_permissions,
            optional_permissions,
            sha256,
            size,
            key_id,
        },
        file,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use nova_package_sign::SigningKey;

    fn temp_dir(tag: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("nova-pack-repo-{tag}-{}", std::process::id()));
        let _ = fs::remove_dir_all(&d);
        fs::create_dir_all(&d).unwrap();
        d
    }

    fn publish_package(dir: &Path, id: &str, version: &str) {
        let manifest = format!(
            "id = \"{id}\"\nname = \"{id}\"\nversion = \"{version}\"\nentry_point = \"bin/x\"\nrequired_permissions = [\"storage\"]\n"
        );
        let pkg = nova_package_format::pack(manifest.as_bytes(), b"binary");
        let signed = nova_package_sign::sign(&pkg, &SigningKey::new("pub-key", vec![1u8; 32]));
        fs::write(dir.join(format!("{id}-{version}.npkg")), signed).unwrap();
    }

    #[test]
    fn an_index_round_trips_through_text() {
        let dir = temp_dir("roundtrip");
        publish_package(&dir, "org.nova.a", "1.0.0");
        publish_package(&dir, "org.nova.a", "1.1.0");
        publish_package(&dir, "org.nova.b", "0.2.0");

        let index = RepoIndex::build("test-repo", &dir).unwrap();
        assert_eq!(index.entries.len(), 3);

        let parsed = RepoIndex::parse(&index.to_text(), Path::new("x")).unwrap();
        assert_eq!(parsed, index);
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn one_record_per_version_not_per_package() {
        let dir = temp_dir("versions");
        publish_package(&dir, "org.nova.a", "1.0.0");
        publish_package(&dir, "org.nova.a", "2.0.0");
        let index = RepoIndex::build("r", &dir).unwrap();
        assert_eq!(index.versions_of("org.nova.a").len(), 2);
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn rebuilding_an_unchanged_repository_produces_identical_records() {
        let dir = temp_dir("stable");
        publish_package(&dir, "org.nova.b", "1.0.0");
        publish_package(&dir, "org.nova.a", "1.0.0");
        let one = RepoIndex::build("r", &dir).unwrap();
        let two = RepoIndex::build("r", &dir).unwrap();
        // generated_at is a clock reading and may differ; everything
        // that gets signed alongside it must not.
        assert_eq!(one.entries, two.entries);
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn a_signed_index_verifies_and_a_tampered_one_does_not() {
        let dir = temp_dir("signed");
        publish_package(&dir, "org.nova.a", "1.0.0");
        let key = RepoSigningKey::from_seed("nova-repo-2026", [42u8; 32]);
        let mut keyring = RepoKeyring::new();
        keyring.trust(key.public());

        RepoIndex::build("r", &dir).unwrap().publish(&dir, &key).unwrap();
        assert!(RepoIndex::load_verified(&dir, &keyring).is_ok());

        // Change one character of the signed document.
        let index_path = dir.join(INDEX_FILE);
        let text = fs::read_to_string(&index_path).unwrap().replace("1.0.0", "9.9.9");
        fs::write(&index_path, text).unwrap();

        let err = RepoIndex::load_verified(&dir, &keyring).unwrap_err();
        assert!(matches!(err, RepoError::Signature(_)), "{err}");
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn an_index_signed_by_an_untrusted_key_is_refused() {
        let dir = temp_dir("untrusted");
        publish_package(&dir, "org.nova.a", "1.0.0");
        let impostor = RepoSigningKey::from_seed("someone-else", [7u8; 32]);
        RepoIndex::build("r", &dir).unwrap().publish(&dir, &impostor).unwrap();

        let mut keyring = RepoKeyring::new();
        keyring.trust(RepoSigningKey::from_seed("nova-repo-2026", [42u8; 32]).public());

        let err = RepoIndex::load_verified(&dir, &keyring).unwrap_err();
        assert!(matches!(err, RepoError::Signature(SignError::UntrustedKey(_))), "{err}");
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn an_index_with_no_signature_beside_it_is_refused() {
        let dir = temp_dir("nosig");
        publish_package(&dir, "org.nova.a", "1.0.0");
        let index = RepoIndex::build("r", &dir).unwrap();
        fs::write(dir.join(INDEX_FILE), index.to_text()).unwrap();

        let err = RepoIndex::load_verified(&dir, &RepoKeyring::new()).unwrap_err();
        assert!(matches!(err, RepoError::Unsigned(_)), "{err}");
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn a_newer_format_version_is_refused_rather_than_partially_read() {
        let text = "nova-repo-index: 99\nrepo: future\n";
        let err = RepoIndex::parse(text, Path::new("x")).unwrap_err();
        assert!(matches!(err, RepoError::UnsupportedVersion(99)), "{err}");
    }

    #[test]
    fn a_file_that_is_not_a_package_is_not_listed() {
        let dir = temp_dir("junk");
        publish_package(&dir, "org.nova.a", "1.0.0");
        fs::write(dir.join("garbage.npkg"), b"not a package at all").unwrap();
        let index = RepoIndex::build("r", &dir).unwrap();
        assert_eq!(index.entries.len(), 1);
        fs::remove_dir_all(&dir).unwrap();
    }
}
