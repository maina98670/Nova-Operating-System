//! Nova OS M11 Day 49 — Ed25519 signatures, for repository metadata.
//!
//! ## Why this crate exists at all
//! M10 Day 43 signs packages with HMAC-SHA256 and says plainly what
//! that costs: a symmetric signature proves *integrity and key
//! possession*, not publisher identity to a third party. Every device
//! that can verify such a signature can also forge one, because it
//! holds the same secret. M10's own release notes name the consequence:
//! "M11's repository needs asymmetric signatures and cannot ship
//! without them."
//!
//! A repository index is exactly the artifact that breaks under a
//! symmetric scheme. The whole point of an index is that many devices
//! read it and one party produces it. Giving every reader the ability
//! to produce a valid one makes the signature decorative.
//!
//! ## Why this is a dependency and not hand-rolled
//! `nova-crypto` is deliberately dependency-free: SHA-256 and
//! HMAC-SHA256 are small, completely specified, and checkable against
//! published test vectors line by line. Ed25519 is not in that
//! category. It needs field arithmetic modulo 2^255 - 19, Edwards curve
//! point operations, scalar reduction and SHA-512, and the ways to get
//! it subtly and catastrophically wrong — non-constant-time field
//! operations, missing small-order point checks, malleable signature
//! acceptance — do not announce themselves by failing a test vector.
//!
//! So this is the one place Nova takes an outside cryptographic
//! implementation: `ed25519-dalek`, pinned. Writing our own here would
//! not be principled minimalism, it would be the most consequential
//! code in the system written by whoever had the afternoon.
//!
//! The version is pinned exactly rather than floated, because a
//! cryptographic dependency silently changing under a device image is
//! not something to find out about later.
//!
//! ## Scope, stated plainly
//! This signs and verifies **repository metadata**. Package signatures
//! remain M10's HMAC scheme in v0.60. The trust chain this gives is:
//! device trusts a repository public key -> index signature verifies ->
//! index names a SHA-256 for each package -> the package that arrives
//! is checked against that hash. That is a real chain and it is
//! genuinely third-party verifiable at the index level, but it means
//! publisher identity is asserted *by the repository*, not proven by
//! the publisher. Per-package Ed25519 signatures are named as an open
//! item in `docs/package-format-v1.md` with M15 owning them.

use ed25519_dalek::{Signature, Signer, SigningKey as DalekSigningKey, Verifier, VerifyingKey};
use std::collections::BTreeMap;
use std::fmt;
use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};

pub const ALGORITHM_NAME: &str = "ed25519";
pub const SEED_LEN: usize = 32;
pub const PUBLIC_LEN: usize = 32;
pub const SIGNATURE_LEN: usize = 64;

#[derive(Debug)]
pub enum SignError {
    Io(String),
    /// A key file or hex string was not a valid key.
    BadKey(String),
    /// A signature was the wrong length or not valid hex.
    BadSignature(String),
    /// The signature did not verify against the key.
    VerificationFailed { key_id: String },
    /// The signature names a key this device does not trust.
    UntrustedKey(String),
}

impl fmt::Display for SignError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SignError::Io(e) => write!(f, "{e}"),
            SignError::BadKey(d) => write!(f, "not a valid Ed25519 key: {d}"),
            SignError::BadSignature(d) => write!(f, "not a valid Ed25519 signature: {d}"),
            SignError::VerificationFailed { key_id } => write!(
                f,
                "signature does not verify against key '{key_id}' — the signed data has been \
                 altered, or it was signed by a different key"
            ),
            SignError::UntrustedKey(k) => {
                write!(f, "signed by key '{k}', which is not in this device's repository keyring")
            }
        }
    }
}

impl std::error::Error for SignError {}

fn to_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

fn from_hex(s: &str) -> Option<Vec<u8>> {
    let s = s.trim();
    if s.len() % 2 != 0 {
        return None;
    }
    (0..s.len()).step_by(2).map(|i| u8::from_str_radix(&s[i..i + 2], 16).ok()).collect()
}

/// A repository's private signing key. Lives on whatever machine
/// publishes the repository — never on a device.
pub struct RepoSigningKey {
    pub key_id: String,
    inner: DalekSigningKey,
}

impl fmt::Debug for RepoSigningKey {
    /// The seed is deliberately absent. A key that ends up in a log
    /// because someone debug-printed a struct is a mundane and very
    /// common way to lose one — the same reasoning M10's `SigningKey`
    /// applies to its own secret.
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "RepoSigningKey {{ key_id: {:?}, seed: <32 bytes redacted> }}", self.key_id)
    }
}

impl RepoSigningKey {
    pub fn from_seed(key_id: impl Into<String>, seed: [u8; SEED_LEN]) -> Self {
        RepoSigningKey { key_id: key_id.into(), inner: DalekSigningKey::from_bytes(&seed) }
    }

    /// 32 bytes from `/dev/urandom`, read directly — the same source
    /// and the same reasoning as M10's `SigningKey::generate`: this is
    /// the one place Nova needs randomness outside the kernel's own
    /// use of it, and the file interface is the same interface
    /// `getrandom(2)` is a faster path to.
    pub fn generate(key_id: impl Into<String>) -> Result<Self, SignError> {
        let mut seed = [0u8; SEED_LEN];
        let mut f = fs::File::open("/dev/urandom").map_err(|e| SignError::Io(e.to_string()))?;
        f.read_exact(&mut seed).map_err(|e| SignError::Io(e.to_string()))?;
        Ok(RepoSigningKey::from_seed(key_id, seed))
    }

    pub fn from_hex(key_id: impl Into<String>, hex: &str) -> Result<Self, SignError> {
        let bytes = from_hex(hex).ok_or_else(|| SignError::BadKey("not hex".into()))?;
        let seed: [u8; SEED_LEN] = bytes
            .try_into()
            .map_err(|_| SignError::BadKey(format!("expected {SEED_LEN} bytes of seed")))?;
        Ok(RepoSigningKey::from_seed(key_id, seed))
    }

    pub fn seed_hex(&self) -> String {
        to_hex(&self.inner.to_bytes())
    }

    pub fn public(&self) -> RepoPublicKey {
        RepoPublicKey { key_id: self.key_id.clone(), bytes: self.inner.verifying_key().to_bytes() }
    }

    pub fn sign(&self, message: &[u8]) -> String {
        to_hex(&self.inner.sign(message).to_bytes())
    }

    /// Writes the private key to a file, owner-read-only.
    pub fn save(&self, path: &Path) -> Result<(), SignError> {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| SignError::Io(e.to_string()))?;
        }
        fs::write(path, format!("{}\t{}\n", self.key_id, self.seed_hex()))
            .map_err(|e| SignError::Io(e.to_string()))?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o600));
        }
        Ok(())
    }

    pub fn load(path: &Path) -> Result<Self, SignError> {
        let text = fs::read_to_string(path).map_err(|e| SignError::Io(e.to_string()))?;
        let line = text.lines().find(|l| !l.trim().is_empty()).ok_or_else(|| SignError::BadKey("empty key file".into()))?;
        let (key_id, hex) = line.split_once('\t').ok_or_else(|| SignError::BadKey("expected `key_id<TAB>seed_hex`".into()))?;
        RepoSigningKey::from_hex(key_id, hex)
    }
}

/// The public half — this is what ships on a device.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RepoPublicKey {
    pub key_id: String,
    bytes: [u8; PUBLIC_LEN],
}

impl RepoPublicKey {
    pub fn from_hex(key_id: impl Into<String>, hex: &str) -> Result<Self, SignError> {
        let raw = from_hex(hex).ok_or_else(|| SignError::BadKey("not hex".into()))?;
        let bytes: [u8; PUBLIC_LEN] = raw
            .try_into()
            .map_err(|_| SignError::BadKey(format!("expected {PUBLIC_LEN} bytes of public key")))?;
        Ok(RepoPublicKey { key_id: key_id.into(), bytes })
    }

    pub fn hex(&self) -> String {
        to_hex(&self.bytes)
    }

    pub fn verify(&self, message: &[u8], signature_hex: &str) -> Result<(), SignError> {
        let raw = from_hex(signature_hex).ok_or_else(|| SignError::BadSignature("not hex".into()))?;
        let sig_bytes: [u8; SIGNATURE_LEN] = raw
            .try_into()
            .map_err(|_| SignError::BadSignature(format!("expected {SIGNATURE_LEN} bytes")))?;
        let verifying = VerifyingKey::from_bytes(&self.bytes).map_err(|e| SignError::BadKey(e.to_string()))?;
        verifying
            .verify(message, &Signature::from_bytes(&sig_bytes))
            .map_err(|_| SignError::VerificationFailed { key_id: self.key_id.clone() })
    }
}

/// The device's set of trusted repository keys.
///
/// A separate keyring from M10's package keystore, deliberately. They
/// answer different questions ("who may publish an index this device
/// reads" vs "who may sign a package this device installs"), they are
/// provisioned at different times, and merging them would mean adding a
/// repository implied trusting its operator to sign packages directly.
#[derive(Debug, Clone, Default)]
pub struct RepoKeyring {
    keys: BTreeMap<String, RepoPublicKey>,
}

impl RepoKeyring {
    pub fn new() -> Self {
        RepoKeyring::default()
    }

    pub fn trust(&mut self, key: RepoPublicKey) {
        self.keys.insert(key.key_id.clone(), key);
    }

    pub fn key_ids(&self) -> Vec<String> {
        self.keys.keys().cloned().collect()
    }

    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }

    pub fn get(&self, key_id: &str) -> Option<&RepoPublicKey> {
        self.keys.get(key_id)
    }

    /// Verifies `signature_hex` over `message`, refusing an unknown key
    /// before any comparison happens.
    pub fn verify(&self, key_id: &str, message: &[u8], signature_hex: &str) -> Result<(), SignError> {
        let key = self.get(key_id).ok_or_else(|| SignError::UntrustedKey(key_id.to_string()))?;
        key.verify(message, signature_hex)
    }

    pub fn load(path: &Path) -> Result<Self, SignError> {
        let mut keyring = RepoKeyring::new();
        if !path.exists() {
            return Ok(keyring);
        }
        let text = fs::read_to_string(path).map_err(|e| SignError::Io(e.to_string()))?;
        for line in text.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let (key_id, hex) =
                line.split_once('\t').ok_or_else(|| SignError::BadKey(format!("expected `key_id<TAB>hex`: {line}")))?;
            keyring.trust(RepoPublicKey::from_hex(key_id, hex)?);
        }
        Ok(keyring)
    }

    pub fn save(&self, path: &Path) -> Result<(), SignError> {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| SignError::Io(e.to_string()))?;
        }
        let mut out = String::from("# Nova OS trusted repository keys (M11). key_id<TAB>ed25519_public_hex\n");
        for key in self.keys.values() {
            out.push_str(&format!("{}\t{}\n", key.key_id, key.hex()));
        }
        fs::write(path, out).map_err(|e| SignError::Io(e.to_string()))
    }
}

/// Default location of the repository keyring under a root.
pub fn default_keyring_path(root: &Path) -> PathBuf {
    root.join("etc/nova/keys/repo-trusted.tsv")
}

#[cfg(test)]
mod tests {
    use super::*;

    /// RFC 8032 section 7.1, test vector 1 (empty message).
    #[test]
    fn rfc8032_test_vector_1() {
        let seed = from_hex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60").unwrap();
        let key = RepoSigningKey::from_hex("rfc8032-1", &to_hex(&seed)).unwrap();
        assert_eq!(key.public().hex(), "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a");
        assert_eq!(
            key.sign(b""),
            "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b"
        );
        assert!(key.public().verify(b"", &key.sign(b"")).is_ok());
    }

    /// RFC 8032 section 7.1, test vector 2 (one-byte message).
    #[test]
    fn rfc8032_test_vector_2() {
        let key =
            RepoSigningKey::from_hex("rfc8032-2", "4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb").unwrap();
        assert_eq!(key.public().hex(), "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c");
        assert_eq!(
            key.sign(&[0x72]),
            "92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00"
        );
    }

    #[test]
    fn a_generated_key_signs_and_verifies() {
        let key = RepoSigningKey::generate("nova-repo-test").expect("/dev/urandom is readable");
        let sig = key.sign(b"nova repository index");
        assert!(key.public().verify(b"nova repository index", &sig).is_ok());
    }

    #[test]
    fn an_altered_message_does_not_verify() {
        let key = RepoSigningKey::from_seed("k", [3u8; 32]);
        let sig = key.sign(b"index v1");
        let err = key.public().verify(b"index v2", &sig).unwrap_err();
        assert!(matches!(err, SignError::VerificationFailed { .. }), "{err}");
    }

    #[test]
    fn another_key_cannot_produce_a_verifying_signature() {
        let real = RepoSigningKey::from_seed("real", [1u8; 32]);
        let impostor = RepoSigningKey::from_seed("impostor", [2u8; 32]);
        let sig = impostor.sign(b"index");
        assert!(real.public().verify(b"index", &sig).is_err());
    }

    #[test]
    fn the_public_half_cannot_sign() {
        // Structural, not a runtime check: RepoPublicKey has no sign
        // method. This test documents the property so that adding one
        // later requires deleting this comment on purpose.
        let key = RepoSigningKey::from_seed("k", [4u8; 32]);
        let public = key.public();
        assert_eq!(public.hex().len(), 64);
    }

    #[test]
    fn a_truncated_signature_is_rejected_as_malformed_not_as_a_mismatch() {
        let key = RepoSigningKey::from_seed("k", [5u8; 32]);
        let sig = key.sign(b"x");
        let err = key.public().verify(b"x", &sig[..40]).unwrap_err();
        assert!(matches!(err, SignError::BadSignature(_)), "{err}");
    }

    #[test]
    fn the_keyring_round_trips_through_a_file() {
        let dir = std::env::temp_dir().join(format!("nova-sign-ed25519-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        let path = dir.join("repo-trusted.tsv");

        let a = RepoSigningKey::from_seed("repo-a", [7u8; 32]);
        let b = RepoSigningKey::from_seed("repo-b", [8u8; 32]);
        let mut keyring = RepoKeyring::new();
        keyring.trust(a.public());
        keyring.trust(b.public());
        keyring.save(&path).unwrap();

        let loaded = RepoKeyring::load(&path).unwrap();
        assert_eq!(loaded.key_ids(), vec!["repo-a".to_string(), "repo-b".to_string()]);
        assert!(loaded.verify("repo-a", b"msg", &a.sign(b"msg")).is_ok());
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn an_unknown_key_is_refused_before_any_comparison() {
        let keyring = RepoKeyring::new();
        let err = keyring.verify("nobody", b"msg", &"00".repeat(64)).unwrap_err();
        assert!(matches!(err, SignError::UntrustedKey(_)), "{err}");
    }

    #[test]
    fn a_missing_keyring_file_is_an_empty_keyring_not_an_error() {
        // An empty keyring refuses everything, which is the correct
        // failure mode. An error here would instead mean a device with
        // no repositories configured could not run the tool at all.
        let keyring = RepoKeyring::load(Path::new("/nonexistent/repo-trusted.tsv")).unwrap();
        assert!(keyring.is_empty());
    }

    #[test]
    fn a_signing_key_file_round_trips() {
        let dir = std::env::temp_dir().join(format!("nova-sign-ed25519-key-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        let path = dir.join("repo.key");
        let key = RepoSigningKey::from_seed("repo-x", [9u8; 32]);
        key.save(&path).unwrap();
        let loaded = RepoSigningKey::load(&path).unwrap();
        assert_eq!(loaded.key_id, "repo-x");
        assert_eq!(loaded.public(), key.public());
        let _ = fs::remove_dir_all(&dir);
    }
}
