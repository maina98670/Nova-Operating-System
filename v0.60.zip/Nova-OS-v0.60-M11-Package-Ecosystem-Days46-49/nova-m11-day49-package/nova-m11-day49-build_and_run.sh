#!/usr/bin/env bash
set -euo pipefail

echo "=== Nova OS Day 49 / M11 tag (Package Ecosystem): build ==="
cargo build --workspace

echo
echo "=== Nova OS: unit tests (workspace) ==="
cargo test --workspace

echo
echo "=== nova-m11-day46-acceptance-test ==="
cargo run -p nova-m11-day46-acceptance-test

echo
echo "=== nova-m11-day47-acceptance-test ==="
cargo run -p nova-m11-day47-acceptance-test

echo
echo "=== nova-m11-day48-acceptance-test ==="
cargo run -p nova-m11-day48-acceptance-test

echo
echo "=== nova-m11-day49-acceptance-test (M11 milestone check) ==="
cargo run -p nova-m11-day49-acceptance-test

echo
echo "M11 (Days 46-49) build + tests + acceptance completed. Tag with:"
echo '  git tag -a v0.60 -m "M11: Package Ecosystem (Days 46-49)"'
