#!/usr/bin/env python3
"""Nova OS v0.67 pre-hardware integration API.

This is a Linux-hosted graphical integration milestone, NOT an ARM64 kernel,
Wayland compositor, or a replacement for Nova's Rust system services.
No third-party Python packages are required.
"""
from __future__ import annotations

import argparse
import base64
import hmac
import json
import mimetypes
import os
import platform
import subprocess
import re
import secrets
import shutil
import socket
import stat
import sys
import threading
import time
import urllib.parse
import webbrowser
import tempfile
from importlib.util import spec_from_file_location, module_from_spec
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
_platform_spec = spec_from_file_location('nova_platform_services', str(HERE.parent / 'integration' / 'platform_services.py'))
_platform_module = module_from_spec(_platform_spec)
_platform_spec.loader.exec_module(_platform_module)
_connect_spec = spec_from_file_location('nova_connectivity', str(HERE.parent / 'integration' / 'connectivity.py'))
_connect_module = module_from_spec(_connect_spec)
_connect_spec.loader.exec_module(_connect_module)
Connectivity = _connect_module.Connectivity
_device_spec = spec_from_file_location('nova_device_prefs', str(HERE.parent / 'integration' / 'device_preferences.py'))
_device_module = module_from_spec(_device_spec)
_device_spec.loader.exec_module(_device_module)
DEVICE_DEFAULTS = _device_module.DEFAULT_DEVICE
validate_device_preferences = _device_module.validate_preferences
configure_pin = _device_module.configure_pin
verify_pin = _device_module.verify_pin
PIN_GUARD = _device_module.PinGuard()
PackageStore = _platform_module.PackageStore
system_diagnostics = _platform_module.system_diagnostics
make_backup = _platform_module.make_backup
list_backups = _platform_module.list_backups
restore_backup = _platform_module.restore_backup
STATIC = HERE / 'static'
DATA = Path(os.environ.get('NOVA_CONFIG_DIR', '~/.config/nova-os')).expanduser().resolve()
ROOT = Path(os.environ.get('NOVA_FILES_ROOT', '~/NovaFiles')).expanduser().resolve()
os.environ.setdefault('NOVA_MOBILE_DATA', str(DATA / 'mobile.sqlite3'))
DEFAULT_SETTINGS = {'theme': 'dark', 'wallpaper': 'aurora', 'accent': 'blue', 'clock24': True, 'name': 'Nova User'}
MAX_BODY = 8 * 1024 * 1024
TOKEN = secrets.token_urlsafe(32)
BRIDGE = Path(os.environ.get('NOVA_BRIDGE_BIN', str(HERE.parent / 'native-bridge' / 'target' / 'release' / 'nova-graphics-bridge'))).expanduser().resolve()
CORE_ROOT = DATA / 'rust-core'

def bridge_available():
    return BRIDGE.is_file() and os.access(BRIDGE, os.X_OK)

def bridge_call(cmd, **payload):
    if not bridge_available():
        raise ValueError('Native Nova Rust bridge not built; run ./build-native.sh')
    env = {**os.environ, 'NOVA_CORE_ROOT': str(CORE_ROOT), 'NOVA_FILES_ROOT': str(ROOT)}
    try:
        result = subprocess.run([str(BRIDGE)], input=json.dumps({'cmd': cmd, **payload}) + '\n',
                                capture_output=True, text=True, encoding='utf-8', timeout=5, env=env)
    except (OSError, subprocess.TimeoutExpired) as e:
        raise ValueError('Native Nova core unavailable: ' + str(e)) from e
    try: obj = json.loads(result.stdout)
    except (ValueError, TypeError): raise ValueError('Native Nova core returned invalid JSON')
    if result.returncode != 0 or not obj.get('ok'):
        raise ValueError(str(obj.get('error','Native Rust bridge failed')))
    return obj['result']

def native_contacts():
    return [{'id': str(c['id']), 'name': c['name'],
             'phone': (c.get('phone_numbers') or [''])[0], 'favorite': c.get('favorite', False)}
            for c in bridge_call('contacts_list')]

LOCK = threading.RLock()

def atomic_json(path: Path, data):
    """Crash-resistant JSON update: private temp file, fsync, atomic replacement."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            os.fchmod(f.fileno(), 0o600)
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        if hasattr(os, 'O_DIRECTORY'):
            dir_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try: os.fsync(dir_fd)
            finally: os.close(dir_fd)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def read_json(filename, default):
    try:
        result = json.loads((DATA / filename).read_text('utf-8'))
        return result if isinstance(result, type(default)) else default
    except (OSError, ValueError):
        return default.copy() if hasattr(default, 'copy') else default

# The modern browser portal shares the app database format with native Qt apps.
sys.path.insert(0, str(HERE.parent / 'native-shell'))
sys.path.insert(0, str(HERE.parent / 'integration'))
from mobile_store import AppData
from modern_portal import Portal
from android_compat import AndroidBridge
from platform_readiness import report as platform_readiness_report
from platform_quality import performance_snapshot, runtime_acceptance
PORTAL = Portal(DATA, AppData, atomic_json)
ANDROID = AndroidBridge(DATA)

def confined(raw: str) -> Path:
    if not isinstance(raw, str) or '\x00' in raw:
        raise ValueError('Invalid file path')
    path = (ROOT / raw).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError('Path is outside Nova Files')
    return path

def relative(path: Path) -> str:
    return path.relative_to(ROOT).as_posix() if path != ROOT else ''

def valid_name(name):
    if not isinstance(name, str) or not name or name in ('.', '..') or '/' in name or '\\' in name or '\x00' in name or len(name) > 150:
        raise ValueError('Invalid filename')
    return name

def file_entry(path: Path):
    info = path.stat()
    return {'name': path.name, 'path': relative(path), 'dir': path.is_dir(), 'bytes': info.st_size if path.is_file() else None, 'modified': int(info.st_mtime), 'ext': path.suffix.lower()}

def list_folder(raw):
    path = confined(raw)
    if not path.is_dir():
        raise ValueError('Folder does not exist')
    result = []
    for child in path.iterdir():
        if child.is_symlink():
            continue
        try: result.append(file_entry(child))
        except OSError: pass
    result.sort(key=lambda e: (not e['dir'], e['name'].lower()))
    return {'path': relative(path), 'items': result, 'root': ROOT.name}

def net_status():
    root = Path('/sys/class/net')
    try:
        devices = [p for p in root.iterdir() if p.name != 'lo']
        linked = [p.name for p in devices if (p / 'operstate').read_text().strip() == 'up']
        wifi = [p.name for p in devices if (p / 'wireless').exists()]
        return {'connected': bool(linked), 'interfaces': linked, 'wifi_available': bool(wifi), 'wifi_connected': any(n in linked for n in wifi)}
    except OSError:
        return {'connected': None, 'interfaces': [], 'wifi_available': None, 'wifi_connected': None}

def battery_status():
    power = Path('/sys/class/power_supply')
    try:
        for node in power.iterdir():
            if (node / 'type').read_text().strip().lower() == 'battery':
                cap = (node / 'capacity').read_text().strip()
                state = (node / 'status').read_text().strip()
                return {'percent': int(cap), 'state': state}
    except (OSError, ValueError):
        pass
    return {'percent': None, 'state': 'unavailable'}

def system_status():
    mem = None
    try:
        text = Path('/proc/meminfo').read_text()
        match = re.search(r'^MemTotal:\s+(\d+)', text, re.M)
        if match: mem = int(match.group(1)) // 1024
    except OSError: pass
    return {'os': platform.system(), 'arch': platform.machine(), 'hostname': socket.gethostname(), 'memory_mb': mem, 'network': net_status(), 'battery': battery_status(), 'mode': 'Linux-hosted graphical shell + optional native Nova cores', 'version': '0.67-integration-foundation', 'native_core': bridge_available()}

def integration_status():
    import importlib.util
    catalog = HERE.parent / 'integration' / 'runtime.py'
    spec = importlib.util.spec_from_file_location('nova_runtime_catalog', str(catalog))
    if not spec or not spec.loader:
        raise RuntimeError('Nova component catalog unavailable')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = module.snapshot()
    result['native_bridge_connected'] = bridge_available()
    result['graphical_server_active'] = True
    return result

def health_snapshot():
    """Observable health, not proof of GPU output or complete Android functionality."""
    bridge_ok = False
    bridge_error = None
    if bridge_available():
        try:
            bridge_call('health')
            bridge_ok = True
        except (ValueError, KeyError, OSError) as exc:
            bridge_error = str(exc)
    gui_file = Path(os.environ.get('NOVA_GUI_READY_FILE', str(DATA / 'gui-ready.json')))
    gui_active = False
    gui_dom_verified = False
    gui_phase = 'unavailable'
    gui_app_tiles = 0
    try:
        state = json.loads(gui_file.read_text())
        gui_active = (state.get('status') == 'event-loop-active'
                      and 0 <= time.time() - float(state.get('timestamp', 0)) <= 20)
        tile_count=state.get('app_tile_count',0)
        gui_dom_verified = (gui_active and state.get('dom_verified') is True
                            and state.get('ui_phase') in ('login','home')
                            and type(tile_count) is int and tile_count >= 8)
        if gui_dom_verified:
            gui_phase = state.get('ui_phase','unknown')
            gui_app_tiles = int(state.get('app_tile_count',0))
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    strict = os.environ.get('NOVA_REQUIRE_RUST_BRIDGE') == '1'
    return {'release': '0.67-integration-foundation',
            'backend_ready': True,
            'original_rust_bridge_healthy': bridge_ok,
            'bridge_error': bridge_error,
            'rust_bridge_required': strict,
            'gui_event_loop_active': gui_active,
            'gui_dom_verified': gui_dom_verified,
            'gui_phase': gui_phase,
            'gui_app_tile_count': gui_app_tiles,
            'gui_event_loop_note': 'Qt heartbeat; does not independently verify displayed pixels',
            'ready': bool(not strict or bridge_ok)}

class Server(BaseHTTPRequestHandler):
    server_version = 'NovaShell/0.67' 
    def log_message(self, fmt, *args):
        print('[nova] ' + fmt % args, flush=True)

    def headers_common(self, code, mime='application/json; charset=utf-8', length=None):
        self.send_response(code)
        self.send_header('Content-Type', mime)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if os.environ.get('NOVA_COLAB_MODE') != '1':
            self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'none'")
        if length is not None: self.send_header('Content-Length', str(length))
        self.end_headers()

    def response(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.headers_common(code, length=len(data))
        self.wfile.write(data)

    def error_json(self, msg, code=400):
        self.response({'error': str(msg)}, code)

    def send_asset(self, path, mime):
        content = path.read_bytes()
        if path.name in ('index.html','modern.html'):
            content = content.replace(b'__NOVA_SESSION_TOKEN__', TOKEN.encode('ascii'))
        self.headers_common(200, mime, len(content))
        self.wfile.write(content)

    def enforce_account(self, path: str):
        """Optional complete API gate for integrated local runtime.

        The original preview has unauthenticated legacy endpoints. With
        NOVA_ENFORCE_AUTH=1, all private /api endpoints require a portal
        session, not just /api/mobile and /api/android.
        This does NOT grant OS-level isolation or encrypt underlying data.
        """
        if os.environ.get('NOVA_ENFORCE_AUTH') != '1':
            return
        public = {'/api/account/status', '/api/health'}
        if path.startswith('/api/') and path not in public:
            PORTAL.require(self.headers.get('X-Nova-Web-Session',''))

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        q = urllib.parse.parse_qs(parsed.query)
        get = lambda key, default='': q.get(key, [default])[0]
        try:
            self.enforce_account(parsed.path)
            if parsed.path == '/api/maintenance':
                PORTAL.require(self.headers.get('X-Nova-Web-Session',''))
                tools_root=HERE.parent/'maintenance'
                result={'scope':'Local development tools; physical device acceptance is separate',
                        'tools':{name:(tools_root/(name+'.py')).is_file() for name in
                                 ('hardware','power','updates','recovery','stability','watchdog','release')},
                        'gui_actions':'Read-only status; use local CLI for maintenance operations'}
                if (tools_root/'power.py').is_file():
                    sys.path.insert(0,str(HERE.parent))
                    from maintenance.power import status as power_status
                    result['power']=power_status()
                return self.response(result)
            if parsed.path in ('/', '/index.html', '/modern'):
                return self.send_asset(STATIC / 'modern.html', 'text/html; charset=utf-8')
            if parsed.path in ('/legacy', '/legacy.html'):
                return self.send_asset(STATIC / 'index.html', 'text/html; charset=utf-8')
            if parsed.path in ('/modern.js', '/modern.css'):
                name = parsed.path.lstrip('/')
                return self.send_asset(STATIC / name, 'text/javascript; charset=utf-8' if name.endswith('.js') else 'text/css; charset=utf-8')
            if parsed.path in ('/api/android/status', '/api/android/staged', '/api/android/apps', '/api/platform/readiness'):
                try: PORTAL.require(self.headers.get('X-Nova-Web-Session',''))
                except PermissionError as e: return self.error_json(str(e),403)
                if parsed.path == '/api/android/status':return self.response(ANDROID.status())
                if parsed.path == '/api/android/staged':return self.response(ANDROID.list_staged())
                if parsed.path == '/api/android/apps':
                    try:return self.response(ANDROID.packages())
                    except (RuntimeError,PermissionError) as e:return self.error_json(str(e),503)
                smoke = HERE.parent / 'vm' / 'out' / 'smoke-result.json'
                try: booted = bool(json.loads(smoke.read_text()).get('smoke_passed'))
                except (OSError,ValueError):booted=False
                return self.response(platform_readiness_report(ANDROID.status(),bridge_available(),booted))
            if parsed.path == '/api/account/status':
                return self.response(PORTAL.status(self.headers.get('X-Nova-Web-Session','')))
            if parsed.path.startswith('/api/mobile/list/'):
                namespace = parsed.path[len('/api/mobile/list/'):]
                try:return self.response(PORTAL.list_records(self.headers.get('X-Nova-Web-Session',''),namespace))
                except PermissionError as e:return self.error_json(str(e),403)
            if parsed.path == '/api/mobile/play':
                try:PORTAL.require(self.headers.get('X-Nova-Web-Session',''))
                except PermissionError as e:return self.error_json(str(e),403)
                path = confined(get('path'))
                formats = {'.mp3':'audio/mpeg','.wav':'audio/wav','.ogg':'audio/ogg',
                           '.m4a':'audio/mp4','.mp4':'video/mp4','.webm':'video/webm'}
                if not path.is_file() or path.suffix.lower() not in formats:
                    return self.error_json('Unsupported media file',404)
                if path.stat().st_size > 50*1024*1024:return self.error_json('Media exceeds 50 MB limit',413)
                return self.send_media(path.read_bytes(),formats[path.suffix.lower()])
            if parsed.path in ('/app.js', '/style.css'):
                name = parsed.path.lstrip('/')
                return self.send_asset(STATIC / name, 'text/javascript; charset=utf-8' if name.endswith('.js') else 'text/css; charset=utf-8')
            if parsed.path == '/api/platform/performance':
                return self.response(performance_snapshot(DATA, ROOT))
            if parsed.path == '/api/platform/acceptance':
                return self.response(runtime_acceptance(health_snapshot(), ANDROID.status(), performance_snapshot(DATA, ROOT)))
            if parsed.path == '/api/system': return self.response(system_status())
            if parsed.path == '/api/connectivity': return self.response(Connectivity().status())
            if parsed.path == '/api/device':
                system=system_status()
                return self.response({'battery':system['battery'],
                    'preferences':read_json('device-preferences.json',DEVICE_DEFAULTS),
                    'storage':system_diagnostics(ROOT),
                    'controls_are_hardware_backed':False,
                    'note':'Brightness, volume, timeout are preferences; hardware controls not connected.'})
            if parsed.path == '/api/lock/status':
                return self.response({'pin_configured': bool(read_json('lock.json',{}).get('digest')),
                    'kind':'UI session lock; not OS authentication or app sandboxing'})
            if parsed.path == '/api/health':
                health = health_snapshot()
                return self.response(health, 200 if health['ready'] else 503)
            if parsed.path == '/api/integration': return self.response(integration_status())
            if parsed.path == '/api/core/status':
                status = {'connected': bridge_available(), 'mode': 'native Rust core via local JSON process' if bridge_available() else 'Python preview fallback', 'cores': ['Settings', 'Contacts', 'Files CRUD', 'Messages (read-only)'] if bridge_available() else []}
                if bridge_available(): status['health'] = bridge_call('health')
                return self.response(status)
            if parsed.path == '/api/core/settings':
                return self.response(bridge_call('settings_list'))
            if parsed.path == '/api/core/messages':
                return self.response(bridge_call('messages_threads'))
            if parsed.path == '/api/settings': return self.response(read_json('settings.json', DEFAULT_SETTINGS))
            if parsed.path == '/api/files': return self.response(list_folder(get('path')))
            if parsed.path == '/api/file':
                path = confined(get('path'))
                if not path.is_file(): return self.error_json('File not found', 404)
                if path.stat().st_size > 1024 * 1024: return self.error_json('Text preview limited to 1 MB', 413)
                if bridge_available():
                    content = bridge_call('file_read', path=relative(path))['content']
                else:
                    try: content = path.read_text('utf-8')
                    except UnicodeDecodeError: return self.error_json('Not a UTF-8 text file', 415)
                return self.response({'path': relative(path), 'content': content})
            if parsed.path == '/api/download':
                path = confined(get('path'))
                if not path.is_file(): return self.error_json('File not found', 404)
                if path.stat().st_size > 20 * 1024 * 1024: return self.error_json('Download limited to 20 MB', 413)
                content = path.read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', 'attachment; filename*=UTF-8\'\'' + urllib.parse.quote(path.name))
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Content-Length', str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            if parsed.path == '/api/media':
                path = confined(get('path'))
                if not path.is_file() or path.suffix.lower() not in {'.png','.jpg','.jpeg','.gif','.webp'}: return self.error_json('Unsupported media file', 404)
                if path.stat().st_size > 10 * 1024 * 1024: return self.error_json('Image too large', 413)
                content = path.read_bytes()
                return self.send_media(content, mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
            if parsed.path == '/api/gallery':
                images = []
                for base, dirs, names in os.walk(ROOT, followlinks=False):
                    dirs[:] = [d for d in dirs if not (Path(base) / d).is_symlink()]
                    for name in names:
                        p = Path(base) / name
                        if p.is_symlink() or p.suffix.lower() not in {'.png','.jpg','.jpeg','.gif','.webp'}: continue
                        images.append({'name': p.name, 'path': relative(p)})
                        if len(images) >= 120: break
                    if len(images) >= 120: break
                return self.response({'images': images})
            if parsed.path == '/api/notes': return self.response(read_json('notes.json', []))
            if parsed.path == '/api/contacts': return self.response(native_contacts() if bridge_available() else read_json('contacts.json', []))
            if parsed.path == '/api/messages': return self.response(read_json('messages.json', []))
            if parsed.path == '/api/notifications': return self.response(read_json('notifications.json', []))
            if parsed.path == '/api/platform/diagnostics':
                return self.response(system_diagnostics(ROOT))
            if parsed.path == '/api/packages':
                return self.response(PackageStore(DATA).list())
            if parsed.path == '/api/backups':
                return self.response(list_backups(DATA))
            if parsed.path == '/api/inventory':
                source = HERE.parent / 'source-v0.60' / 'apps'
                apps = sorted(p.name for p in source.iterdir() if p.is_dir()) if source.is_dir() else []
                return self.response({'rust_source_apps': apps, 'status': 'Settings/Contacts/Messages core bridge active' if bridge_available() else 'Native bridge not built; Python fallback used', 'bridge_connected': bridge_available()})
            return self.error_json('Not found', 404)
        except PermissionError as exc:
            return self.error_json(str(exc), 403)
        except (ValueError, OSError) as exc:
            return self.error_json(str(exc))

    def send_media(self, content, mime):
        self.headers_common(200, mime, len(content))
        self.wfile.write(content)

    def do_POST(self):
        if not hmac.compare_digest(self.headers.get('X-Nova-Token', ''), TOKEN):
            return self.error_json('Invalid session token', 403)
        origin = self.headers.get('Origin')
        if origin:
            expected = 'http://' + self.headers.get('Host', '')
            if origin != expected and os.environ.get('NOVA_COLAB_MODE') != '1':
                return self.error_json('Invalid origin', 403)
        try:
            n = int(self.headers.get('Content-Length','0'))
            if n <= 0 or n > MAX_BODY: return self.error_json('Invalid request size', 413)
            payload = json.loads(self.rfile.read(n))
            if not isinstance(payload, dict): raise ValueError('Expected JSON object')
            if self.path not in ('/api/account/create', '/api/account/login'):
                self.enforce_account(self.path)
            with LOCK: result = self.mutate(self.path, payload)
            self.response(result)
        except PermissionError as exc:
            self.error_json(str(exc),403)
        except (ValueError, OSError, UnicodeError, KeyError, TypeError) as exc:
            self.error_json(str(exc))

    def mutate(self, url, p):
        session=self.headers.get('X-Nova-Web-Session','')
        if url == '/api/account/create': return PORTAL.create(p)
        if url == '/api/account/login': return PORTAL.login(p)
        if url == '/api/account/logout': return PORTAL.logout(session)
        if url.startswith('/api/android/'):
            PORTAL.require(session)
            if url == '/api/android/upload/start':return ANDROID.begin(p.get('name'),p.get('bytes'),p.get('sha256'))
            if url == '/api/android/upload/chunk':return ANDROID.append(p.get('id'),p.get('offset'),p.get('base64'))
            if url == '/api/android/upload/finish':return ANDROID.finish(p.get('id'))
            # Executing Android programs requires an explicit runtime opt-in and
            # loopback API access. The Colab preview cannot execute Waydroid.
            if self.client_address[0] not in ('127.0.0.1','::1'):
                raise PermissionError('Android execution requires direct localhost access')
            if url == '/api/android/install':return ANDROID.install(p.get('id'))
            if url == '/api/android/launch':return ANDROID.launch(p.get('package'))
            if url == '/api/android/remove':return ANDROID.remove(p.get('package'))
            raise ValueError('Unknown Android action')
        if url == '/api/mobile/save':return PORTAL.save_record(session,p)
        if url == '/api/mobile/delete':return PORTAL.delete_record(session,p)
        if url == '/api/mobile/diagnostics':return PORTAL.diagnostics(session,p.get('command',''),system_status)
        if url == '/api/device/preferences':
            prefs=validate_device_preferences(p,read_json('device-preferences.json',DEVICE_DEFAULTS))
            atomic_json(DATA/'device-preferences.json',prefs)
            return prefs
        if url == '/api/lock/setup':
            existing=read_json('lock.json',{})
            if existing.get('digest') and not PIN_GUARD.check(p.get('current_pin',''),existing):
                raise ValueError('Current PIN incorrect')
            record=configure_pin(p.get('pin'))
            atomic_json(DATA/'lock.json',record)
            return {'pin_configured':True,'note':'UI session lock only; APIs remain locally accessible'}
        if url == '/api/lock/verify':
            existing=read_json('lock.json',{})
            if not existing.get('digest'):raise ValueError('No PIN configured')
            if not PIN_GUARD.check(p.get('pin',''),existing):
                raise ValueError('Incorrect PIN')
            return {'unlocked':True}
        if url.startswith('/api/connectivity/'):
            parts=url.strip('/').split('/')
            if len(parts)!=4:raise ValueError('Unknown connectivity operation')
            return Connectivity().operate(parts[2],parts[3],p)
        if url == '/api/packages/install':
            return PackageStore(DATA).install_base64(p.get('base64'))
        if url == '/api/packages/uninstall':
            return PackageStore(DATA).uninstall(p.get('id'))
        if url == '/api/backups/create':
            return make_backup(DATA, ROOT)
        if url == '/api/backups/recover':
            return restore_backup(DATA, ROOT, p.get('name'))
        if url.startswith('/api/notifications/'):
            items = read_json('notifications.json', [])
            if url == '/api/notifications/post':
                title = str(p.get('title','')).strip()[:100]
                body = str(p.get('body','')).strip()[:500]
                if not title: raise ValueError('Notification title required')
                items.append({'id':secrets.token_hex(8), 'title':title, 'body':body,
                              'created':int(time.time()), 'read':False, 'local_only':True})
                items = items[-100:]
            elif url == '/api/notifications/read':
                for item in items:
                    if item.get('id') == p.get('id'):
                        item['read']=True
            elif url == '/api/notifications/clear':
                items=[]
            else:
                raise ValueError('Unsupported notification operation')
            atomic_json(DATA / 'notifications.json', items)
            return items
        if url == '/api/core/settings':
            key = p.get('key')
            if key not in {'display_brightness','ringer_volume','language','wifi_enabled','do_not_disturb','text_scale'}:
                raise ValueError('Unsupported Nova core setting')
            return bridge_call('settings_set', key=key, value=p.get('value'))
        if url == '/api/contacts/save' and bridge_available():
            if p.get('delete'):
                bridge_call('contacts_remove', id=int(p['id']))
            elif p.get('id'):
                bridge_call('contacts_update', id=int(p['id']), name=str(p.get('name','')), phone=str(p.get('phone','')))
            else:
                bridge_call('contacts_add', name=str(p.get('name','')), phone=str(p.get('phone','')))
            return native_contacts()
        if url == '/api/settings':
            s = read_json('settings.json', DEFAULT_SETTINGS)
            allowed = {'theme': ('dark', 'light'), 'wallpaper': ('aurora','sunset','forest','midnight'), 'accent': ('blue','violet','teal','pink')}
            for k, vals in allowed.items():
                if k in p:
                    if p[k] not in vals: raise ValueError('Invalid '+k)
                    s[k] = p[k]
            if 'clock24' in p:
                if not isinstance(p['clock24'], bool): raise ValueError('Invalid clock format')
                s['clock24'] = p['clock24']
            if 'name' in p:
                name = str(p['name']).strip()[:50]
                if not name: raise ValueError('Name cannot be empty')
                s['name'] = name
            atomic_json(DATA / 'settings.json', s)
            return s
        if url == '/api/files/create':
            parent = confined(p.get('path',''))
            if not parent.is_dir(): raise ValueError('Parent directory not found')
            target = confined(relative(parent / valid_name(p['name'])))
            if target.exists(): raise ValueError('Item already exists')
            if p.get('dir', False): target.mkdir()
            else:
                content = str(p.get('content',''))[:1024*1024]
                if bridge_available(): bridge_call('file_create', path=relative(target), content=content)
                else: target.write_text(content, encoding='utf-8')
            return {'created': relative(target)}
        if url == '/api/files/save':
            path = confined(p['path'])
            if not path.is_file() or path.is_symlink(): raise ValueError('File not found')
            if path.suffix.lower() not in {'.txt','.md','.json','.log','.csv','.py','.rs','.toml','.c','.h','.sh','.html','.css','.js'}: raise ValueError('Only text files can be edited')
            text = p.get('content')
            if not isinstance(text, str) or len(text.encode('utf-8')) > 1024 * 1024: raise ValueError('Text file exceeds 1 MB')
            if bridge_available(): bridge_call('file_write', path=relative(path), content=text)
            else: path.write_text(text, encoding='utf-8')
            return {'saved': relative(path)}
        if url == '/api/files/rename':
            src = confined(p['path'])
            if src == ROOT or not src.exists(): raise ValueError('Item not found')
            dest = confined(relative(src.parent / valid_name(p['name'])))
            if dest.exists(): raise ValueError('Destination exists')
            if bridge_available() and src.is_file(): bridge_call('file_rename', path=relative(src), dest=relative(dest))
            else: src.rename(dest)
            return {'renamed': relative(dest)}
        if url == '/api/files/trash':
            src = confined(p['path'])
            if src == ROOT or not src.exists(): raise ValueError('Item not found')
            trash = DATA / 'trash'
            trash.mkdir(parents=True, exist_ok=True)
            dest = trash / (str(int(time.time()*1000)) + '-' + secrets.token_hex(4) + '-' + src.name)
            shutil.move(str(src), str(dest))
            return {'moved_to_trash': src.name}
        if url == '/api/files/upload':
            parent = confined(p.get('path',''))
            if not parent.is_dir(): raise ValueError('Parent directory not found')
            dest = confined(relative(parent / valid_name(p['name'])))
            if dest.exists(): raise ValueError('Item already exists')
            data = base64.b64decode(p['base64'], validate=True)
            if len(data) > 5 * 1024 * 1024: raise ValueError('Upload limited to 5 MB')
            dest.write_bytes(data)
            return {'uploaded': relative(dest)}
        if url in ('/api/notes/save','/api/contacts/save','/api/messages/save'):
            kind = url.split('/')[2]
            key = {'notes':'notes.json','contacts':'contacts.json','messages':'messages.json'}[kind]
            items = read_json(key, [])
            if p.get('delete'):
                items = [i for i in items if i.get('id') != p.get('id')]
            elif kind == 'notes':
                title = str(p.get('title','')).strip()[:100]
                content = str(p.get('content',''))[:15000]
                if not title: raise ValueError('Note title required')
                obj = {'id': str(p.get('id') or secrets.token_hex(8)), 'title': title, 'content': content, 'updated': int(time.time())}
                items = [i for i in items if i.get('id') != obj['id']] + [obj]
            elif kind == 'contacts':
                name = str(p.get('name','')).strip()[:100]
                phone = str(p.get('phone','')).strip()[:50]
                if not name: raise ValueError('Contact name required')
                obj = {'id': str(p.get('id') or secrets.token_hex(8)), 'name': name, 'phone': phone}
                items = [i for i in items if i.get('id') != obj['id']] + [obj]
            elif kind == 'messages':
                recipient = str(p.get('recipient','')).strip()[:100]
                body = str(p.get('body','')).strip()[:2000]
                if not recipient or not body: raise ValueError('Recipient and message required')
                items.append({'id': secrets.token_hex(8), 'recipient': recipient, 'body': body, 'created': int(time.time()), 'local_only': True})
            atomic_json(DATA / key, items)
            return items
        raise ValueError('Unsupported operation')

def main():
    parser = argparse.ArgumentParser(description='Nova OS v0.67 refined runtime backend')
    parser.add_argument('--port', type=int, default=8767)
    parser.add_argument('--host', choices=['127.0.0.1','0.0.0.0'], default='127.0.0.1', help='0.0.0.0 only inside a private QEMU guest')
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535: parser.error('Port must be 1024–65535')
    DATA.mkdir(parents=True, exist_ok=True)
    ROOT.mkdir(parents=True, exist_ok=True)
    if os.environ.get('NOVA_REQUIRE_RUST_BRIDGE') == '1':
        # Prevent a release build silently booting the fallback core.
        bridge_call('health')
    # Create an example file without overwriting an existing one.
    if not any(ROOT.iterdir()):
        (ROOT / 'Welcome to Nova.txt').write_text('Welcome to Nova OS v0.67!\n\nFiles here are real files in ~/NovaFiles.\nYour original v0.60 Rust source code is preserved separately.\n', encoding='utf-8')
    address = (args.host, args.port)
    server = ThreadingHTTPServer(address, Server)
    url = f'http://127.0.0.1:{args.port}'
    print('\nNova OS v0.67 — UNIFIED DESKTOP DEVELOPMENT BUILD', flush=True)
    print('Native Rust cores:', 'CONNECTED' if bridge_available() else 'not compiled (Python preview mode)', flush=True)
    print('Open: ' + url, flush=True)
    print('Files: ' + str(ROOT), flush=True)
    print('Settings: ' + str(DATA), flush=True)
    print('This is not an independently booted OS or a Wayland compositor.\n', flush=True)
    if not args.no_browser: threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__ == '__main__': main()
