"""Nova v0.67 performance observations and release-gate evidence.

All metrics are sourced from the current Linux host/guest, NOT a phone.
Performance goals are engineering targets, not a claim of achievement.
"""
from __future__ import annotations
import os
import time
import shutil
from pathlib import Path


def _meminfo():
    result = {}
    try:
        for line in Path('/proc/meminfo').read_text().splitlines():
            k, _, v = line.partition(':')
            if k in ('MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'):
                result[k.lower() + '_mb'] = int(v.strip().split()[0]) // 1024
    except (OSError, ValueError, IndexError):
        pass
    return result


def _self_rss_mb():
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):
                return int(line.split()[1]) / 1024
    except (OSError, ValueError, IndexError):
        pass
    return None


def _cgroup_limit_mb():
    for path in ('/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory/memory.limit_in_bytes'):
        try:
            raw = Path(path).read_text().strip()
            if raw == 'max': return None
            value = int(raw)
            if value >= 1 << 60: return None
            return value // 1048576
        except (OSError, ValueError):
            continue
    return None


def performance_snapshot(config, files):
    config, files = Path(config), Path(files)
    mem = _meminfo()
    try: free = shutil.disk_usage(files).free // (1024 * 1024)
    except OSError: free = None
    try: load = [round(x, 2) for x in os.getloadavg()]
    except OSError: load = None
    return {
        'observed_at_unix': int(time.time()),
        'host_or_guest': 'Linux process observation, not a measured phone benchmark',
        'ram': mem,
        'cgroup_memory_limit_mb': _cgroup_limit_mb(),
        'nova_backend_rss_mb': _self_rss_mb(),
        'storage_free_mb': free,
        'load_average': load,
        'targets': {'minimum_ram_mb': 1024, 'idle_ram_target_mb': 350,
                    'boot_seconds_target': 20, 'ui_fps_target': 60},
        'targets_measured': False,
        'warning': 'Qt/WebEngine, systemd and other guest processes are not included in backend RSS.',
    }


def runtime_acceptance(health, android, perf):
    bridge = bool(health.get('original_rust_bridge_healthy'))
    gui = bool(health.get('gui_event_loop_active'))
    android_ok = bool(android.get('execution_available'))
    return {
        'release': 'Nova OS v0.67',
        'ready_for_phone_hardware': False,
        'source_tests_are_not_boot_tests': True,
        'observations': {
            'backend_service': bool(health.get('backend_ready')),
            'rust_bridge': bridge,
            'qt_event_loop_heartbeat': gui,
            'android_container_running': android_ok,
            'memory_observed': perf.get('nova_backend_rss_mb') is not None,
        },
        'manual_gates': {
            'qemu_arm64_graphical_boot': 'unverified',
            'actual_video_and_audio': 'unverified',
            'real_signed_native_app_install': 'not implemented',
            'android_apk_install_launch_uninstall': 'unverified',
            'per_app_security_isolation': 'not implemented',
            'low_memory_1gb_and_2gb': 'unverified',
            'repeated_reboot_and_restore': 'unverified',
        },
        'note': 'Waydroid may be available on a supported Linux host; it is not bundled in Nova.',
    }
