#!/usr/bin/env python3
"""Print the guide's exact version sequence and the current acceptance blockers."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from integration.boot_evidence import load_report, validate_boot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--require-next-milestone', action='store_true')
    args = parser.parse_args()
    guide = json.loads((ROOT / 'docs/guide-milestones.json').read_text())
    blockers = validate_boot(ROOT, load_report(ROOT / 'vm/out/smoke-result.json'))
    print(json.dumps({
        'release': guide['current_integration_version'],
        'next_guide_version': guide['next_named_milestone'],
        'next_milestone': 'M13 Hardware Integration',
        'version_sequence': [m['version'] for m in guide['milestones']],
        'arm64_smoke_verified': not blockers,
        'boot_blockers': blockers,
        'guide_advancement_blockers': guide['advancement_blockers'],
        'can_advance': False,
        'note': 'Source tests and emulator results cannot certify physical phone acceptance.'
    }, indent=2))
    # Until real guide milestone acceptance is implemented and independently run,
    # no local report or flag can promote the public version.
    return 2 if args.require_next_milestone else 0


if __name__ == '__main__':
    raise SystemExit(main())
