#!/usr/bin/env python3
"""Boot ARM64 QEMU and verify running Nova services, API, and Qt event-loop heartbeat.

Requires fully-built vm/out disk and kernel + locally installed QEMU. VNC remains
on loopback (5901). This is an execution test, NOT visual pixel verification.
"""
import argparse
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from integration.boot_evidence import artifact_fingerprint, source_fingerprint
API='http://127.0.0.1:8767'
TOKEN = re.compile(r'<meta\s+name="nova-token"\s+content="([^"]+)"')


def fetch(path, data=None, token=None, session=None, timeout=3):
    headers={}
    if session:
        headers['X-Nova-Web-Session']=session
    if data is not None:
        data=json.dumps(data).encode('utf-8')
        headers.update({'Content-Type':'application/json','X-Nova-Token':token or ''})
    with urllib.request.urlopen(urllib.request.Request(API+path,data=data,headers=headers),timeout=timeout) as resp:
        return resp.read()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--timeout',type=int,default=420,help='Seconds to wait for ARM64 software emulation')
    parser.add_argument('--m2',action='store_true',help='Exercise experimental Nova early PID1 -> systemd handoff')
    parser.add_argument('--password-env',default='NOVA_SMOKE_PASSWORD', help='Environment variable with the test guest account password')
    parser.add_argument('--result',default=str(ROOT/'vm/out/smoke-result.json'))
    args=parser.parse_args()
    result={'release':'0.67','evidence_schema':2,'smoke_passed':False,
            'vm_ram_mb':None,'m2_requested':args.m2,'boot_observed':False,
            'rust_bridge_connected':False,'original_runtime_active':False,
            'gui_event_loop_active':False,'gui_dom_verified':False,
            'gui_phase':'unavailable','home_screen_verified':False,
            'persistent_data_roundtrip':False,
            'diagnostics_available':False,'package_service_available':False,
            'backup_restore_staged':False,
            'pixels_manually_verified':False,'nova_early_init_handoff_observed':False,
            'note':'A GUI event-loop heartbeat is not an image proof; visually inspect via VNC or GTK.'}
    dest=Path(args.result);dest.parent.mkdir(parents=True,exist_ok=True)
    # Invalidate old PASS evidence before every preflight, including early exits.
    def save():
        temporary=dest.with_name(dest.name+'.tmp')
        temporary.write_text(json.dumps(result,indent=2)+'\n')
        os.replace(temporary,dest)
    def fail(message):
        result['error']=message
        save()
        raise SystemExit(message)
    save()
    ram=os.environ.get('NOVA_VM_RAM_MB','1024')
    if ram not in ('1024','1536','2048','3072','4096'):
        fail('NOVA_VM_RAM_MB must be 1024, 1536, 2048, 3072 or 4096')
    result['vm_ram_mb']=int(ram)
    if os.environ.get('NOVA_UPDATE_WORKSPACE'):
        fail('The standard smoke harness does not yet certify A/B slot boots. Use the direct QEMU runner and inspect the guest.')
    password=os.environ.get(args.password_env,'')
    if len(password)<8:
        fail(f'Set {args.password_env} to an 8+ character password for guest login/setup. '
                         'The test will not bypass authentication. The password is not written to results.')
    if not (ROOT/'vm/out/nova-arm64.ext4').is_file():
        fail('No ARM64 image. Run ./scripts/build-all-arm64.sh first.')
    if not shutil_which('qemu-system-aarch64'):
        fail('qemu-system-aarch64 missing. Install qemu-system-arm.')
    try:
        fetch('/api/health',timeout=1)
        fail('Port 8767 is already occupied; stop old Nova/QEMU first.')
    except (urllib.error.URLError,TimeoutError,OSError):
        pass
    log_path=dest.parent/'smoke-serial.log'
    proc=None
    started=time.monotonic()
    try:
        result['source_sha256']=source_fingerprint(ROOT)
        with log_path.open('wb') as log:
            vm_env=os.environ.copy()
            vm_env['NOVA_ENABLE_M2_INIT']='1' if args.m2 else '0'
            vm_env['NOVA_VM_RAM_MB']=ram
            proc=subprocess.Popen(['bash',str(ROOT/'vm/run-arm64-qemu.sh'),'--vnc'],
                                  cwd=ROOT, env=vm_env, stdout=log,stderr=subprocess.STDOUT,
                                  start_new_session=True)
            print('ARM64 QEMU started; serial logs:',log_path,flush=True)
            last_status=None
            session=None
            token=None
            while time.monotonic()-started < args.timeout:
                if proc.poll() is not None:
                    raise RuntimeError('QEMU exited early (code '+str(proc.returncode)+')')
                try:
                    health=json.loads(fetch('/api/health'))
                    if not health.get('ready'):
                        time.sleep(3)
                        continue
                    if session is None:
                        # Strict guest mode protects every private endpoint.
                        # Log in via the supported account API; never disable it.
                        page=fetch('/').decode('utf-8')
                        match=TOKEN.search(page)
                        if not match:raise RuntimeError('Missing Nova session token')
                        token=match.group(1)
                        account=json.loads(fetch('/api/account/status'))
                        if account.get('setup_required'):
                            auth=json.loads(fetch('/api/account/create',
                                {'name':'Nova QEMU Test','password':password},token=token))
                        else:
                            auth=json.loads(fetch('/api/account/login',
                                {'password':password},token=token))
                        session=auth['session']
                        result['account_authenticated']=True
                    sysinfo=json.loads(fetch('/api/system',session=session))
                    if sysinfo.get('arch') not in ('aarch64','arm64'):
                        raise RuntimeError('Expected ARM64 guest, got '+str(sysinfo.get('arch')))
                    status=json.loads(fetch('/api/core/status',session=session))
                    integration=json.loads(fetch('/api/integration',session=session))
                    result['boot_observed']=True
                    result['rust_bridge_connected']=bool(status.get('connected'))
                    result['gui_event_loop_active']=bool(health.get('gui_event_loop_active'))
                    result['gui_dom_verified']=bool(health.get('gui_dom_verified'))
                    result['gui_phase']=health.get('gui_phase','unavailable')
                    result['home_screen_verified']=result['gui_dom_verified'] and result['gui_phase']=='home'
                    result['original_runtime_active']=(integration.get('guest_services',{}).get('nova-runtime.service')=='active')
                    current=(result['rust_bridge_connected'],result['gui_dom_verified'],result['original_runtime_active'])
                    if last_status != current:
                        print('Guest observed: Rust / initialized Nova GUI / original runtime:',current,flush=True)
                        last_status=current
                    if all(current):
                        # The guest user may still see the login screen; this is a
                        # genuine initialized GUI, not yet evidence of a signed-in home.
                        fname='nova-smoke-'+str(os.getpid())+'.txt'
                        fetch('/api/files/create',{'path':'','name':fname,'content':'Nova ARM64 smoke check'},token,session)
                        entry=json.loads(fetch('/api/file?path='+fname,session=session))
                        result['persistent_data_roundtrip']=(entry.get('content')=='Nova ARM64 smoke check')
                        if not result['persistent_data_roundtrip']:
                            raise RuntimeError('File roundtrip check failed')
                        diagnostics=json.loads(fetch('/api/platform/diagnostics',session=session))
                        result['diagnostics_available']=('storage_free_mb' in diagnostics and
                                                        'network_interfaces' in diagnostics)
                        packages=json.loads(fetch('/api/packages',session=session))
                        result['package_service_available']=isinstance(packages,list)
                        backup=json.loads(fetch('/api/backups/create',{},token,session))
                        staged=json.loads(fetch('/api/backups/recover',{'name':backup['name']},token,session))
                        result['backup_restore_staged']=(staged.get('live_data_changed') is False)
                        if not (result['diagnostics_available'] and result['package_service_available']
                                and result['backup_restore_staged']):
                            raise RuntimeError('Platform diagnostics, packages, or backup staging check failed')
                        result['guest_system']=sysinfo
                        result['observed_at_unix']=int(time.time())
                        result['smoke_passed']=True
                        print('PASS: ARM64 guest, Nova Rust bridge/runtime, initialized Qt GUI and same-boot file roundtrip')
                        print('GUI phase:',result['gui_phase'],'(login is expected until user signs in)')
                        break
                except urllib.error.HTTPError as exc:
                    # Incorrect credentials are an actionable failure, not a silent retry.
                    if exc.code in (401,403) and session is None and token is not None:
                        raise RuntimeError('Nova guest login failed; check '+args.password_env) from exc
                except (urllib.error.URLError,TimeoutError,OSError,ValueError,KeyError):
                    pass
                time.sleep(3)
            else:
                result['error']='Timed out before all boot checks passed'
            if not result.get('smoke_passed'):
                print('FAIL: see serial logs:',log_path,flush=True)
    except Exception as exc:
        result['error']=str(exc)
        print('FAIL:',exc,flush=True)
    finally:
        if args.m2 and log_path.is_file():
            serial=log_path.read_text(errors='replace')
            result['nova_early_init_handoff_observed']=('M0 ARM64 Linux boot reached Nova early init' in serial and 'M2 handoff' in serial)
            if result.get('smoke_passed') and not result['nova_early_init_handoff_observed']:
                result['smoke_passed']=False
                result['error']='Nova early PID1 handoff markers missing from serial log'
        if proc and proc.poll() is None:
            try:os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                proc.wait(timeout=5)
        # The guest legitimately writes to its disk during boot. Bind evidence
        # to the stopped image, not its pre-boot checksum, or every real boot
        # would invalidate its own acceptance report.
        if result.get('smoke_passed'):
            try:
                result['artifacts']=artifact_fingerprint(ROOT)
            except (OSError,ValueError) as exc:
                result['smoke_passed']=False
                result['error']='Cannot record stopped VM artifacts: '+str(exc)
        result['test_duration_sec']=round(time.monotonic()-started,1)
        save()
        print('Result:',dest)
    return 0 if result.get('smoke_passed') else 1


def shutil_which(name):
    from shutil import which
    return which(name)

if __name__=='__main__':sys.exit(main())
