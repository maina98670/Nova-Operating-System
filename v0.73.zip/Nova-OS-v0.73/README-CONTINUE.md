# Nova OS v0.73 Hardware Integration

This is a development source package for guide M13, days 66 to 68.
Its active UI and API version label is v0.73. It is not a certified or
boot-tested phone release. See BUILD-STATUS.json for the actual local results.

This snapshot was assembled from the supplied current Nova integration
baseline. For v0.67 and v0.73 it is a reconstructed development snapshot,
not an original historical release or proof of a physical device port.
Earlier Rust sources and the original guide remain preserved.

This stage adds or exposes: Same-session component and simultaneous-use evidence validation.

## Check this source package

Use Python 3.11 or newer. Versions v0.87 and later additionally require
python3-cryptography for the signed update and release tools.

```bash
bash scripts/check-v073.sh
python3 scripts/guide-status.py
python3 scripts/nova-maintenance.py hardware-status
```

Read docs/MAINTENANCE.md for the local tool commands introduced at each stage.
Commands requiring a later-stage module are unavailable in earlier packages.
The System maintenance app shows which local tools are included.

## ARM64 compilation and boot

The original cross-build pipeline remains available on a supported full
Ubuntu or Debian host with its documented dependencies:

```bash
bash scripts/build-all-arm64.sh
NOVA_VM_RAM_MB=1024 bash vm/run-arm64-qemu.sh
```

No ARM64 compiler, Cargo toolchain or QEMU emulator is installed in the
authoring environment, so this package contains source rather than a newly
compiled kernel or disk image. Actual GUI, real-device drivers, calls, SMS,
camera, per-app OS isolation, 1 GB endurance and the full guide acceptance
tests remain unverified. v1.00 naming does not change those facts.

The existing Weston, Linux, systemd and Qt WebEngine design remains. The K1
to K14 custom-kernel track is separate and has no v-number releases in the
supplied guide. It is not silently substituted for this Linux-based track.
