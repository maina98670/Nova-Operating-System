"""Validate boot evidence against the source and VM artifacts actually tested.

This prevents accidentally reusing stale local reports; it is not a signature
or an independent observer of the guest display.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import time

REQUIRED = (
    'smoke_passed', 'boot_observed', 'account_authenticated',
    'rust_bridge_connected', 'original_runtime_active',
    'gui_event_loop_active', 'gui_dom_verified',
    'persistent_data_roundtrip', 'diagnostics_available',
    'package_service_available', 'backup_restore_staged',
)


def sha256(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def source_fingerprint(root):
    """Hash runtime/build source, excluding generated reports and build outputs."""
    root = Path(root)
    result = hashlib.sha256()
    for directory in ('maintenance', 'integration', 'graphics-shell', 'native-shell', 'native-bridge',
                      'native-runtime', 'boot', 'scripts', 'source-v0.60', 'vm'):
        for path in sorted((root / directory).rglob('*')):
            rel = path.relative_to(root)
            if any(part in ('__pycache__', 'target', 'out', '.git') for part in rel.parts):
                continue
            if path.is_file() and not path.is_symlink():
                result.update(rel.as_posix().encode() + b'\0')
                result.update(bytes.fromhex(sha256(path)))
    return result.hexdigest()


def artifact_fingerprint(root):
    """Hash image/kernel/initrd so evidence cannot outlive an image rebuild."""
    out = Path(root) / 'vm/out'
    boot = out / 'rootfs/boot'
    files = {'disk': out / 'nova-arm64.ext4'}
    # A matched pair is required; never independently choose two kernel versions.
    kernels = sorted(p for p in boot.glob('vmlinuz-*')
                     if (boot / ('initrd.img-' + p.name[8:])).is_file())
    if not kernels:
        raise ValueError('No matched ARM64 kernel and initramfs pair')
    # The runner selects with sort -V; require a single pair for unambiguous evidence.
    if len(kernels) != 1:
        raise ValueError('Multiple kernel versions: retain one tested kernel/initramfs pair')
    files['kernel'] = kernels[0]
    files['initramfs'] = boot / ('initrd.img-' + kernels[0].name[8:])
    return {key: {'path': path.relative_to(root).as_posix(),
                  'bytes': path.stat().st_size, 'sha256': sha256(path)}
            for key, path in files.items()}


def validate_boot(root, report, *, now=None):
    errors = []
    if not isinstance(report, dict):
        return ['Boot report must be an object']
    if report.get('evidence_schema') != 2:
        errors.append('Run the updated smoke harness to generate schema 2 evidence')
    for field in REQUIRED:
        if report.get(field) is not True:
            errors.append(field + ' was not verified')
    if report.get('release') != '0.73':
        errors.append('Boot evidence is for another release')
    if report.get('vm_ram_mb') != 1024:
        errors.append('Guide requires a 1024 MB QEMU acceptance run')
    if report.get('m2_requested') is True and report.get('nova_early_init_handoff_observed') is not True:
        errors.append('Requested M2 handoff was not observed')
    if report.get('gui_phase') not in ('login', 'home'):
        errors.append('No initialized login or home screen was observed')
    stamp = report.get('observed_at_unix')
    if type(stamp) not in (int, float) or not 0 < stamp <= (now or time.time()) + 5:
        errors.append('Missing or invalid observation time')
    if report.get('source_sha256') != source_fingerprint(root):
        errors.append('Source changed since the boot test')
    try:
        if report.get('artifacts') != artifact_fingerprint(root):
            errors.append('VM artifacts changed since the boot test')
    except (OSError, ValueError) as exc:
        errors.append('VM artifacts unavailable: ' + str(exc))
    return errors


def load_report(path):
    try:
        value = json.loads(Path(path).read_text())
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}
