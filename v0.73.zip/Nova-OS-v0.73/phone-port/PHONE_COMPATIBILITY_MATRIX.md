# Nova OS v0.73 — Hardware-port validation matrix

**All rows are UNKNOWN or UNVERIFIED for a real phone until an exact target is selected.** QEMU/Colab behavior is not proof of phone support.

| Area | Current Nova source state | Required device-specific validation |
|---|---|---|
| Bootloader / AVB | Android layout guidance and readiness blocker | Unlock policy, backup, target-specific images, AVB and rollback |
| Kernel + DTB | Existing ARM64 Linux QEMU builder | Compatible device kernel, DTB, module ABI and firmware |
| Display | Weston + Qt-based development UI | DRM/KMS or appropriate supported graphics stack, rotation and brightness |
| Touch / keys | Qt mouse/keyboard UI | Input-event mapping, multitouch, power and volume buttons |
| Storage | Nova Files API and SQLite data | Partition mounting, persistence, encryption and filesystem health |
| RAM / CPU | Process monitoring, limited source testing | Boots on 1–2 GB physical RAM; OOM recovery, thermal and suspend |
| Wi-Fi | NetworkManager adapter | Driver, firmware, connection/reconnect and power states |
| Bluetooth | BlueZ adapter | Controller, pairing, audio, firmware and sleep handling |
| Audio | Multimedia UI + Linux audio packages | Speaker, microphone, routing, capture and volume |
| Camera | Camera source/UI prototypes | Sensor driver, ISP, permissions and capture path |
| Battery / charging | Capability indicators | Fuel gauge, charging safety, thermal control and sleep |
| Cellular / SIM / SMS | Prototyped dialer/messages interfaces | Modem, SIM, VoLTE, emergency calling and radio isolation |
| Sensors | No production device integration | Rotation, proximity, ambient light, GPS/GNSS |
| Android APK runtime | APK staging + optional Waydroid adapter | Binder, container permissions, Android guest image, graphics, input, audio, RAM |
| Native app security | Browser account gate and basic service hardening | Per-app sandbox, secure updates and user-data protection |
| Recovery | Backup staging and QEMU diagnostics | Stock restore path, safe reboot, data-recovery test |

A successful phone port needs a documented evidence trail for every feature claimed to work. Do not disable Android Verified Boot checks on a real phone without model-specific engineering and an explicit recovery plan.
