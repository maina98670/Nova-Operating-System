# Nova OS v0.73 — Phone-porting kit (NOT a phone ROM)

**Status: PREPARATION ONLY. There are no phone-flashable `boot.img`, `vendor_boot.img`, `init_boot.img`, or `super.img` images in this kit.** The public Nova OS version remains `0.73`.

This package preserves the original v0.73 source and provides a *read-only* Android phone inventory tool, a blocked-by-default device readiness validator, and a portable userspace staging archive generator. These tools do **not** unlock, erase, write, reboot, or flash a connected phone.

## Why an ARM64 QEMU image is not a phone ROM

The existing `vm/build-arm64-qemu.sh` creates a Debian ARM64 root filesystem plus a QEMU-specific Linux kernel. Phone bootloaders require **device-specific boot image headers, exact partition mappings, a matching kernel/DTB/modules/firmware, verified-boot decisions, and a tested recovery route**. On some phones the generic ramdisk belongs in `init_boot`, while `vendor_boot` has device-specific boot components. The factory layout must be established *before creating any images*.

## Stage A — Collect details from the exact phone (no modifications)

On your **local Windows / Ubuntu / Chromebook host** with Android Platform Tools and USB debugging authorized:

```bash
python3 phone-port/tools/inspect_phone.py --output phone-report.json
```

No adb access from a typical hosted Google Colab notebook to your local USB phone. Run the inspector on a computer connected to the phone instead. The tool does not save device serial numbers, account names, or personal files. Review any report before sharing it.

## Stage B — Create a target-specific profile and check what is missing

```bash
cp phone-port/profiles/device-profile.template.json phone-port/profiles/my-phone.json
python3 phone-port/tools/preflight.py --profile phone-port/profiles/my-phone.json --report phone-report.json
```

Profile fields intentionally start blank/false. Fill them only from proven evidence. The preflight normally exits **2 (NOT READY)**. An exit code of 0 only shows manifest requirements are satisfied; it is **not** permission or a substitute for expert board-level review.

## Stage C — Prepare a userspace payload safely (host only)

```bash
python3 phone-port/tools/build_userspace_overlay.py --output phone-port/out/nova-v0.73-userspace-overlay.tar.gz
```

This archive contains Nova service/UI Python source, integration logic and **a service template**, but is **not** a phone partition or flashed image. It requires a matching ARM64 Linux base, compiled native Rust components, runtime dependencies, and a configured graphical environment. The script does not touch a phone.

## Stage D — Device bring-up (future; requires model/codename)

1. Obtain OEM stock firmware and identify precise boot/rollback/restore sequence.
2. Confirm bootloader unlock and data backup (unlocking commonly erases user data).
3. Establish compatible device kernel source, device tree, drivers, firmware and mounting strategy.
4. Build/test the matching root filesystem, initramfs, kernel modules and *device-specific* images.
5. First attempt a **non-destructive boot** only if officially supported, with a known recovery route.
6. Validate display, touch, storage, power, Wi-Fi, BT, audio, modem, camera and suspend/resume. Many features are currently not integrated in Nova.
7. Confirm persistence/recovery and full 1–2 GB RAM workload tests before any user-data affecting flash.

**Do not use `fastboot flashall`, `fastboot erase`, `fastboot flashing unlock`, `dd`, or partition write tools as a generic shortcut.** OEM-specific steps can wipe or brick a phone. No destructive command is provided in this kit.

## Nova runtime readiness currently known

- Source/UI: existing v0.73 code retained; graphical preview tested, but not an independent phone session.
- Boot: ARM64 QEMU build scripts exist; a full graphical ARM64 QEMU boot has **not** been confirmed by this kit.
- Waydroid/APKs: staging/inspection supported; **actual Android APK execution has not been verified**.
- Nova APIs: Python server with original Rust bridge when compiled and running; not a production sandbox.
- Device kernel/display/touch/modem: **unknown** until a phone is selected and ported.
- Lock screen: app/web interface, not proven device-wide disk encryption or platform authentication.

## External technical references

- Android boot layout: https://source.android.com/docs/core/architecture/partitions/generic-boot
- Android partitions: https://source.android.com/docs/core/architecture/partitions
- Bootloader warnings: https://source.android.com/docs/core/architecture/bootloader/locking_unlocking
- postmarketOS porting introduction: https://wiki.postmarketos.org/wiki/Porting_to_a_new_device
