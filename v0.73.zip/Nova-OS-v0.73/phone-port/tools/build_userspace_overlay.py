#!/usr/bin/env python3
"""Create portable Nova userspace staging tar; NOT a flashable boot image."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[2]
COPY_DIRS=("graphics-shell", "native-shell", "integration")
COPY_FILES=(("phone-port/systemd/nova-api.service.template", "usr/share/nova/nova-api.service.template"),)
FORBIDDEN={".db", ".sqlite", ".sqlite3", ".pyc", ".pem", ".key", ".p12"}

def payload_files():
    for dirname in COPY_DIRS:
        source=ROOT/dirname
        if not source.is_dir(): raise FileNotFoundError(source)
        for f in sorted(source.rglob('*')):
            if f.is_symlink() or not f.is_file(): continue
            if f.suffix.lower() in FORBIDDEN or any(x in f.parts for x in ("__pycache__",".git", "target")): continue
            rel=Path('opt/nova')/f.relative_to(ROOT)
            yield f, rel.as_posix()
    for file, target in COPY_FILES:
        yield ROOT/file,target


def build(out):
    out=Path(out).resolve()
    out.parent.mkdir(parents=True,exist_ok=True)
    manifest={"nova_version":"0.73", "kind":"NON_FLASHABLE_USERSPACE_STAGING", "files":{}}
    with tarfile.open(out,"w:gz") as archive:
        for src, target in payload_files():
            data=src.read_bytes()
            info=tarfile.TarInfo(target)
            info.size=len(data); info.mtime=0; info.uid=0; info.gid=0
            info.uname="root"; info.gname="root"
            info.mode=0o755 if src.stat().st_mode & 0o111 else 0o644
            archive.addfile(info,io.BytesIO(data))
            manifest["files"][target]=hashlib.sha256(data).hexdigest()
        data=(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode()
        info=tarfile.TarInfo('usr/share/nova/overlay-manifest.json')
        info.size=len(data); info.mode=0o644; info.mtime=0
        archive.addfile(info,io.BytesIO(data))
    return len(manifest['files'])


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',default='phone-port/out/nova-v0.73-userspace-overlay.tar.gz')
    args=ap.parse_args()
    print('Created NON-FLASHABLE userspace staging archive:',args.output)
    print('Source files packaged:',build(args.output))
    print('NO boot.img / NO partition images / NO flash performed')

if __name__=='__main__': main()
