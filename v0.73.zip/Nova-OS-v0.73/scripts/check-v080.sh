#!/usr/bin/env bash
set -euo pipefail
exec bash "$(dirname "$0")/check-v077.sh" "$@"
