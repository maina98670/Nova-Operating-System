#!/usr/bin/env python3
"""Nova pre-hardware release gate: source pass != boot pass != production stable."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from integration.boot_evidence import load_report, validate_boot


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--require-boot',action='store_true',help='Fail unless actual ARM64 smoke test passed')
    parser.add_argument('--output',default=str(ROOT/'verification-report-v0.73.json'))
    args=parser.parse_args()
    source=subprocess.run([sys.executable,str(ROOT/'scripts/preflight.py'),'--strict-source'],capture_output=True,text=True)
    try:
        preflight=json.loads(source.stdout)
    except ValueError:
        preflight={'source_verified':False,'error':source.stderr}
    suite=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
    smoke_path=ROOT/'vm/out/smoke-result.json'
    boot=load_report(smoke_path)
    boot_errors=validate_boot(ROOT,boot)
    boot_pass=not boot_errors
    source_pass=(preflight.get('source_verified') and suite.returncode==0)
    classification=('ARM64 boot candidate tested; requires manual pixel check and device validation'
                    if boot_pass else 'Source-integrated engineering release candidate; ARM64 boot UNVERIFIED')
    report={'release':'Nova OS v0.73 Integration Foundation','source_gate_passed':bool(source_pass),
            'source_preflight':preflight,'tests_output':suite.stderr[-2500:],
            'arm64_boot_gate_passed':boot_pass,'boot_smoke':boot if boot else None,
            'boot_gate_blockers':boot_errors,
            'production_stable':False,'manual_visual_confirmation':False,
            'classification':classification,
            'unresolved':['Native Nova compositor rendering not implemented (Weston remains)',
                         'Eight Qt apps are development implementations; complete functional QEMU testing pending',
                         'Wi-Fi and Bluetooth need actual adapters, guest device permissions and authorized opt-in',
                         'Lock screen is a UI session guard, not an OS-enforced security boundary',
                         'Device brightness/volume preferences do not operate physical controls',
                         'No executable Nova Store repository; resource bundles only',
                         'Email inbox headers and SMTP only; OAuth, attachments and full sync pending',
                         'Nova Init not PID 1 (systemd remains)',
                         'Original CLI app binaries not all graphical Wayland clients',
                         'APK staging implemented but APK signing cannot be verified until Android package manager is running',
                         'Waydroid not bundled or verified; requires Binder, Wayland and supported guest container privileges',
                         'Embedded Qt WebEngine is not Nova custom DRM compositor',
                         'No production mobile sandbox, signed OTA or phone driver support']}
    Path(args.output).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'source_gate_passed':bool(source_pass),
                       'arm64_boot_gate_passed':boot_pass,'production_stable':False,
                       'classification':classification,
                       'report':args.output},indent=2))
    if not source_pass or (args.require_boot and not boot_pass):return 1
    return 0

if __name__=='__main__':sys.exit(main())
