#!/usr/bin/env python3
"""A transparent evidence matrix. Source present != boot tested != Android-ready."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
SMOKE=ROOT/'vm/out/smoke-result.json'
try: smoke=json.loads(SMOKE.read_text())
except (ValueError,OSError):smoke={}
boot=bool(smoke.get('smoke_passed'))
modules=[
  ('1. ARM64 boot','builder + kernel/initramfs validation', 'guest QEMU boot ' + ('observed' if boot else 'not verified')),
  ('2. Init/services','systemd starts original Nova daemon and Python/Rust bridge','Nova Init not PID 1'),
  ('3. Compositor','Weston Wayland + native Nova Qt GUI','Nova DRM compositor not implemented'),
  ('4. Application manager','original Rust protocol daemon + Qt independent window processes','original 12 app CLIs not all Qt-native'),
  ('5. Process/memory','Qt QProcess controls + systemd service memory limits','per-app OOM/suspend policies incomplete'),
  ('6. IPC','original Nova Rust IPC runtime + local JSON API','IPC full guest path requires boot test'),
  ('7. Storage','Rust file bridge + persistent actual files + atomic JSON','reboot persistence requires VM boot test'),
  ('8. Security','session token, path confinement, service hardening','no per-app production sandbox'),
  ('9. Package manager','verified data-only resource bundle installation/uninstall','executable app installer and signatures absent'),
  ('10. Mobile UI','Qt launcher, recent app processes, native views','gesture lock screen and real phone touch absent'),
  ('11. Network/audio','virtual network status and ALSA diagnostics','Wi-Fi pairing/audio route controls unavailable'),
  ('12. Recovery','restricted backups, non-destructive restore staging, smoke tests','automatic A/B rollback not implemented'),
]
report={'release':'Nova OS v0.73 Integration Foundation','source_components':104,
        'arm64_qemu_smoke_observed':boot, 'pre_hardware_production_stable':False,
        'areas':[{'area':name,'available':implemented,'remaining':remaining} for name,implemented,remaining in modules]}
path=ROOT/'verification-12-systems.json'
path.write_text(json.dumps(report,indent=2)+'\n')
if len(sys.argv)<2 or sys.argv[1]!='--json':
    for item in report['areas']:
        print(f"{item['area']}: {item['available']}\n   NOT COMPLETE: {item['remaining']}")
    print('ARM64 observed:',boot,'\nWritten:',path)
else:print(json.dumps(report,indent=2))
