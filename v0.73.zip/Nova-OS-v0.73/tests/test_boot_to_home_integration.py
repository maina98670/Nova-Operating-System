"""v0.73 boot-to-home contract tests; no QEMU result is implied."""
from pathlib import Path
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request

ROOT=Path(__file__).resolve().parents[1]

class BootHomeContractTests(unittest.TestCase):
    def test_launcher_has_login_and_home_boot_phases(self):
        js=(ROOT/'graphics-shell/static/modern.js').read_text()
        self.assertIn("phase:'booting'",js)
        self.assertIn("phase:'login'",js)
        self.assertIn("phase:'home'",js)
        self.assertIn("phase:'error'",js)
        self.assertIn('renderApps();goHome();dateTick();window.__NOVA_UI_STATE__',js)

    def test_qt_client_verifies_real_dom_before_heartbeat(self):
        source=(ROOT/'native-shell/modern_webview.py').read_text()
        self.assertIn('window.__NOVA_UI_STATE__',source)
        self.assertIn("phase=='home'",source)
        self.assertIn("phase=='login'",source)
        self.assertIn('app_tiles:count',source)
        self.assertIn("'dom_verified':True",source)
        self.assertIn('QWebEngineView',source)

    def test_authenticated_guest_smoke_does_not_bypass_login(self):
        source=(ROOT/'vm/smoke-arm64-qemu.py').read_text()
        self.assertIn('NOVA_SMOKE_PASSWORD',source)
        self.assertIn('/api/account/status',source)
        self.assertIn('/api/account/create',source)
        self.assertIn('/api/account/login',source)
        self.assertIn('gui_dom_verified',source)
        self.assertIn('home_screen_verified',source)
        self.assertIn("'X-Nova-Web-Session'",source)

    def test_guest_vt_fallback_keeps_shell(self):
        src=(ROOT/'vm/guest/nova-profile').read_text()
        self.assertIn('/usr/local/bin/nova-desktop-session',src)
        self.assertNotIn('exec /usr/local/bin/nova-desktop-session',src)
        self.assertIn('VT shell available for repair',src)

    def test_m0_to_m3_boot_scripts_still_present(self):
        for x in ('vm/run-arm64-qemu.sh','vm/build-arm64-qemu.sh',
                  'boot/integrated/nova-early-init/src/main.rs',
                  'vm/guest/nova-compositor-run','vm/guest/nova-desktop-session'):
            self.assertTrue((ROOT/x).is_file(),x)

    def test_guest_public_health_only_trusts_fresh_dom_verified_marker(self):
        with tempfile.TemporaryDirectory(prefix='nova77-home-contract-') as d:
            base=Path(d)
            with socket.socket() as sock:
                sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            ready=base/'gui.json'
            env={**os.environ,'NOVA_CONFIG_DIR':str(base/'config'),
                 'NOVA_FILES_ROOT':str(base/'files'),'NOVA_GUI_READY_FILE':str(ready),
                 'NOVA_ENFORCE_AUTH':'1'}
            server=subprocess.Popen([sys.executable,str(ROOT/'graphics-shell/server.py'),
                '--no-browser','--port',str(port)],cwd=ROOT,env=env,
                stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            url=f'http://127.0.0.1:{port}/api/health'
            try:
                for _ in range(100):
                    try:
                        with urllib.request.urlopen(url,timeout=.5) as r:json.load(r)
                        break
                    except (OSError,ValueError):time.sleep(.1)
                else:self.fail('server did not start')
                def health():
                    with urllib.request.urlopen(url,timeout=2) as r:return json.load(r)
                self.assertFalse(health()['gui_dom_verified'])
                ready.write_text(json.dumps({'status':'event-loop-active',
                    'timestamp':time.time(),'dom_verified':True,
                    'ui_phase':'login','app_tile_count':13}))
                obj=health()
                self.assertTrue(obj['gui_dom_verified'])
                self.assertEqual(obj['gui_phase'],'login')
                self.assertEqual(obj['gui_app_tile_count'],13)
                for phase, tiles in [('booting',13), ('home',0), ('home','13')]:
                    ready.write_text(json.dumps({'status':'event-loop-active',
                        'timestamp':time.time(),'dom_verified':True,
                        'ui_phase':phase,'app_tile_count':tiles}))
                    self.assertFalse(health()['gui_dom_verified'])
                ready.write_text(json.dumps({'status':'event-loop-active',
                    'timestamp':time.time()-45,'dom_verified':True,
                    'ui_phase':'home','app_tile_count':13}))
                self.assertFalse(health()['gui_dom_verified'])
            finally:
                server.terminate()
                try:server.communicate(timeout=5)
                except subprocess.TimeoutExpired:server.kill();server.wait(timeout=3)

if __name__=='__main__':unittest.main()
