# Nova OS v0.77 — M0–M3 → Login → Home screen

This is an update **within Nova OS v0.77**, based on the previous `M0-M3-Integrated` source. It preserves the original M0–M3 milestones and Weston recovery compositor. No new Linux kernel and no flashable phone ROM are created here.

## Intended boot path

```
QEMU firmware / ARM64 Linux kernel + initramfs (M0-compatible VM path)
  ├── optional /sbin/nova-early-init as PID 1 (M2) → systemd
  ├── original DRM splash (M1, best effort; firmware/DRM-dependent)
  ├── original Nova services, strict account-authenticated HTTP backend
  ├── Weston Wayland compositor, or ARM64 M3 if explicitly built and selected
  └── Qt WebEngine fullscreen Wayland window → modern Nova JavaScript GUI
       ├── first boot: Nova account setup / sign-in screen
       └── after sign-in: home screen and Nova app grid
```

Original M0 code/configuration is retained as historical reference. The QEMU build uses a distribution ARM64 kernel, not proof of running a newly built original M0 kernel. M2 currently executes systemd, so it is **not a permanent Nova service manager**. M3 still needs wlroots 0.17 build and runtime verification.

## New integration changes

- `graphics-shell/static/modern.js`: publishes explicit `booting`, `login`, `home`, `error` JavaScript boot phases.
- `native-shell/modern_webview.py`: verifies login/home DOM and populated app tiles before announcing graphical readiness; continuously tracks subsequent login and home transitions; retries if the UI cannot load.
- `graphics-shell/server.py`: read-only `/api/health` distinguishes an active Qt event loop, initialized GUI DOM, and currently displayed UI phase. **None verifies actual pixels on screen.**
- `vm/guest/nova-profile`: starts the graphical session on tty1 but leaves the VT shell accessible if it fails.
- `vm/guest/nova-boot-splash.service`: skips a duplicate splash when M2 early init is selected.
- `vm/smoke-arm64-qemu.py`: respects v0.77 account authentication instead of attempting unauthorized private API calls; requires a user-supplied test password. Reports login-screen readiness separately from an authenticated home.
- `scripts/boot-home-status.py`: read-only boot-chain status helper, installed as `nova-boot-status` in the guest.

## Build on a full Ubuntu/Debian workstation with sudo and ARM64 cross-build tools

Build dependencies are specified in the existing scripts; the disk build requires ample RAM, disk space, networking, and rootless `sudo` to bootstrap an ARM64 Debian guest. Review scripts before execution.

```bash
./scripts/build-all-arm64.sh
```

View the VM using a graphical Linux desktop:

```bash
NOVA_ENABLE_M2_INIT=1 ./vm/run-arm64-qemu.sh
```

If experimental M2 causes a failure, leave it disabled and test the default systemd boot:

```bash
NOVA_ENABLE_M2_INIT=0 ./vm/run-arm64-qemu.sh
```

**Inside the guest's login shell**, run:

```bash
nova-boot-status
systemctl --no-pager status nova-shell.service
cat /home/nova/nova-desktop.log
```

The first boot should show a Nova account-creation page. After creating an account and signing in, the same native Qt window shows the modern launcher and clickable app grid. The readiness API should change from `gui_phase: login` to `gui_phase: home`. This is a test target, not a result observed on QEMU here.

## Automated QEMU smoke test

The real QEMU test must authenticate because private API routes enforce Nova account sessions. Set a strong test password for the **test VM**. On first use, this creates an account; on subsequent use, the password must match the one previously configured. Do not use your personal password in smoke-test scripts.

```bash
read -rsp 'Nova test guest password: ' NOVA_SMOKE_PASSWORD; echo
export NOVA_SMOKE_PASSWORD
python3 vm/smoke-arm64-qemu.py --m2 --timeout 900
unset NOVA_SMOKE_PASSWORD
```

The smoke test checks: ARM64 guest architecture, original Rust bridge/runtime status, DOM-verified Qt login/home GUI startup, file persistence, diagnostics, package listing and backup staging. It **does not automatically sign into the Qt window**, prove rendered pixels, Android APK execution, or phone flash readiness. The user must complete Qt sign-in and visually inspect the home screen separately.

Results: `vm/out/smoke-result.json` and `vm/out/smoke-serial.log`.

## Source-only testing (including Colab)

```bash
python3 -m unittest discover -s tests -q
node --check graphics-shell/static/modern.js  # if Node is installed
bash -n vm/run-arm64-qemu.sh vm/build-arm64-qemu.sh vm/guest/nova-desktop-session
python3 scripts/verify-integrity.py
```

The optional Chromium end-to-end test needs `playwright` and `chromium`, and local web navigation permission:

```bash
NOVA_RUN_BROWSER_E2E=1 python3 -m unittest discover -s tests -p 'test_gui_boot_browser.py' -v
```

It may be blocked in restricted hosted workspaces. This does not imply that QEMU works or fails.

**Never flash** `vm/out/nova-arm64.ext4` directly to a real phone. Creating a phone ROM requires a known device/bootloader, kernel/device tree, vendor drivers, verified partitions and a recovery procedure.
