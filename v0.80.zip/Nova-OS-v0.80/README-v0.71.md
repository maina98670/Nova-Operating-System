# Nova OS v0.71 — native graphical shell integration

## Scope and honest status

This release is an **engineering integration package**, not an Android replacement and **not a prebuilt boot image**. It preserves all 104 original v0.60 Rust workspace modules, 9 milestone archives and M0–M3 source, and adds a real Python/Qt **native graphical Wayland client**, wired to the Nova backend and original v0.60 Rust cores when the native bridge is built.

It supersedes the QEMU **Chromium kiosk display** from v0.70: guest display is now **Linux ARM64 → systemd → Weston Wayland compositor → native Qt Nova GUI**, with the original Nova App Manager/compositor protocol runtime (if successfully built), and a Rust bridge into the existing Settings, Contacts, Files and read-only Messages cores.

### What has working code

- Graphical native Qt home, app drawer, quick settings, clock/network/battery *observations* and Back/Home navigation.
- Graphical Files (open/edit/create/trash/rename/import), Settings (appearance + original Rust settings preferences), Notes, Contacts, saved Messages drafts, Photos, arithmetic Calculator, About, installed component catalog and Camera limitation screen.
- Backend uses existing v0.70 source API, with per-run local session token on mutations; Files/settings/contacts backed by the original Rust cores **only when the bridge is installed and healthy**. Notes/drafts remain Python-backed.
- Original 104 Rust workspace modules and nine history ZIPs preserved. ARM64 strict build pipelines retained. The existing App Manager and compositor **protocol/state** runtime binaries can be built, staged and started by systemd.
- QEMU guest builder now installs `python3-pyqt5` and `qtwayland5` and launches native Qt window after Weston; no guest Chromium required.

### What is not finished

- **No independent Nova compositor yet**: Weston provides actual pixel rendering; the original Nova compositor library is protocol/state management only. Qt is the graphical **client**.
- **No Nova Init as PID 1**: systemd is still PID 1. M0–M3 are historical boot prototypes.
- **No independent Nova kernel**: Linux ARM64 is used as the kernel.
- App binaries in the original v0.60 source are not all graphical applications. Qt shell's functioning screens share original cores where supported, but do not launch all 12 original CLI app binaries as windows.
- Other libraries/tools are preserved/buildable, not all running at boot; some are tests and intentionally should not run as services.
- Real Wi-Fi management, SIM/calls/SMS, microphone, camera capture, Bluetooth, phone power drivers, full permission mediation, production verified sandbox/security and OTA updates remain unimplemented on real phones.
- **No successful ARM64 QEMU boot has been verified in this authoring environment** (no QEMU, Cargo or network access here). We verified Python/API tests and boot script syntax, not a guest image running.

### Test on Google Colab

Use the separate `Nova-OS-v0.71-Native-Shell-Colab.ipynb`. It verifies all source files, runs tests, compiles the native Rust bridge when possible and launches the existing web preview. The final cells use Ubuntu's `python3-pyqt5` and Qt offscreen rendering to generate screenshots of the **native Qt shell itself** (distinct from a Chromium/browser preview). Colab does not boot the guest.

### Build and boot QEMU on full Ubuntu/Debian

```bash
sudo apt update
sudo apt install -y curl ca-certificates build-essential pkg-config libssl-dev \
  gcc-aarch64-linux-gnu file qemu-system-arm debootstrap qemu-user-static \
  binfmt-support rsync e2fsprogs python3
# Install Rust with rustup if `cargo --version` fails, then:
cd Nova-OS-v0.71-Native-Shell
python3 -m unittest discover -s tests -v
./scripts/build-all-arm64.sh
./vm/run-arm64-qemu.sh
```

The guest defaults to Debian 13 (trixie), whose newer glibc generally avoids the Ubuntu 24.04 host → Debian 12 ARM64 ABI incompatibility seen with earlier builds. You can override with `NOVA_DISTRO=bookworm`, but host-built binaries may then require newer glibc than the guest supplies.

This needs a full machine capable of chroot, binfmt and QEMU, sudo, Debian apt internet access and disk space. It builds original ARM64 app executables, the native Rust core bridge and the Nova App Manager/protocol runtime. Any failure stops the build, rather than claiming a complete OS. If it succeeds, the intended screen opens directly on the QEMU virtual GPU.

For VNC viewing instead of local GTK QEMU window:

```bash
./vm/run-arm64-qemu.sh --vnc
```

Serial boot diagnostic mode:

```bash
./vm/run-arm64-qemu.sh --headless
```

Guest checks after successful boot:

```bash
systemctl status nova-shell nova-catalog nova-runtime --no-pager
journalctl -b -u nova-shell -u nova-runtime --no-pager
cat /home/nova/nova-desktop.log
cat /home/nova/weston.log
cat /var/lib/nova/runtime-status.json
```

### Run native window directly on Ubuntu without QEMU

```bash
sudo apt install -y python3-pyqt5 qtwayland5
./build-native.sh  # Rust and Cargo required; optional for pure UI preview
./run-native-desktop.sh
```

For a **mobile-size window** the app's layout adapts down to ~520 px; this is a Linux Qt tablet/phone-style GUI, not yet a physical smartphone OS. All development guest images use autologin: do not expose them to the internet or deploy on a phone.

### Next architecture milestones

1. Verify v0.71 boots all the way to Qt on QEMU ARM64; fix any actual kernel/display/ABI errors seen in logs.
2. Replace Weston with a real native Nova compositor backend (Wayland DRM/KMS + input + window rendering), not merely the original state-only compositor.
3. Move original Rust app executables into graphical Wayland clients and use the original App Manager lifecycle/permissions to launch them.
4. Make Nova Init a true PID 1 only after service supervision, recovery, signals and filesystem handling are production tested.
5. Port drivers and modem/SMS/camera/audio/battery handling to selected real ARM64 phone hardware, then enforce production isolation/security.
