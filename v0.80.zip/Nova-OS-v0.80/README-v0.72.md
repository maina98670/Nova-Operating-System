# Nova OS v0.72 — Pre-hardware Stabilization RC1

**Release status: SOURCE/INTEGRATION TESTED — ARM64 BOOT NOT VERIFIED IN THIS BUILD ENVIRONMENT.**

This is a source-complete development release candidate based on v0.71, **not a finished smartphone OS or an Android replacement**. It preserves the 104 original v0.60 Rust workspace modules, all nine historical ZIP versions, M0–M3 boot source, the original Rust core bridge, the original App Manager/compositor **protocol** runtime, and the native Qt graphical shell. Historical code is preserved, **not necessarily installed or running**.

## What's new in v0.72

- Strict API startup in ARM64 guest: if the original Rust bridge is missing or unhealthy, Nova backend fails explicitly. No hidden Python fallback in the QEMU release pipeline. Developer preview retains a deliberately disclosed fallback when not in strict mode.
- Native Qt Wayland client emits a short-lived GUI event-loop heartbeat only after being displayed in the Qt event loop. The backend exposes `/api/health`; a heartbeat **does not prove visually correct pixels**.
- Graphical desktop session checks Weston socket and backend readiness, retries unexpectedly failing Qt clients up to three times, logs errors, and stops after repeated crashes rather than reporting success.
- Crash-resistant, private (0600) atomic JSON updates with fsync. User settings, notes, saved messages, contacts fallback, and local notifications share this storage path. Files remain actual files under `NovaFiles`.
- Native Qt **Recent screens** (within the shell, NOT process-level multitasking) and **local Notifications** (not Android push) with read/clear persistence.
- Fixed ARM64 boot-image file ownership after checking the Rust bridge inside chroot (a previous root-health-test could produce root-owned files that Nova user cannot write).
- New source preflight, 40 automated regression tests, host QEMU smoke harness, and explicit release gates with machine-readable reports.

## What the ARM64 image runs (not yet verified here)

```text
Linux ARM64 kernel
  -> systemd PID 1
     -> nova-runtime-daemon [original Nova Rust App Manager + compositor protocol]
     -> nova-shell.service [Python API + ORIGINAL Rust v0.60 bridge, strict]
     -> nova-catalog.service [source/installed/runtime status]
  -> tty1 autologin (DEVELOPMENT APPLIANCE ONLY)
     -> Weston [actual Wayland compositor]
        -> Nova native Qt shell [home/apps/files/settings/contacts/notes/messages/photos/notifications]
```

The Qt shell is **not Chromium**. However, **Weston** is still the pixel renderer, and **systemd** remains PID 1. The original Nova compositor is only protocol/state management, not a standalone GPU compositor. The original app binaries are mostly console tools/cores, not 12 complete Wayland graphical processes. Do not treat the 104 Rust modules as 104 background processes.

## Tested here

- Python regression suite: **40 tests** run against the source and a real local API server, including authentication, file path confinement, crash-resistant JSON storage, notifications, configuration, lifecycle test stubs, and inventory.
- Historical archive validity, M0–M3 source and all 104 Cargo manifests inspected by preflight.
- Bash syntax and Python compilation checks.
- **Cannot verify** ARM64 QEMU boot, native Qt rendering, Rust compilation or original Rust daemon execution in this authoring container: Rust, PyQt5 and QEMU are unavailable. The accompanying Colab notebook validates Rust/Qt on Colab (not full ARM64 boot).

## Test in Google Colab

Open `Nova-OS-v0.72-Stabilization-Colab.ipynb`, run its cells, and upload `Nova-OS-v0.72-Stabilization-RC1.zip`. It runs source gates and tests, compiles native Rust bridge on Colab x86_64, runs the strict Rust-backed API, renders offscreen native Qt screenshots and displays the browser compatibility preview. Colab is **not** the complete ARM64 OS boot test.

## Full ARM64 build on Ubuntu (recommended)

Use a full **Ubuntu 24.04 / Debian desktop/VM with sudo, internet, several GB of free storage**, not Crostini or restricted Colab containers. Build is cross-architecture, and needs emulation to generate the Debian ARM64 image.

```bash
sudo apt update
sudo apt install -y ca-certificates curl build-essential pkg-config libssl-dev \
  gcc-aarch64-linux-gnu file qemu-system-arm qemu-user-static \
  debootstrap binfmt-support rsync e2fsprogs python3
# Install current stable Rust via rustup if `cargo --version` fails:
# curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
# source "$HOME/.cargo/env"
unzip Nova-OS-v0.72-Stabilization-RC1.zip
cd Nova-OS-v0.72-Stabilization-RC1
python3 scripts/preflight.py --strict-source
python3 -m unittest discover -s tests -v
./scripts/build-all-arm64.sh
```

**Do not claim successful boot from the disk image's existence.** Run the real QEMU test:

```bash
python3 vm/smoke-arm64-qemu.py --timeout 600
python3 scripts/release-gate.py --require-boot
# For two successive boot cycles and all build/test gates:
# ./scripts/stability-check.sh
```

The smoke harness starts QEMU with VNC on `127.0.0.1:5901`, waits for the ARM64 guest to report a healthy Rust bridge, original runtime daemon, native GUI event-loop heartbeat and a persistent file round-trip. It creates `vm/out/smoke-result.json` and `vm/out/smoke-serial.log`, then closes QEMU. It **cannot verify correct visual pixels or touchscreen gestures**, which need the manual test below. The smoke harness might fail on machines without a working virtual graphics backend; inspect the log rather than masking the failure.

For an interactive real graphical boot after the smoke test:

```bash
./vm/run-arm64-qemu.sh
# Or VNC: ./vm/run-arm64-qemu.sh --vnc
```

Click Home, Files, Settings, Notifications, Recent, Contacts and Photos; edit a file; reboot the guest and check persistence. **Observe the desktop inside the VM**, not merely in Chrome on the Ubuntu host.

Useful guest diagnostic commands (on the guest serial console):

```bash
systemctl status nova-shell nova-runtime nova-catalog --no-pager
journalctl -b -u nova-shell -u nova-runtime -u nova-catalog --no-pager
cat /home/nova/nova-desktop.log
cat /home/nova/weston.log
cat /var/lib/nova/runtime-status.json
```

`python3 scripts/release-gate.py` generates `verification-report-v0.72.json`. It clearly distinguishes source verified from ARM64 guest boot verified and **never claims production stability**.

## Acceptance criteria BEFORE choosing phone hardware

1. Source and native Rust workspace build pass without fallback (40 Python checks plus Rust tests and strict ARM64 builds).
2. QEMU boots repeatedly to Nova Qt on its **virtual display**; the smoke test passes.
3. Files, Settings, Contacts, local Notifications, Notes and Messages draft storage survive reboot.
4. Normal termination, crashed-client retry and service restart are observed in guest logs.
5. App lifecycle, process isolation and permissions receive security testing, with unsupported features disabled rather than simulated.
6. A conscious decision is made whether to **retain Linux + systemd + Weston as the long-term base** or fund a **true Nova compositor, Nova Init and graphical app-process integration**. Those are substantial missing projects, not checkbox builds.

## Explicitly NOT FINISHED

- Nova's own Wayland/DRM/KMS compositor rendering (Weston still in use).
- Nova Init as PID 1 (systemd still in use).
- All 12 original CLI binaries as independently launched graphical Nova apps. Qt screens call original Rust cores where the bridge supports them.
- Android APK compatibility, Android SDK/ART, Play Services, production sandbox and OTA updates.
- Real camera, microphone, SIM, voice calls, SMS, Wi-Fi/BT configuration, battery charging and phone drivers.
- Actual ARM64 QEMU boot success in this authoring environment and a manual graphical VM pass.

Because these are incomplete, **v0.72 is a tested development release candidate, NOT the stable final release before hardware**. Use the release gates to decide whether to continue to a qualified pre-hardware stable release.
