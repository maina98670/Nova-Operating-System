# Nova OS v0.74 — Native Mobile Apps Integration (development candidate)

## What this release actually is

A **source-preserving update** to v0.73. Uses the existing ARM64 Linux image builder, systemd, Weston Wayland compositor, Nova JSON backend, native Rust bridge, and independent Qt app process launcher. **No new kernel was developed or modified.** The goal is an Android-inspired *software experience*, not Android compatibility.

The native Qt launcher now has **eight additional apps**: Browser, Music, Clock, Store, Terminal, Email, Video Player and Calendar. Existing Files, Settings, Notes, Contacts, local Messages, Photos, Calculator, notifications, diagnostics, data packages, and recovery remain. New app state uses an unprivileged 0600-permission SQLite file with WAL transactions and 64 KiB per-record limits. Existing original Rust files, 104 Cargo workspace members and nine historical archives are preserved.

## New app functionality and honest limits

| App | Implemented in v0.74 | Unfinished / runtime dependency |
|---|---|---|
| Browser | Qt WebEngine widget, HTTP/HTTPS navigation, Back/Forward, bookmarks/history, explicit save-download selection | Engine requires PyQt WebEngine, real graphical session, substantial RAM; incomplete tabs/security audit |
| Music | Local audio file library, play/pause/stop, user-created playlists and track assignment | Qt Multimedia, GStreamer codecs and audio output; full playlist playback automation incomplete |
| Clock | Time display, stopwatch, countdown, saved alarms | Background delivery depends on `nova-reminders.service`; no hardware RTC/wake-from-suspend support |
| Store | Installs/removes existing checksum-verified Nova **data resource** bundles | Does NOT install executable apps, run APKs or have trusted signed app repository |
| Terminal | Shell command execution as unprivileged guest user, process output, stop command | Real arbitrary shell access; no per-app sandbox, use only in trusted development images |
| Email | Saved drafts; optional SMTP-over-TLS send and IMAP-over-TLS **header list**, password entered for each action | No OAuth2, full inbox sync, attachment handling or integrated keyring; never stores SMTP/IMAP passwords |
| Video Player | Local file selection, play/pause/stop, seek, video widget | Codec and graphical/audio device support required; subtitle picker/fullscreen incomplete |
| Calendar | Persistent events and background reminders | Basic event list; recurrence and sync not implemented |

Nova's native shell also includes **an on-screen typing keyboard** for Qt text inputs, launcher app search, separate Qt application windows via `QProcess` in guest sessions, and snapshots that can include the new mobile SQLite app data (live backups use SQLite's safe snapshot API). Restore **stages** recovered data for review rather than overwriting current files.

## 11 requested areas — real implementation status

1. **Visual UI** — existing launcher/navigation/theme/notifications + eight app icons, app search and on-screen keyboard. No production lock, complete gestures, split-screen or verified GPU acceleration.
2. **Multitasking** — separate Qt app processes under Weston on guest startup; launcher tracks PIDs and can stop apps. Not individual sandboxes, app suspension or Android's process lifecycle.
3. **Eight apps** — native Qt pages and functionality as detailed above; parts depend on codecs/network/configuration.
4. **Existing apps** — prior Qt and Rust-backed features retained, no real modem/camera integration.
5. **Nova services** — original Rust bridge/App Manager protocol preserved; background reminder service added. systemd still PID 1 and Weston still composes windows.
6. **Networking/multimedia** — HTTPS/SMTP/IMAP clients, Qt Multimedia and GStreamer guest dependencies. No physical Wi-Fi or Bluetooth APIs.
7. **Security** — original server request token and file confinement preserved, service run unprivileged, local data mode 0600, TLS mail connections, browser URL validation. **No per-app sandbox, secure session lock, secrets vault or complete security assessment.**
8. **Store/updates** — data-resource package installer reused; executable signatures, repository trust, OTA and A/B rollback not implemented.
9. **Accounts/personalization** — existing persistent preferences and wallpaper retained; app data persists; no multi-user identity or Kiswahili translation release gate.
10. **Performance** — bounded app data, separate processes, existing service memory limit. Neither 1 GB idle usage nor target FPS/boot time benchmarked.
11. **Recovery/stability** — existing backups and recovery staging, plus mobile SQLite snapshots and app tests; no production recovery partition or crash-free certification.

## Tests and verified claims

- Automated Python unit, integration, source, and script suite: **72 tests passed in the build environment**.
- Source audit: **104 original Cargo modules**, nine historical version archives, M0–M3 boot prototypes found.
- Release gate: source verified. **ARM64 image not built here; graphical QEMU boot is not verified**.
- No Qt native window was rendered in this execution environment (PyQt5/QEMU not installed); the optional Colab notebook can exercise this stage.

### Google Colab verification

1. Upload `Nova-OS-v0.74-Colab.ipynb` into Colab and run the cells.
2. When prompted upload `Nova-OS-v0.74-Mobile-Apps.zip`.
3. The notebook runs source/regression tests, attempts Rust build, starts the existing browser preview, and optionally installs Qt to render screenshots of all native pages. Colab does **not** boot the guest OS.

### Ubuntu ARM64 QEMU build

On a full Ubuntu host with QEMU/cross-building prerequisites (see older README files):

```bash
cd Nova-OS-v0.74-Mobile-Apps
./scripts/build-all-arm64.sh
python3 vm/smoke-arm64-qemu.py --timeout 600
./vm/run-arm64-qemu.sh
```

The image builder fetches Debian ARM64 packages over the network and requires sudo. It **refuses to overwrite an existing QEMU image**; do not delete a working image without a backup. Its intended boot is Linux → systemd → Nova Rust/JSON services → Weston → native Qt home and independent app windows. The old Nova Init and independent compositor sources remain preserved but aren't active in this guest.

On a native desktop Linux host with PyQt5 and QtWayland installed, run `./run-native-desktop.sh`.

## Acceptance gates still required before hardware

- Verified ARM64 guest boot and human-visible native Qt desktop on the QEMU display
- Actual click-through/functional tests of all eight apps in the guest
- Media playback and browser process tests at 1 GB and 2 GB allocated RAM
- Real executable package signing, app isolation, permissions enforcement, update/recovery design
- Verified persistent user data and functional reminders across guest reboot
- Hardening of Qt WebEngine, terminal exposure, auth, system startup and media handling

**Classification: v0.74 mobile software integration engineering preview; NOT final stable, not hardware-ready and not Android-equivalent.**
