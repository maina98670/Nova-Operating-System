# Nova OS v0.75 — Modern GUI + Connectivity (development release)

This is a source-preserving integration release based on Nova v0.74. **The existing Linux ARM64 kernel and system boot arrangement are unchanged.** The original 104 Rust workspace members and nine historical milestone packages remain intact.

## Implemented scope (the five requested areas)

| Area | Changes | Boundaries |
|---|---|---|
| 1. Modern interface | Reworked native Qt home layout, styled app tiles, gradient hero/status bar, refreshed browser-compatible preview and app drawer | Design and event-loop source tests, not a QEMU screen/graphics performance certification |
| 2. Wi-Fi and Bluetooth | New NetworkManager / BlueZ connectivity service and graphical Settings pages; real adapter detection, Wi-Fi networks, radio enable/disable, connect with password; Bluetooth device discovery, pairing and connection actions | **Mutations disabled by default.** Enable `NOVA_ENABLE_RADIO_CONTROL=1` only on an authorized Linux guest with real adapters, running services and permissions. Colab explicitly disables radio mutations. No simulated connection success. QEMU virtio Ethernet is not Wi-Fi. |
| 3. Status, quick settings, notifications | Real link and battery status, Bluetooth status, six control-center tiles, saved DND/brightness preferences, persisted notifications and marking as read | Brightness and volume are preferences, **not host hardware controls**. Battery may be unavailable. Notifications are local, not push. |
| 4. Multitasking / recent apps | Native Qt apps remain separate QProcess processes; running-app list with Switch and Close; child Qt apps receive focus requests through QLocalServer/QLocalSocket | Processes still share the same Linux user; Weston activation may prevent focus stealing. Colab preview shows recent *screens*, not OS processes. |
| 5. Battery, storage and device settings | Device/power page with battery / RAM / disk observations and stored preferences for brightness, volume, timeout, reduced motion. PIN-backed graphical session lock | PINs are scrypt-hashed and rate-limited; the lock is **only a GUI guard**, not disk encryption or OS authentication. Hardware backlight, audio mixer and sleep aren't actuated. |

## How to test in Colab

Upload the accompanying `Nova-OS-v0.75-Colab.ipynb` notebook to Google Colab. Run each cell in sequence and upload `Nova-OS-v0.75-Modern-Connectivity.zip` when prompted. The notebook runs all Python tests, attempts to compile the original Nova Rust bridge, starts the browser-compatible preview, and (if Qt dependencies install) renders native Qt pages offscreen.

## Host Linux GUI

```bash
cd Nova-OS-v0.75-Modern-Connectivity
./build-native.sh               # requires cargo; builds existing Nova Rust bridge
./run-native-desktop.sh           # requires PyQt5 and an X11/Wayland session
```

For a **permitted test VM with a passed-through Wi-Fi/Bluetooth adapter**, you can choose to enable radio operations when launching the backend:

```bash
NOVA_ENABLE_RADIO_CONTROL=1 ./run-native-desktop.sh
```

Use only on a VM/host where you are authorized to manage radios. This makes commands available; it does not create missing drivers or guarantee pairing. The Colab flag `NOVA_COLAB_MODE=1` always disables radio mutations.

## ARM64 QEMU builder (Ubuntu workstation, not Colab)

```bash
./scripts/build-all-arm64.sh
python3 vm/smoke-arm64-qemu.py --timeout 600
./vm/run-arm64-qemu.sh
```

**Not yet boot-tested in the build environment.** The builder includes `network-manager` and `bluez`; QEMU virtual Ethernet is still the actual networking device. Kernel, systemd and Weston remain in the guest boot chain.

## Verification and release criteria

```bash
python3 scripts/audit-source.py
python3 -m unittest discover -s tests -v
python3 scripts/release-gate.py
# Only on a system where an ARM64 image was built and a real smoke test completed:
python3 scripts/release-gate.py --require-boot
```

Source-level pass is not evidence of successful ARM64 GUI boot. This version is a functional software development candidate, **not a complete Android-class phone operating system**. Outstanding work includes true phone drivers, app sandboxes, system-wide lock enforcement, OTA, cellular calling, SMS, camera, native Nova compositor rendering, and full QEMU boot acceptance.

## Backups

Nova backup snapshots include the new `device-preferences.json`. PIN hash records in `lock.json` are deliberately **excluded**; recovered configurations must set up a new PIN. Original Rust core contacts are also excluded from current snapshot scope.
