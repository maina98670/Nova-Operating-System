# Nova OS v0.76 — Polished Experience (browser-first)

**Purpose:** Fix the poor and inconsistent browser UI in v0.75. This is a practical, testable *Linux-hosted Nova desktop preview*; it is **not** an independently booted ARM64 operating system, production Android replacement or tested mobile phone port.

## What changed

- New modern responsive Nova design: cohesive desktop/mobile home screen, custom icon styles, translucent control center, app drawer, dark/light mode, wallpaper choices and polished full-window app surfaces.
- **All eight v0.74/v0.75 apps are in the browser launcher** (Browser, Music, Clock, Store, Terminal, Email, Video and Calendar). No separate Qt viewer or port 6088 is necessary to find them.
- First-launch account creation and login with a password protected by **salted scrypt**, one local preview profile, session login/logout and throttling after failed attempts. This is not OS login or production-grade multiuser isolation.
- Real live time/date from the **client browser/system clock and timezone**, optional 12/24-hour format. Clock countdown and stopwatch; saved alarms and calendar events. **In the web preview, reminders are checked while the page is active; no guarantee of delivery when offline or closed**.
- Persistent app records in SQLite (`NOVA_MOBILE_DATA`, shared DB format with native Qt apps) for Clock, Calendar, Browser history/bookmarks, Email drafts, and more.
- Browser external link launcher with history/bookmarks, local Email drafts, local media playback (browser codec support required), secure-ish allowlisted diagnostics console, live device capabilities, original Files/Notes/Contacts and resource-package tools.
- Updated Quick Settings with saved preview preferences for brightness/volume, accurate unavailable-hardware labels. No radio state is faked.
- Existing v0.75 Qt source, original 104 Rust workspace members, all nine historical source packages, ARM64 build scripts, and original API endpoints preserved.

## Google Colab — easiest way to open

Use `Nova-OS-v0.76-Polished-Colab.ipynb`. Upload the notebook using **File → Upload notebook**, then run the cells and upload **the ZIP** at the archive prompt. The notebook performs extraction, runs the regression tests and starts Nova on **port 8796**, then opens the browser preview. It does **not** require PyQt5, Qt SIP, a VNC server, venv or a GPU.

## Launch on a Linux computer

From this extracted folder:

```bash
export NOVA_CONFIG_DIR="$HOME/.config/nova-os"
export NOVA_FILES_ROOT="$HOME/NovaFiles"
python3 graphics-shell/server.py --port 8796 --no-browser
```

Open `http://127.0.0.1:8796`. On first launch, create your one local preview account. On later launches, sign in with that password. Opening a new Colab runtime discards unmounted `/content` files; use Google Drive for backups if desired.

## Features by maturity

| Area | Status |
|---|---|
| Responsive Nova home, control center, first-run account, navigation | Implemented, browser interaction smoke-tested with mock services |
| Live time/date | Browser clock with local timezone; not hardcoded |
| Files, Contacts, Notes, Settings | Connected to existing local Nova backend and Rust bridge when present |
| Clock, Calendar | SQLite events/alarms; page-open reminder checks (native reminder service separate) |
| Browser | HTTPS/HTTP external tab launcher, history, bookmarks; not embedded browser engine |
| Email | Local drafts, no sending/sync in this browser preview |
| Music/Video | HTML media playback from Nova Files; limited browser codecs and 5 MB upload limit |
| Store | View/manage resource bundles; no executable app installer or APK support |
| Terminal | Read-only diagnostic command allowlist; not interactive Linux shell |
| Wi-Fi, Bluetooth, battery | Host capability observations, no claimed phone hardware support |
| Web account | One local scrypt-hashed preview profile; **NOT** OS security or sandbox |
| QEMU standalone graphical boot | **Not verified**; original Linux/systemd/Weston builder retained |
| Native Nova compositor, mobile drivers | Not completed |

## Security and limits

- The new portal protects its **new mobile data endpoints** with a time-limited session header. **Legacy preview APIs are retained for compatibility with Qt/Rust integrations and are not protected by this portal login.** Do not expose this development server to the public internet or store valuable secrets in it.
- Profile credential is stored in `NOVA_CONFIG_DIR/portal-account.json` as a salted scrypt hash. This is *excluded* from the ordinary Nova backup by design. There is no production password recovery flow.
- The app SQLite DB resides at `NOVA_MOBILE_DATA`, default `NOVA_CONFIG_DIR/mobile.sqlite3`, and is included in backup when configured. Backup and restore must still be validated against real boot/recovery scenarios.
- Native Qt and ARM64 boot code from v0.75 is preserved. The web shell is **not** an implementation of Nova's own Wayland compositor, systemd replacement, app-process sandbox, telephony, camera capture, or hardware Wi-Fi/Bluetooth.

## Validation

Run:

```bash
python3 -m unittest discover -s tests -q
python3 scripts/audit-source.py
node --check graphics-shell/static/modern.js
```

The new tests cover onboarding/login, invalid passwords, authorization for mobile storage, calendar record persistence, safe diagnostics, media confinement and compatibility with original endpoints. Layout is visually checked through static and mock-backed browser renders; this is not a successful end-to-end ARM64 QEMU boot.
