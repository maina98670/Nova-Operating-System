# Nova OS v0.77 Guide Continuation

This package continues the supplied v0.77 Boot to Home source. All 104 original
Rust workspace members, nine milestone archives and the complete build guide
are preserved. Public version remains **0.77**, as the included v0.77 release
notes require until the outstanding acceptance checks have passed.

## Changes

- QEMU defaults to **1024 MB**, matching the guide's low memory test requirement.
- Build and launcher scripts have executable permissions. The supplied ZIP
  stored them as non-executable, which broke nested `./scripts/...` calls.
- Every smoke attempt invalidates previous success evidence before checking
  prerequisites. A missing password, image or QEMU executable leaves a failure
  record instead of an old successful report.
- Boot evidence records the source fingerprint, disk/kernel/initramfs checksums,
  requested memory and M2 selection. Release checks reject changed artifacts,
  missing launcher DOM checks and truthy strings used in place of booleans.
- A requested M2 test cannot pass without the early init handoff serial markers.
- GUI health requires a fresh initialized login/home marker and at least eight
  launcher tiles. An empty or malformed launcher is not GUI readiness.
- `scripts/guide-status.py` reports the guide's exact named versions and the
  acceptance blockers. It does not promote a version based on source presence.
- Generated verification reports no longer invalidate the source integrity
  manifest merely by being regenerated.

## Guide version names

| Milestone | Version | Guide days |
|---|---|---|
| Boot Foundation M0 | v0.07 | 1 |
| Core OS M4 | v0.13 | 2 to 10 |
| IPC Applications and Sandboxing M5 | v0.20 | 11 to 17 |
| SDK M6 | v0.27 | 18 to 22 |
| GUI M7 | v0.33 | 23 to 28 |
| Networking M8 | v0.40 | 29 to 33 |
| Hardware Abstraction M9 | v0.47 | 34 to 39 |
| Security M10 | v0.53 | 40 to 45 |
| Packages M11 | v0.60 | 46 to 49 |
| Reference Device Port M12 | v0.67 | 50 to 65 |
| Hardware Integration M13 | v0.73 | 66 to 68 |
| Phone UX and System Apps M14 | v0.80 | 69 to 71 |
| Power Recovery and Updates M15 | v0.87 | 72 to 75 |
| Stability and Security M16 | v0.93 | 76 to 80 |
| Release Engineering M17 | v1.00 | 81 to 85 |

v0.77 is the existing intermediate integration label, not a named guide
milestone. The next named version above it is **v0.80**, but the guide requires
earlier acceptance gates first. In particular, a successful browser preview
cannot certify v0.67 reference-device bring-up or v0.73 hardware integration.

## Checks completed in this continuation

The Python suite ran 146 tests: **145 passed and one optional Chromium test
was skipped**. ARM64 compilation, a live QEMU graphical boot, whole-guest RAM
measurements and physical phone tests were not run here because the necessary
toolchain, emulator and hardware are absent. No flashable firmware is supplied.

The new tests exercise stale report invalidation, changed source/image
rejection, strict evidence types, required DOM readiness, missing M2 evidence,
guide version names, blocked milestone promotion and actual shell argument
construction at the 1 GB default. The shell-argument test uses an inert
argument recorder; it does not claim to boot a VM.

## Continue on Ubuntu or Debian

Extract this archive and open a terminal in its top-level directory. Python
3.11 or newer is required by the existing TOML tooling.

```bash
bash scripts/check-v077.sh
python3 scripts/guide-status.py
```

To build the ARM64 disk on a full non-root development account with sudo,
internet access and the dependencies documented in `README-BOOT-TO-HOME.md`:

```bash
bash scripts/build-all-arm64.sh
```

For unambiguous evidence, retain one matched `vmlinuz-VERSION` and
`initrd.img-VERSION` pair in `vm/out/rootfs/boot` before running the smoke test.
The harness hashes the stopped disk after the test; this can take time for a large image.
Supply a password specifically for this development VM, never a personal one:

```bash
read -rsp 'Nova test VM password: ' NOVA_SMOKE_PASSWORD; echo
export NOVA_SMOKE_PASSWORD
NOVA_VM_RAM_MB=1024 python3 vm/smoke-arm64-qemu.py --timeout 900
unset NOVA_SMOKE_PASSWORD
python3 scripts/release-gate.py --require-boot
NOVA_VM_RAM_MB=1024 bash vm/run-arm64-qemu.sh
```

To exercise the optional early-init handoff, add `--m2` to the smoke command.
By default the smoke command explicitly selects the normal systemd path, even
if the caller has exported an M2 selection elsewhere.

The smoke test checks the guest API, Qt DOM readiness and same-boot file
round trips. It does **not** prove pixels, persistence across a reboot,
separate native app lifecycle, phone drivers, calls, SMS, Android app execution,
or production security. Visually inspect the guest, then execute the guide's
remaining real-device checks before advancing the milestone label.

## Next acceptance work

1. Build and boot ARM64 at 1 GB; record the smoke report and inspect the display.
2. Execute the earlier guide's core runtime acceptance tests, including reboot
   persistence and actual per-app permissions, rather than inferring them from
   archived source.
3. Complete the chosen reference device's M12 and M13 hardware tests.
4. Complete M14's real phone app tasks, notification shade and device-state
   quick settings before naming an accepted release **v0.80**.

`python3 scripts/guide-status.py --require-next-milestone` intentionally exits
with status 2 while these real-device gates have not been implemented and run.
