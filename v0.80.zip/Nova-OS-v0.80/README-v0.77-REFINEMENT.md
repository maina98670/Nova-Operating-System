# Nova OS v0.77 — Same-version integration refinement

This is **Nova OS v0.77**, refined on top of the `Nova-OS-v0.77-Integration-Foundation` source. The public version **has not changed**. The original 104 Rust workspace members, historical nine source snapshots, application source, Linux ARM64 build pipeline, and the v0.77 APK staging module are preserved.

## What's new in this v0.77 package

- New browser **Performance** and **Device Readiness** apps showing real Linux host/guest metrics and explicit unverified release gates.
- Improved mobile launcher touch targets, keyboard focus, reduced-motion behavior and layout; retained all existing app pages, Wi-Fi/Bluetooth status, and browser-local real clock.
- Strict preview **account gate for private legacy APIs** when `NOVA_ENFORCE_AUTH=1` (enabled in ARM64 guest service and the included Colab test notebook). The account remains a browser session; **not OS-level sandboxing**.
- APK screen has manual Android app launch/uninstall controls, but only with explicit Waydroid opt-in and a working runtime; remote/browser-only previews cannot bypass runtime preflight.
- Added `scripts/android-live-acceptance.py` for a trusted test APK, requiring an explicit `--confirm`, and `scripts/verify-integrity.py` for a SHA-256 source integrity manifest.
- Added strict-login/performance acceptance tests, bringing the automated source/API suite to **114 checks**, plus a six-area status document explaining everything not yet operational.
- No Linux kernel changes, no new product version, no bundled Android operating system.

## Start the browser preview

```bash
cd Nova-OS-v0.77-Refined
./scripts/check-v077.sh
export NOVA_CONFIG_DIR="$HOME/.config/nova-os"
export NOVA_FILES_ROOT="$HOME/NovaFiles"
export NOVA_ENFORCE_AUTH=1
python3 graphics-shell/server.py --no-browser --port 8797
```

Open <http://127.0.0.1:8797>. Create a Nova preview account. You can now open all existing app pages, **Performance**, **Device Readiness**, and **Android Apps**. Use the included `Nova-OS-v0.77-Refined-Colab.ipynb` to run it inside Google Colab without Qt/SIP/VNC.

**Do not expose this development server on the public internet.** It lacks production-grade Linux user isolation and app sandboxing.

## What must still be tested before first phone

Read `docs/v0.77-SIX-AREA-COMPLETION-STATUS.md`. Important unsolved release blockers: ARM64 QEMU graphical boot not confirmed here, no production per-app sandbox, no executable native app store, actual Waydroid Android app execution not confirmed, 1–2 GB RAM/endurance testing not run, and no supported phone camera/telephony/Wi-Fi/Bluetooth driver integration. The graphical desktop on QEMU relies on Linux/systemd/Weston/Qt WebEngine; it is not Nova's own independent kernel/compositor.

The same v0.77 label will remain until these tests are satisfied; source/API test passes must not be mistaken for a hardware-ready OS.
