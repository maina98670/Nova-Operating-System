# Nova OS v0.77 — Fourteen-area Integration Foundation

This is a **development build**, based on v0.76, preserving **104 original Rust workspace members** and **nine milestone archives**. The original ARM64 Linux kernel is unchanged. It is **not** a completed Android replacement, a phone-ready firmware image, or an Android runtime bundled into Nova.

## Improvements made in this build

- Single modern **browser-first Nova home screen** with all eight added apps and legacy app screens, first-run account and login, live clock, preferences, persistent SQLite app data, resource packages, Wi-Fi/Bluetooth capability reporting and backup tools retained.
- New **Android Apps** launcher screen: runtime preflight, device capability status, authenticated APK staging, streamed upload (maximum 100 MiB), SHA-256 content verification, structural APK ZIP inspection, ABI hints and an explicit warning that APK signatures are **not** yet verified.
- Optional **Waydroid** adapter for reading installed Android packages, installing, launching and uninstalling apps on a properly configured **local Linux Wayland host**. No automatic privilege elevation, container boot, image installation or executable app install happens in Colab.
- Runtime actions require both `NOVA_ENABLE_ANDROID_RUNTIME=1` and a working Waydroid Binder/Wayland/session preflight, plus direct loopback HTTP request. **Default: disabled**.
- New **Release Status** application reports 14 project components with explicit unverified requirements; preserving source alone does not mark services complete.
- Updated **guest desktop startup** to launch `native-shell/modern_webview.py`, a native Qt WebEngine **Wayland client** loading the unified Nova browser shell, instead of the older inconsistent native UI. Weston/systemd still provide compositor/startup and the web engine is Chromium-derived internally. This boot path is **not yet QEMU-tested**.
- Expanded security/regression tests for APK staging, bad archives, authentication, disabled runtime and the 14-area readiness report.

## The 14 areas and their current maturity

1. ARM64 boot — existing builder retained, QEMU boot not verified in this release.
2. Nova Init and services — existing systemd/Rust bridge, Nova Init is not PID 1.
3. Native graphics — Qt WebEngine Wayland client, Weston remains compositor.
4. App Manager — Qt process launcher retained, Android application switching pending runtime tests.
5. Processes and memory — service limits and system info, mobile OOM policy incomplete.
6. Nova IPC — original Rust protocols preserved, guest runtime requires full test.
7. Storage — real files, SQLite, settings, guest reboot persistence unverified.
8. Security — portal sessions, file confinement and Linux service hardening; **not** Android-like app sandboxing.
9. Nova packages — data-resource packages, not signed executable app packages.
10. Modern UI — browser-first shell; gestures/native GPU rendering require more work.
11. Networking and audio — capability probes and media playback via browser; actual radio and speaker controls not verified.
12. Updates/recovery — backup and staging; no signed A/B OS OTA.
13. **APK installer — APK upload and inspection implemented; live install unverified**.
14. **Android Compatibility Layer — Waydroid optional integration preflight, not installed/bundled/boot-tested**.

## Run in Google Colab (browser preview)

Use `Nova-OS-v0.77-Colab.ipynb`. It needs the ZIP and a CPU runtime, **not PyQt5, SIP, VNC, QEMU or a Waydroid container**. It runs the project tests, starts the browser preview at port **8797**, and opens it in Colab. Create your account, then open **Android Apps** and **Release Status** from the home screen.

## Run on Ubuntu (browser interface)

```bash
cd Nova-OS-v0.77-Integration-Foundation
./scripts/check-v077.sh
export NOVA_CONFIG_DIR="$HOME/.config/nova-os"
export NOVA_FILES_ROOT="$HOME/NovaFiles"
python3 graphics-shell/server.py --no-browser --port 8797
```

Open `http://127.0.0.1:8797` in a browser. The embedded Qt Wayland client additionally requires a full desktop with Python Qt WebEngine bindings installed; it is not necessary for browser preview.

## Optional Android runtime prerequisites (not available in Colab)

Waydroid requires a supported Linux kernel, Binder, container support, a compatible Android image, and a working Wayland graphical session. Do **not** enable Android execution on an internet-facing Nova preview. Follow the official Waydroid installation docs for the specific Debian/Ubuntu release, then confirm the container is initialized/running and run:

```bash
python3 scripts/android-preflight.py
# In a trusted local development session only, after Waydroid works:
NOVA_ENABLE_ANDROID_RUNTIME=1 python3 graphics-shell/server.py --port 8797 --no-browser
```

The browser APK installer can stage APKs in Colab but **cannot execute them there**. When Waydroid is available, Android Package Manager performs the real install/signing and compatibility checks. Some apps need Play Services, DRM, specific ABIs/hardware, or certification; none is guaranteed. Android-compatible features are optional because low-memory targets may not accommodate a full container.

Official documentation: https://docs.waydro.id/usage/install-on-desktops and https://docs.waydro.id/usage/install-and-run-android-applications.

## Release verification

```bash
./scripts/check-v077.sh
# On a supported Ubuntu ARM64/QEMU-capable build host, with prerequisites:
./scripts/build-all-arm64.sh
python3 vm/smoke-arm64-qemu.py --timeout 600
./vm/run-arm64-qemu.sh
```

Automated source/API tests do not certify the ARM64 guest display, audio/video, native app multitasking, Android runtime, or hardware. Run those on an appropriate host and keep any failures as blockers before hardware porting.
