# Nova OS v0.77 — M0–M3 actual boot integration

The four original milestone sources are preserved at `boot/legacy/m0...m3`. This directory integrates them with the modern v0.77 **existing Linux-based** Debian ARM64 guest while preserving a recoverable systemd/Weston path.

| Milestone | v0.77 runtime integration | Status |
|---|---|---|
| M0 boot | ARM64 Linux, initramfs, virtio devices and QEMU disk | Builder present; boot unverified here |
| M1 display | Original M2-version DRM splash binary and splash.raw installed; best-effort systemd startup before GUI | ARM64 artifact validated; display not observed |
| M2 Nova Init | Rust `nova-early-init` based on M2 concepts; mounts core pseudo-filesystems, starts original splash, then **execs systemd as PID 1** | Source implemented; compile + live boot required |
| M3 display | Original `nova-display.c` and Meson project remain intact; guest can select `nova` **only if** a compatible ARM64 wlroots 0.17 binary is provided | Original binary not built/tested here; Weston is default fallback |

**Do not confuse this M2 early PID 1 handoff with the original M2 supervisor as a permanent service manager.** Keeping the latter running would strand current systemd services, so the new program hands off to systemd. Similarly, preserving the original M3 code is not proof that it renders pixels in the target guest.

## Build all four into the development guest (Ubuntu host)

Install cross Rust target, gcc-aarch64-linux-gnu, and QEMU dependencies from the v0.77 README, then:

```bash
./scripts/build-m0-m3-arm64.sh
./scripts/build-all-arm64.sh
./vm/run-arm64-qemu.sh
```

The full build compiles and installs `nova-early-init`, validates ARM64 ELF headers and packages the M1 splash in the guest. The default display remains Weston until M3 is verified. To exercise the optional M2 boot handoff, run:

```bash
NOVA_ENABLE_M2_INIT=1 ./vm/run-arm64-qemu.sh
```

Check serial logs for `M0 ARM64 Linux boot reached Nova early init` and `M2 handoff`. If no GUI, reboot in default mode `./vm/run-arm64-qemu.sh` and inspect logs.

## M3 compositor path

The original `nova-display.c` uses the **wlroots 0.17 API**. Debian release repositories may provide a different version; installing a newer wlroots does not make this C source compatible. To attempt compilation **during the image build**, use a compatible Debian ARM64 repository with `libwlroots-0.17-dev` and run the image builder using:

```bash
NOVA_BUILD_M3=1 NOVA_COMPOSITOR_DEFAULT=nova ./scripts/build-all-arm64.sh
```

This will fail clearly rather than install a newer incompatible wlroots. The build must occur **before** creation of the ext4 guest image. For a binary compiled separately against guest-compatible ARM64 libraries, provide `NOVA_M3_BIN=/absolute/path/to/nova-display` to the image builder.

Then edit `/etc/nova/boot.conf` in the guest to `NOVA_COMPOSITOR=nova`. The session script attempts M3 and falls back to Weston if the compositor exits before a client connects. **An M3 binary is required, and successful graphics rendering is still a separate acceptance gate.**

## Safety/limits

- No flashing, unlocking, boot partition changes, or mobile driver claims.
- QEMU first, followed by actual ARM64 phone-porting work for a named device.
- You must visually verify the splash, compositor, Qt app navigation and restart/recovery in a real VM before declaring hardware readiness.
