//! Nova v0.77 M0-M2 early boot handoff.
//! Reuses M2's mount/splash/reaping concepts; hands PID 1 over to systemd
//! so all existing v0.77 Rust, Python, Qt and networking services can start.
//! This is NOT a replacement for a complete production Nova service manager.
use std::ffi::CString;
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::Command;
use std::time::{Duration, Instant};

const SPLASH: &str = "/opt/nova/bin/nova-splash";
const SYSTEMD_PATHS: &[&str] = &["/lib/systemd/systemd", "/usr/lib/systemd/systemd"];

fn msg(message: &str) { eprintln!("nova-early-init: {message}"); }

fn mount_fs(source: &str, target: &str, fs: &str) {
    let _ = std::fs::create_dir_all(target);
    let src = CString::new(source).unwrap();
    let dst = CString::new(target).unwrap();
    let fs = CString::new(fs).unwrap();
    let code = unsafe { libc::mount(src.as_ptr(), dst.as_ptr(), fs.as_ptr(), 0, std::ptr::null()) };
    if code != 0 && std::io::Error::last_os_error().raw_os_error() != Some(libc::EBUSY) {
        msg(&format!("mount {target} unavailable: {}", std::io::Error::last_os_error()));
    }
}

fn splash() {
    if !Path::new(SPLASH).exists() { msg("M1 splash absent; continuing"); return; }
    // DRM devices may appear after root mounting. Do not hold up a boot indefinitely.
    let until = Instant::now() + Duration::from_secs(3);
    while !Path::new("/dev/dri/card0").exists() && Instant::now() < until {
        std::thread::sleep(Duration::from_millis(100));
    }
    if !Path::new("/dev/dri/card0").exists() { msg("No DRM card yet; splash skipped"); return; }
    let mut fds = [0i32; 2];
    if unsafe { libc::pipe(fds.as_mut_ptr()) } != 0 { msg("Splash status pipe unavailable"); return; }
    let (r, w) = (fds[0], fds[1]);
    let spawn = unsafe {
        Command::new(SPLASH).pre_exec(move || {
            // The original M2 splash reports first pixels over fd 3.
            libc::close(r);
            if libc::dup2(w, 3) < 0 { return Err(std::io::Error::last_os_error()); }
            if w != 3 { libc::close(w); }
            Ok(())
        }).spawn()
    };
    unsafe { libc::close(w); }
    match spawn {
        Ok(mut child) => {
            let mut pollfd = libc::pollfd { fd: r, events: libc::POLLIN | libc::POLLHUP, revents: 0 };
            let result = unsafe { libc::poll(&mut pollfd, 1, 4000) };
            let mut b = [0u8; 1];
            let got = if result > 0 { unsafe { libc::read(r, b.as_mut_ptr().cast(), 1) } } else { -1 };
            if got == 1 { msg("M1/M2 splash signalled first pixel"); }
            else { msg("Splash did not signal a framebuffer; continuing"); }
            // The DRM master must not remain held when the compositor starts.
            if child.try_wait().ok().flatten().is_none() { let _ = child.kill(); }
            let _ = child.wait();
        }
        Err(e) => msg(&format!("splash failed to start: {e}")),
    }
    unsafe { libc::close(r); }
}

fn main() {
    if std::env::args().any(|x| x == "--check") {
        println!("nova-early-init v0.77; early PID1 mount -> M1 splash -> systemd handoff");
        return;
    }
    let pid = unsafe { libc::getpid() };
    if pid != 1 { msg("must be launched as PID 1; use init= kernel parameter"); std::process::exit(2); }
    msg("M0 ARM64 Linux boot reached Nova early init as PID 1");
    mount_fs("proc", "/proc", "proc");
    mount_fs("sysfs", "/sys", "sysfs");
    mount_fs("devtmpfs", "/dev", "devtmpfs");
    splash();
    for path in SYSTEMD_PATHS {
        if Path::new(path).exists() {
            msg(&format!("M2 handoff: exec {path} as PID 1; Nova service units start next"));
            let err = Command::new(path).exec();
            msg(&format!("handoff failure at {path}: {err}"));
        }
    }
    msg("FATAL: no usable systemd executable. Keeping PID 1 alive for serial diagnostics.");
    loop { std::thread::sleep(Duration::from_secs(60)); }
}
