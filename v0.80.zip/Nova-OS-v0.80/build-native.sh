#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v cargo >/dev/null 2>&1; then
  echo 'Rust/Cargo not found. Install: https://rustup.rs/ or sudo apt install cargo rustc' >&2
  exit 2
fi
cargo build --release --manifest-path native-bridge/Cargo.toml
NOVA_CORE_ROOT="$(pwd)/.nova-build-test" native-bridge/target/release/nova-graphics-bridge <<<'{"cmd":"health"}'
rm -rf .nova-build-test
printf 'Nova Rust core bridge ready. Launch: ./run-integrated.sh\n'
