# v0.74 implementation gates

| Area | Status |
|---|---|
| 1. GUI | Qt app launcher, theme, widgets, on-screen keyboard; native window checks pending |
| 2. Multitasking | Separate Qt processes using QProcess when NOVA_SEPARATE_APPS=1; no secure sandbox or app suspension |
| 3. Eight apps | Native implementations of Browser, Music, Clock, Store, Terminal, Email, Video, Calendar; dependencies/feature gaps detailed in README-v0.74.md |
| 4. Existing apps | Retained v0.73 Rust bridge, Qt and preview apps |
| 5. System services | Existing Rust bridge + reminder service; systemd and Weston active |
| 6. Networking/media | Qt WebEngine, Qt Multimedia, GStreamer and TLS email clients; virtual guest devices unverified |
| 7. Security | Existing API token/file confinement + data 0600; no production per-app sandbox/authentication/verified boot |
| 8. Store/updates | Verified resource ZIP install/uninstall; no executable app packages or trusted OTA |
| 9. User preferences | Persistent prefs, bookmarks, media lists, drafts, calendar and alarms; no multiuser OS accounts |
| 10. Performance | Unmeasured. 1 GB/2 GB RAM, 60 FPS and cold boot gates still outstanding |
| 11. Recovery | Existing staged restore + consistent SQLite app-data snapshots |

## Verification

- Automated Python source/integration tests: 72 passing
- Original source inventory: 104 Rust modules and nine historical milestone archives preserved
- ARM64 QEMU boot test: **not run in current environment**
- Interactive native Qt desktop: **not run in current environment**
- Full phone hardware/Android APK compatibility: **not supported by this build**

This is a **development candidate**, not a final stable release.
