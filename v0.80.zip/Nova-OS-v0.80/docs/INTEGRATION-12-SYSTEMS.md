# Nova OS v0.73 — Twelve-system integration evidence

**This is an engineering preview, not a finished Android alternative.** The original Nova v0.60 source and all nine historical snapshots remain preserved. Source inclusion does not imply an app runs as a service. The native Qt Wayland client uses the original Rust settings/contacts/files/messages bridge (messages read-only in Rust), and the original App Manager and compositor **protocol/state** daemon remains a separate process when built.

| Goal | What the v0.73 build actually does | Remaining blocker |
| --- | --- | --- |
| 1. ARM64 kernel and boot | Debian Linux ARM64 QEMU image builder + smoke harness | Need real repeated QEMU boot verification |
| 2. Nova Init and services | systemd dependency-managed Nova services, bounded restart and health probes | Original Nova Init not PID 1 |
| 3. Nova compositor | Native Qt on Weston Wayland, desktop shell permits child windows | Nova’s own DRM/KMS compositor still not a pixel renderer |
| 4. App Manager | Original Rust protocol daemon; Qt launcher can create managed separate Qt **processes** in guest | Original 12 Rust CLI apps not all independent graphics apps |
| 5. Process/memory | Child-process lifecycle controls and systemd memory/task limits | Low-memory process suspension and per-app resource isolation not done |
| 6. IPC | Rust IPC/protocol source and local JSON API to Rust bridge | End-to-end QEMU daemon tests required |
| 7. Files | Real file operations and crash-resistant private JSON | Reboot persistence not verified in VM |
| 8. Security | API mutation token, path boundary checks, hardening flags for services | Not a production per-app sandbox; GET API access remains local-development trust model |
| 9. Package Manager | Checksum-verified *data-only* Nova resource packages install and uninstall | No signed trusted native executable packages or APK support |
| 10. Mobile UI | Qt launcher, recent separate-process list, native GUI views, notifications | No completed lockscreen, gestures, phone input stack |
| 11. Networking/audio | Kernel net and sound-device observations; virtio networking in QEMU | No Wi-Fi pairing, Bluetooth, voice calls or complete audio routing |
| 12. Recovery | Non-destructive user data snapshots and recovery staging; boot smoke diagnostics | No automatic A/B OTA rollback or secure full-system recovery |

### What independent native app windows actually mean

Set `NOVA_SEPARATE_APPS=1` (automatically set in the QEMU desktop session) and launch an application from the Qt launcher. The shell starts the **same Nova Qt frontend in a new Linux process** focused on that app’s view, with a fixed argument allowlist. This is a valid process-level lifecycle test but **not** the original Rust app binary, not a sandbox, and not an Android task manager. Child processes use the same Linux user and Rust-backed API. Stop a child in the `Recent` screen. Weston desktop-shell supplies multitasking window management; kiosk-shell was intentionally removed for this preview.

### Nova resource package manifest

The data-only installer accepts a ZIP of at most 4 MB with exactly one `manifest.json` and a list of resource files. Example:

```json
{"schema":1,"id":"org.nova.demo","name":"Demo","version":"1.0.0",
 "files":{"resources/readme.txt":"<64-character sha256 hex of file bytes>"}}
```

These checksums prevent accidental byte mismatch but **are not publisher signatures**. No executable package code is launched from this installer; do not call it a full app store.

### Local source + API verification

```bash
python3 -m unittest discover -s tests -v
python3 scripts/preflight.py --strict-source
python3 scripts/verify-12-systems.py
python3 scripts/release-gate.py
```

### Full ARM64 boot on Ubuntu

```bash
./scripts/build-all-arm64.sh
python3 vm/smoke-arm64-qemu.py --timeout 600
python3 scripts/release-gate.py --require-boot
./vm/run-arm64-qemu.sh
```

The QEMU smoke test proves API/Rust/runtime/GUI event-loop reporting and a file round trip; a human must inspect actual virtual display pixels, open/close separate app windows, test persistence after reboot and inspect journal logs. **No ARM64 guest boot was verified in the authoring environment.**

### Recovery

Nova `Recovery` makes a local ZIP of GUI settings, notes, drafts, fallback contacts, notifications and `NovaFiles` under a size cap. Files reachable only through symlinks are excluded. Restore always stages the backed-up files in a separate directory and does **not** replace live data. The original Rust core database, system rootfs and installed executable apps are not backed up by this function. It is a preview backup facility, not a fully verified OS recovery solution.

### Pre-hardware acceptance gate

Do not call Nova production stable until repeated QEMU boots, visual QA, original Rust daemon execution, multi-app lifecycle, security isolation, persistent data across reboots, low-memory checks and recovery have been demonstrated with logs. Hardware-dependent telephony, Wi-Fi, camera, battery and sensors cannot be certified without a supported phone.
