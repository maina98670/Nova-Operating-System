# Nova maintenance development tools

These tools extend the existing Linux-hosted Nova source. They operate on a
dedicated directory and selected child processes. They do not create a new
kernel, port a phone, install a physical recovery partition, or implement a
production bootloader. Run the source/API checks before use.

## Dependencies

Use Python 3.11 or newer. The base preview needs the standard library. Signed
update and release commands additionally need python3-cryptography. On a Debian
or Ubuntu development host, install the distribution package or use an isolated
Python environment with requirements-maintenance.txt.

## v0.67 and v0.73 hardware evidence

```bash
python3 scripts/nova-maintenance.py hardware-status
python3 scripts/nova-maintenance.py hardware-evidence --evidence evidence/hardware.json
python3 scripts/nova-maintenance.py hardware-evidence --evidence evidence/hardware.json --integration
```

The first command reports actual node presence while leaving functions
unverified. The evidence validator requires one exact device and boot session,
measured component results and matching evidence-file hashes. The integration
check additionally requires camera, audio, Wi-Fi and touch active together.
These are operator-recorded observations; a passed schema check cannot replace
independent physical testing. The included template intentionally fails.

## v0.87 signed image staging

Generate development keys outside the source tree. Keep the private key local;
provide a separately trusted public key to the verifier. A bundled public key
alone does not establish publisher identity.

```bash
python3 scripts/nova-maintenance.py keygen --private /tmp/nova-dev-key.pem --public /tmp/nova-dev-public.pem
python3 scripts/nova-maintenance.py bundle --rootfs vm/out/nova-arm64.ext4 --kernel /path/to/ARM64-kernel --initramfs /path/to/ARM64-initramfs --version 0.80 --device qemu-virt-arm64 --private-key /tmp/nova-dev-key.pem --output /tmp/nova-initial.zip
python3 scripts/nova-maintenance.py initialize --workspace /tmp/nova-device-workspace --bundle /tmp/nova-initial.zip --public-key /tmp/nova-dev-public.pem --device qemu-virt-arm64
```

The workspace must be empty before initialization. Build a subsequent bundle
with a newer guide version, then stage and test it:

```bash
python3 scripts/nova-maintenance.py stage-update --workspace /tmp/nova-device-workspace --bundle /tmp/nova-newer.zip --public-key /tmp/nova-dev-public.pem
NOVA_UPDATE_WORKSPACE=/tmp/nova-device-workspace bash vm/run-arm64-qemu.sh
python3 scripts/nova-maintenance.py mark-healthy --workspace /tmp/nova-device-workspace
```

Inspect the guest before marking it healthy. Two unacknowledged trials cause
the next selection to choose the last accepted slot. A wrong device, invalid
signature, damaged image, replayed version or unexpected ZIP entry is rejected.
The signed templates remain immutable; QEMU boots separate writable copies.
This is file-based A/B selection. Shared guest user-data migration between
slots, physical bootloader integration, production anti-rollback counters and
network OTA transport remain unimplemented. The standard smoke harness does
not certify the optional A/B boot path.

## Data backup and restoration

These commands affect only userdata inside the initialized workspace. They do
not automatically back up the current preview account or guest filesystem.
To test real Nova data, configure the app data under that userdata directory
or copy it there after stopping the app. Avoid concurrent application writes
when taking a multi-file snapshot; SQLite files use the SQLite backup API.

```bash
python3 scripts/nova-maintenance.py backup --workspace /tmp/nova-device-workspace
python3 scripts/nova-maintenance.py restore --workspace /tmp/nova-device-workspace --name nova-data-RETURNED_ID.zip
python3 scripts/nova-maintenance.py reset-data --workspace /tmp/nova-device-workspace
python3 scripts/nova-maintenance.py repair-restore --workspace /tmp/nova-device-workspace
```

Restore checks every backup file before switching live userdata. Previous data
is retained under userdata-before-ID. Reset quarantines the previous directory
instead of erasing it. The recovery journal supports repair after interruption.
The backup limit is 128 MB for this development implementation. Backups are
private but not encrypted; they can contain application data.

## Power

```bash
python3 scripts/nova-maintenance.py power-status
# On the intended local device only; this can suspend that device:
NOVA_ENABLE_POWER_CONTROL=1 python3 scripts/nova-maintenance.py suspend --confirm
```

Status reads Linux power and battery interfaces. The suspend adapter calls the
local power manager only after explicit opt-in. No sleep, wake, idle power or
battery-life measurements have been made on a physical reference phone here.

## v0.93 stability observation

```bash
python3 scripts/nova-maintenance.py soak --output /tmp/nova-short-check.json --duration-seconds 2 --interval-seconds 1
python3 scripts/nova-maintenance.py soak --output /path/to/evidence/soak.json --duration-seconds 172800 --interval-seconds 60 --device-id EXACT_REFERENCE_DEVICE --health-url http://127.0.0.1:8767/api/health
```

The second command is a real two-day run; it is supplied for execution on the
reference device and was not run here. Each run records elapsed monotonic time,
boot identity, memory and optional local service health. Interrupted and short
runs cannot pass the duration condition. Memory-leak, suspend/wake, battery and
security-boundary results still need explicit physical tests. No report from
this collector alone marks the guide milestone accepted.

## v1.00 watchdog and signed source release

```bash
python3 scripts/nova-maintenance.py watchdog --output /tmp/nova-child-crash.json --timeout 10 -- python3 /path/to/test_service.py
python3 scripts/nova-maintenance.py package-source --output /tmp/Nova-source.zip --private-key /tmp/nova-dev-key.pem --public-key /tmp/nova-dev-public.pem
python3 scripts/nova-maintenance.py verify-release --archive /tmp/Nova-source.zip --signed-manifest /tmp/Nova-source.zip.signed.json --public-key /tmp/nova-dev-public.pem
```

The watchdog controls only its own launched child and produces a private exit
or timeout report. With --workspace it also discards a pending directory A/B
update after a failed child. It is not a kernel watchdog or a phone-wide hang
recovery system. Output and environment are not collected by default.

Source archives have stable file order, fixed ZIP timestamps and executable
modes, and exclude private key files and runtime databases. They are source
packages, not bootable images. Add --require-final-acceptance to package-source
to require the guide's final physical-device evidence. The provided acceptance
template remains unverified and this gate intentionally fails.

## References

Ed25519 API: https://cryptography.io/en/latest/hazmat/primitives/asymmetric/ed25519/
Linux power manager: https://www.freedesktop.org/software/systemd/man/latest/systemctl.html
