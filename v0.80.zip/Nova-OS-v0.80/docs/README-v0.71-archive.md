# Nova OS v0.71 — Native Graphical Integration

**Start here:** [README-v0.71.md](README-v0.71.md). The following is the previous v0.70 guide, preserved for reference.

---

# Nova OS v0.70 — Original Source Integration + ARM64 Boot Pipeline

**Built from your v0.69 source, retaining all nine original Nova milestone archives (v0.07–v0.60), the M0–M3 boot prototypes, and every one of the 104 original v0.60 Rust workspace members.** This is a more integrated *development OS builder*, **not** a finished Android alternative.

## What is now connected

- **Original Nova cores**: the working v0.68/v0.69 JSON Rust bridge links real original Settings, Contacts, file-system and read-only Messages libraries. These passed user tests on Colab for v0.69; v0.70's modified package still requires independent Rust build/boot verification.
- **Original Nova App Manager and Compositor protocol**: `native-runtime/` now links `nova-app-manager`, `nova-compositor-core`, `nova-ipc` and `nova-fsmgr` in one *long-lived process*. The builder installs this as `nova-runtime.service` if and only if the ARM64 executable is compiled. This compositor protocol **does not render graphics**, and the original apps are **not yet graphical programs**.
- **Original apps and tools**: all 12 app projects, 48 libraries, and 44 tools are indexed in `integration/registry.json`. The optional ARM64 workspace build stages only the 12 original application executables and 3 intentional CLI tools. Dangerous/hostile/acceptance-test tools are never autostarted. Manifests and binaries of built apps are installed into canonical `/apps/org.nova.*/` layout, for the original App Manager to discover.
- **Preservation inside boot image**: all nine source snapshots, original boot prototypes, original Rust workspace and integration manifest are placed under `/opt/nova` in the guest, not falsely treated as boot daemons.
- **Service/boot status**: `nova-catalog.service` inspects the actual runtime and writes state. The hosted GUI has a **Components** screen showing all 104 modules, staged binary count, Rust bridge status and active guest service status.
- **Boot path**: ARM64 Linux kernel -> systemd -> original Nova App Manager/protocol daemon (if compiled) and Rust core bridge -> Python graphical app backend -> Weston -> Chromium kiosk presenting Nova UI on the QEMU screen.

### Non-negotiable limitations

1. **This archive is source and image-builder scripts, not a pre-built `.img`.** Host environment here lacks Rust, QEMU and cross-build tooling; ARM64 compilation, Debian guest image creation and complete QEMU graphical boot have **not been run** here.
2. **Not every crate is a running daemon**. Forty-eight are libraries; forty-four are development, CLI or acceptance-test tools. Compiling them and preserving their files is different from creating a production runtime and drivers.
3. The **original Nova Init is not PID 1** (systemd is), and the original **Nova compositor is not a pixel renderer** (Weston/Chromium is the actual guest display). Existing Nova Rust app executables mostly demonstrate protocol/data logic, not native touch UI.
4. Mobile functions such as SIM/calls/SMS, Wi-Fi management, camera capture, Bluetooth, audio and battery still need supported real phone hardware drivers, proper permissions and implementation. QEMU does not supply them automatically.
5. This development image uses **automatic login** and has not undergone production security validation. **Do not deploy on a phone** or expose the development service to the public internet.

## Test source + graphical components in Google Colab

Use `Nova-OS-v0.70-Colab.ipynb` (distributed alongside this ZIP). Colab verifies source, Python tests, native Rust bridge when compiled, and the interactive web GUI. The Components app will show all original source crates. Colab **does not** boot an ARM64 guest, and Linux's `eth0` is not proof of Wi-Fi on a phone.

## Build the full ARM64 development boot image on Ubuntu

Requirements: 64-bit Ubuntu/Debian, sudo, functioning binfmt_misc for ARM64, Rust stable and rustup, `gcc-aarch64-linux-gnu`, `file`, `curl`, internet for Debian packages, 10+ GiB free disk, QEMU system emulation and ideally a graphical desktop (or use `--vnc`). Install:

```bash
sudo apt update
sudo apt install -y curl ca-certificates build-essential pkg-config libssl-dev \
  gcc-aarch64-linux-gnu file qemu-system-arm debootstrap qemu-user-static \
  binfmt-support rsync e2fsprogs python3
# If cargo is missing, follow official rustup installation instructions.
# Verify `cargo --version` and `rustup --version` before building.
```

Then run **from the extracted package directory**:

```bash
python3 scripts/audit-source.py
python3 -m unittest discover -s tests -v
./scripts/build-all-arm64.sh
./vm/run-arm64-qemu.sh
```

The build script intentionally fails if any original workspace build, ARM64 binaries, Rust bridge, Nova daemon, or required boot component cannot be produced. It does not quietly replace missing original code with Python. If host Rust tests fail due an existing source issue and you want only a *cross-compilation diagnostic*, use `NOVA_SKIP_HOST_RUST_TESTS=1 ./scripts/build-all-arm64.sh` (still fails if the original cross-build fails).

After image creation, the file should be `vm/out/nova-arm64.ext4`; kernel and initrd remain in `vm/out/rootfs/boot/`. Because building uses `debootstrap`, the builder requires a fully functional Ubuntu/Debian host with privileged binfmt/chroot. It refuses to overwrite the existing `.ext4` disk, protecting stored VM data. To view remotely, use `./vm/run-arm64-qemu.sh --vnc` and connect to the local VNC port 5901. For serial diagnostics only use `--headless`.

Check the actual guest after boot:

```bash
systemctl status nova-shell nova-catalog nova-runtime --no-pager
ls -l /run/nova/*.sock
journalctl -b -u nova-runtime -u nova-shell -u nova-catalog --no-pager
cat /var/lib/nova/runtime-status.json
```

The first expected test is **successful ARM64 Linux boot and display of the Nova home screen *inside QEMU*, not merely a browser running on Colab**. If the original daemon is active, `/run/nova/app-manager.sock` and the Nova compositor protocol socket should exist. That does **not** indicate native pixels/Wayland surface rendering by Nova itself.

## Project structure

| Directory | Purpose |
|---|---|
| `source-v0.60/` | Unmodified canonical original 104-member Rust source tree |
| `history/` | Complete guide and nine historical milestone ZIPs |
| `boot/legacy/` | Original M0–M3 startup and compositor prototypes |
| `native-bridge/` | Working original Rust settings/contacts/files/messages core adapter |
| `native-runtime/` | **New** process integrating original App Manager and compositor IPC protocol |
| `integration/` | Complete 104-member source registry + truthful runtime/boot detector |
| `graphics-shell/` | Working browser-based Nova home and apps; adds Components screen |
| `scripts/` | Strict original source tests, ARM64 all-workspace build, binary staging, artifact check |
| `vm/` | QEMU ARM64 Linux rootfs/disk builder and guest systemd services |

**Next necessary development after a verified boot**: real Wayland/Smithay pixel compositor + native window UI for Rust apps, App Manager activation from graphical launcher, actual Nova Init replacement only after verified PID 1 semantics, and actual smartphone hardware/driver portability.
