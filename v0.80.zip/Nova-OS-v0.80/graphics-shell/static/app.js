'use strict';
const $ = (id) => document.getElementById(id);
const token = document.querySelector('meta[name="nova-token"]').content;
const icon = (name, cls='icon') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
const escapeHTML = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const apps = [
  {id:'files', title:'Files', icon:'folder', subtitle:'Your local Nova files'},
  {id:'settings', title:'Settings', icon:'settings', subtitle:'Personalize your experience'},
  {id:'notes', title:'Notes', icon:'note', subtitle:'Ideas worth keeping'},
  {id:'calculator', title:'Calculator', icon:'calculator', subtitle:'Quick calculations'},
  {id:'photos', title:'Photos', icon:'gallery', subtitle:'Images in Nova Files'},
  {id:'contacts', title:'Contacts', icon:'contacts', subtitle:'Local address book'},
  {id:'messages', title:'Messages', icon:'message', subtitle:'Local drafts only'},
  {id:'camera', title:'Camera', icon:'camera', subtitle:'Hardware backend pending'},
  {id:'about', title:'About Nova', icon:'info', subtitle:'System information'},
  {id:'components', title:'Components', icon:'info', subtitle:'Nova runtime integration status'},
  {id:'search', title:'Search', icon:'search', subtitle:'Find apps and files'},
  {id:'wifi', title:'Wi-Fi', icon:'wifi', subtitle:'Networks and connectivity'},
  {id:'bluetooth', title:'Bluetooth', icon:'grid', subtitle:'Devices and pairing'},
  {id:'device', title:'Device & power', icon:'battery', subtitle:'Battery, storage and preferences'},
  {id:'notifications', title:'Notifications', icon:'bell', subtitle:'Local alerts'},
  {id:'recents', title:'Recent apps', icon:'overview', subtitle:'Recently opened preview screens'},
  {id:'lock', title:'Screen lock', icon:'settings', subtitle:'UI session PIN lock'}
];
let settings = {theme:'dark',wallpaper:'aurora',accent:'blue',clock24:true,name:'Nova User'};
let system = null;
let connectivity = null;
let deviceInfo = null;
let locked = false;
let recents = [];
let coreStatus = null;
let coreSettings = null;
let current = null;
let filePath = '';
let fileEdit = null;
let fileBinary = null;
let selectedImage = null;
let noteEdit = null;
let contactEdit = null;
let calculator = '0';
let toastTimeout;
let notes = [], contacts = [], messages = [];
let showOverview = false;
function appById(id){return apps.find(x=>x.id===id)}
function appIcon(a){return `<span class="app-icon ${a.id}">${icon(a.icon)}</span>`}
function toast(msg){clearTimeout(toastTimeout);$('toast').textContent=msg;$('toast').classList.remove('hidden');toastTimeout=setTimeout(()=>$('toast').classList.add('hidden'),3500)}
async function api(path, data){
  const opts = data===undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json','X-Nova-Token':token},body:JSON.stringify(data)};
  let resp;
  try {resp=await fetch(path,opts)}catch(err){throw new Error('Nova service unavailable: '+err.message)}
  let body;try{body=await resp.json()}catch{throw new Error('Invalid server reply')}
  if(!resp.ok) throw new Error(body.error || `HTTP ${resp.status}`);
  return body;
}
async function task(fn){try{return await fn()}catch(err){toast(err.message);console.error(err);return null}}
function applySettings(){document.body.dataset.theme=settings.theme;document.body.dataset.wallpaper=settings.wallpaper;document.body.dataset.accent=settings.accent}
function paintClock(){
  const now=new Date(); const hr24=settings.clock24;
  const t=now.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',hour12:!hr24});
  $('hero-time').textContent=t;$('status-time').textContent=t;
  $('hero-date').textContent=now.toLocaleDateString([], {weekday:'long',month:'long',day:'numeric'});
  $('quick-date').textContent=now.toLocaleDateString([], {weekday:'long',month:'short',day:'numeric'});
  let h=now.getHours(),g=h<12?'Good morning.':h<17?'Good afternoon.':'Good evening.';
  $('hero-greeting').textContent=g;
}
function updateStatus(){
  if(!system) return;
  $('status-network').classList.toggle('inactive',!system.network.connected);
  $('status-network').title=system.network.connected?'Network link active':'No active network link detected';
  $('status-battery').classList.toggle('inactive',system.battery.percent===null);
  $('status-battery').title=system.battery.percent===null?'Battery unavailable':`Battery ${system.battery.percent}% (${system.battery.state})`;
}
async function refreshSystem(){
  const [s,c,d]=await Promise.all([task(()=>api('/api/system')),task(()=>api('/api/connectivity')),task(()=>api('/api/device'))]);
  if(s)system=s;if(c)connectivity=c;if(d)deviceInfo=d;
  if(system){updateStatus();renderQuick();if(current==='about')renderAbout();}
}
function launchGrid(){const visible=['files','settings','notes','contacts','messages','photos','calculator','wifi','bluetooth','device','notifications','lock'].map(appById);$('app-grid').innerHTML=visible.map(a=>`<button class="app-shortcut" data-open="${a.id}" aria-label="Open ${a.title}">${appIcon(a)}<span>${a.title}</span></button>`).join('')}
async function openApp(id){
  if(locked && id!=='lock'){toast('Unlock Nova to continue');return}
  let a=appById(id);if(!a)return;
  if(id!=='lock'){recents=[id,...recents.filter(x=>x!==id)].slice(0,12)}
  current=id;fileEdit=null;fileBinary=null;noteEdit=null;selectedImage=null;contactEdit=null;showOverview=false;
  $('home').classList.add('hidden');$('app-window').classList.remove('hidden');
  $('window-title').textContent=a.title;$('window-subtitle').textContent=a.subtitle;
  $('window-icon').innerHTML=appIcon(a);
  $('window-content').scrollTop=0;
  closeQuick();await renderActive();
}
function home(){if(locked){openApp('lock');return}current=null;showOverview=false;$('home').classList.remove('hidden');$('app-window').classList.add('hidden');closeQuick();}
function back(){
  if(locked){openApp('lock');return}
  if(!$('quickpanel').classList.contains('hidden')){closeQuick();return}
  if(!current){return}
  if(current==='files'){
    if(fileBinary!==null){fileBinary=null;renderFiles();return}
    if(fileEdit!==null){fileEdit=null;renderFiles();return}
    if(filePath){filePath=filePath.includes('/')?filePath.slice(0,filePath.lastIndexOf('/')):'';renderFiles();return}
  }
  if(current==='notes'&&noteEdit!==null){noteEdit=null;renderNotes();return}
  if(current==='contacts'&&contactEdit!==null){contactEdit=null;renderContacts();return}
  if(current==='photos'&&selectedImage!==null){selectedImage=null;renderPhotos();return}
  home();
}
function overview(){openApp(locked?'lock':'recents')}
function setContent(html){$('window-content').innerHTML=html;$('window-content').scrollTop=0}
async function renderActive(){
  switch(current){
    case 'files':return renderFiles();case 'settings':return renderSettings();case 'notes':return renderNotes();
    case 'calculator':return renderCalculator();case 'photos':return renderPhotos();case 'contacts':return renderContacts();
    case 'messages':return renderMessages();case 'camera':return renderCamera();case 'about':return renderAbout();case 'components':return renderComponents();case 'search':return renderSearch();
    case 'wifi':return renderWifi();case 'bluetooth':return renderBluetooth();case 'device':return renderDevice();case 'notifications':return renderNotifications();case 'recents':return renderRecents();case 'lock':return renderLock();
  }
}
function header(title, subtitle, tools=''){return `<div class="files-toolbar"><div><h1 class="page-heading">${title}</h1><p class="page-intro" style="margin-bottom:0">${subtitle}</p></div><div class="row-actions">${tools}</div></div>`}
function btn(text, act, primary=false, i=''){return `<button class="btn${primary?' primary':''}" data-action="${act}">${i?icon(i):''}${text}</button>`}
function systemLine(key,value){return `<div class="system-line"><span>${escapeHTML(key)}</span><strong>${escapeHTML(value)}</strong></div>`}
function prettyBytes(n){if(n==null)return '';if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(1)+' MB'}
function dateFmt(n){return new Date(n*1000).toLocaleDateString([], {month:'short',day:'numeric',year:'numeric'})}

async function renderFiles(){
  if(current!=='files')return;
  if(fileBinary!==null){
    const name=fileBinary.split('/').pop();
    setContent(`${header(escapeHTML(name),'Binary file in Nova Files',btn('Back to Files','file-binary-back',false,'back'))}<div class="card" style="text-align:center;padding:50px 18px"><div style="font-size:56px">📦</div><h2>${escapeHTML(name)}</h2><p class="page-intro">Download this file to open it with an appropriate application on your computer.</p><a class="btn primary" href="/api/download?path=${encodeURIComponent(fileBinary)}" download>${icon('folder')} Download file</a></div>`);return;
  }
  if(fileEdit!==null){
    const result=await task(()=>api('/api/file?path='+encodeURIComponent(fileEdit)));
    if(!result)return;
    setContent(`${header(escapeHTML(fileEdit.split('/').pop()),'Edit UTF-8 text file',btn('Save changes','save-file',true,'save')+btn('Rename','rename-file')+btn('Move to trash','trash-file'))}<div class="file-breadcrumb">${btn('Back to Files','file-editor-back',false,'back')}</div><textarea id="file-body" class="edit-area" spellcheck="false" style="min-height:45vh"></textarea><div class="banner">Changes are written to your Nova Files folder on this computer. Moving to trash keeps a recoverable copy inside Nova's configuration folder.</div>`);
    $('file-body').value=result.content;return;
  }
  const result=await task(()=>api('/api/files?path='+encodeURIComponent(filePath)));
  if(!result)return;
  let segments=filePath.split('/').filter(Boolean), crumb=`<button data-action="file-root">${icon('home')} ${escapeHTML(result.root)}</button>`;
  let built='';for(const s of segments){built=built?built+'/'+s:s;crumb+=icon('chevron')+`<button data-dir="${escapeHTML(built)}">${escapeHTML(s)}</button>`}
  const tools=btn('New folder','create-folder',false,'plus')+btn('New file','create-file',false,'note')+btn('Upload','upload-file',true,'upload');
  const items=result.items.map(it=>`<button class="file-tile" data-file="${escapeHTML(it.path)}" data-dirflag="${it.dir?'1':'0'}"><div class="file-icon">${it.dir?icon('folder'):it.ext.match(/\.(png|jpg|jpeg|gif|webp)/)?'🖼️':'📄'}</div><div><strong>${escapeHTML(it.name)}</strong><div class="file-meta">${it.dir?'Folder':prettyBytes(it.bytes)}</div></div></button>`).join('');
  setContent(`${header('Your files','Real files, securely scoped to the Nova Files folder.',tools)}<div class="crumb file-breadcrumb">${crumb}</div>${items?`<div class="file-grid">${items}</div>`:'<div class="empty-state"><span class="empty-symbol">📂</span>This folder is empty.<br/>Add your first file or folder above.</div>'}<div class="banner">Files are stored in <b>~/NovaFiles</b> by default. You can change the root using NOVA_FILES_ROOT before launching. Nova never browses outside the selected folder.</div>`);
}
async function performFileAction(action){
  if(action==='file-root'){filePath='';await renderFiles();return}
  if(action==='file-editor-back'){fileEdit=null;await renderFiles();return}
  if(action==='file-binary-back'){fileBinary=null;await renderFiles();return}
  if(action==='create-folder'||action==='create-file'){
    const name=prompt(action==='create-folder'?'Folder name':'Text filename (for example hello.txt)');if(name===null)return;
    const res=await task(()=>api('/api/files/create',{path:filePath,name,dir:action==='create-folder'}));if(res){toast('Created '+name);renderFiles()}return;
  }
  if(action==='upload-file'){$('upload').value='';$('upload').click();return}
  if(action==='save-file'){
    const res=await task(()=>api('/api/files/save',{path:fileEdit,content:$('file-body').value}));if(res)toast('Saved to disk');return;
  }
  if(action==='rename-file'){
    const name=prompt('Rename file to:',fileEdit.split('/').pop());if(name===null)return;
    const res=await task(()=>api('/api/files/rename',{path:fileEdit,name}));if(res){fileEdit=res.renamed;toast('Renamed');renderFiles()}return;
  }
  if(action==='trash-file'){
    if(!confirm(`Move ${fileEdit.split('/').pop()} to Nova Trash?`))return;
    const res=await task(()=>api('/api/files/trash',{path:fileEdit}));if(res){toast('Moved to Nova Trash');fileEdit=null;renderFiles()}return;
  }
}
async function openFile(path,isDir){
  if(isDir){filePath=path;return renderFiles()}
  if(/\.(png|jpe?g|gif|webp)$/i.test(path)){selectedImage=path;return openApp('photos').then(()=>{selectedImage=path;renderPhotos()})}
  if(!/\.(txt|md|json|log|csv|py|rs|toml|c|h|sh|html|css|js)$/i.test(path)){fileBinary=path;return renderFiles()}
  fileEdit=path;return renderFiles();
}
async function upload(file){
  if(!file)return;if(file.size>5*1024*1024){toast('Upload limited to 5 MB');return}
  const reader=new FileReader();reader.onload=async()=>{
    const contents=reader.result.split(',')[1];
    const result=await task(()=>api('/api/files/upload',{path:filePath,name:file.name,base64:contents}));
    if(result){toast('Uploaded '+file.name);renderFiles()}
  };reader.readAsDataURL(file);
}

const themes=['dark','light'],wallpapers=['aurora','sunset','forest','midnight'],accents=['blue','violet','teal','pink'];
function settingButtons(key, options){return `<div class="choices settings-choices">${options.map(o=>`<button class="choice ${settings[key]===o?'active':''}" data-setting="${key}" data-value="${o}">${typeof o==='boolean'?(o?'24-hour':'12-hour'):o[0].toUpperCase()+o.slice(1)}</button>`).join('')}</div>`}
async function renderSettings(){
  if(!coreStatus)coreStatus=await task(()=>api('/api/core/status'));
  coreSettings=coreStatus?.connected ? await task(()=>api('/api/core/settings')) : null;
  if(current!=='settings')return;
  setContent(`<h1 class="page-heading">Make it yours.</h1><p class="page-intro">Your preferences are saved on your computer and restored when Nova opens.</p>
    <section class="card"><h2>Appearance</h2><div class="setting-row"><div class="row-copy"><div class="row-label">Theme</div><div class="row-sub">Bright or deep, your choice.</div></div>${settingButtons('theme',themes)}</div><div class="setting-row"><div class="row-copy"><div class="row-label">Accent color</div><div class="row-sub">Give Nova a signature color.</div></div>${settingButtons('accent',accents)}</div><div class="row-label" style="margin:19px 0 12px">Wallpaper</div><div class="choices">${wallpapers.map(w=>`<button class="wallpaper-choice ${w} ${settings.wallpaper===w?'active':''}" data-setting="wallpaper" data-value="${w}">${w[0].toUpperCase()+w.slice(1)}</button>`).join('')}</div></section>
    <section class="card"><h2>Personal</h2><div class="setting-row"><div class="row-copy"><div class="row-label">Display name</div><div class="row-sub">Only saved locally.</div></div><div class="row-actions"><input class="field" id="settings-name" maxlength="50" style="max-width:170px" value="${escapeHTML(settings.name)}"/>${btn('Save','save-name',true)}</div></div><div class="setting-row"><div class="row-copy"><div class="row-label">Clock format</div><div class="row-sub">System time comes from your computer.</div></div>${settingButtons('clock24',[true,false])}</div></section>
    <section class="card"><h2>Original Nova Rust Settings core</h2>${coreSettings ? `
      <div class="banner">CONNECTED: These settings read and write through the original v0.60 Rust nova-settings-core library. Hardware state may not change until drivers are connected.</div>
      ${systemLine('Language',coreSettings.language==='sw'?'Swahili':'English')}
      <label class="form-label" for="native-language">SYSTEM LANGUAGE</label><select class="field" id="native-language" data-core-key="language"><option value="en" ${coreSettings.language==='en'?'selected':''}>English</option><option value="sw" ${coreSettings.language==='sw'?'selected':''}>Swahili</option></select>
      <label class="form-label" for="native-brightness">DISPLAY BRIGHTNESS PREFERENCE: ${coreSettings.display_brightness}%</label><input class="field" id="native-brightness" type="range" min="0" max="100" data-core-key="display_brightness" value="${coreSettings.display_brightness}"/>
      <label class="form-label" for="native-text">TEXT SCALE: ${coreSettings.text_scale}%</label><input class="field" id="native-text" type="number" min="80" max="200" step="25" data-core-key="text_scale" value="${coreSettings.text_scale}"/>
      <label class="form-label" for="native-dnd">DO NOT DISTURB PREFERENCE</label><select class="field" id="native-dnd" data-core-key="do_not_disturb"><option value="false" ${!coreSettings.do_not_disturb?'selected':''}>Off</option><option value="true" ${coreSettings.do_not_disturb?'selected':''}>On</option></select>
      <div style="margin-top:12px">${btn('Save native settings','save-native-settings',true,'save')}</div>
      `:'<div class="banner">Rust core not connected. Build it with ./build-native.sh, then restart Nova. Appearance settings above remain usable in preview mode.</div>'}</section>
    <section class="card"><h2>Connectivity and device controls</h2><div class="hub-links"><button data-open="wifi" class="btn">Wi-Fi networks</button><button data-open="bluetooth" class="btn">Bluetooth devices</button><button data-open="device" class="btn">Battery & storage</button><button data-open="lock" class="btn">Screen lock</button></div></section>
    <section class="card"><h2>Connected hardware</h2>${systemLine('Network',system?.network.connected?'Active · '+(system.network.interfaces.join(', ')||'interface'): 'No active link detected')}${systemLine('Wi-Fi hardware',system?.network.wifi_available?'Detected':'Not exposed to Nova')}${systemLine('Battery',system?.battery.percent===null?'Unavailable':system?.battery.percent+'%')}${systemLine('Host OS',system?.os||'Unknown')}<div class="banner">Wi-Fi, battery, and other hardware information is read-only. No simulated toggle pretends to change real hardware.</div></section>`)
}
async function updateSetting(k,v){
  const result=await task(()=>api('/api/settings',{[k]:v}));if(!result)return;
  settings=result;applySettings();paintClock();renderQuick();if(current==='settings')renderSettings();toast('Saved');
}

async function renderNotes(){
  if(current!=='notes')return;
  notes=(await task(()=>api('/api/notes')))||[];
  if(noteEdit!==null){const item=notes.find(n=>n.id===noteEdit)||{title:'',content:''};
    setContent(`${header(noteEdit==='new'?'New note':'Edit note','Stored locally on this computer',btn('Save','save-note',true,'save')+(noteEdit==='new'?'':btn('Delete','delete-note',false,'trash')))}<label class="form-label" for="note-title">TITLE</label><input id="note-title" class="field" maxlength="100" placeholder="Your note title" value="${escapeHTML(item.title)}"/><label class="form-label" for="note-body">NOTE</label><textarea id="note-body" class="edit-area" style="min-height:42vh" placeholder="Start writing…"></textarea>${btn('All notes','notes-back')}`);
    $('note-body').value=item.content;return;
  }
  const cards=[...notes].reverse().map(n=>`<button class="note-card" data-note="${escapeHTML(n.id)}"><strong>${escapeHTML(n.title)}</strong><span>${escapeHTML(n.content)}</span><small>${dateFmt(n.updated)}</small></button>`).join('');
  setContent(`${header('Notes','Write something worth remembering.',btn('New note','new-note',true,'plus'))}${cards?`<div class="note-grid">${cards}</div>`:'<div class="empty-state"><span class="empty-symbol">📝</span>No notes yet. Capture your first idea.</div>'}`)
}
async function noteAction(action){
  if(action==='new-note'){noteEdit='new';return renderNotes()}
  if(action==='notes-back'){noteEdit=null;return renderNotes()}
  if(action==='save-note'){
    const payload={title:$('note-title').value,content:$('note-body').value};if(noteEdit!=='new')payload.id=noteEdit;
    const res=await task(()=>api('/api/notes/save',payload));if(res){noteEdit=null;toast('Note saved');renderNotes()}return;
  }
  if(action==='delete-note'){
    if(!confirm('Delete this note?'))return;
    const res=await task(()=>api('/api/notes/save',{delete:true,id:noteEdit}));if(res){noteEdit=null;toast('Note deleted');renderNotes()}
  }
}

function compute(expr){
  const src=expr.replace(/\s/g,'');if(!/^-?\d+(?:\.\d+)?(?:[+\-*/]-?\d+(?:\.\d+)?)*$/.test(src))throw Error('Invalid expression');
  const parts=src.match(/-?\d+(?:\.\d+)?|[+\-*/]/g);
  const nums=[Number(parts[0])],ops=[];
  for(let i=1;i<parts.length;i+=2){const op=parts[i],value=Number(parts[i+1]);if(op==='*'){nums[nums.length-1]*=value}else if(op==='/'){nums[nums.length-1]/=value}else{ops.push(op);nums.push(value)}}
  let r=nums[0];for(let i=0;i<ops.length;i++)r=ops[i]==='+'?r+nums[i+1]:r-nums[i+1];
  if(!Number.isFinite(r))throw Error('Cannot divide by zero');return Number(r.toPrecision(12)).toString();
}
function renderCalculator(){
  if(current!=='calculator')return;
  const keys=['C','±','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','⌫','0','.','='];
  setContent(`<h1 class="page-heading">Calculator</h1><p class="page-intro">A small tool for big plans.</p><div class="calc-box"><div class="calc-display" id="calc-display">${escapeHTML(calculator)}</div><div class="calc-buttons">${keys.map(k=>`<button data-calc="${escapeHTML(k)}" class="${k==='='?'equals':'+−×÷'.includes(k)?'operator':''}">${escapeHTML(k)}</button>`).join('')}</div></div>`)
}
function calculatorKey(k){
  const opmap={'×':'*','÷':'/','−':'-'};
  try{
    if(k==='C')calculator='0';
    else if(k==='⌫')calculator=calculator.length>1?calculator.slice(0,-1):'0';
    else if(k==='=')calculator=compute(calculator);
    else if(k==='%')calculator=(Number(compute(calculator))/100).toString();
    else if(k==='±')calculator=calculator.startsWith('-')?calculator.slice(1):'-'+calculator;
    else if(calculator.length<34){const val=opmap[k]||k;calculator=calculator==='0'&&/[\d]/.test(val)?val:calculator+val}
  }catch(err){toast(err.message)}
  if($('calc-display'))$('calc-display').textContent=calculator;
}

async function renderPhotos(){
  if(current!=='photos')return;
  if(selectedImage){setContent(`${header('Photo viewer','A file from your Nova Files folder.',btn('Back to gallery','photo-back',false,'back'))}<div class="card" style="text-align:center"><img class="selected-photo" alt="${escapeHTML(selectedImage.split('/').pop())}" src="/api/media?path=${encodeURIComponent(selectedImage)}"/><div class="row-sub">${escapeHTML(selectedImage)}</div></div>`);return}
  const result=await task(()=>api('/api/gallery'));if(!result)return;
  setContent(`${header('Photos','Your images, organized in one place.',btn('Open Files','go-files',true,'folder'))}${result.images.length?`<div class="gallery-grid">${result.images.map(im=>`<button data-photo="${escapeHTML(im.path)}" style="background:transparent;padding:0"><img class="gallery-item" alt="${escapeHTML(im.name)}" src="/api/media?path=${encodeURIComponent(im.path)}" loading="lazy"/></button>`).join('')}</div>`:'<div class="empty-state"><span class="empty-symbol">🌅</span>No photos yet.<br/>Upload JPG, PNG, GIF or WebP images in Files to see them here.</div>'}`)
}

async function renderContacts(){
  if(current!=='contacts')return;
  if(!coreStatus)coreStatus=await task(()=>api('/api/core/status'));
  contacts=(await task(()=>api('/api/contacts')))||[];
  if(contactEdit!==null){const c=contacts.find(x=>x.id===contactEdit)||{name:'',phone:''};setContent(`${header(contactEdit==='new'?'New contact':'Edit contact',coreStatus?.connected?'Native Nova Contacts core':'Local preview contacts',btn('Save','save-contact',true,'save')+(contactEdit==='new'?'':btn('Delete','delete-contact',false,'trash')))}<label class="form-label">NAME</label><input id="contact-name" class="field" maxlength="100" value="${escapeHTML(c.name)}" placeholder="Full name"/><label class="form-label">PHONE</label><input id="contact-phone" class="field" maxlength="50" value="${escapeHTML(c.phone)}" placeholder="Phone number"/><div style="margin-top:18px">${btn('All contacts','contacts-back')}</div>`);return}
  setContent(`${header('Contacts',coreStatus?.connected?'Powered by nova-contacts-core (Rust)':'Local preview address book.',btn('Add contact','new-contact',true,'plus'))}${contacts.length?`<div class="card">${[...contacts].sort((a,b)=>a.name.localeCompare(b.name)).map(c=>`<button class="list-row" style="width:100%;background:transparent;text-align:left" data-contact="${escapeHTML(c.id)}"><div class="name-line"><span class="contact-avatar">${escapeHTML(c.name[0].toUpperCase())}</span><div><div class="row-label">${escapeHTML(c.name)}</div><div class="row-sub">${escapeHTML(c.phone||'No phone number')}</div></div></div>${icon('chevron')}</button>`).join('')}</div>`:'<div class="empty-state"><span class="empty-symbol">👤</span>No contacts yet. Add your first contact.</div>'}<div class="banner">Contacts are ${coreStatus?.connected?'managed by the original Nova Rust core':'stored in Python preview mode'}; they do not synchronize with a SIM card or cloud service.</div>`)
}
async function contactAction(action){
  if(action==='new-contact'){contactEdit='new';return renderContacts()}
  if(action==='contacts-back'){contactEdit=null;return renderContacts()}
  if(action==='save-contact'){
    const p={name:$('contact-name').value,phone:$('contact-phone').value};if(contactEdit!=='new')p.id=contactEdit;
    const res=await task(()=>api('/api/contacts/save',p));if(res){contactEdit=null;toast('Contact saved');renderContacts()}return;
  }
  if(action==='delete-contact'){
    if(!confirm('Delete contact?'))return;
    const res=await task(()=>api('/api/contacts/save',{delete:true,id:contactEdit}));if(res){contactEdit=null;toast('Deleted');renderContacts()}
  }
}
async function renderMessages(){
  if(current!=='messages')return;
  messages=(await task(()=>api('/api/messages')))||[];
  if(!coreStatus)coreStatus=await task(()=>api('/api/core/status'));
  const nativeThreads=coreStatus?.connected ? await task(()=>api('/api/core/messages')) : null;
  setContent(`<h1 class="page-heading">Messages</h1><p class="page-intro">Local message drafts. SIM and SMS transport are not connected yet.</p><div class="card"><h2>Write a local message</h2><label class="form-label">TO</label><input class="field" id="msg-to" placeholder="Name or number" maxlength="100"/><label class="form-label">MESSAGE</label><textarea id="msg-body" class="edit-area" style="min-height:96px" maxlength="2000" placeholder="Your message…"></textarea><div style="margin-top:12px">${btn('Save draft','save-message',true,'save')}</div></div><section class="card"><h2>Saved drafts</h2>${messages.length?[...messages].reverse().map(m=>`<div class="list-row"><div><div class="row-label">To ${escapeHTML(m.recipient)}</div><div class="row-sub">${escapeHTML(m.body)}</div><div class="row-sub">${dateFmt(m.created)} · Not sent</div></div></div>`).join(''):'<div class="row-sub">No drafts saved yet.</div>'}</section>${nativeThreads!==null?`<section class="card"><h2>Original Nova Rust message threads (read only)</h2><div class="row-sub">No real modem or SMS transport is connected.</div>${nativeThreads.length?nativeThreads.map(t=>`<div class="list-row"><strong>${escapeHTML(t.peer)}</strong><span>${t.messages.length} messages</span></div>`).join(''):'<div class="row-sub">No native threads yet.</div>'}</section>`:''}`)
}
function renderCamera(){setContent(`<h1 class="page-heading">Camera</h1><p class="page-intro">Camera support will be available after a device backend is integrated.</p><div class="card" style="padding:50px 20px;text-align:center"><div style="font-size:65px">📷</div><h2 style="font-size:20px;margin:16px 0">Camera hardware is not connected</h2><p class="row-sub">This hosted preview has no Nova camera HAL access. A working phone camera requires the device-specific driver, capture service, and UI integration.</p><div style="margin-top:25px">${btn('Browse photos','go-photos',true,'gallery')}</div></div>`)}
function renderAbout(){
  if(current!=='about')return;
  const n=system?.network||{},b=system?.battery||{};
  setContent(`<div class="hero-logo">N</div><div class="about-title">Nova OS <small>Original source integration · v0.70</small></div><p class="page-intro" style="margin-top:19px">Graphical Linux-hosted release using the original Nova Rust core libraries when built. ARM64 boot integration is separate and a native phone OS is not yet complete.</p><section class="card"><h2>Host system</h2>${systemLine('Execution mode',system?.mode||'Checking…')}${systemLine('Host operating system',system?.os||'Unknown')}${systemLine('CPU architecture',system?.arch||'Unknown')}${systemLine('Memory',system?.memory_mb?system.memory_mb+' MB':'Unavailable')}${systemLine('Connected network',n.connected?'Yes':'No active link')}${systemLine('Battery',b.percent==null?'Not exposed':b.percent+'%')}${systemLine('Version',system?.version||'0.70-integration')}</section><section class="card"><h2>Integration status</h2><div class="banner">✓ Clickable launcher, system navigation, file manager, settings, notes, calculator, local contacts and local message drafts are implemented in this preview.</div><div class="banner">Original Nova Rust core status: ${system?.native_core?'Connected (Settings, Contacts, Messages read-only)':'Not built (Python preview mode)'}. Native Smithay pixel rendering and physical phone drivers remain unfinished; ARM64 QEMU graphical boot has not yet been verified.</div>${btn('View original Rust app inventory','inventory')+'<button class="btn" data-open="components">View component status</button>'}</section><div id="inventory-box"></div>`)
}
async function inventory(){const res=await task(()=>api('/api/inventory'));if(!res)return;$('inventory-box').innerHTML=`<section class="card"><h2>Original Rust apps in v0.60</h2><div class="banner">${escapeHTML(res.status)}</div>${res.rust_source_apps.map(a=>`<div class="system-line codeface">${escapeHTML(a)}</div>`).join('')}</section>`}
async function renderComponents(){
  if(current!=='components')return;
  const data=await task(()=>api('/api/integration'));
  if(!data)return;
  const c=data.counts;
  const summary=header('Nova components', 'Source, installed binaries, and runtime status are different.',btn('Refresh','components-refresh'));
  const stats=`<section class="card">${systemLine('Original Rust modules',data.source_count)}${systemLine('Source manifests present',c.source_present)}${systemLine('Installed standalone binaries',c.binary_installed)}${systemLine('Original libraries',c.libraries)}${systemLine('Original apps',c.apps)}${systemLine('Developer / test tools',c.tools)}${systemLine('Original Rust bridge connected',data.native_bridge_connected?'Yes':'No')}${systemLine('Original App Manager socket',data.nova_protocol_sockets?.['app-manager']?'Available':'Not detected')}${systemLine('Nova compositor protocol socket',data.nova_protocol_sockets?.compositor?'Available':'Not detected')}${systemLine('Native Nova compositor','Not yet')}${systemLine('Nova Init as PID 1','Not yet')}</section>`;
  const services=Object.entries(data.guest_services).map(([k,v])=>systemLine(k,v)).join('');
  const rows=data.components.map(x=>`<div class="system-line"><span>${escapeHTML(x.name)} <small>(${escapeHTML(x.kind)})</small></span><strong>${escapeHTML(x.status)}</strong></div>`).join('');
  setContent(summary+stats+`<section class="card"><h2>Guest services</h2>${services}</section><div class="banner">${escapeHTML(data.caveat)}</div><section class="card"><h2>Original workspace inventory (104)</h2>${rows}</section>`);
}
async function renderSearch(){
  if(current!=='search')return;
  setContent(`<h1 class="page-heading">Search Nova</h1><p class="page-intro">Find an app or a file in the top-level Nova Files folder.</p><input class="field" id="search-input" placeholder="Type an app or filename…" autofocus/><div id="search-results" class="search-results" style="margin-top:22px"></div>`);
  $('search-input').focus();await searchResults('');
}
async function searchResults(text){
  const el=$('search-results');if(!el)return;
  const q=text.trim().toLowerCase();const matches=apps.filter(a=>a.id!=='search'&&a.title.toLowerCase().includes(q)).slice(0,8);
  const root=await task(()=>api('/api/files'));if(!root||!$('search-results'))return;
  const f=root.items.filter(i=>i.name.toLowerCase().includes(q)).slice(0,12);
  el.innerHTML=`<div class="row-sub" style="margin:5px 0">APPS</div>${matches.map(a=>`<button class="search-result" data-open="${a.id}">${appIcon(a)}<div><strong>${escapeHTML(a.title)}</strong><div class="row-sub">${escapeHTML(a.subtitle)}</div></div></button>`).join('')||'<div class="row-sub">No matching apps</div>'}<div class="row-sub" style="margin:16px 0 5px">FILES · ROOT FOLDER</div>${f.map(i=>`<button class="search-result" data-search-file="${escapeHTML(i.path)}" data-dirflag="${i.dir?'1':'0'}">${i.dir?icon('folder'):icon('note')}<strong>${escapeHTML(i.name)}</strong></button>`).join('')||'<div class="row-sub">No matching top-level files</div>'}`;
}
function toggleQuick(){const opening=$('quickpanel').classList.contains('hidden');$('quickpanel').classList.toggle('hidden',!opening);$('overlay-shade').classList.toggle('hidden',!opening);if(opening){refreshSystem();renderQuick()}}
function closeQuick(){$('quickpanel').classList.add('hidden');$('overlay-shade').classList.add('hidden')}
function renderQuick(){
  const n=system?.network||{}, b=system?.battery||{};
  const wifi=connectivity?.wifi||{},bt=connectivity?.bluetooth||{};
  const tiles=[
    {name:'Wi-Fi',status:wifi.connected?wifi.network||'Connected':wifi.available?'Disconnected':'No adapter',icon:'wifi',active:wifi.connected,go:'wifi'},
    {name:'Bluetooth',status:bt.enabled?'Enabled':bt.available?'Off':'No controller',icon:'grid',active:!!bt.enabled,go:'bluetooth'},
    {name:'Device',status:b.percent===null?'Battery unavailable':b.percent+'%',icon:'battery',active:b.percent!=null,go:'device'},
    {name:'Notifications',status:'View local alerts',icon:'bell',active:false,go:'notifications'},
    {name:'Appearance',status:settings.theme==='dark'?'Dark theme':'Light theme',icon:'moon',active:true,action:'quick-theme'},
    {name:'Lock',status:'Session PIN',icon:'settings',active:false,go:'lock'}
  ];
  $('quick-grid').innerHTML=tiles.map(t=>`<button class="quick-tile ${t.active?'active':''}" ${t.go?`data-open="${t.go}"`:`data-action="${t.action}"`}>${icon(t.icon)}<strong>${t.name}</strong><small>${escapeHTML(t.status)}</small></button>`).join('');
  $('quick-system-note').textContent=wifi.available?'Host adapter detected · Control requires permission':'Connection via '+(n.interfaces?.join(', ')||'none')+' · No virtual Wi-Fi radio';
}

async function renderWifi(){
  const c=await task(()=>api('/api/connectivity'));if(!c||current!=='wifi')return;
  connectivity=c;const w=c.wifi;
  const controls=w.available&&w.can_control;
  setContent(`${header('Wi-Fi','Real NetworkManager radio status; no simulated connections.')}
    <section class="card">${systemLine('Adapter',w.available?'Detected':'Not exposed')}${systemLine('Radio',w.enabled===null?'Unavailable':w.enabled?'Enabled':'Disabled')}${systemLine('Connected network',w.network||'None')}
    <div class="banner">${escapeHTML(w.reason||'Controls enabled in this guest')}</div>
    <div class="hub-links">${controls?`${btn('Enable','wifi-enable')}${btn('Disable','wifi-disable')}${btn('Rescan','wifi-scan')}`:btn('Wi-Fi adapter unavailable','wifi-noop')}</div></section>
    <section class="card"><h2>Connect to a network</h2><label class="form-label">Network name</label><input id="wifi-ssid" class="field" maxlength="64" autocomplete="off"/>
    <label class="form-label">Password</label><input id="wifi-password" type="password" class="field" maxlength="128" autocomplete="off" />
    ${w.networks?.length?`<div class="row-sub" style="margin-top:16px">NEARBY NETWORKS</div>${w.networks.map(n=>`<button class="search-result" data-select-ssid="${escapeHTML(n.ssid)}">${icon('wifi')}<strong>${escapeHTML(n.ssid)}</strong><small>${n.signal}% · ${escapeHTML(n.security||'Open')}</small></button>`).join('')}`:''}
    <div style="margin-top:12px">${controls?btn('Connect','wifi-connect',true):'<div class="banner">Connection disabled: requires a real Wi-Fi adapter and authorized host radio controls.</div>'}</div></section>`);
}

async function renderBluetooth(){
  const c=await task(()=>api('/api/connectivity'));if(!c||current!=='bluetooth')return;
  connectivity=c;const b=c.bluetooth;
  const controls=b.available&&b.can_control;
  const devices=b.devices.map(d=>`<div class="system-line"><span>${escapeHTML(d.name)}<small> ${escapeHTML(d.address)}</small></span>${controls?`<button class="btn" data-bt-pair="${escapeHTML(d.address)}">Pair</button>`:''}</div>`).join('');
  setContent(`${header('Bluetooth','Pairing uses the host BlueZ stack, if available.')}
    <section class="card">${systemLine('Controller',b.available?'Detected':'Not exposed')}${systemLine('Powered',b.enabled===null?'Unknown':b.enabled?'On':'Off')}
    <div class="banner">${escapeHTML(b.reason||'Control available')}</div><div class="hub-links">${controls?`${btn('On','bt-enable')}${btn('Off','bt-disable')}${btn('Scan','bt-scan')}`:'Device controls unavailable'}</div></section>
    <section class="card"><h2>Known devices</h2>${devices||'<p class="row-sub">No devices exposed in this environment.</p>'}</section>`);
}

async function renderDevice(){
  const d=await task(()=>api('/api/device'));if(!d||current!=='device')return;
  deviceInfo=d;const p=d.preferences||{};
  setContent(`${header('Device & power','System readings and stored display/audio preferences.')}
    <section class="card"><h2>Device health</h2>${systemLine('Battery',d.battery?.percent==null?'Unavailable':d.battery.percent+'%')}${systemLine('Charging',d.battery?.state||'Unknown')}
    ${systemLine('Free storage',d.storage?.storage_free_mb==null?'Unavailable':d.storage.storage_free_mb+' MB')}
    ${systemLine('Available RAM',d.storage?.ram_available_mb==null?'Unavailable':d.storage.ram_available_mb+' MB')}</section>
    <section class="card"><h2>Preferences</h2><label class="form-label">Brightness preference: <span id="bright-read">${p.brightness_preference}</span>%</label>
    <input class="field" type="range" id="device-brightness" min="0" max="100" value="${p.brightness_preference}" />
    <label class="form-label">Volume preference: <span id="volume-read">${p.volume_preference}</span>%</label>
    <input class="field" type="range" id="device-volume" min="0" max="100" value="${p.volume_preference}" />
    <label class="form-label">Screen timeout preference (minutes)</label>
    <select id="device-timeout" class="field">${[1,2,5,10,30].map(v=>`<option value="${v}" ${p.screen_timeout_minutes===v?'selected':''}>${v}</option>`).join('')}</select>
    <label class="form-label"><input id="device-reduce-motion" type="checkbox" ${p.reduce_motion?'checked':''}/> Reduce animations</label>
    ${btn('Save device preferences','device-save',true)}
    <div class="banner">These sliders do not change the host backlight, volume mixer, or power policy.</div></section>`);
}
async function renderNotifications(){
  const items=await task(()=>api('/api/notifications'));if(!items||current!=='notifications')return;
  setContent(`${header('Notifications','Local messages and reminders stored across restarts.',btn('Clear','alerts-clear'))}
  ${items.slice().reverse().map(n=>`<section class="card"><div class="setting-row"><div><strong>${escapeHTML(n.title)}</strong><p class="row-sub">${escapeHTML(n.body)}</p></div><button class="btn" data-alert-read="${escapeHTML(n.id)}" ${n.read?'disabled':''}>${n.read?'Read':'Mark read'}</button></div></section>`).join('')||'<section class="card">No notifications yet.</section>'}`);
}
function renderRecents(){
  setContent(`${header('Recent Nova screens','Hosted preview navigation only; native QEMU uses independent Qt processes.')}
    <section class="card">${recents.map(id=>{const a=appById(id);return `<button class="search-result" data-open="${a.id}">${appIcon(a)}<strong>${escapeHTML(a.title)}</strong></button>`}).join('')||'No recent screens.'}</section>`);
}
async function renderLock(){
  const state=await task(()=>api('/api/lock/status'));if(!state||current!=='lock')return;
  const configured=state.pin_configured;
  setContent(`${header('Nova screen lock',locked?'Session locked':'Local session PIN lock')}
    <section class="card"><div class="banner">UI-only session lock. This does not encrypt Nova Files or replace operating-system authentication.</div>
    ${locked?`<label class="form-label">Enter PIN</label><input type="password" id="lock-pin" class="field" inputmode="numeric" maxlength="12"/>${btn('Unlock','lock-unlock',true)}`:
    `${configured?btn('Lock session','lock-now',true):'<p>Set a PIN to enable this screen lock.</p>'}
    ${configured?'<label class="form-label">Current PIN</label><input type="password" id="lock-current" class="field" maxlength="12"/>':''}
    <label class="form-label">New PIN (4–12 digits)</label><input type="password" id="lock-new" class="field" maxlength="12" inputmode="numeric" />${btn(configured?'Change PIN':'Set PIN','lock-setup')}`}
    </section>`);
}

async function onAction(act){
  if(act.startsWith('file-')||['create-folder','create-file','upload-file','save-file','rename-file','trash-file'].includes(act))return performFileAction(act);
  if(['new-note','notes-back','save-note','delete-note'].includes(act))return noteAction(act);
  if(['new-contact','contacts-back','save-contact','delete-contact'].includes(act))return contactAction(act);
  if(['wifi-enable','wifi-disable','wifi-scan','wifi-connect','bt-enable','bt-disable','bt-scan'].includes(act)){
    const isWifi=act.startsWith('wifi-'),part=act.split('-')[1];
    const payload=isWifi&&part==='connect'?{ssid:$('wifi-ssid').value,password:$('wifi-password').value}:{};
    const result=await task(()=>api(`/api/connectivity/${isWifi?'wifi':'bluetooth'}/${part}`,payload));
    if(result){toast('Device manager accepted request');isWifi?renderWifi():renderBluetooth()}return;
  }
  if(act==='wifi-noop')return toast('No Wi-Fi radio available');
  if(act==='device-save'){
    const p={brightness_preference:Number($('device-brightness').value),volume_preference:Number($('device-volume').value),
      screen_timeout_minutes:Number($('device-timeout').value),reduce_motion:$('device-reduce-motion').checked};
    const result=await task(()=>api('/api/device/preferences',p));if(result){toast('Preferences saved');renderDevice()}return;
  }
  if(act==='alerts-clear'){const r=await task(()=>api('/api/notifications/clear',{}));if(r){toast('Cleared');renderNotifications()}return;}
  if(act==='lock-setup'){
    const r=await task(()=>api('/api/lock/setup',{pin:$('lock-new').value,current_pin:$('lock-current')?.value||''}));
    if(r){toast('PIN saved');renderLock()}return;
  }
  if(act==='lock-now'){locked=true;return openApp('lock')}
  if(act==='lock-unlock'){
    const r=await task(()=>api('/api/lock/verify',{pin:$('lock-pin').value}));
    if(r?.unlocked){locked=false;toast('Session unlocked');home()}return;
  }
  if(act==='save-name')return updateSetting('name',$('settings-name').value);
  if(act==='save-native-settings'){
    if(!coreSettings)return;
    const fields=[...document.querySelectorAll('[data-core-key]')];
    for(const field of fields){
      const key=field.dataset.coreKey;
      let value=field.value;
      if(['display_brightness','text_scale'].includes(key))value=Number(value);
      if(key==='do_not_disturb')value=value==='true';
      const result=await task(()=>api('/api/core/settings',{key,value}));
      if(!result)return;
    }
    toast('Nova Rust settings saved');return renderSettings();
  }
  if(act==='photo-back'){selectedImage=null;return renderPhotos()}
  if(act==='go-files')return openApp('files');if(act==='go-photos')return openApp('photos');
  if(act==='save-message'){
    const r=await task(()=>api('/api/messages/save',{recipient:$('msg-to').value,body:$('msg-body').value}));
    if(r){toast('Draft saved locally — not sent');renderMessages()}return;
  }
  if(act==='inventory')return inventory();
  if(act==='components-refresh')return renderComponents();
  if(act==='quick-theme')return updateSetting('theme',settings.theme==='dark'?'light':'dark');
  if(act==='quick-readonly')return toast('Hardware controls unavailable in this environment');
}
function bindEvents(){
  $('status-open').addEventListener('click',toggleQuick);$('quick-close').addEventListener('click',closeQuick);
  $('overlay-shade').addEventListener('click',closeQuick);
  $('window-close').addEventListener('click',home);$('window-back').addEventListener('click',back);
  $('nav-back').addEventListener('click',back);$('nav-home').addEventListener('click',home);$('nav-apps').addEventListener('click',overview);
  $('upload').addEventListener('change',e=>upload(e.target.files?.[0]));
  document.addEventListener('click',async e=>{
    const target=e.target.closest('[data-open],[data-action],[data-file],[data-dir],[data-note],[data-contact],[data-photo],[data-calc],[data-setting],[data-search-file],[data-alert-read],[data-bt-pair],[data-select-ssid]');if(!target)return;
    if(target.dataset.open){await openApp(target.dataset.open);return}
    if(target.dataset.alertRead){const r=await task(()=>api('/api/notifications/read',{id:target.dataset.alertRead}));if(r)renderNotifications();return}
    if(target.dataset.selectSsid){if($('wifi-ssid'))$('wifi-ssid').value=target.dataset.selectSsid;return}
    if(target.dataset.btPair){const r=await task(()=>api('/api/connectivity/bluetooth/pair',{address:target.dataset.btPair}));if(r)renderBluetooth();return}
    if(target.dataset.action){await onAction(target.dataset.action);return}
    if(target.dataset.setting){const {setting,value}=target.dataset;return updateSetting(setting,setting==='clock24'?value==='true':value)}
    if(target.dataset.dir!==undefined){filePath=target.dataset.dir;fileEdit=null;return renderFiles()}
    if(target.dataset.file){return openFile(target.dataset.file,target.dataset.dirflag==='1')}
    if(target.dataset.note){noteEdit=target.dataset.note;return renderNotes()}
    if(target.dataset.contact){contactEdit=target.dataset.contact;return renderContacts()}
    if(target.dataset.photo){selectedImage=target.dataset.photo;return renderPhotos()}
    if(target.dataset.calc){calculatorKey(target.dataset.calc);return}
    if(target.dataset.searchFile){const path=target.dataset.searchFile,isDir=target.dataset.dirflag==='1';await openApp('files');return openFile(path,isDir)}
  });
  document.addEventListener('input',e=>{if(e.target.id==='search-input')searchResults(e.target.value);if(e.target.id==='device-brightness')$('bright-read').textContent=e.target.value;if(e.target.id==='device-volume')$('volume-read').textContent=e.target.value});
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'){back();return}
    if(e.key==='/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();openApp('search')}
  });
  $('quick-settings').addEventListener('click',()=>openApp('settings'));
}
async function boot(){
  bindEvents();launchGrid();
  const fetched=await task(()=>api('/api/settings'));if(fetched)settings=fetched;
  applySettings();paintClock();setInterval(paintClock,15000);
  coreStatus=await task(()=>api('/api/core/status'));
  await refreshSystem();setInterval(refreshSystem,60000);
}
boot();
