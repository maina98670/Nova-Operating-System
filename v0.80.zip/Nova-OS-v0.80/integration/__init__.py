"""Nova OS integration status."""
