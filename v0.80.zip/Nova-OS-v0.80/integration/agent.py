"""Low-privilege service health reporter. Never starts test tools or pretends that libraries are services."""
import json, os, signal, time
from pathlib import Path
from runtime import snapshot
PATH=Path(os.environ.get('NOVA_STATUS_FILE','/var/lib/nova/runtime-status.json'))
ACTIVE=True

def stop(_signum,_frame):
    global ACTIVE
    ACTIVE=False

if __name__=='__main__':
    signal.signal(signal.SIGTERM,stop)
    signal.signal(signal.SIGINT,stop)
    PATH.parent.mkdir(parents=True,exist_ok=True)
    while ACTIVE:
        obj=snapshot()
        obj['generated_at_unix']=int(time.time())
        tmp=PATH.with_name(PATH.name+'.tmp')
        tmp.write_text(json.dumps(obj,indent=2)+'\n')
        tmp.replace(PATH)
        for _ in range(30):
            if not ACTIVE:break
            time.sleep(1)
