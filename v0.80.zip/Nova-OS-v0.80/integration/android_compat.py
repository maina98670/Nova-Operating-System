"""Nova Android compatibility bridge — staged APKs and optional Waydroid CLI.

No Android execution occurs in preview/Colab mode. Installing an APK does not
make Nova an Android runtime; real execution needs a working Waydroid container.
This is not an APK verifier: Android signing and permissions are verified by the
Android package manager, NOT by this ZIP inspection.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import platform
import re
import secrets
import shutil
import subprocess
import threading
from pathlib import Path
from zipfile import ZipFile, BadZipFile

MAX_APK_BYTES = 100 * 1024 * 1024
MAX_CHUNK_BYTES = 512 * 1024
PACKAGE_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+$')
APK_ID_RE = re.compile(r'^[a-f0-9]{32}$')


def _file_hash(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def inspect_apk(path: Path) -> dict:
    """Nonexecuting ZIP integrity inspection. NEVER treat this as signature verification."""
    path = Path(path)
    if not path.is_file() or path.stat().st_size > MAX_APK_BYTES or path.stat().st_size < 22:
        raise ValueError('APK size invalid or exceeds 100 MiB')
    try:
        with ZipFile(path) as archive:
            entries = archive.infolist()
            if not entries or len(entries) > 12000:
                raise ValueError('Invalid APK entry count')
            if sum(i.file_size for i in entries) > 1024 * 1024 * 1024:
                raise ValueError('APK expanded content too large')
            names = {i.filename for i in entries}
            if 'AndroidManifest.xml' not in names:
                raise ValueError('Missing AndroidManifest.xml')
            if archive.getinfo('AndroidManifest.xml').file_size > 8*1024*1024:
                raise ValueError('APK manifest too large')
            if not any(n == 'classes.dex' or re.fullmatch(r'classes\d+\.dex', n) for n in names) and not any(n.startswith('lib/') and n.endswith('.so') for n in names):
                raise ValueError('APK contains neither DEX bytecode nor native library')
            for i in entries:
                n = i.filename
                if n.startswith('/') or '\\' in n or any(part == '..' for part in n.split('/')):
                    raise ValueError('Unsafe APK member path')
                if i.compress_size and i.file_size > 1500 * max(i.compress_size, 1) and i.file_size > 10*1024*1024:
                    raise ValueError('Suspicious APK compression ratio')
            bad = archive.testzip()
            if bad:
                raise ValueError('Corrupted APK entry')
            archs = sorted({n.split('/')[1] for n in names if n.startswith('lib/') and n.endswith('.so') and len(n.split('/')) >= 3})
            signature_v1 = any(n.startswith('META-INF/') and n.upper().endswith(('.RSA','.DSA','.EC')) for n in names)
    except (BadZipFile, KeyError, OSError, RuntimeError) as e:
        raise ValueError('Invalid APK archive') from e
    return {
        'archive_valid': True, 'bytes': path.stat().st_size,
        'sha256': _file_hash(path),
        'native_abis': archs, 'entries': len(entries),
        'v1_signature_file_present': signature_v1,
        'signature_verified': False,
        'note': 'ZIP inspection only. Android Package Manager must verify signing and compatibility.',
    }


class AndroidBridge:
    """Preflight and controlled commands; no sudo, systemctl or shell execution."""
    def __init__(self, base: Path, *, enabled=None, command='waydroid'):
        self.base = Path(base).resolve() / 'android-apks'
        self.enabled = (os.environ.get('NOVA_ENABLE_ANDROID_RUNTIME') == '1') if enabled is None else bool(enabled)
        self.command = command
        self.lock = threading.RLock()
        self.base.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.base, 0o700)

    def _path(self, id: str, suffix='.apk') -> Path:
        if not isinstance(id, str) or not APK_ID_RE.fullmatch(id):
            raise ValueError('Invalid APK id')
        return self.base / (id + suffix)

    def _run(self, *args, timeout=20) -> str:
        command = shutil.which(self.command)
        if not command:
            raise RuntimeError('Waydroid executable not installed')
        try:
            r = subprocess.run([command, *args], capture_output=True, text=True,
                               timeout=timeout, check=False, env=os.environ.copy())
        except (subprocess.TimeoutExpired, OSError) as e:
            raise RuntimeError('Waydroid command unavailable or timed out') from e
        if r.returncode:
            raise RuntimeError((r.stderr or r.stdout or 'Waydroid exited with an error').strip()[:800])
        return r.stdout.strip()[:24000]

    def status(self) -> dict:
        exe = shutil.which(self.command)
        binder = any(Path(p).exists() for p in ['/dev/binder', '/dev/binderfs/binder', '/dev/anbox-binder'])
        wayland = bool(os.environ.get('WAYLAND_DISPLAY'))
        colab = os.environ.get('NOVA_COLAB_MODE') == '1'
        native = platform.machine() in ('aarch64','arm64')
        enabled = self.enabled and not colab
        ready = bool(exe and binder and wayland and enabled)
        status = {'installed':bool(exe),'binder_device':binder,'wayland_session':wayland,
                  'arch':platform.machine(),'arm64_guest':native,'enabled':enabled,
                  'colab_preview':colab,'ready_to_try':ready,
                  'mode': 'optional Waydroid runtime; not an Android framework implemented by Nova',
                  'execution_available': False, 'missing':[]}
        for ok, name in [(bool(exe),'Waydroid executable'),(binder,'Binder device'),(wayland,'Wayland session'),(enabled,'opt-in enablement')]:
            if not ok: status['missing'].append(name)
        if ready:
            try:
                state = self._run('status',timeout=5)
                status['waydroid_status'] = state[:1000]
                status['execution_available'] = all(re.search(r'^'+label+r'\s*:\s*RUNNING\s*$', state, re.I | re.M) for label in ('Session','Container'))
            except RuntimeError as e:
                status['waydroid_error'] = str(e)
        return status

    def _require_runtime(self):
        status = self.status()
        if not status['ready_to_try'] or not status['execution_available']:
            raise PermissionError('Android runtime unavailable. Configure a working local Waydroid session first.')

    def begin(self, name: str, total: int, expected_sha256: str) -> dict:
        if not isinstance(name, str) or not name.lower().endswith('.apk') or len(name)>160 or '/' in name or '\\' in name or any(ord(c)<32 for c in name):
            raise ValueError('Use a valid .apk filename')
        if not isinstance(total, int) or not 22 <= total <= MAX_APK_BYTES:
            raise ValueError('APK size invalid (100 MiB maximum)')
        if not isinstance(expected_sha256, str) or not re.fullmatch('[a-f0-9]{64}',expected_sha256):
            raise ValueError('SHA-256 checksum is required')
        with self.lock:
            id = secrets.token_hex(16)
            meta = {'id':id,'name':name,'expected_bytes':total,'expected_sha256':expected_sha256,
                    'received':0,'ready':False}
            self._path(id, '.part').touch(mode=0o600,exist_ok=False)
            self._path(id,'.json').write_text(json.dumps(meta))
            os.chmod(self._path(id,'.json'),0o600)
            return {'id':id,'max_chunk_bytes':MAX_CHUNK_BYTES}

    def _load(self,id) -> dict:
        try: meta = json.loads(self._path(id,'.json').read_text())
        except (OSError,ValueError) as e: raise ValueError('Unknown staged APK') from e
        return meta

    def append(self,id:str,index:int,encoded:str) -> dict:
        if not isinstance(encoded,str) or len(encoded)>4*((MAX_CHUNK_BYTES+2)//3)+4:
            raise ValueError('APK chunk too large')
        try: chunk=base64.b64decode(encoded,validate=True)
        except Exception as e: raise ValueError('Invalid Base64 APK chunk') from e
        if not chunk or len(chunk)>MAX_CHUNK_BYTES: raise ValueError('APK chunk size invalid')
        with self.lock:
            meta=self._load(id)
            if meta['ready']:raise ValueError('APK already finalized')
            part=self._path(id,'.part')
            if not isinstance(index,int) or index!=meta['received']:
                raise ValueError('Unexpected upload offset')
            if meta['received']+len(chunk)>meta['expected_bytes']:
                raise ValueError('APK upload exceeds declared size')
            with part.open('ab') as f:
                f.write(chunk); f.flush(); os.fsync(f.fileno())
            meta['received']+=len(chunk)
            self._path(id,'.json').write_text(json.dumps(meta))
            return {'received':meta['received'],'total':meta['expected_bytes']}

    def finish(self,id:str) -> dict:
        with self.lock:
            meta=self._load(id)
            if meta['ready']:return meta
            if meta['received']!=meta['expected_bytes']:
                raise ValueError('APK upload incomplete')
            part=self._path(id,'.part')
            result=inspect_apk(part)
            if result['sha256']!=meta['expected_sha256']:
                raise ValueError('APK checksum mismatch')
            os.replace(part,self._path(id))
            meta.update({'ready':True,'inspection':result})
            self._path(id,'.json').write_text(json.dumps(meta))
            return meta

    def list_staged(self) -> list:
        with self.lock:
            result=[]
            for file in sorted(self.base.glob('*.json')):
                try:
                    data=json.loads(file.read_text())
                    if data.get('ready') and self._path(data['id']).is_file():
                        result.append({k:data[k] for k in ('id','name','expected_bytes','ready','inspection')})
                except (OSError,ValueError,KeyError):pass
            return result[:200]

    def install(self,id:str):
        self._require_runtime()
        meta=self._load(id)
        if not meta.get('ready') or not self._path(id).is_file():raise ValueError('APK not finalized')
        if inspect_apk(self._path(id))['sha256']!=meta['expected_sha256']:
            raise ValueError('Staged APK changed after inspection')
        result=self._run('app','install',str(self._path(id)),timeout=120)
        return {'submitted':True,'output':result,'note':'Waydroid Android Package Manager determines actual installation result and signing.'}

    def packages(self):
        self._require_runtime()
        return {'output':self._run('app','list')}

    def launch(self,package):
        self._require_runtime()
        if not isinstance(package,str) or not PACKAGE_RE.fullmatch(package):raise ValueError('Invalid Android package name')
        return {'output':self._run('app','launch',package)}

    def remove(self,package):
        self._require_runtime()
        if not isinstance(package,str) or not PACKAGE_RE.fullmatch(package):raise ValueError('Invalid Android package name')
        return {'output':self._run('app','remove',package)}
