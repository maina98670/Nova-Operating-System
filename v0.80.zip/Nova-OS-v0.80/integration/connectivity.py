"""Nova connectivity adapter for Linux guests.

Reads real NetworkManager/BlueZ status when available. All radio mutations are
explicitly opt-in and are disabled in Colab or when no host adapter exists.
An interface is not a driver: this module does not create Wi-Fi/Bluetooth support.
"""
from __future__ import annotations
import os
import re
import shutil
import subprocess
from pathlib import Path

MAC = re.compile(r'^[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}$')


def split_nmcli(line):
    fields=[]; field=''; escaping=False
    for ch in line:
        if escaping:
            field += ch; escaping=False
        elif ch == '\\': escaping=True
        elif ch == ':': fields.append(field);field=''
        else: field += ch
    fields.append(field)
    return fields


class Connectivity:
    def __init__(self, runner=None, which=None, environ=None):
        self.runner = runner or subprocess.run
        self.which = which or shutil.which
        self.env = environ if environ is not None else os.environ

    def command(self, argv, timeout=5):
        try:
            completed = self.runner(argv, capture_output=True, text=True, timeout=timeout,
                                    env={**os.environ, 'LC_ALL':'C'})
        except (subprocess.TimeoutExpired, OSError) as exc:
            raise ValueError('Connectivity service unavailable: '+str(exc)) from exc
        if completed.returncode != 0:
            # Never echo a command/password, only bounded utility error output.
            raise ValueError('Device operation failed: '+(completed.stderr.strip() or 'service rejected request')[:220])
        return completed.stdout.strip()

    def control_available(self):
        return (self.env.get('NOVA_ENABLE_RADIO_CONTROL') == '1'
                and self.env.get('NOVA_COLAB_MODE') != '1')

    def nmcli(self, *args):
        if not self.which('nmcli'):raise ValueError('NetworkManager (nmcli) is not installed')
        return self.command(['nmcli', *args])

    def bluetoothctl(self, *args):
        if not self.which('bluetoothctl'):raise ValueError('BlueZ (bluetoothctl) is not installed')
        return self.command(['bluetoothctl', *args])

    def status(self):
        wifi={'available':False,'enabled':None,'connected':False,'network':None,
              'devices':[],'networks':[],'can_control':False,'reason':'No NetworkManager Wi-Fi adapter exposed'}
        bt={'available':False,'enabled':None,'devices':[],'can_control':False,
            'reason':'No BlueZ Bluetooth controller exposed'}
        if self.which('nmcli'):
            try:
                devices=self.nmcli('-t','-f','DEVICE,TYPE,STATE,CONNECTION','device','status')
                for line in devices.splitlines():
                    fields=split_nmcli(line)
                    if len(fields)>=3 and fields[1]=='wifi':
                        wifi['devices'].append({'interface':fields[0], 'state':fields[2],
                            'connection':fields[3] if len(fields)>3 else ''})
                wifi['available']=bool(wifi['devices'])
                if wifi['available']:
                    wifi['enabled']=self.nmcli('radio','wifi')=='enabled'
                    wifi['connected']=any(d['state'] in ('connected','connecting') for d in wifi['devices'])
                    wifi['network']=next((d['connection'] for d in wifi['devices'] if d['state']=='connected'),None)
                    wifi['reason']='Radio operations require NOVA_ENABLE_RADIO_CONTROL=1' if not self.control_available() else ''
                    wifi['can_control']=self.control_available()
                    try:
                        rows=self.nmcli('-t','-f','IN-USE,SSID,SIGNAL,SECURITY','device','wifi','list')
                        seen=set()
                        for line in rows.splitlines()[:100]:
                            fields=split_nmcli(line)
                            if len(fields)<4:continue
                            use,ssid,signal,security=fields[:4]
                            if not ssid or ssid in seen:continue
                            seen.add(ssid)
                            try:strength=max(0,min(100,int(signal)))
                            except ValueError:strength=0
                            wifi['networks'].append({'ssid':ssid[:64],'signal':strength,
                                'security':security[:50], 'connected':use=='*'})
                    except ValueError:pass
            except ValueError as exc: wifi['reason']=str(exc)
        if self.which('bluetoothctl'):
            try:
                show=self.bluetoothctl('show')
                bt['available']='Controller ' in show
                if bt['available']:
                    found=re.search(r'^\s*Powered:\s*(yes|no)',show,re.MULTILINE)
                    bt['enabled']=found.group(1)=='yes' if found else None
                    bt['can_control']=self.control_available()
                    bt['reason']='Radio operations require NOVA_ENABLE_RADIO_CONTROL=1' if not self.control_available() else ''
                    for line in self.bluetoothctl('devices').splitlines()[:50]:
                        found=re.match(r'^Device\s+([\da-fA-F:]{17})\s+(.+)$',line.strip())
                        if found: bt['devices'].append({'address':found.group(1),'name':found.group(2)[:100]})
            except ValueError as exc: bt['reason']=str(exc)
        return {'wifi':wifi,'bluetooth':bt,'host_control_opt_in':self.control_available(),
                'hardware_note':'Status reflects devices exposed to this Linux environment; QEMU/Colab may expose no radios.'}

    def operate(self, kind, action, payload):
        if kind not in ('wifi','bluetooth') or action not in ('enable','disable','scan','connect','pair','disconnect'):
            raise ValueError('Unsupported device operation')
        current=self.status()[kind]
        if not current['available']:
            raise ValueError('No '+kind+' adapter is exposed to this Linux environment')
        if not self.control_available():
            raise ValueError('Radio control disabled. Enable NOVA_ENABLE_RADIO_CONTROL=1 only inside an authorized test guest.')
        if kind=='wifi':
            if action in ('enable','disable'):
                self.nmcli('radio','wifi','on' if action=='enable' else 'off')
            elif action=='scan':
                self.nmcli('device','wifi','rescan')
            elif action=='connect':
                ssid=payload.get('ssid')
                password=payload.get('password','')
                if not isinstance(ssid,str) or not 1<=len(ssid)<=64 or '\0' in ssid:
                    raise ValueError('Invalid network name')
                if not isinstance(password,str) or len(password)>128:
                    raise ValueError('Invalid Wi-Fi password')
                args=['device','wifi','connect',ssid]
                if password:args+=['password',password]
                self.nmcli(*args)
            else:raise ValueError('Unsupported Wi-Fi operation')
        else:
            if action in ('enable','disable'):
                self.bluetoothctl('power','on' if action=='enable' else 'off')
            elif action in ('pair','connect','disconnect'):
                addr=payload.get('address','')
                if not isinstance(addr,str) or not MAC.fullmatch(addr):
                    raise ValueError('Invalid Bluetooth device address')
                self.bluetoothctl(action,addr)
            elif action=='scan':
                # BlueZ scanning must be time bounded; do not leave discovery on.
                self.command(['bluetoothctl','--timeout','5','scan','on'],timeout=9)
        return {'ok':True,'operation':action,'device':kind,
                'note':'Command accepted by the host device manager; connection should be rechecked.'}
