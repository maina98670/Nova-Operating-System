"""Hardware observations and explicit display/audio software preferences for Nova."""
import hashlib
import hmac
import os
import secrets
import time

DEFAULT_DEVICE={'brightness_preference':75,'volume_preference':60,'screen_timeout_minutes':5,'reduce_motion':False}


def validate_preferences(changes, previous):
    if not isinstance(changes,dict):raise ValueError('Expected an object')
    valid=set(DEFAULT_DEVICE)
    if not set(changes)<=valid:raise ValueError('Unknown device setting')
    out={**DEFAULT_DEVICE,**previous}
    for k,v in changes.items():
        if k in ('brightness_preference','volume_preference'):
            if type(v)!=int or not 0<=v<=100:raise ValueError('Invalid percentage for '+k)
        elif k=='screen_timeout_minutes':
            if type(v)!=int or v not in (1,2,5,10,30):raise ValueError('Invalid screen timeout')
        elif k=='reduce_motion':
            if type(v)!=bool:raise ValueError('Invalid reduce motion setting')
        out[k]=v
    return out


def configure_pin(pin):
    if not isinstance(pin,str) or not pin.isascii() or not pin.isdigit() or not 4<=len(pin)<=12:
        raise ValueError('PIN must contain 4 to 12 digits')
    salt=secrets.token_bytes(16)
    digest=hashlib.scrypt(pin.encode(),salt=salt,n=2**14,r=8,p=1)
    return {'salt':salt.hex(),'digest':digest.hex(),'scheme':'scrypt-n16384-r8-p1'}


def verify_pin(pin, stored):
    if not isinstance(pin,str) or len(pin)>32 or not isinstance(stored,dict):return False
    try:
        digest=hashlib.scrypt(pin.encode(),salt=bytes.fromhex(stored['salt']),n=2**14,r=8,p=1)
        return hmac.compare_digest(digest,bytes.fromhex(stored['digest']))
    except (ValueError,KeyError,TypeError):return False

class PinGuard:
    """Session-rate limiter. GUI lock isn't a substitute for kernel/app isolation."""
    def __init__(self):self.failed=0;self.block_until=0
    def check(self,pin,config):
        if time.monotonic()<self.block_until:
            raise ValueError('Too many attempts. Try again shortly.')
        if not verify_pin(pin,config):
            self.failed+=1
            if self.failed>=5:
                self.block_until=time.monotonic()+30
                self.failed=0
            return False
        self.failed=0;self.block_until=0
        return True
