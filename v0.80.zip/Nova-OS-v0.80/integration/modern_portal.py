"""Single-user browser-first Nova portal (development feature).

This is an authenticated *web experience*, not operating-system login or a
replacement for Linux user isolation. Legacy API compatibility remains.
"""
from __future__ import annotations
import hashlib
import hmac
import json
import re
import secrets
import threading
import time
from pathlib import Path


class Portal:
    NAMESPACES = {
        'clock.alarms', 'calendar.events', 'browser.bookmarks', 'browser.history',
        'music.tracks', 'music.playlists', 'video.history', 'email.drafts',
        'launcher.favorites', 'nova.preferences',
    }

    def __init__(self, config_dir: Path, app_data_factory, atomic_write):
        self.path = config_dir / 'portal-account.json'
        self.app_path = config_dir / 'mobile.sqlite3'
        self.storage = app_data_factory
        self.atomic_write = atomic_write
        self.lock = threading.RLock()
        self.sessions = {}
        self.failures = 0
        self.lockout_until = 0.0

    def _account(self):
        try:
            data = json.loads(self.path.read_text('utf-8'))
            return data if isinstance(data, dict) and data.get('hash') else None
        except (OSError, ValueError):
            return None

    def _is_auth(self, session):
        if not isinstance(session, str) or len(session) != 64:
            return False
        # Tokens are random 256-bit values, keyed to this server process.
        with self.lock:
            expiry = self.sessions.get(hashlib.sha256(session.encode()).hexdigest(), 0)
            return expiry > time.monotonic()

    def require(self, session):
        if not self._is_auth(session):
            raise PermissionError('Sign in to access your Nova account')

    def status(self, session):
        account = self._account()
        return {'setup_required': account is None, 'signed_in': self._is_auth(session),
                'name': account.get('name') if account and self._is_auth(session) else None,
                'security_scope':'Nova web preview account only; not Linux/OS authentication'}

    def _new_session(self):
        session = secrets.token_hex(32)
        with self.lock:
            now = time.monotonic()
            self.sessions = {k:v for k,v in self.sessions.items() if v>now}
            self.sessions[hashlib.sha256(session.encode()).hexdigest()] = now + 8*3600
        return session

    def create(self, payload):
        name = str(payload.get('name','')).strip()
        password = payload.get('password','')
        if not 2 <= len(name) <= 50 or any(ord(c)<32 for c in name):
            raise ValueError('Name must be 2–50 characters')
        if not isinstance(password,str) or not 8 <= len(password) <= 128:
            raise ValueError('Password must be 8–128 characters')
        with self.lock:
            if self._account():
                raise ValueError('An account is already configured')
            salt = secrets.token_bytes(16)
            digest = hashlib.scrypt(password.encode(),salt=salt,n=2**14,r=8,p=1)
            self.atomic_write(self.path, {'name':name,'salt':salt.hex(),
                         'hash':digest.hex(),'algorithm':'scrypt-n16384-r8-p1'})
            return {'name':name,'session':self._new_session()}

    def login(self,payload):
        password=payload.get('password','')
        account=self._account()
        with self.lock:
            if time.monotonic()<self.lockout_until:
                raise ValueError('Too many attempts. Try again in 30 seconds')
            if not account:
                raise ValueError('Create a Nova account first')
            try:
                candidate=hashlib.scrypt(str(password).encode(),salt=bytes.fromhex(account['salt']),n=2**14,r=8,p=1)
                valid=hmac.compare_digest(candidate,bytes.fromhex(account['hash']))
            except (ValueError,KeyError,TypeError):
                valid=False
            if not valid:
                self.failures+=1
                if self.failures>=5:
                    self.lockout_until=time.monotonic()+30
                    self.failures=0
                raise ValueError('Incorrect password')
            self.failures=0
            return {'name':account['name'],'session':self._new_session()}

    def logout(self,session):
        with self.lock:
            if session:
                self.sessions.pop(hashlib.sha256(session.encode()).hexdigest(),None)
        return {'signed_in':False}

    def list_records(self,session,namespace):
        self.require(session)
        if namespace not in self.NAMESPACES:raise ValueError('Unknown application storage')
        with self.storage(self.app_path) as db:
            return db.list(namespace,1000)

    def save_record(self,session,payload):
        self.require(session)
        namespace=payload.get('namespace')
        if namespace not in self.NAMESPACES:raise ValueError('Unknown application storage')
        data=payload.get('value')
        if not isinstance(data,dict):raise ValueError('Expected application record')
        with self.storage(self.app_path) as db:
            key=db.save(namespace,data,payload.get('id'))
        return {'id':key,'saved':True}

    def delete_record(self,session,payload):
        self.require(session)
        namespace=payload.get('namespace')
        if namespace not in self.NAMESPACES:raise ValueError('Unknown application storage')
        with self.storage(self.app_path) as db:
            deleted=db.delete(namespace,payload.get('id'))
        return {'deleted':deleted}

    def diagnostics(self,session,cmd,system_status):
        self.require(session)
        cmd=str(cmd).strip().lower()
        status=system_status()
        commands={
          'help': 'Supported: help, date, whoami, uname, memory, network, version, pwd',
          'date':time.strftime('%Y-%m-%d %H:%M:%S %Z'),
          'whoami':self._account().get('name','Nova User'),
          'uname':status.get('os','Linux')+' '+status.get('arch','unknown'),
          'memory':str(status.get('memory_mb'))+' MB total RAM',
          'network':json.dumps(status.get('network'),ensure_ascii=False),
          'version':'Nova v0.80 web preview / Linux-hosted',
          'pwd':'~/NovaFiles (virtualized app view)',
        }
        if cmd not in commands: raise ValueError('Read-only diagnostics console. Try help')
        return {'output':commands[cmd], 'mode':'safe read-only diagnostics; not a Linux terminal'}
