#!/usr/bin/env python3
"""Nova pre-hardware platform services (data packages, diagnostics, recovery).

Data-only development packages are NOT trusted executable apps. These services
run as an unprivileged user and do not change host network, hardware or boot.
"""
from __future__ import annotations
import base64
import hashlib
import json
import os
import re
import shutil
import sqlite3
from contextlib import closing
import stat
import tempfile
import time
import zipfile
from pathlib import Path, PurePosixPath

APP_ID = re.compile(r'^org\.nova\.[a-z][a-z0-9_-]{1,47}$')
VERSION = re.compile(r'^\d+\.\d+\.\d+(?:-[a-z0-9.-]{1,24})?$')
MAX_PACKAGE = 4 * 1024 * 1024
MAX_UNPACKED = 8 * 1024 * 1024
MAX_BACKUP = 32 * 1024 * 1024
PERSISTENT_JSON = ('settings.json','notes.json','messages.json','contacts.json','notifications.json','device-preferences.json')


def _within_zip(name: str) -> bool:
    path = PurePosixPath(name)
    return bool(name and not name.startswith('/') and '\\' not in name
                and all(part not in ('', '.', '..') for part in name.split('/'))
                and not name.endswith('/') and all(part not in ('', '.', '..') for part in path.parts)
                and len(path.parts) <= 8 and len(name) <= 180)


def _regular_entry(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16)
    return (not stat.S_ISLNK(mode) and not (stat.S_IFMT(mode) and not stat.S_ISREG(mode)))


def _zip_entries(archive: zipfile.ZipFile, max_bytes: int):
    entries = {}
    total = 0
    for info in archive.infolist():
        if not _within_zip(info.filename) or not _regular_entry(info):
            raise ValueError('Unsafe ZIP entry')
        if info.filename in entries:
            raise ValueError('Duplicate ZIP entry')
        total += info.file_size
        if total > max_bytes or info.file_size > max_bytes:
            raise ValueError('Archive expands beyond size limit')
        entries[info.filename] = info
    return entries


class PackageStore:
    """Only installs checksum-verified resources; does not launch code."""
    def __init__(self, data: Path):
        self.root = Path(data) / 'packages'
        self.root.mkdir(parents=True, exist_ok=True)

    def list(self):
        found = []
        for path in sorted(self.root.iterdir()):
            if path.is_dir() and not path.is_symlink() and APP_ID.fullmatch(path.name):
                try:
                    manifest = json.loads((path / 'manifest.json').read_text('utf-8'))
                    if manifest.get('id') == path.name:
                        found.append({'id': path.name, 'version':manifest.get('version'),
                            'name': manifest.get('name',path.name),
                            'runtime':'resources-only', 'trusted_executable':False})
                except (OSError, ValueError):
                    continue
        return found

    def install_base64(self, encoded: str):
        if not isinstance(encoded, str) or len(encoded) > MAX_PACKAGE * 2:
            raise ValueError('Package input too large')
        try:
            data = base64.b64decode(encoded, validate=True)
        except Exception as exc:
            raise ValueError('Package must be base64 ZIP') from exc
        if len(data) > MAX_PACKAGE:
            raise ValueError('Package ZIP exceeds 4 MB')
        temp_zip = self.root / ('.upload-' + os.urandom(8).hex() + '.zip')
        try:
            temp_zip.write_bytes(data)
            with zipfile.ZipFile(temp_zip) as archive:
                entries = _zip_entries(archive, MAX_UNPACKED)
                if 'manifest.json' not in entries:
                    raise ValueError('Package manifest.json missing')
                manifest = json.loads(archive.read('manifest.json'))
                if not isinstance(manifest, dict) or manifest.get('schema') != 1:
                    raise ValueError('Unsupported package schema')
                app_id, version = manifest.get('id'), manifest.get('version')
                if not isinstance(app_id, str) or not APP_ID.fullmatch(app_id):
                    raise ValueError('Invalid Nova application id')
                if not isinstance(version, str) or not VERSION.fullmatch(version):
                    raise ValueError('Invalid package version')
                names = manifest.get('files')
                if not isinstance(names, dict) or not names or len(names) > 100:
                    raise ValueError('Missing resource checksums')
                if set(entries) != set(names) | {'manifest.json'}:
                    raise ValueError('Files do not match manifest')
                for name, digest in names.items():
                    if not name.startswith('resources/') or not isinstance(digest,str) or not re.fullmatch('[0-9a-f]{64}', digest):
                        raise ValueError('Only checksum-verified data resources are supported')
                    if hashlib.sha256(archive.read(name)).hexdigest() != digest:
                        raise ValueError('Package file checksum mismatch')
                if (self.root / app_id).exists():
                    raise ValueError('Package already installed; uninstall before reinstalling')
                staging = Path(tempfile.mkdtemp(prefix='.install-', dir=self.root))
                try:
                    for name in entries:
                        dest = staging.joinpath(*PurePosixPath(name).parts)
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        dest.write_bytes(archive.read(name))
                        dest.chmod(0o600)
                    os.replace(staging, self.root / app_id)
                finally:
                    if staging.exists(): shutil.rmtree(staging)
                return {'installed':app_id, 'version':version,'runtime':'resources-only', 'trusted_executable':False}
        except (zipfile.BadZipFile, UnicodeError, KeyError, TypeError, json.JSONDecodeError) as exc:
            raise ValueError('Invalid Nova data package') from exc
        finally:
            temp_zip.unlink(missing_ok=True)

    def uninstall(self, app_id: str):
        if not isinstance(app_id, str) or not APP_ID.fullmatch(app_id):
            raise ValueError('Invalid app id')
        dest = self.root / app_id
        if not dest.is_dir() or dest.is_symlink():
            raise ValueError('Package not installed')
        shutil.rmtree(dest)
        return {'uninstalled':app_id}


def system_diagnostics(root: Path):
    info = {'time_unix': int(time.time()), 'network_interfaces': [],
            'audio_devices':False, 'qemu_guest': False,'ram_available_mb':None,
            'storage_free_mb':None, 'load_average':None,'health_scope':'host or guest observations; no hardware control'}
    try:
        info['network_interfaces'] = sorted(p.name for p in Path('/sys/class/net').iterdir() if p.name!='lo')
        info['audio_devices'] = Path('/dev/snd').is_dir()
        info['qemu_guest'] = 'QEMU' in (Path('/sys/class/dmi/id/product_name').read_text(errors='replace') if Path('/sys/class/dmi/id/product_name').is_file() else '')
    except OSError: pass
    try:
        text = Path('/proc/meminfo').read_text()
        m = re.search(r'^MemAvailable:\s+(\d+)', text, re.M)
        if m: info['ram_available_mb'] = int(m.group(1)) // 1024
    except OSError: pass
    try: info['storage_free_mb'] = shutil.disk_usage(root).free // 1024 // 1024
    except OSError: pass
    try: info['load_average'] = list(os.getloadavg())
    except OSError: pass
    return info


def make_backup(config: Path, files: Path):
    """Create a snapshot of Nova user data. Does not include Rust DB or credentials."""
    backups = config / 'backups'
    backups.mkdir(parents=True, exist_ok=True)
    name = time.strftime('nova-%Y%m%d-%H%M%S-', time.gmtime()) + os.urandom(3).hex() + '.zip'
    staging = backups / ('.' + name + '.tmp')
    written = 0
    try:
        with zipfile.ZipFile(staging,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
            for filename in PERSISTENT_JSON:
                f = config / filename
                if f.is_file() and not f.is_symlink():
                    size = f.stat().st_size
                    written += size
                    if written > MAX_BACKUP: raise ValueError('Backup exceeds size limit')
                    archive.write(f, 'config/' + filename)
            # Snapshot Nova v0.75 app SQLite using the SQLite backup API rather than
            # copying a live WAL database (which could omit recent commits).
            mobile_path = os.environ.get('NOVA_MOBILE_DATA')
            if mobile_path:
                db = Path(mobile_path)
                if db.is_file() and not db.is_symlink():
                    with tempfile.TemporaryDirectory(prefix='nova-mobile-backup-') as tmp:
                        snapshot = Path(tmp) / 'mobile.sqlite3'
                        with closing(sqlite3.connect(str(db))) as source, closing(sqlite3.connect(str(snapshot))) as target:
                            source.backup(target)
                        written += snapshot.stat().st_size
                        if written > MAX_BACKUP:raise ValueError('Backup exceeds size limit')
                        archive.write(snapshot, 'mobile/mobile.sqlite3')
            for base, folders, filenames in os.walk(files, followlinks=False):
                folders[:] = sorted(n for n in folders if not (Path(base)/n).is_symlink())
                for name0 in sorted(filenames):
                    src = Path(base)/name0
                    if not src.is_file() or src.is_symlink(): continue
                    rel = src.relative_to(files).as_posix()
                    if not _within_zip(rel): continue
                    written += src.stat().st_size
                    if written > MAX_BACKUP: raise ValueError('Backup exceeds size limit')
                    archive.write(src, 'files/' + rel)
        os.chmod(staging,0o600)
        os.replace(staging, backups / name)
        return {'name':name,'bytes':(backups/name).stat().st_size,
                'scope':'Nova GUI + v0.75 preferences (excluding PIN hashes) + mobile app data (when configured) + files; original Rust core DB excluded'}
    finally:
        staging.unlink(missing_ok=True)


def list_backups(config: Path):
    backups = config / 'backups'
    return [{'name':p.name,'bytes':p.stat().st_size} for p in sorted(backups.glob('nova-*.zip'))
            if p.is_file() and not p.is_symlink()]


def restore_backup(config: Path, files: Path, name: str):
    """Recover to a separate directory for inspection; never overwrite live data."""
    if not isinstance(name, str) or not re.fullmatch(r'nova-[0-9]{8}-[0-9]{6}-[0-9a-f]{6}\.zip', name):
        raise ValueError('Invalid backup name')
    src = config / 'backups' / name
    if not src.is_file() or src.is_symlink() or src.stat().st_size > MAX_BACKUP:
        raise ValueError('Backup not found or too large')
    recovery = config / 'recovered'
    recovery.mkdir(parents=True, exist_ok=True)
    dest = recovery / name.removesuffix('.zip')
    if dest.exists(): raise ValueError('Recovery directory already exists')
    stage = Path(tempfile.mkdtemp(prefix='.recover-',dir=recovery))
    try:
        with zipfile.ZipFile(src) as z:
            entries = _zip_entries(z, MAX_BACKUP)
            for filename, info in entries.items():
                if not (filename.startswith('files/') or filename == 'mobile/mobile.sqlite3' or filename in {'config/' + value for value in PERSISTENT_JSON}):
                    raise ValueError('Unexpected backup entry')
                if info.file_size > MAX_BACKUP: raise ValueError('Backup file too large')
                out = stage.joinpath(*PurePosixPath(filename).parts)
                out.parent.mkdir(parents=True,exist_ok=True)
                out.write_bytes(z.read(info))
                out.chmod(0o600)
        os.replace(stage,dest)
        return {'recovered_to':str(dest), 'live_data_changed':False,
                'note':'Recovery is staged; administrator must review before applying.'}
    except (zipfile.BadZipFile, OSError, UnicodeError) as exc:
        raise ValueError('Invalid backup') from exc
    finally:
        if stage.exists(): shutil.rmtree(stage)
