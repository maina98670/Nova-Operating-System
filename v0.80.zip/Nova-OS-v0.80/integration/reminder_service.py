"""Background notification delivery for Nova Clock and Calendar.
Run as the regular Nova user; supports QEMU/Linux, not suspend/resume alarms.
"""
from __future__ import annotations
import argparse
import datetime as dt
import os
import sys
import time
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'native-shell'))
from mobile_store import AppData
from backend import NovaClient, NovaApiError


def _as_local(iso_value):
    if not isinstance(iso_value,str):return None
    try:
        result=dt.datetime.fromisoformat(iso_value)
        return result.astimezone().replace(tzinfo=None) if result.tzinfo else result
    except ValueError:return None


def send_due(store, notify, now=None):
    """Send due notifications. Mark after successful delivery for at-least-once delivery."""
    now=now or dt.datetime.now()
    total=0
    cases=(('clock.alarms','label','Nova Clock','enabled'),
           ('calendar.events','title','Nova Calendar','remind'))
    for ns,name_field,heading,flag in cases:
        for item in store.list(ns,MAX_CHECK):
            if not item.get(flag, False) or item.get('fired',False):continue
            moment=_as_local(item.get('at'))
            if moment is None or moment>now:continue
            # Discard long overdue reminders instead of flooding after downtime.
            if (now-moment).days>=2:
                changed={k:v for k,v in item.items() if k!='id'}
                changed['fired']=True
                store.save(ns,changed,item['id']);continue
            body=str(item.get(name_field,'Reminder'))[:180]
            notify(heading,body)
            changed={k:v for k,v in item.items() if k!='id'}
            changed['fired']=True
            store.save(ns,changed,item['id'])
            total+=1
    return total


MAX_CHECK=1000


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--interval',type=int,default=10)
    parser.add_argument('--once',action='store_true')
    args=parser.parse_args()
    if not 1<=args.interval<=3600:parser.error('interval must be 1..3600')
    client=NovaClient('http://127.0.0.1:8767')
    while True:
        try:
            def notify(title,message):
                # Connect each iteration so server restarts don't leave stale tokens.
                client.connect()
                client.post('/api/notifications/post',{'title':title,'body':message})
            with AppData() as data:
                send_due(data,notify)
        except (NovaApiError,OSError,ValueError) as e:
            print('[nova-reminders] backend unavailable:',type(e).__name__,file=sys.stderr)
        if args.once:break
        time.sleep(args.interval)
    return 0


if __name__=='__main__':raise SystemExit(main())
