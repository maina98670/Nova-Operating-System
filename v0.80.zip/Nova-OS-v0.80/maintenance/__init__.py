"""Nova development maintenance tools. Hardware acceptance is separate."""
