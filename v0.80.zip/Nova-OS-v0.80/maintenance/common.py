"""Private, atomic state files and constrained maintenance workspaces."""
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import tempfile


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.' + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, sort_keys=True, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        Path(name).unlink(missing_ok=True)


def workspace(path, *, create=False):
    supplied = Path(path).absolute()
    if supplied.is_symlink() or any(p.is_symlink() for p in supplied.parents):
        raise ValueError('Maintenance workspace cannot contain symlink components')
    path = supplied.resolve()
    if path == Path('/') or len(path.parts) < 4:
        raise ValueError('Use a dedicated development directory')
    marker = path / '.nova-maintenance-workspace'
    if create:
        if path.exists() and any(path.iterdir()):
            raise ValueError('Workspace initialization requires an empty directory')
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
        marker.write_text('nova-directory-maintenance-v1\n')
        marker.chmod(0o600)
    if marker.is_symlink() or not marker.is_file() or marker.read_text() != 'nova-directory-maintenance-v1\n':
        raise ValueError('Not an initialized Nova maintenance workspace')
    return path


@contextmanager
def locked(path):
    root = workspace(path)
    with (root / '.lock').open('a') as stream:
        os.chmod(root / '.lock', 0o600)
        fcntl.flock(stream, fcntl.LOCK_EX)
        try:
            yield root
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)
