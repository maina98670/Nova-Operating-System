"""Collect observations and validate operator-recorded physical test evidence."""
import json
from pathlib import Path
import platform
from .common import digest

COMPONENTS = ('display','touch','storage','audio','wifi','bluetooth','camera',
              'sensors','battery','usb','modem')


def observations():
    def exists(pattern):
        return bool(list(Path('/').glob(pattern.lstrip('/'))))
    return {'architecture': platform.machine(), 'kernel': platform.release(),
            'nodes': {'drm': exists('/dev/dri/card*'), 'input': exists('/dev/input/event*'),
                      'audio': Path('/dev/snd').is_dir(), 'camera': exists('/dev/video*'),
                      'battery': exists('/sys/class/power_supply/*/capacity')},
            'components': {name: 'unverified' for name in COMPONENTS},
            'device_functions_verified': False,
            'note': 'Node presence does not prove a driver or physical function works'}


def validate_evidence(path, *, integration=False):
    path = Path(path).resolve()
    report = json.loads(path.read_text())
    if not isinstance(report,dict):
        raise ValueError('Hardware evidence must be an object')
    errors = []
    device_id = report.get('device_id')
    boot_id = report.get('boot_id')
    if report.get('schema') != 1 or not isinstance(device_id,str) or not device_id.strip() or not boot_id:
        errors.append('Exact device identity and same-session boot identity are required')
    checks = report.get('components',{})
    for name in COMPONENTS:
        check = checks.get(name,{}) if isinstance(checks,dict) else {}
        if not isinstance(check,dict) or check.get('status') != 'passed':
            errors.append(name + ': no passed physical test')
            continue
        if check.get('device_id') != device_id or check.get('boot_id') != boot_id:
            errors.append(name + ': device or boot session mismatch')
        relative = check.get('evidence_file','')
        target = (path.parent/relative).resolve()
        if (not relative or Path(relative).is_absolute() or not target.is_relative_to(path.parent)
                or not target.is_file() or target.is_symlink()):
            errors.append(name + ': physical test evidence file missing')
        elif digest(target) != check.get('sha256'):
            errors.append(name + ': evidence checksum mismatch')
        if not isinstance(check.get('measurement'),dict) or not check.get('measurement'):
            errors.append(name + ': measured result missing')
    if integration:
        combined = report.get('simultaneous_usage',{})
        if (not isinstance(combined,dict) or combined.get('status') != 'passed'
                or combined.get('boot_id') != boot_id
                or not {'camera','audio','wifi','touch'}.issubset(set(combined.get('active_components',[])))
                or type(combined.get('duration_seconds')) not in (int,float)
                or combined['duration_seconds'] <= 0):
            errors.append('Concurrent camera audio Wi-Fi and touch test has no same-session evidence')
    return {'accepted': not errors, 'scope': 'Operator-supplied evidence validation; no independent physical observation',
            'blockers': errors, 'device_id': device_id}
