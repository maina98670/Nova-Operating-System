//! Local process-per-command IPC bridge. Each command reads a single JSON request
//! on stdin, runs the *original* Nova Rust core, and emits JSON on stdout.
//! No listening network socket, no App Manager impersonation, no modem simulation.
use nova_app_storage::ScopedStorage;
use nova_contacts_core::ContactStore;
use nova_messages_core::MessageStore;
use nova_settings_core::{SettingValue, SettingsStore};
use serde_json::{json, Value};
use std::fs;
use std::io::{self, Read};
use std::path::{PathBuf,Path,Component};

struct ScopedDir { dir: PathBuf }
impl ScopedDir {
    fn new(app: &str) -> Result<Self,String> {
        // Only these three literals are accepted; no user path comes from IPC.
        if !["settings","contacts","messages"].contains(&app) { return Err("invalid core".into()); }
        let root = std::env::var_os("NOVA_CORE_ROOT").ok_or("NOVA_CORE_ROOT is required")?;
        let dir = PathBuf::from(root).join(app);
        fs::create_dir_all(&dir).map_err(|e|e.to_string())?;
        Ok(Self{dir})
    }
    fn path(&self, relative:&str)->io::Result<PathBuf> {
        if !["settings.json","contacts.json","messages.json"].contains(&relative) {
            return Err(io::Error::new(io::ErrorKind::InvalidInput,"unsupported key"));
        }
        Ok(self.dir.join(relative))
    }
}
impl ScopedStorage for ScopedDir {
    fn read(&self, relative: &str)->io::Result<Option<Vec<u8>>> {
        match fs::read(self.path(relative)?) {
            Ok(v)=>Ok(Some(v)),
            Err(e) if e.kind()==io::ErrorKind::NotFound=>Ok(None),
            Err(e)=>Err(e),
        }
    }
    fn write(&self, relative: &str, data:&[u8])->io::Result<()> {
        let p=self.path(relative)?;
        let tmp=p.with_extension("new");
        fs::write(&tmp,data)?;
        fs::rename(&tmp,p)
    }
}
// Strict path confinement for Nova's user-files folder; resolves existing parents.
fn user_path(raw:&str, existing:bool)->Result<PathBuf,String>{
    let root=std::env::var_os("NOVA_FILES_ROOT").ok_or("NOVA_FILES_ROOT required")?;
    let root=fs::canonicalize(PathBuf::from(root)).map_err(|e|e.to_string())?;
    let relative=Path::new(raw);
    if relative.is_absolute() || relative.components().any(|c|!matches!(c,Component::Normal(_))) {
        return Err("invalid relative path".into());
    }
    let p=root.join(relative);
    let resolved=if existing {
        fs::canonicalize(&p).map_err(|e|e.to_string())?
    } else {
        let parent=p.parent().ok_or("missing parent")?;
        fs::canonicalize(parent).map_err(|e|e.to_string())?.join(p.file_name().ok_or("missing filename")?)
    };
    if !resolved.starts_with(&root)||resolved==root {
        return Err("file is outside Nova Files".into());
    }
    Ok(resolved)
}

fn string<'a>(req: &'a Value,key: &str)->Result<&'a str,String>{
    req.get(key).and_then(Value::as_str).ok_or_else(||format!("missing string {key}"))
}
fn run(req:Value)->Result<Value,String>{
    match string(&req,"cmd")? {
        "health"=>Ok(json!({"core":"Nova v0.60 Rust", "settings":true,"contacts":true,"messages_readonly":true})),
        "settings_list"=>{
            let s=SettingsStore::load(ScopedDir::new("settings")?).map_err(|e|e.to_string())?;
            let vals:serde_json::Map<String,Value>=s.list().into_iter().map(|(k,v)|(k.to_owned(),json!(v))).collect();
            Ok(Value::Object(vals))
        },
        "settings_set"=>{
            let mut s=SettingsStore::load(ScopedDir::new("settings")?).map_err(|e|e.to_string())?;
            let k=string(&req,"key")?;
            let value=req.get("value").ok_or("missing value")?;
            let v=if let Some(b)=value.as_bool(){SettingValue::Bool(b)}
            else if let Some(n)=value.as_i64(){SettingValue::Int(n)}
            else if let Some(st)=value.as_str(){SettingValue::Text(st.to_owned())}
            else {return Err("unsupported setting value type".into())};
            s.set(k,v).map_err(|e|e.to_string())?;
            Ok(json!({"key":k,"value":s.get(k)}))
        },
        "file_read"=>{
            let p=user_path(string(&req,"path")?,true)?;
            let data=nova_fsmgr::read_file(&p).map_err(|e|e.to_string())?;
            if data.len()>1024*1024 {return Err("text file exceeds 1 MB".into())}
            let content=String::from_utf8(data).map_err(|_|"not UTF-8 text")?;
            Ok(json!({"content":content}))
        },
        "file_write"=>{
            let p=user_path(string(&req,"path")?,true)?;
            let contents=string(&req,"content")?;
            if contents.len()>1024*1024{return Err("text file exceeds 1 MB".into())}
            nova_fsmgr::write_file(&p,contents.as_bytes()).map_err(|e|e.to_string())?;
            Ok(json!({"saved":true}))
        },
        "file_create"=>{
            let p=user_path(string(&req,"path")?,false)?;
            let contents=string(&req,"content")?;
            if contents.len()>1024*1024{return Err("text file exceeds 1 MB".into())}
            nova_fsmgr::create_file(&p,contents.as_bytes()).map_err(|e|e.to_string())?;
            Ok(json!({"created":true}))
        },
        "file_rename"=>{
            let p=user_path(string(&req,"path")?,true)?;
            let to=user_path(string(&req,"dest")?,false)?;
            if to.exists(){return Err("destination exists".into())}
            nova_fsmgr::rename_file(&p,&to).map_err(|e|e.to_string())?;
            Ok(json!({"renamed":true}))
        },
        "contacts_list"=>{
            let s=ContactStore::load(ScopedDir::new("contacts")?).map_err(|e|e.to_string())?;
            Ok(json!(s.list()))
        },
        "contacts_add"=>{
            let mut s=ContactStore::load(ScopedDir::new("contacts")?).map_err(|e|e.to_string())?;
            let name=string(&req,"name")?.trim();
            if name.is_empty()||name.chars().count()>100{return Err("invalid contact name".into())}
            let phone=string(&req,"phone")?.trim();
            if phone.chars().count()>50{return Err("phone too long".into())}
            let id=s.add(name.to_owned(), if phone.is_empty(){vec![]}else{vec![phone.to_owned()]},None).map_err(|e|e.to_string())?;
            Ok(json!({"id":id}))
        },
        "contacts_remove"=>{
            let mut s=ContactStore::load(ScopedDir::new("contacts")?).map_err(|e|e.to_string())?;
            let id=req.get("id").and_then(Value::as_u64).ok_or("invalid contact id")?;
            let id=u32::try_from(id).map_err(|_|"contact ID overflow")?;
            s.remove(id).map_err(|e|e.to_string())?;
            Ok(json!({"deleted":id}))
        },
        "contacts_update"=>{
            let mut s=ContactStore::load(ScopedDir::new("contacts")?).map_err(|e|e.to_string())?;
            let id=req.get("id").and_then(Value::as_u64).ok_or("invalid contact id")?;
            let id=u32::try_from(id).map_err(|_|"contact ID overflow")?;
            let name=string(&req,"name")?.trim();
            if name.is_empty()||name.chars().count()>100{return Err("invalid contact name".into())}
            let phone=string(&req,"phone")?.trim();
            if phone.chars().count()>50{return Err("phone too long".into())}
            s.update(id,name.to_owned(),if phone.is_empty(){vec![]}else{vec![phone.to_owned()]}).map_err(|e|e.to_string())?;
            Ok(json!({"updated":id}))
        },
        "messages_threads"=>{
            let s=MessageStore::load(ScopedDir::new("messages")?).map_err(|e|e.to_string())?;
            let threads:Vec<Value>=s.threads().into_iter().map(|t|json!({"peer":t.peer_number,"messages":t.messages})).collect();
            Ok(json!(threads))
        },
        _=>Err("unsupported command".into()),
    }
}
fn main(){
    let mut buf=String::new();
    let output=(||->Result<Value,String>{
        io::stdin().take(65536).read_to_string(&mut buf).map_err(|e|e.to_string())?;
        let req:Value=serde_json::from_str(&buf).map_err(|e|e.to_string())?;
        run(req)
    })();
    match output {
        Ok(value)=>println!("{}",json!({"ok":true,"result":value})),
        Err(e)=>{println!("{}",json!({"ok":false,"error":e}));std::process::exit(1)}
    }
}
