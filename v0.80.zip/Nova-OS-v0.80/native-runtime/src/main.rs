//! Nova original runtime IPC service daemon. It does NOT render display pixels.
//! The graphical display is still Weston + native Qt until a Nova compositor backend is implemented.
use nova_app_manager::AppManager;
use nova_compositor_core::server::CompositorServer;
use nova_fsmgr::paths;
use std::fs;
use std::thread;
use std::time::Duration;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    nova_fsmgr::ensure_dirs(&[paths::RUN, paths::LOG, paths::APPS])?;
    let apps=AppManager::new();
    let mut installed=0usize;
    if let Ok(entries)=fs::read_dir(paths::APPS) {
        for entry in entries.flatten() {
            let dir=entry.path();
            if !dir.is_dir() || !dir.join("nova-app.toml").is_file() { continue; }
            if let Some(id)=dir.file_name().and_then(|x|x.to_str()) {
                match apps.install(id) {
                    Ok(())=>{installed+=1; println!("[nova-runtime] registered {id}");},
                    Err(e)=>eprintln!("[nova-runtime] cannot register {id}: {e}")
                }
            }
        }
    }
    let _app_thread=apps.serve(nova_ipc::SOCKET_PATH)?;
    let compositor=CompositorServer::new();
    let _compositor_thread=compositor.serve(nova_compositor_core::protocol::SOCKET_PATH)?;
    let output=compositor.create_output("nova-qemu-protocol-output",1080,2400);
    println!("[nova-runtime] App Manager socket={}, app manifests={}, compositor protocol output={:?}",
             nova_ipc::SOCKET_PATH,installed,output);
    println!("[nova-runtime] Compositor is protocol/state only; Weston remains the display renderer.");
    loop { thread::sleep(Duration::from_secs(60)); }
}
