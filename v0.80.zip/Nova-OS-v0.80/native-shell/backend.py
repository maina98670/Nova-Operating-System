"""Local Nova native GUI -> existing JSON API / original Rust bridge transport.

Uses only Python's standard library.  No arbitrary commands or web access.
All mutation requests require the per-run token served from the local GUI.
"""
from __future__ import annotations
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

TOKEN_RE = re.compile(r'<meta\s+name="nova-token"\s+content="([^"]+)"')

class NovaApiError(Exception):
    pass

@dataclass
class NovaClient:
    base: str = 'http://127.0.0.1:8767'
    token: str = ''

    def __post_init__(self):
        p = urllib.parse.urlsplit(self.base)
        if p.scheme != 'http' or p.hostname not in ('localhost','127.0.0.1','::1') or p.username or p.password or p.path not in ('','/') or p.query or p.fragment:
            raise ValueError('Nova GUI only accepts an uncredentialed local HTTP backend')
        self.base = self.base.rstrip('/')

    def _read(self, path: str, post=None, *, raw: bool=False):
        if not path.startswith('/') or path.startswith('//'):
            raise ValueError('API path must be absolute and local')
        headers = {'Accept': 'application/json'}
        data = None
        if post is not None:
            if not self.token:
                self.connect()
            data = json.dumps(post, ensure_ascii=False).encode('utf-8')
            headers.update({'Content-Type':'application/json','X-Nova-Token':self.token})
        request = urllib.request.Request(self.base + path, data=data, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=8) as response:
                content = response.read(10 * 1024 * 1024)
        except urllib.error.HTTPError as exc:
            msg = exc.reason
            try:
                msg = json.loads(exc.read(2048)).get('error', msg)
            except (ValueError, OSError):
                pass
            raise NovaApiError(f'{exc.code}: {msg}') from exc
        except (OSError, urllib.error.URLError) as exc:
            raise NovaApiError('Nova backend unavailable: '+str(exc)) from exc
        if raw:
            return content
        try:
            return json.loads(content)
        except ValueError as exc:
            raise NovaApiError('Invalid Nova API response') from exc

    def connect(self):
        page = self._read('/', raw=True).decode('utf-8')
        match = TOKEN_RE.search(page)
        if not match:
            raise NovaApiError('Nova session token not found')
        self.token = match.group(1)
        return self.get('/api/core/status')

    def get(self, route, **params):
        if params:
            route += ('&' if '?' in route else '?') + urllib.parse.urlencode(params)
        return self._read(route)

    def post(self, path, payload):
        return self._read(path, payload)

    def image(self, path):
        return self._read('/api/media?' + urllib.parse.urlencode({'path':path}), raw=True)
