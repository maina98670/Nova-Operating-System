"""Eight native Qt applications for Nova OS v0.74.

Apps run as normal Linux-user Qt processes when NOVA_SEPARATE_APPS=1.
These Qt clients do not constitute OS sandboxing or full Android compatibility.
"""
from __future__ import annotations
import email
from email.message import EmailMessage
import email.utils
import imaplib
import smtplib
import os
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

from PyQt5.QtCore import Qt, QUrl, QProcess, QTimer, QObject, pyqtSignal
from PyQt5.QtWidgets import (
    QLabel, QPushButton, QLineEdit, QPlainTextEdit, QTextEdit, QHBoxLayout,
    QVBoxLayout, QListWidget, QFileDialog, QInputDialog, QMessageBox,
    QComboBox, QDateTimeEdit, QCheckBox, QWidget
)
from mobile_store import AppData


def _button(title, on_click):
    button=QPushButton(title)
    button.clicked.connect(on_click)
    return button


def _line(placeholder, content=''):
    value=QLineEdit()
    value.setPlaceholderText(placeholder)
    value.setText(str(content))
    return value


def _section(layout,title,detail=''):
    head=QLabel(title)
    head.setStyleSheet('font-size:23px;font-weight:700;padding:10px 0')
    layout.addWidget(head)
    if detail:
        sub=QLabel(detail);sub.setWordWrap(True);layout.addWidget(sub)


def is_web_address(address):
    p=urlparse(address.strip())
    return p.scheme in ('http','https') and bool(p.hostname) and not p.username and not p.password


class QtResult(QObject):
    completed=pyqtSignal(bool,str)
    inbox=pyqtSignal(str)


class NovaMobileApps:
    def __init__(self,host):
        self.host=host
        self.store=AppData()
        self.browser_view=None
        self.media_player=None
        self.video_player=None
        self.shell_proc=None
        self.mail_results=[]
        self.mail_signal=QtResult(host)
        self._mail_events=[]
        self.mail_signal.completed.connect(self._mail_finished)
        self.mail_signal.inbox.connect(self._mail_inbox_received)
        self.clock_timer=None

    def _refresh(self, name):self.host.open_page(name,False)

    def _notify(self,title,body):
        try:self.host.client.post('/api/notifications/post',{'title':title,'body':body})
        except Exception:pass

    def _safe(self, action):
        try:return action()
        except Exception as exc:
            self.host.message(f'Nova application error: {exc}',False)
            return None

    def page_clock(self,v):
        _section(v,'Nova Clock','Local time, alarms, countdown and stopwatch. Background reminders require the Nova reminder service.')
        now=QLabel(datetime.now().strftime('%A %d %B %Y · %H:%M:%S'))
        now.setStyleSheet('font-size:25px; padding:10px;')
        v.addWidget(now)
        clock=QTimer(now);clock.timeout.connect(lambda:now.setText(datetime.now().strftime('%A %d %B %Y · %H:%M:%S')));clock.start(1000)
        _section(v,'Alarms')
        when=QDateTimeEdit(datetime.now()+timedelta(minutes=5));when.setCalendarPopup(True);when.setDisplayFormat('yyyy-MM-dd HH:mm');v.addWidget(when)
        label=_line('Alarm label','Alarm');v.addWidget(label)
        def add_alarm():
            def save():
                self.store.save('clock.alarms',{'at':when.dateTime().toString(Qt.ISODate), 'label':label.text()[:120], 'enabled':True,'fired':False})
                self._refresh('clock')
            self._safe(save)
        v.addWidget(_button('Add alarm',add_alarm))
        for row in self.store.list('clock.alarms',100):
            item=QHBoxLayout();item.addWidget(QLabel(f"{row.get('at')} · {row.get('label','Alarm')}"))
            item.addWidget(_button('Remove',lambda _,key=row['id']:(self.store.delete('clock.alarms',key),self._refresh('clock'))))
            v.addLayout(item)
        _section(v,'Countdown timer')
        seconds=_line('Seconds','60');v.addWidget(seconds)
        timer_view=QLabel('Not started');v.addWidget(timer_view)
        tick=QTimer(timer_view)
        state={'remaining':0}
        def tick_fn():
            state['remaining']-=1
            timer_view.setText(f"{state['remaining']} seconds remaining")
            if state['remaining']<=0:
                tick.stop();timer_view.setText('Timer complete');self._notify('Nova Clock','Countdown finished')
        tick.timeout.connect(tick_fn)
        def start():
            try:
                val=int(seconds.text());assert 0<val<=86400
            except (AssertionError, ValueError):return self.host.message('Enter 1–86400 seconds',False)
            state['remaining']=val;timer_view.setText(f'{val} seconds remaining');tick.start(1000)
        v.addWidget(_button('Start timer',start))
        _section(v,'Stopwatch')
        stopwatch=QLabel('00:00.0');v.addWidget(stopwatch)
        watch=QTimer(stopwatch);watch.setInterval(100)
        sw={'ticks':0}
        def sw_tick():
            sw['ticks']+=1
            stopwatch.setText(f"{sw['ticks']//600:02}:{(sw['ticks']//10)%60:02}.{sw['ticks']%10}")
        watch.timeout.connect(sw_tick)
        controls=QHBoxLayout();controls.addWidget(_button('Start',lambda:watch.start()));controls.addWidget(_button('Pause',lambda:watch.stop()))
        controls.addWidget(_button('Reset',lambda:(watch.stop(),sw.update(ticks=0),stopwatch.setText('00:00.0'))));v.addLayout(controls)

    def page_calendar(self,v):
        _section(v,'Nova Calendar','Persistent events and scheduled local notifications.')
        title=_line('Event title');v.addWidget(title)
        when=QDateTimeEdit(datetime.now()+timedelta(hours=1));when.setCalendarPopup(True);when.setDisplayFormat('yyyy-MM-dd HH:mm');v.addWidget(when)
        remind=QCheckBox('Remind me at event time');remind.setChecked(True);v.addWidget(remind)
        details=QTextEdit();details.setPlaceholderText('Event details');details.setMaximumHeight(110);v.addWidget(details)
        def save():
            if not title.text().strip():return self.host.message('Enter an event title',False)
            self._safe(lambda:self.store.save('calendar.events',{'title':title.text().strip()[:180],
                'at':when.dateTime().toString(Qt.ISODate),'remind':remind.isChecked(),
                'fired':False,'details':details.toPlainText()[:4000]}))
            self._refresh('calendar')
        v.addWidget(_button('Save event',save))
        rows=sorted(self.store.list('calendar.events',500),key=lambda x:x.get('at',''))
        for row in rows:
            line=QHBoxLayout();line.addWidget(QLabel(f"{row.get('at')}  ·  {row.get('title')}"))
            line.addWidget(_button('Delete',lambda _,key=row['id']:(self.store.delete('calendar.events',key),self._refresh('calendar'))));v.addLayout(line)

    def page_browser(self,v):
        _section(v,'Nova Browser','Qt WebEngine is required for page rendering. HTTPS is preferred. History and bookmarks are stored locally.')
        url=_line('https://example.org', 'https://example.org');v.addWidget(url)
        bar=QHBoxLayout();v.addLayout(bar)
        status=QLabel('Opening a web page requires PyQt WebEngine and network access.')
        try:
            # Qt WebEngine's sandbox must not be disabled to run as root in Colab.
            # Offscreen/Colab preview uses the feature-unavailable message.
            if hasattr(os, 'geteuid') and os.geteuid() == 0:
                raise ImportError('WebEngine is disabled under root for safety')
            if os.environ.get('QT_QPA_PLATFORM') == 'offscreen':
                raise ImportError('WebEngine is not started in offscreen tests')
            from PyQt5.QtWebEngineWidgets import QWebEngineView
            self.browser_view=QWebEngineView(self.host)
            self.browser_view.setMinimumHeight(400)
            self.browser_view.setUrl(QUrl(url.text()))
            self.browser_view.urlChanged.connect(lambda q:url.setText(q.toString()))
            self.browser_view.loadFinished.connect(lambda ok:status.setText('Page loaded' if ok else 'Page load failed'))
            def request_download(item):
                # Web pages cannot write arbitrary files without a user choice.
                suggested=Path(item.path()).name if item.path() else 'download'
                selected,_=QFileDialog.getSaveFileName(self.host,'Save downloaded file',str(Path.home()/'Downloads'/suggested))
                if selected:
                    item.setPath(selected)
                    item.accept()
                else:
                    item.cancel()
            self.browser_view.page().profile().downloadRequested.connect(request_download)
            v.addWidget(self.browser_view)
        except ImportError:
            self.browser_view=None
            status.setText('Qt WebEngine requires an unprivileged graphical session and python3-pyqt5.qtwebengine.')
        def navigate():
            address=url.text().strip()
            if not urlparse(address).scheme:address='https://'+address
            if not is_web_address(address):return self.host.message('Only HTTP/HTTPS web URLs are allowed',False)
            self.store.save('browser.history',{'url':address,'visited':datetime.now().isoformat()})
            if self.browser_view:self.browser_view.setUrl(QUrl(address))
        bar.addWidget(_button('Go',navigate))
        bar.addWidget(_button('Back',lambda:self.browser_view.back() if self.browser_view else None))
        bar.addWidget(_button('Forward',lambda:self.browser_view.forward() if self.browser_view else None))
        def bookmark():
            address=url.text().strip()
            if not is_web_address(address):return self.host.message('Enter an HTTP/HTTPS URL',False)
            self.store.save('browser.bookmarks',{'url':address});self._refresh('browser')
        bar.addWidget(_button('Bookmark',bookmark))
        v.addWidget(status)
        _section(v,'Saved bookmarks')
        for item in self.store.list('browser.bookmarks',30):
            v.addWidget(_button(item['url'][:100],lambda _,address=item['url']:(url.setText(address),navigate())))
        v.addWidget(QLabel('WebEngine and its content sandbox require further security and memory testing; this is not a production browser.'))

    def _media(self,layout,video=False):
        try:
            from PyQt5.QtMultimedia import QMediaPlayer,QMediaContent
            from PyQt5.QtCore import QUrl
            player=QMediaPlayer(self.host)
            if video:
                from PyQt5.QtMultimediaWidgets import QVideoWidget
                widget=QVideoWidget(self.host);widget.setMinimumHeight(310)
                player.setVideoOutput(widget);layout.addWidget(widget)
                self.video_player=player
            else:self.media_player=player
            return player,QMediaContent,QUrl
        except ImportError:
            layout.addWidget(QLabel('Qt Multimedia unavailable. Install python3-pyqt5.qtmultimedia and GStreamer plugins.'))
            return None,None,None

    def page_music(self,v):
        _section(v,'Nova Music','Local playback; actual codec support depends on Qt Multimedia/GStreamer.')
        player,Media,Url=self._media(v)
        collection=self.store.list('music.tracks',1000)
        tracks=QListWidget();tracks.addItems([Path(item.get('path','')).name for item in collection]);v.addWidget(tracks)
        def add():
            paths,_=QFileDialog.getOpenFileNames(self.host,'Add music','','Audio (*.mp3 *.ogg *.wav *.flac *.m4a)')
            for p in paths:self.store.save('music.tracks',{'path':p})
            self._refresh('music')
        def play():
            n=tracks.currentRow()
            if n<0 or not player:return
            path=collection[n].get('path','')
            if not Path(path).is_file():return self.host.message('Audio file is unavailable',False)
            player.setMedia(Media(Url.fromLocalFile(str(Path(path).resolve()))));player.play()
        controls=QHBoxLayout()
        for label,fn in [('Add files',add),('Play',play),('Pause',lambda:player.pause() if player else None),
                         ('Stop',lambda:player.stop() if player else None)]:controls.addWidget(_button(label,fn))
        v.addLayout(controls)
        _section(v,'Playlists')
        playlist_name=_line('New playlist name');v.addWidget(playlist_name)
        playlists=QListWidget()
        current_playlists=self.store.list('music.playlists',100)
        playlists.addItems([f"{x.get('name','Playlist')} · {len(x.get('tracks',[]))} tracks" for x in current_playlists])
        v.addWidget(playlists)
        def create_playlist():
            if not playlist_name.text().strip():return self.host.message('Enter playlist name',False)
            self.store.save('music.playlists',{'name':playlist_name.text().strip()[:100], 'tracks':[]})
            self._refresh('music')
        def add_to_playlist():
            pidx=playlists.currentRow();tidx=tracks.currentRow()
            if pidx<0 or tidx<0:return self.host.message('Choose a playlist and an audio track',False)
            entry=current_playlists[pidx]
            ids=list(entry.get('tracks',[]));track_id=collection[tidx]['id']
            if track_id not in ids:ids.append(track_id)
            self.store.save('music.playlists',{'name':entry.get('name','Playlist'),'tracks':ids},entry['id'])
            self._refresh('music')
        v.addWidget(_button('Create playlist',create_playlist))
        v.addWidget(_button('Add selected track to selected playlist',add_to_playlist))

    def page_video(self,v):
        _section(v,'Nova Video','Local video player; actual playback requires Qt Multimedia/GStreamer codecs.')
        player,Media,Url=self._media(v,video=True)
        filename=QLabel('No file selected');v.addWidget(filename)
        def browse():
            path,_=QFileDialog.getOpenFileName(self.host,'Open video','','Video (*.mp4 *.webm *.mkv *.ogv *.avi)')
            if not path or not player:return
            player.setMedia(Media(Url.fromLocalFile(path)));filename.setText(Path(path).name)
            self.store.save('video.history',{'path':path,'opened':datetime.now().isoformat()})
            player.play()
        ctr=QHBoxLayout();v.addLayout(ctr)
        for label,fn in [('Open video',browse),('Play',lambda:player.play() if player else None),
            ('Pause',lambda:player.pause() if player else None),('Stop',lambda:player.stop() if player else None)]:ctr.addWidget(_button(label,fn))
        from PyQt5.QtWidgets import QSlider
        seek=QSlider(Qt.Horizontal)
        seek.setRange(0,1000);v.addWidget(seek)
        if player:
            player.durationChanged.connect(lambda d:seek.setMaximum(max(1,d)))
            player.positionChanged.connect(seek.setValue)
            seek.sliderMoved.connect(player.setPosition)

    def page_terminal(self,v):
        _section(v,'Nova Terminal','Developer console running as the current Linux user; NOT sandboxed. Commands may change files and processes.')
        output=QPlainTextEdit();output.setReadOnly(True);output.setMinimumHeight(250);v.addWidget(output)
        command=_line('Enter a shell command');v.addWidget(command)
        proc=QProcess(self.host);self.shell_proc=proc
        def receive():
            text=bytes(proc.readAllStandardOutput()).decode('utf-8','replace')
            text+=bytes(proc.readAllStandardError()).decode('utf-8','replace')
            output.insertPlainText(text[-20000:])
        proc.readyReadStandardOutput.connect(receive)
        proc.readyReadStandardError.connect(receive)
        proc.finished.connect(lambda code,_:output.appendPlainText(f'\n[exit code {code}]'))
        def run():
            cmd=command.text().strip()
            if not cmd or len(cmd)>2048:return
            if proc.state()!=QProcess.NotRunning:return self.host.message('Wait for current command or stop it',False)
            output.appendPlainText('$ '+cmd+'\n');proc.setProgram('/bin/sh');proc.setArguments(['-lc',cmd])
            root=os.environ.get('NOVA_FILES_ROOT') or str(Path.home())
            if Path(root).is_dir():proc.setWorkingDirectory(root)
            proc.start();command.clear()
        command.returnPressed.connect(run)
        ctr=QHBoxLayout();ctr.addWidget(_button('Run',run));ctr.addWidget(_button('Stop process',lambda:proc.terminate()));v.addLayout(ctr)

    def page_email(self,v):
        _section(v,'Nova Email','Drafts are local. Optional IMAP/SMTP uses encrypted connections; passwords are not stored.')
        from_addr=_line('Sender email');to_addr=_line('Recipient email');subject=_line('Subject')
        body=QTextEdit();body.setPlaceholderText('Write your message')
        server=_line('SMTP SSL host (e.g. mail.example.org)');port=_line('SMTP SSL port','465')
        for w in (from_addr,to_addr,subject,body,server,port):v.addWidget(w)
        def save_draft():
            self.store.save('email.drafts',{'from':from_addr.text()[:320], 'to':to_addr.text()[:320],
                  'subject':subject.text()[:300], 'body':body.toPlainText()[:20000]})
            self._refresh('email')
        v.addWidget(_button('Save draft',save_draft))
        def send():
            sender=from_addr.text().strip();recipient=to_addr.text().strip()
            if not all('@' in addr and '\n' not in addr and '\r' not in addr for addr in (sender,recipient)):
                return self.host.message('Enter valid sender and recipient email addresses',False)
            if not server.text().strip():return self.host.message('Enter an SMTP SSL server',False)
            password,ok=QInputDialog.getText(self.host,'Nova Email','SMTP app password (not saved)',QLineEdit.Password)
            if not ok or not password:return
            try:p=int(port.text());assert 1<=p<=65535
            except (ValueError,AssertionError):return self.host.message('Invalid SMTP port',False)
            msg=EmailMessage();msg['From']=sender;msg['To']=recipient
            msg['Subject']=subject.text().replace('\n',' ')[:300];msg.set_content(body.toPlainText())
            import threading
            host=server.text().strip()
            def worker():
                try:
                    with smtplib.SMTP_SSL(host,p,timeout=12) as smtp:
                        smtp.login(sender,password)
                        smtp.send_message(msg)
                    self.mail_signal.completed.emit(True,'Email accepted by SMTP server')
                except (OSError,smtplib.SMTPException) as exc:
                    self.mail_signal.completed.emit(False,'SMTP failed: '+type(exc).__name__)
            threading.Thread(target=worker,daemon=True).start()
            v.addWidget(QLabel('Sending...'))
        v.addWidget(_button('Send with SMTP SSL',send))
        _section(v,'Saved drafts')
        for item in self.store.list('email.drafts',100):
            row=QHBoxLayout()
            row.addWidget(_button(item.get('subject') or '(no subject)',lambda _,x=item:(from_addr.setText(x.get('from','')),to_addr.setText(x.get('to','')),subject.setText(x.get('subject','')),body.setPlainText(x.get('body','')))))
            row.addWidget(_button('Delete',lambda _,key=item['id']:(self.store.delete('email.drafts',key),self._refresh('email'))));v.addLayout(row)
        _section(v,'Read inbox via IMAP SSL')
        imap_host=_line('IMAP SSL host');imap_port=_line('IMAP SSL port','993')
        for field in (imap_host,imap_port):v.addWidget(field)
        def inbox_sync():
            if not imap_host.text().strip() or not from_addr.text().strip():
                return self.host.message('Enter the sender email address and IMAP host',False)
            password,ok=QInputDialog.getText(self.host,'Nova Email','IMAP app password (not saved)',QLineEdit.Password)
            if not ok or not password:return
            try:p=int(imap_port.text());assert 1<=p<=65535
            except (ValueError,AssertionError):return self.host.message('Invalid IMAP port',False)
            account=from_addr.text().strip();server_name=imap_host.text().strip()
            import threading
            def worker():
                items=[]
                try:
                    with imaplib.IMAP4_SSL(server_name,p,timeout=12) as conn:
                        conn.login(account,password)
                        typ,_=conn.select('INBOX',readonly=True)
                        if typ!='OK':raise OSError('Could not select inbox')
                        typ,data=conn.search(None,'ALL')
                        if typ!='OK':raise OSError('Could not search inbox')
                        for uid in data[0].split()[-20:]:
                            code,parts=conn.fetch(uid,'(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])')
                            if code!='OK':continue
                            raw=next((part[1] for part in parts if isinstance(part,tuple)),None)
                            if not raw:continue
                            header=email.message_from_bytes(raw)
                            items.append({'from':str(header.get('From',''))[:200],
                                'subject':str(header.get('Subject',''))[:200],
                                'date':str(header.get('Date',''))[:150]})
                    self.mail_signal.inbox.emit(json.dumps(items))
                except (OSError,imaplib.IMAP4.error) as exc:
                    self.mail_signal.completed.emit(False,'IMAP failed: '+type(exc).__name__)
            threading.Thread(target=worker,daemon=True).start()
        v.addWidget(_button('Fetch latest 20 message headers',inbox_sync))
        for item in self.mail_results:
            entry=QLabel(f"{item.get('date','')} — {item.get('from','')} — {item.get('subject','')}")
            entry.setWordWrap(True);v.addWidget(entry)
        v.addWidget(QLabel('IMAP fetches headers only. OAuth2, attachment downloads and complete inbox synchronization are unfinished.'))

    def _mail_inbox_received(self,data):
        try:self.mail_results=json.loads(data)
        except ValueError:self.mail_results=[]
        self._notify('Nova Email',f'{len(self.mail_results)} inbox headers fetched')
        if self.host.page=='email':self._refresh('email')

    def _mail_finished(self,success,message):
        self._notify('Nova Email',message)
        self.host.message(message,success)

    def page_store(self,v):
        _section(v,'Nova Store','Verified resource bundles only. Executable app installation is NOT yet supported.')
        packages=self.host.fetch('/api/packages',[])
        for item in packages:
            line=QHBoxLayout();line.addWidget(QLabel(f"{item.get('id')}  ·  {item.get('version')}"))
            line.addWidget(_button('Uninstall',lambda _,key=item['id']:(self.host.invoke('/api/packages/uninstall',{'id':key}),self._refresh('store'))));v.addLayout(line)
        def install():
            import base64
            path,_=QFileDialog.getOpenFileName(self.host,'Install verified Nova resource package','','ZIP (*.zip)')
            if not path:return
            content=Path(path).read_bytes()
            if len(content)>4*1024*1024:return self.host.message('Package too large (limit 4 MiB)',False)
            if self.host.invoke('/api/packages/install',{'base64':base64.b64encode(content).decode('ascii')}):
                self._refresh('store')
        v.addWidget(_button('Install checked resource bundle',install))
        v.addWidget(QLabel('App binary signatures, repository trust and executable sandboxing are required before general native app installation.'))

    def render(self,name,v):
        getattr(self,'page_'+name)(v)
