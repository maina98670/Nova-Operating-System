"""Nova simple on-screen keyboard for text fields, without a device input driver.
A QDialog containing keys; text remains in the targeted local Qt widget.
"""
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QDialog, QHBoxLayout, QVBoxLayout, QPushButton, QLineEdit, QTextEdit, QPlainTextEdit

class NovaKeyboard(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle('Nova Keyboard')
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.target=None
        self.upper=False
        outer=QVBoxLayout(self)
        self.keybuttons=[]
        for row in ('qwertyuiop','asdfghjkl','zxcvbnm'):
            bar=QHBoxLayout()
            for char in row:
                button=QPushButton(char)
                button.setMinimumHeight(45)
                button.clicked.connect(lambda _,c=char:self.input(c))
                self.keybuttons.append((char,button))
                bar.addWidget(button)
            outer.addLayout(bar)
        controls=QHBoxLayout()
        for label,action in [('⇧ Shift',self.shift),('Space',lambda:self.input(' ')),
                             ('⌫ Backspace',self.backspace),('Enter',lambda:self.input('\n')),
                             ('Close',self.hide)]:
            button=QPushButton(label);button.clicked.connect(action);controls.addWidget(button)
        outer.addLayout(controls)

    def set_target(self,target):
        if isinstance(target,(QLineEdit,QTextEdit,QPlainTextEdit)):
            self.target=target

    def input(self,key):
        target=self.target
        if target is None:return
        if isinstance(target,QLineEdit):
            if key=='\n':return
            target.insert(key.upper() if self.upper else key)
        else:
            target.insertPlainText(key.upper() if self.upper else key)

    def backspace(self):
        target=self.target
        if target is None:return
        target.backspace() if isinstance(target,QLineEdit) else target.textCursor().deletePreviousChar()

    def shift(self):
        self.upper=not self.upper
        for char,button in self.keybuttons:button.setText(char.upper() if self.upper else char)

    def open(self):
        focused=QApplication.focusWidget()
        self.set_target(focused)
        self.show();self.raise_()
