"""Durable user-scoped SQLite storage for Nova v0.74 Qt applications.

The SQLite file is only an app data store. Linux filesystem DAC applies; this
module is not a per-app sandbox, identity provider, or secure credential vault.
"""
from __future__ import annotations
import json
import os
import re
import sqlite3
import time
import uuid
from pathlib import Path

NAMESPACES = frozenset({
    'clock.alarms', 'calendar.events', 'browser.bookmarks', 'browser.history',
    'music.tracks', 'music.playlists', 'video.history', 'email.drafts',
    'email.accounts', 'launcher.favorites', 'nova.preferences',
})
MAX_PAYLOAD = 64 * 1024
MAX_RECORDS = 3000
ID_PATTERN = re.compile(r'^[A-Za-z0-9_-]{1,80}$')


def data_path() -> Path:
    override = os.environ.get('NOVA_MOBILE_DATA')
    if override:
        return Path(override).expanduser()
    base = Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local/share')))
    return base / 'nova' / 'mobile.sqlite3'


class AppData:
    def __init__(self, path=None):
        self.path = Path(path) if path is not None else data_path()
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self.path.is_symlink():
            raise ValueError('Refusing a symlink for Nova application data')
        self.db = sqlite3.connect(str(self.path), timeout=5)
        self.db.execute('PRAGMA busy_timeout=5000')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('''CREATE TABLE IF NOT EXISTS records (
            namespace TEXT NOT NULL, id TEXT NOT NULL,
            payload TEXT NOT NULL, updated REAL NOT NULL,
            PRIMARY KEY(namespace, id))''')
        self.db.execute('CREATE INDEX IF NOT EXISTS records_by_ns ON records(namespace,updated)')
        self.db.commit()
        try:os.chmod(self.path, 0o600)
        except OSError:pass

    @staticmethod
    def _validate(namespace, key=None):
        if namespace not in NAMESPACES:
            raise ValueError('Unsupported Nova app data namespace')
        if key is not None and not ID_PATTERN.fullmatch(str(key)):
            raise ValueError('Invalid Nova record id')

    def save(self, namespace, value, key=None):
        self._validate(namespace, key)
        if not isinstance(value, dict):
            raise ValueError('Nova app payload must be an object')
        payload = json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        if len(payload.encode('utf-8')) > MAX_PAYLOAD:
            raise ValueError('Nova app payload exceeds 64 KiB')
        key = key or uuid.uuid4().hex
        self._validate(namespace, key)
        with self.db:
            count = self.db.execute('SELECT COUNT(*) FROM records WHERE namespace=?', (namespace,)).fetchone()[0]
            exists = self.db.execute('SELECT 1 FROM records WHERE namespace=? AND id=?', (namespace, key)).fetchone()
            if count >= MAX_RECORDS and not exists:
                raise ValueError('Nova app storage quota reached')
            self.db.execute('INSERT INTO records(namespace,id,payload,updated) VALUES(?,?,?,?) '
                'ON CONFLICT(namespace,id) DO UPDATE SET payload=excluded.payload,updated=excluded.updated',
                (namespace,key,payload,time.time()))
        return key

    def get(self, namespace, key):
        self._validate(namespace, key)
        row=self.db.execute('SELECT payload FROM records WHERE namespace=? AND id=?',(namespace,key)).fetchone()
        return json.loads(row[0]) if row else None

    def list(self, namespace, limit=1000):
        self._validate(namespace)
        limit=max(1,min(int(limit),MAX_RECORDS))
        rows=self.db.execute('SELECT id,payload FROM records WHERE namespace=? ORDER BY updated DESC LIMIT ?',
                             (namespace,limit)).fetchall()
        return [{**json.loads(payload), 'id':key} for key,payload in rows]

    def delete(self, namespace, key):
        self._validate(namespace, key)
        with self.db:
            return self.db.execute('DELETE FROM records WHERE namespace=? AND id=?',(namespace,key)).rowcount>0

    def close(self):
        self.db.close()

    def __enter__(self):return self
    def __exit__(self,*args):self.close()
