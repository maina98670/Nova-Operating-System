#!/usr/bin/env python3
"""Nova Wayland graphical client displaying the unified modern shell.

Qt WebEngine is a native Wayland client using an embedded web renderer; this
is NOT Nova's custom DRM compositor, and Weston remains the guest compositor.
"""
from __future__ import annotations
import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import urlopen

from PyQt5.QtCore import QTimer, QUrl, Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.QtWebEngineWidgets import QWebEngineView

PORT = int(os.environ.get('NOVA_SHELL_PORT','8767'))
URL = 'http://127.0.0.1:%d/' % PORT
READY = Path(os.environ.get('NOVA_GUI_READY_FILE', str(Path.home() / '.local/state/nova/gui-ready.json')))


class NovaWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Nova OS — Unified Graphical Session')
        self.setMinimumSize(320,550)
        self.view=NovaWebView(self)
        self.setCentralWidget(self.view)
        self.view.loadFinished.connect(self.loaded)
        self.heartbeat=QTimer(self)
        self.heartbeat.timeout.connect(self.write_heartbeat)
        self.loaded_ok=False
        self.ui_phase='booting'
        self.app_tile_count=0
        self.probe_count=0
        self.probe=QTimer(self)
        self.probe.timeout.connect(self.verify_ui)
        self.view.load(QUrl(URL))
        self.showFullScreen()

    def loaded(self,ok):
        self.loaded_ok=False
        self.probe_count=0
        if ok:
            # Loading HTML is not proof that modern.js initialized the launcher.
            self.probe.start(400)
            self.verify_ui()
        else:
            print('[nova] graphical login failed to load; API check required',file=sys.stderr,flush=True)
            self.heartbeat.stop()
            self.probe.stop()
            try:READY.unlink(missing_ok=True)
            except OSError:pass
            QApplication.instance().exit(7)

    def verify_ui(self):
        """Wait for the real JS app boot, including first-run account screen.

        A loaded HTML file alone must never mark the desktop ready. Qt's JS
        callback checks that the modern launcher ran and populated its apps.
        """
        if not self.loaded_ok:
            self.probe_count += 1
        if self.probe_count > 90:
            print('[nova] HTML loaded but Nova launcher did not initialize',
                  file=sys.stderr, flush=True)
            self.probe.stop()
            self.loaded_ok=False
            self.heartbeat.stop()
            QApplication.instance().exit(8)
            return
        script = """(function() {
            var s=window.__NOVA_UI_STATE__;
            var overlay=document.getElementById('auth-overlay');
            var home=document.getElementById('home-apps');
            var count=home?home.querySelectorAll('.app-item').length:0;
            return {phase:s&&s.phase||'booting',app_tiles:count,
                    auth_visible:!!overlay&&!overlay.classList.contains('hidden')};
        })()"""
        self.view.page().runJavaScript(script, self.on_ui_probe)

    def on_ui_probe(self, state):
        if not isinstance(state, dict): return
        phase=state.get('phase')
        count=state.get('app_tiles',0)
        auth_visible=state.get('auth_visible')
        valid=(phase=='login' and bool(auth_visible) and count>=8) or \
              (phase=='home' and not auth_visible and count>=8)
        if not valid:
            if self.loaded_ok:
                self.loaded_ok=False
                self.heartbeat.stop()
                try:READY.unlink(missing_ok=True)
                except OSError:pass
                self.probe.setInterval(400)
                self.probe_count=0
            return
        if not self.loaded_ok:
            print('[nova] Nova GUI boot verified: '+phase+' screen, '+str(count)+
                  ' app tiles; physical pixel rendering NOT verified',flush=True)
        self.loaded_ok=True
        # Continue checking for login -> home -> logout transitions.
        self.probe.setInterval(2000)
        self.probe_count=0
        self.ui_phase=phase
        self.app_tile_count=count
        if not self.heartbeat.isActive():self.heartbeat.start(5000)
        self.write_heartbeat()

    def write_heartbeat(self):
        if not self.loaded_ok:return
        try:
            READY.parent.mkdir(parents=True,exist_ok=True)
            temp=READY.with_suffix('.tmp')
            temp.write_text(json.dumps({'status':'event-loop-active',
                'timestamp':time.time(), 'dom_verified':True,
                'ui_phase':self.ui_phase,'app_tile_count':self.app_tile_count,
                'backend':'Qt WebEngine Wayland client (not native compositor)',
                'url':URL}))
            os.replace(temp,READY)
        except OSError as exc:
            print('[nova] heartbeat unavailable:',exc,file=sys.stderr)

    def closeEvent(self,event):
        self.heartbeat.stop()
        self.probe.stop()
        try:READY.unlink(missing_ok=True)
        except OSError:pass
        super().closeEvent(event)


class NovaWebView(QWebEngineView):
    """Keeps Nova local desktop as the main window; external links open in separate windows."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.children_windows=[]

    def createWindow(self,kind):
        child=QWebEngineView()
        child.setAttribute(Qt.WA_DeleteOnClose,True)
        child.setWindowTitle('Nova Browser')
        child.resize(900,640)
        child.show()
        self.children_windows.append(child)
        return child


def main():
    # Fail before displaying a window when the native service is unavailable.
    try:
        with urlopen('http://127.0.0.1:%d/api/health' % PORT,timeout=5) as result:
            health=json.load(result)
        if not health.get('ready'):
            raise RuntimeError('Nova backend is unhealthy')
    except Exception as exc:
        print('[nova] cannot launch desktop: '+str(exc),file=sys.stderr)
        return 2
    os.environ.setdefault('QT_QPA_PLATFORM','wayland')
    app=QApplication(sys.argv)
    app.setApplicationName('Nova OS')
    desktop=NovaWindow()
    return app.exec_()


if __name__=='__main__':raise SystemExit(main())
