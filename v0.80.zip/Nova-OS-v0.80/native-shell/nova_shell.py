#!/usr/bin/env python3
"""Nova OS v0.75 native Qt/Wayland application shell.

This is a real GUI application using Qt widgets over Wayland, not HTML or Chromium.
Weston currently supplies the actual Wayland compositor, and Linux is the kernel.
The original Nova Rust bridge backs the applicable API endpoints.
"""
from __future__ import annotations
import argparse
import ast
import operator
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

from PyQt5.QtCore import Qt, QTimer, QSize, QProcess
from PyQt5.QtNetwork import QLocalSocket, QLocalServer
from PyQt5.QtGui import QFont, QPixmap, QIcon
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFrame, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QGridLayout, QStackedWidget, QListWidget,
    QLineEdit, QTextEdit, QMessageBox, QInputDialog, QFileDialog, QComboBox,
    QScrollArea, QFormLayout, QCheckBox, QSlider, QToolButton
)
from backend import NovaClient, NovaApiError
from mobile_apps import NovaMobileApps
from mobile_keyboard import NovaKeyboard

APPS = [
    ('files','Files','📁'), ('settings','Settings','⚙'),
    ('notes','Notes','✎'), ('contacts','Contacts','◉'),
    ('messages','Messages','✉'), ('photos','Photos','▣'),
    ('calculator','Calculator','▦'), ('quick','Quick settings','☼'), ('notifications','Notifications','♧'), ('components','Components','▤'),
    ('system','System','ⓘ'), ('camera','Camera','◎'),
    ('wifi','Wi-Fi','◉'), ('bluetooth','Bluetooth','ᛒ'),
    ('device','Device & power','▥'), ('lock','Screen lock','🔒'),
    ('packages','Packages','▧'), ('recovery','Recovery','↶'),
    ('browser','Browser','◎'), ('music','Music','♫'),
    ('clock','Clock','◷'), ('store','Nova Store','▧'),
    ('terminal','Terminal','⌘'), ('email','Email','✉'),
    ('video','Video Player','▶'), ('calendar','Calendar','▦'),
]

COLORS = {
    'blue':'#69a7ff', 'teal':'#63e4d3',
    'violet':'#b19bff', 'pink':'#ff94b7'
}


def safe_calculate(expression: str) -> str:
    """Calculator arithmetic, intentionally no Python eval() or function calls."""
    ops = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
           ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
           ast.Mod: operator.mod}
    def walk(node, depth=0):
        if depth > 20: raise ValueError('Too many nested operations')
        if isinstance(node, ast.Expression): return walk(node.body, depth+1)
        if isinstance(node, ast.Constant) and type(node.value) in (int,float):
            if abs(node.value) > 1e12: raise ValueError('Number too large')
            return node.value
        if isinstance(node, ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            v = walk(node.operand, depth+1)
            return v if isinstance(node.op,ast.UAdd) else -v
        if isinstance(node, ast.BinOp) and type(node.op) in ops:
            a,b=walk(node.left, depth+1),walk(node.right, depth+1)
            out=ops[type(node.op)](a,b)
            if abs(out)>1e15: raise ValueError('Result too large')
            return out
        raise ValueError('Unsupported expression')
    if len(expression)>120: raise ValueError('Expression too long')
    result=walk(ast.parse(expression,mode='eval'))
    return f'{result:.10g}'


def clean_layout(layout):
    while layout.count():
        item=layout.takeAt(0)
        w=item.widget()
        if w is not None: w.deleteLater()
        elif item.layout(): clean_layout(item.layout())


def heading(text, level='large'):
    label=QLabel(text)
    label.setObjectName('heading' if level=='large' else 'subheading')
    label.setWordWrap(True)
    return label


def btn(text, fn=None, accent=False, enabled=True):
    b=QPushButton(text)
    b.setCursor(Qt.PointingHandCursor)
    if accent:b.setProperty('accent','true')
    b.setEnabled(enabled)
    if fn: b.clicked.connect(fn)
    return b


class NovaWindow(QMainWindow):
    def __init__(self, client: NovaClient):
        super().__init__()
        self.client=client
        self.setWindowTitle('Nova OS — Native Desktop')
        self.setMinimumSize(520, 570)
        self.resize(1100, 750)
        self.history=[]
        self.recent=[]  # In-shell views (fallback for embedded/Colab mode).
        self.app_processes={}  # Native Qt app windows, each a separate OS process.
        self.child_mode = os.environ.get('NOVA_CHILD_APP') == '1'
        self.separate_apps = (os.environ.get('NOVA_SEPARATE_APPS') == '1' and not self.child_mode)
        self.page='home'
        self.last_page_error=None
        self.current_dir=''
        self.notes=[]
        self.contacts=[]
        self.active_note=None
        self.active_contact=None
        self.system={}
        self.settings={}
        self.core={}
        self.native={}
        self.connectivity={}
        self.device={}
        self.locked=False
        self.activation_server=None
        self.mobile = NovaMobileApps(self)
        self.keyboard = NovaKeyboard(self)
        QApplication.instance().focusChanged.connect(self._track_edit_focus)

        outer=QWidget()
        outer.setObjectName('outer')
        root=QVBoxLayout(outer)
        root.setContentsMargins(18,12,18,12)
        root.setSpacing(8)

        top=QHBoxLayout()
        self.brand=QLabel('◈  NOVA  ·  v0.75')
        self.brand.setObjectName('brand')
        top.addWidget(self.brand)
        top.addStretch(1)
        self.status=QLabel('Connecting…')
        self.status.setObjectName('status')
        top.addWidget(self.status)
        root.addLayout(top)

        self.stack=QStackedWidget()
        self.stack.setObjectName('stack')
        root.addWidget(self.stack, 1)
        bottom=QHBoxLayout()
        bottom.setSpacing(12)
        bottom.addStretch(1)
        bottom.addWidget(btn('⌨',self.keyboard.open))
        bottom.addWidget(btn('‹  Back',self.go_back))
        bottom.addWidget(btn('●  Home',self.home,True))
        bottom.addWidget(btn('▤ Recent',lambda:self.open_page('recents')))
        bottom.addWidget(btn('▦ Apps',lambda:self.open_page('apps')))
        bottom.addStretch(1)
        root.addLayout(bottom)
        self.setCentralWidget(outer)
        self.poll=QTimer(self)
        self.poll.timeout.connect(self.update_clock)
        self.poll.start(10_000)
        self.heartbeat=QTimer(self)
        self.heartbeat.timeout.connect(self._gui_heartbeat)
        self.heartbeat.start(5_000)
        self.refresh_state()
        if self.child_mode:self.setup_activation_socket()
        self.home()

    def _track_edit_focus(self,old,new):
        self.keyboard.set_target(new)

    def _gui_heartbeat(self):
        """Mark event-loop liveness, not GPU/Wayland pixels."""
        dest = os.environ.get('NOVA_GUI_READY_FILE')
        if not dest or not self.isVisible():
            return
        try:
            target = Path(dest)
            target.parent.mkdir(parents=True, exist_ok=True)
            temp = target.with_name(target.name + '.tmp.' + str(os.getpid()))
            temp.write_text(json.dumps({'status':'event-loop-active',
                            'pid':os.getpid(), 'timestamp':time.time(),
                            'renderer':'Qt client; Weston compositor'}))
            os.replace(temp, target)
        except OSError as exc:
            print('[nova] GUI heartbeat unavailable:', exc, file=sys.stderr)

    def setup_activation_socket(self):
        """Allow the parent launcher to request raising an already-open Qt app."""
        self.activation_server=QLocalServer(self)
        name=f'nova-app-{os.getuid()}-{os.getpid()}' if hasattr(os,'getuid') else f'nova-app-{os.getpid()}'
        QLocalServer.removeServer(name)
        if self.activation_server.listen(name):
            self.activation_server.newConnection.connect(self._activation_connection)

    def _activation_connection(self):
        while self.activation_server.hasPendingConnections():
            socket=self.activation_server.nextPendingConnection()
            socket.readyRead.connect(lambda s=socket:self._raise_from_socket(s))
            socket.disconnected.connect(socket.deleteLater)

    def _raise_from_socket(self,socket):
        if bytes(socket.readAll()).strip()==b'raise':
            self.showNormal()
            self.raise_()
            self.activateWindow()
        socket.disconnectFromServer()

    def focus_app(self,name):
        proc=self.app_processes.get(name)
        if proc is None or proc.state()==QProcess.NotRunning:return
        socket=QLocalSocket(self)
        owner=int(proc.processId())
        target=f'nova-app-{os.getuid()}-{owner}' if hasattr(os,'getuid') else f'nova-app-{owner}'
        socket.connectToServer(target)
        if socket.waitForConnected(400):
            socket.write(b'raise')
            socket.waitForBytesWritten(400)
            socket.disconnectFromServer()
        else:
            self.message('Application running; Weston may require switching to its window manually.')

    def refresh_state(self):
        try:
            self.system=self.client.get('/api/system')
            self.settings=self.client.get('/api/settings')
            self.native=self.client.get('/api/core/status')
            self.connectivity=self.client.get('/api/connectivity')
            self.device=self.client.get('/api/device')
            if self.native.get('connected'):
                self.core=self.client.get('/api/core/settings')
        except NovaApiError as exc:
            self.message(str(exc),False)
        self.apply_theme()
        self.update_clock()

    def update_clock(self):
        now=datetime.now().strftime('%H:%M')
        net=self.system.get('network',{})
        wifi=self.connectivity.get('wifi',{})
        bt=self.connectivity.get('bluetooth',{})
        link=('◉ '+(wifi.get('network') or 'Wi-Fi') if wifi.get('connected') else ('▣ '+', '.join(net.get('interfaces') or []) if net.get('connected') else 'Offline'))
        bt_label=' ᛒ' if bt.get('enabled') else ''
        battery=self.system.get('battery',{})
        bat=f" {battery.get('percent')}%" if battery.get('percent') is not None else ''
        self.status.setText(f'{now}  ·  {link}{bt_label}{bat}')

    def apply_theme(self):
        accent=COLORS.get(self.settings.get('accent','blue'),COLORS['blue'])
        dark=self.settings.get('theme','dark')=='dark'
        bg='#0b1222' if dark else '#e8eff9'
        pane='#17243a' if dark else '#ffffff'
        fg='#eef5ff' if dark else '#17243a'
        muted='#aebfda' if dark else '#50637d'
        hover='#273a56' if dark else '#dbe7f6'
        edge='#38506c' if dark else '#ccd9ec'
        self.setStyleSheet(f'''
           QWidget#outer {{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {bg},stop:1 {pane});color: {fg};font: 13px 'DejaVu Sans';}}
           QWidget, QFrame {{ color: {fg}; }}
           QLabel#brand {{ color: {accent};font: bold 20px 'DejaVu Sans'; }}
           QLabel#status {{ color: {muted};font-size: 12px; }}
           QLabel#heading {{ font: bold 27px 'DejaVu Sans'; margin-bottom: 7px; }}
           QLabel#subheading {{ font: bold 17px 'DejaVu Sans'; }}
           QPushButton {{background: {pane};border:1px solid {edge};border-radius:13px;padding:11px 17px;font-weight:600;text-align:center;}}
           QPushButton:hover {{background: {hover};}}
           QPushButton[accent="true"] {{background: {accent}; color:#0b1728; border-color:{accent};}}
           QPushButton:disabled {{color: {muted};}}
           QLineEdit,QTextEdit,QListWidget,QComboBox {{background:{pane};color:{fg};border:1px solid {edge};border-radius:12px;padding:11px;selection-background-color:{accent};}}
           QScrollArea {{border:0px; background:transparent;}}
           QScrollArea QWidget#scrollBody {{background:transparent;}}
           QLabel#muted {{color:{muted};}}
           QFrame#tile {{background:{pane};border:1px solid {edge};border-radius:22px;}}
           QFrame#hero {{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #142f53,stop:1 #284875);border:1px solid {edge};border-radius:27px;padding:16px;}}
           QLabel#heroTitle {{font:bold 33px 'DejaVu Sans';color:white;}}
           QLabel#heroSub {{color:#d1e7ff;font:13px 'DejaVu Sans';}}
           QPushButton#appTile {{min-height:100px;font:600 15px 'DejaVu Sans';padding:16px;border-radius:20px;}}
           QSlider::groove:horizontal {{height:6px;background:{edge};border-radius:3px;}}
           QSlider::handle:horizontal {{width:17px;background:{accent};margin:-6px 0;border-radius:8px;}}
           QCheckBox {{spacing:10px;}}
        ''')

    def message(self,text,ok=True):
        QMessageBox.information(self,'Nova OS',text) if ok else QMessageBox.warning(self,'Nova OS',text)

    def invoke(self,endpoint,payload,then=None):
        try:
            result=self.client.post(endpoint,payload)
            if then:then(result)
            return result
        except (NovaApiError,ValueError) as exc:
            self.message(str(exc),False)
            return None

    def fetch(self,endpoint,default=None,**params):
        try:return self.client.get(endpoint,**params)
        except NovaApiError as exc:
            self.message(str(exc),False)
            return default

    def open_page(self,page,push=True):
        if self.locked and page != 'lock':return
        if push and self.page != page:self.history.append(self.page)
        if page not in ('home','apps','recents'):
            self.recent = [p for p in self.recent if p != page] + [page]
            self.recent = self.recent[-10:]
        self.page=page
        w=QWidget()
        w.setObjectName('scrollBody')
        v=QVBoxLayout(w)
        v.setContentsMargins(14,12,14,14)
        v.setSpacing(14)
        self.last_page_error=None
        try:
            handler=getattr(self,'page_'+page,None)
            if handler is not None:handler(v)
            else:self.mobile.render(page,v)
        except Exception as exc:
            self.last_page_error=str(exc)
            v.addWidget(heading('Unable to open '+page))
            v.addWidget(QLabel(str(exc)))
        v.addStretch(1)
        wrapper=QScrollArea()
        wrapper.setWidgetResizable(True)
        wrapper.setWidget(w)
        while self.stack.count():
            old=self.stack.widget(0)
            self.stack.removeWidget(old)
            old.deleteLater()
        self.stack.addWidget(wrapper)
        self.stack.setCurrentWidget(wrapper)

    def home(self):
        if self.locked:return self.open_page('lock',False)
        self.history.clear()
        self.open_page('home',False)

    def go_back(self):
        if self.locked:return
        self.open_page(self.history.pop() if self.history else 'home',False)

    def launch_app(self, name):
        if self.locked:return
        """Launch a separately managed Qt process with a fixed allowlisted app id.

        Each process uses the same Rust-backed API; it is NOT an OS sandbox,
        independent original Rust app executable, or Android APK runtime.
        """
        allowed = {item[0] for item in APPS}
        if name not in allowed:
            self.message('Application is not registered',False)
            return
        if not self.separate_apps:
            self.open_page(name)
            return
        proc = self.app_processes.get(name)
        if proc is not None and proc.state() != QProcess.NotRunning:
            self.focus_app(name)
            return
        proc = QProcess(self)
        proc.setProgram(sys.executable)
        proc.setArguments([str(Path(__file__).resolve()), '--window', '--app', name, '--child'])
        env = proc.processEnvironment()
        # QProcess inherits environment by default. Mark children explicitly.
        from PyQt5.QtCore import QProcessEnvironment
        env = QProcessEnvironment.systemEnvironment()
        env.insert('NOVA_CHILD_APP','1')
        env.insert('NOVA_SEPARATE_APPS','0')
        proc.setProcessEnvironment(env)
        proc.finished.connect(lambda _code,_status,n=name:self.app_processes.pop(n,None))
        self.app_processes[name]=proc
        proc.start()
        if not proc.waitForStarted(3000):
            self.app_processes.pop(name,None)
            self.message('Could not launch '+name+': '+proc.errorString(),False)

    def stop_app(self,name):
        proc=self.app_processes.get(name)
        if proc is None or proc.state()==QProcess.NotRunning:return
        proc.terminate()
        # No forced termination from the UI; try graceful shutdown first.

    def page_home(self,v):
        now=datetime.now()
        hero=QFrame();hero.setObjectName('hero')
        hv=QVBoxLayout(hero)
        hv.setContentsMargins(24,23,24,23)
        kicker=QLabel('N O V A   O S   /   M O B I L E')
        kicker.setObjectName('heroSub');hv.addWidget(kicker)
        title=QLabel(now.strftime('%H:%M'));title.setObjectName('heroTitle');hv.addWidget(title)
        sub=QLabel(now.strftime('%A, %d %B')+'  ·  Your space, your way')
        sub.setObjectName('heroSub');hv.addWidget(sub)
        v.addWidget(hero)
        row=QHBoxLayout()
        wifi=self.connectivity.get('wifi',{})
        bt=self.connectivity.get('bluetooth',{})
        row.addWidget(btn('◉  '+('Wi-Fi: '+str(wifi.get('network') or 'Connected') if wifi.get('connected') else 'Wi-Fi settings'),lambda:self.open_page('wifi')))
        row.addWidget(btn('ᛒ  '+('Bluetooth on' if bt.get('enabled') else 'Bluetooth'),lambda:self.open_page('bluetooth')))
        row.addWidget(btn('☼  Quick panel',lambda:self.open_page('quick')))
        v.addLayout(row)
        v.addSpacing(10)
        v.addWidget(heading('Your essentials','small'))
        v.addWidget(QLabel('Open an app, or browse the full app drawer.'))
        grid=QGridLayout();grid.setSpacing(13)
        chosen=('browser','files','messages','contacts','music','video','clock','calendar','email','store','wifi','settings')
        for idx,(name,title,icon) in enumerate([item for appid in chosen for item in APPS if item[0]==appid]):
            b=btn(f'{icon}\n{title}',lambda _=False,n=name:self.launch_app(n))
            b.setObjectName('appTile')
            grid.addWidget(b,idx//4,idx%4)
        v.addLayout(grid)
        v.addSpacing(8)
        v.addWidget(QLabel('Original Rust bridge: '+('connected' if self.native.get('connected') else 'not connected — preview mode')))

    def page_recents(self,v):
        v.addWidget(heading('Running apps' if self.separate_apps else 'Recent screens'))
        if self.separate_apps:
            v.addWidget(QLabel('Independent Qt app processes (not sandboxed). Select Switch to focus an existing app.'))
            alive=[(name,proc) for name,proc in self.app_processes.items() if proc.state()!=QProcess.NotRunning]
            if not alive:v.addWidget(QLabel('No other app processes running.'))
            for name,proc in alive:
                title=next((entry[1] for entry in APPS if entry[0]==name),name.title())
                v.addWidget(QLabel(f'{title}: PID {int(proc.processId())}'))
                actions=QHBoxLayout()
                actions.addWidget(btn('Switch to '+title,lambda _=False,n=name:self.focus_app(n),True))
                actions.addWidget(btn('Close '+title,lambda _=False,n=name:self.stop_app(n)))
                v.addLayout(actions)
            v.addWidget(btn('Refresh running apps',lambda:self.open_page('recents',False)))
            return
        v.addWidget(QLabel('Switch between recently opened Nova views. These are not separate app processes.'))
        if not self.recent:
            v.addWidget(QLabel('No recent screens yet.'))
        for name in reversed(self.recent):
            title=next((entry[1] for entry in APPS if entry[0]==name),name.title())
            v.addWidget(btn('◉  '+title,lambda _=False,n=name:self.open_page(n)))
        v.addWidget(btn('Clear recent views',lambda:self.clear_recent_views()))

    def clear_recent_views(self):
        self.recent.clear()
        self.open_page('recents',False)

    def page_notifications(self,v):
        v.addWidget(heading('Notifications'))
        v.addWidget(QLabel('Local Nova notifications saved across restarts; not Android push notifications.'))
        items=self.fetch('/api/notifications',[])
        if not items:
            v.addWidget(QLabel('No notifications.'))
        for item in reversed(items[-50:]):
            message=('● ' if not item.get('read') else '○ ')+item.get('title','Notification')+' — '+item.get('body','')
            label=QLabel(message);label.setWordWrap(True)
            v.addWidget(label)
            if not item.get('read'):
                def mark(_=False, n=item['id']):
                    if self.invoke('/api/notifications/read',{'id':n}) is not None:
                        self.open_page('notifications',False)
                v.addWidget(btn('Mark read',mark))
        if items:
            def clear():
                if self.invoke('/api/notifications/clear',{}) is not None:
                    self.open_page('notifications',False)
            v.addWidget(btn('Clear notifications',clear))
        v.addWidget(btn('Create test notification',lambda:self.create_test_notification(),True))

    def create_test_notification(self):
        if self.invoke('/api/notifications/post',{'title':'Nova test notification','body':'Local notifications are working.'}) is not None:
            self.open_page('notifications',False)

    def page_apps(self,v):
        v.addWidget(heading('All apps'))
        search=QLineEdit();search.setPlaceholderText('Search apps…');v.addWidget(search)
        grid=QGridLayout()
        grid.setSpacing(13)
        buttons=[]
        for idx,(name,title,icon) in enumerate(APPS):
            b=btn(f'{icon}  {title}',lambda _=False,n=name:self.launch_app(n))
            b.setMinimumHeight(74)
            grid.addWidget(b,idx//3,idx%3)
            buttons.append((name,title,b))
        search.textChanged.connect(lambda query:[widget.setVisible(query.lower() in title.lower() or query.lower() in name.lower()) for name,title,widget in buttons])
        v.addLayout(grid)

    def page_settings(self,v):
        v.addWidget(heading('Settings'))
        v.addWidget(QLabel('Preferences persist across restarts.'))
        form=QFormLayout()
        theme=QComboBox();theme.addItems(['dark','light']);theme.setCurrentText(self.settings.get('theme','dark'))
        accent=QComboBox();accent.addItems(list(COLORS));accent.setCurrentText(self.settings.get('accent','blue'))
        wallpaper=QComboBox();wallpaper.addItems(['aurora','sunset','forest','midnight']);wallpaper.setCurrentText(self.settings.get('wallpaper','aurora'))
        name=QLineEdit(self.settings.get('name','Nova User'))
        clock=QCheckBox('24-hour clock');clock.setChecked(bool(self.settings.get('clock24',True)))
        for title,widget in [('Theme',theme),('Accent',accent),('Wallpaper preference',wallpaper),('Display name',name),('Clock',clock)]:form.addRow(title,widget)
        v.addLayout(form)
        def save():
            result=self.invoke('/api/settings',{'theme':theme.currentText(),'accent':accent.currentText(),
                'wallpaper':wallpaper.currentText(),'name':name.text(),'clock24':clock.isChecked()})
            if result:
                self.settings=result;self.apply_theme();self.message('Settings saved')
        v.addWidget(btn('Save appearance',save,True))
        v.addWidget(heading('Connectivity and device','small'))
        nav=QHBoxLayout()
        for label,page in [('◉ Wi-Fi','wifi'),('ᛒ Bluetooth','bluetooth'),('▥ Device','device'),('🔒 Lock screen','lock')]:
            nav.addWidget(btn(label,lambda _=False,p=page:self.open_page(p)))
        v.addLayout(nav)
        v.addSpacing(16)
        v.addWidget(heading('Original Nova Rust settings','small'))
        if not self.native.get('connected'):
            v.addWidget(QLabel('Not connected. Compile native bridge and restart the backend.'))
            return
        v.addWidget(QLabel('These values are stored by Nova v0.60 Rust settings core.'))
        language=QComboBox();language.addItems(['en','sw']);language.setCurrentText(self.core.get('language','en'))
        brightness=QSlider(Qt.Horizontal);brightness.setRange(0,100);brightness.setValue(int(self.core.get('display_brightness',75)))
        dnd=QCheckBox('Do not disturb');dnd.setChecked(bool(self.core.get('do_not_disturb',False)))
        v.addWidget(QLabel('Language'));v.addWidget(language)
        v.addWidget(QLabel('Brightness preference'));v.addWidget(brightness)
        v.addWidget(dnd)
        def save_core():
            for k,val in [('language',language.currentText()),('display_brightness',brightness.value()),('do_not_disturb',dnd.isChecked())]:
                if self.invoke('/api/core/settings',{'key':k,'value':val}) is None: return
            self.message('Nova Rust preferences saved (hardware controls not yet connected)')
        v.addWidget(btn('Save Rust core settings',save_core,True))

    def page_files(self,v):
        v.addWidget(heading('Files'))
        result=self.fetch('/api/files',{'items':[]},path=self.current_dir)
        if not result:return
        v.addWidget(QLabel('/NovaFiles/'+self.current_dir))
        row=QHBoxLayout()
        row.addWidget(btn('↑ Up',lambda:self.file_folder('/'.join(self.current_dir.split('/')[:-1]))))
        row.addWidget(btn('+ Folder',lambda:self.file_create(True)))
        row.addWidget(btn('+ Text',lambda:self.file_create(False)))
        row.addWidget(btn('Upload',self.file_upload))
        v.addLayout(row)
        self.filelist=QListWidget()
        self.fileitems=result['items']
        for item in self.fileitems:
            self.filelist.addItem(('📁  ' if item['dir'] else '📄  ')+item['name'])
        self.filelist.itemDoubleClicked.connect(lambda item:self.file_open(self.filelist.currentRow()))
        v.addWidget(self.filelist)
        r=QHBoxLayout()
        r.addWidget(btn('Open',lambda:self.file_open(self.filelist.currentRow()),True))
        r.addWidget(btn('Rename',self.file_rename))
        r.addWidget(btn('Trash',self.file_trash))
        v.addLayout(r)
        v.addWidget(QLabel('Changes are made to real files inside the configured NovaFiles folder.'))

    def file_item(self):
        row=self.filelist.currentRow()
        return self.fileitems[row] if 0<=row<len(self.fileitems) else None

    def file_folder(self,path):
        self.current_dir=path;self.open_page('files',False)

    def file_open(self,row):
        if not 0<=row<len(self.fileitems):return
        item=self.fileitems[row]
        if item['dir']:return self.file_folder(item['path'])
        if Path(item['name']).suffix.lower() not in {'.txt','.md','.json','.log','.csv','.py','.rs','.toml','.c','.h','.sh','.html','.css','.js'}:
            self.message('This file type is not a text document. Images appear in Photos.');return
        result=self.fetch('/api/file',None,path=item['path'])
        if not result:return
        self.open_editor(item['path'],result['content'])

    def open_editor(self,path,content):
        self.history.append('files')
        self.page='file_editor'
        w=QWidget();v=QVBoxLayout(w)
        v.addWidget(heading(Path(path).name))
        editor=QTextEdit(content);v.addWidget(editor)
        def save():
            if self.invoke('/api/files/save',{'path':path,'content':editor.toPlainText()}):self.message('Saved')
        v.addWidget(btn('Save text file',save,True))
        while self.stack.count():
            old=self.stack.widget(0);self.stack.removeWidget(old);old.deleteLater()
        self.stack.addWidget(w)

    def file_create(self,folder):
        name,ok=QInputDialog.getText(self,'Nova Files','New '+('folder' if folder else 'text file')+' name')
        if ok and name:
            if self.invoke('/api/files/create',{'path':self.current_dir,'name':name,'dir':folder}):self.open_page('files',False)

    def file_upload(self):
        import base64
        path,_=QFileDialog.getOpenFileName(self,'Import file')
        if not path:return
        p=Path(path)
        if p.stat().st_size>5*1024*1024:return self.message('Upload limit: 5 MB',False)
        payload={'path':self.current_dir,'name':p.name,'base64':base64.b64encode(p.read_bytes()).decode('ascii')}
        if self.invoke('/api/files/upload',payload):self.open_page('files',False)

    def file_rename(self):
        item=self.file_item()
        if not item:return
        name,ok=QInputDialog.getText(self,'Rename','New name',text=item['name'])
        if ok and name and self.invoke('/api/files/rename',{'path':item['path'],'name':name}):self.open_page('files',False)

    def file_trash(self):
        item=self.file_item()
        if not item:return
        if QMessageBox.question(self,'Trash','Move '+item['name']+' to Nova Trash?')!=QMessageBox.Yes:return
        if self.invoke('/api/files/trash',{'path':item['path']}):self.open_page('files',False)

    def page_notes(self,v):
        v.addWidget(heading('Notes'))
        self.notes=self.fetch('/api/notes',[])
        self.notelist=QListWidget();self.notelist.addItems([n.get('title','Untitled') for n in self.notes]);v.addWidget(self.notelist)
        self.note_title=QLineEdit();self.note_title.setPlaceholderText('Note title')
        self.note_content=QTextEdit();self.note_content.setPlaceholderText('Write something…')
        self.notelist.currentRowChanged.connect(self.load_note)
        v.addWidget(self.note_title);v.addWidget(self.note_content)
        row=QHBoxLayout();row.addWidget(btn('New',self.clear_note));row.addWidget(btn('Save',self.save_note,True));row.addWidget(btn('Delete',self.delete_note));v.addLayout(row)

    def load_note(self,row):
        if 0<=row<len(self.notes):
            n=self.notes[row];self.active_note=n['id'];self.note_title.setText(n['title']);self.note_content.setPlainText(n.get('content',''))

    def clear_note(self):
        self.active_note=None;self.notelist.clearSelection();self.notelist.setCurrentRow(-1);self.note_title.clear();self.note_content.clear()

    def save_note(self):
        payload={'id':self.active_note,'title':self.note_title.text(),'content':self.note_content.toPlainText()}
        if self.invoke('/api/notes/save',payload):self.open_page('notes',False)

    def delete_note(self):
        if self.active_note and self.invoke('/api/notes/save',{'id':self.active_note,'delete':True}):self.open_page('notes',False)

    def page_contacts(self,v):
        v.addWidget(heading('Contacts'))
        self.contacts=self.fetch('/api/contacts',[])
        self.contactlist=QListWidget()
        self.contactlist.addItems([c['name']+' · '+c.get('phone','') for c in self.contacts])
        self.contactlist.currentRowChanged.connect(self.load_contact)
        v.addWidget(self.contactlist)
        self.contact_name=QLineEdit();self.contact_name.setPlaceholderText('Name')
        self.contact_phone=QLineEdit();self.contact_phone.setPlaceholderText('Phone')
        v.addWidget(self.contact_name);v.addWidget(self.contact_phone)
        row=QHBoxLayout();row.addWidget(btn('New',self.clear_contact));row.addWidget(btn('Save',self.save_contact,True));row.addWidget(btn('Delete',self.delete_contact));v.addLayout(row)
        v.addWidget(QLabel('Contacts are '+('backed by original Nova Rust' if self.native.get('connected') else 'stored in preview mode')+'.'))

    def load_contact(self,row):
        if 0<=row<len(self.contacts):
            c=self.contacts[row];self.active_contact=c['id'];self.contact_name.setText(c['name']);self.contact_phone.setText(c.get('phone',''))

    def clear_contact(self):
        self.active_contact=None;self.contactlist.setCurrentRow(-1);self.contact_name.clear();self.contact_phone.clear()

    def save_contact(self):
        payload={'id':self.active_contact,'name':self.contact_name.text(),'phone':self.contact_phone.text()}
        if self.invoke('/api/contacts/save',payload):self.open_page('contacts',False)

    def delete_contact(self):
        if self.active_contact and self.invoke('/api/contacts/save',{'id':self.active_contact,'delete':True}):self.open_page('contacts',False)

    def page_messages(self,v):
        v.addWidget(heading('Messages'))
        v.addWidget(QLabel('Local drafts only. SMS/modem hardware is not connected.'))
        data=self.fetch('/api/messages',[])
        lst=QListWidget();lst.addItems([m.get('recipient','')+': '+m.get('body','')[:120] for m in data]);v.addWidget(lst)
        number=QLineEdit();number.setPlaceholderText('Recipient')
        body=QTextEdit();body.setPlaceholderText('Draft your message…')
        v.addWidget(number);v.addWidget(body)
        def save():
            if self.invoke('/api/messages/save',{'recipient':number.text(),'body':body.toPlainText()}):self.open_page('messages',False)
        v.addWidget(btn('Save local draft',save,True))
        if self.native.get('connected'):
            v.addWidget(heading('Original Nova Rust message core','small'))
            threads=self.fetch('/api/core/messages',[])
            v.addWidget(QLabel(str(len(threads))+' Rust message threads currently present (read-only).'))

    def page_photos(self,v):
        v.addWidget(heading('Photos'))
        data=self.fetch('/api/gallery',{'images':[]})
        images=data.get('images',[])
        if not images:
            v.addWidget(QLabel('No images in Nova Files. Upload pictures using Files.'))
            return
        grid=QGridLayout()
        for idx,item in enumerate(images[:45]):
            try:
                pix=QPixmap();pix.loadFromData(self.client.image(item['path']))
                label=QLabel();label.setPixmap(pix.scaled(QSize(190,155),Qt.KeepAspectRatio,Qt.SmoothTransformation))
                label.setToolTip(item['name']);label.setAlignment(Qt.AlignCenter)
                grid.addWidget(label,idx//4,idx%4)
            except (NovaApiError,OSError):continue
        v.addLayout(grid)

    def page_calculator(self,v):
        v.addWidget(heading('Calculator'))
        edit=QLineEdit();edit.setPlaceholderText('Example: (17 * 4) / 2')
        edit.setMinimumHeight(50);v.addWidget(edit)
        result=heading('0');v.addWidget(result)
        def calculate():
            try:result.setText(safe_calculate(edit.text()))
            except (ValueError,ZeroDivisionError,OverflowError,SyntaxError) as exc:result.setText('Error: '+str(exc))
        grid=QGridLayout()
        for i,key in enumerate(['7','8','9','/','4','5','6','*','1','2','3','-','0','.','(',')','C','+','%','=']):
            if key=='=': action=calculate
            elif key=='C':action=edit.clear
            else:action=lambda _=False,k=key:edit.setText(edit.text()+k)
            grid.addWidget(btn(key,action,key=='='),i//4,i%4)
        v.addLayout(grid)
        edit.returnPressed.connect(calculate)

    def page_quick(self,v):
        self.refresh_state()
        v.addWidget(heading('Control center'))
        v.addWidget(QLabel('Real connectivity status · Controls require adapter access'))
        wifi=self.connectivity.get('wifi',{})
        bt=self.connectivity.get('bluetooth',{})
        tiles=QGridLayout();tiles.setSpacing(12)
        for idx,(label,state,page) in enumerate([
            ('◉ Wi-Fi','Connected' if wifi.get('connected') else 'Not connected','wifi'),
            ('ᛒ Bluetooth','Enabled' if bt.get('enabled') else 'Off / unavailable','bluetooth'),
            ('☼ Display','Saved brightness preference','device'),
            ('♧ Notifications','View your local alerts','notifications'),
            ('▥ Storage','Disk and battery information','device'),
            ('🔒 Lock','Lock this Nova graphical session','lock')]):
            b=btn(label+'\n'+state,lambda _=False,p=page:self.open_page(p))
            b.setMinimumHeight(92);tiles.addWidget(b,idx//2,idx%2)
        v.addLayout(tiles)
        v.addWidget(heading('Display preferences','small'))
        prefs=self.device.get('preferences',{})
        bright=QSlider(Qt.Horizontal);bright.setRange(0,100);bright.setValue(int(prefs.get('brightness_preference',75)))
        v.addWidget(QLabel('Brightness preference (not physical backlight)'));v.addWidget(bright)
        vol=QSlider(Qt.Horizontal);vol.setRange(0,100);vol.setValue(int(prefs.get('volume_preference',60)))
        v.addWidget(QLabel('Volume preference (not system audio mixer)'));v.addWidget(vol)
        def save():
            if self.invoke('/api/device/preferences',{'brightness_preference':bright.value(),'volume_preference':vol.value()}) is not None:
                self.device=self.client.get('/api/device')
                self.message('Display and audio preferences saved')
        v.addWidget(btn('Save preferences',save,True))
        v.addWidget(QLabel('No simulated airplane-mode or radio activation is reported as successful.'))

    def page_wifi(self,v):
        v.addWidget(heading('Wi-Fi'))
        state=self.fetch('/api/connectivity',{}).get('wifi',{})
        v.addWidget(QLabel('Adapter: '+('detected' if state.get('available') else 'not exposed to this environment')))
        v.addWidget(QLabel('Radio: '+str(state.get('enabled'))+'  ·  Network: '+str(state.get('network') or 'none')))
        if not state.get('available'):
            v.addWidget(QLabel(state.get('reason','No Wi-Fi adapter')))
            v.addWidget(QLabel('QEMU and Google Colab commonly provide Ethernet instead of a Wi-Fi radio.'))
            return
        permitted=state.get('can_control',False)
        v.addWidget(QLabel('Control: '+('available' if permitted else state.get('reason','read-only'))))
        actions=QHBoxLayout()
        def operate(action,payload=None):
            if self.invoke('/api/connectivity/wifi/'+action,payload or {}) is not None:
                self.open_page('wifi',False)
        actions.addWidget(btn('Enable Wi-Fi',lambda:operate('enable'),enabled=permitted))
        actions.addWidget(btn('Disable Wi-Fi',lambda:operate('disable'),enabled=permitted))
        actions.addWidget(btn('Scan',lambda:operate('scan'),enabled=permitted))
        v.addLayout(actions)
        ssid=QLineEdit();ssid.setPlaceholderText('Network name (SSID)')
        password=QLineEdit();password.setPlaceholderText('Wi-Fi password (if needed)');password.setEchoMode(QLineEdit.Password)
        v.addWidget(ssid);v.addWidget(password)
        networks=state.get('networks',[])
        if networks:
            v.addWidget(heading('Available networks','small'))
            for network in networks[:20]:
                n=network['ssid']
                label=n+' · '+str(network['signal'])+'% · '+str(network['security'] or 'Open')
                v.addWidget(btn(label,lambda _=False,x=n:ssid.setText(x)))
        v.addWidget(btn('Connect',lambda:operate('connect',{'ssid':ssid.text(),'password':password.text()}),True,permitted))
        v.addWidget(QLabel('Connection requires NetworkManager, a real adapter and guest permissions.'))

    def page_bluetooth(self,v):
        v.addWidget(heading('Bluetooth'))
        state=self.fetch('/api/connectivity',{}).get('bluetooth',{})
        v.addWidget(QLabel('Controller: '+('detected' if state.get('available') else 'unavailable')))
        v.addWidget(QLabel('Powered: '+str(state.get('enabled'))))
        permitted=state.get('can_control',False)
        v.addWidget(QLabel(state.get('reason','Device manager ready')))
        buttons=QHBoxLayout()
        def operate(action,payload=None):
            if self.invoke('/api/connectivity/bluetooth/'+action,payload or {}) is not None:
                self.open_page('bluetooth',False)
        for action,label in [('enable','Enable'),('disable','Disable'),('scan','Scan devices')]:
            buttons.addWidget(btn(label,lambda _=False,a=action:operate(a),enabled=permitted))
        v.addLayout(buttons)
        for device in state.get('devices',[]):
            item=QHBoxLayout()
            addr=device['address'];item.addWidget(QLabel(device['name']+' · '+addr))
            item.addWidget(btn('Pair',lambda _=False,a=addr:operate('pair',{'address':a}),enabled=permitted))
            item.addWidget(btn('Connect',lambda _=False,a=addr:operate('connect',{'address':a}),enabled=permitted))
            v.addLayout(item)
        v.addWidget(QLabel('Pairing may require confirmation in the BlueZ system agent.'))

    def page_device(self,v):
        v.addWidget(heading('Device & power'))
        info=self.fetch('/api/device',{})
        battery=info.get('battery',{})
        v.addWidget(heading('Battery and storage','small'))
        v.addWidget(QLabel('Battery: '+(str(battery.get('percent'))+'%' if battery.get('percent') is not None else 'not exposed by Linux/QEMU')))
        v.addWidget(QLabel('Charging state: '+str(battery.get('state','unavailable'))))
        diag=info.get('storage',{})
        for key,label in [('storage_free_mb','Free storage (MB)'),('ram_available_mb','Available memory (MB)'),('audio_devices','Audio device detected')]:
            v.addWidget(QLabel(label+': '+str(diag.get(key,'unavailable'))))
        v.addWidget(heading('Display and sound preferences','small'))
        p=info.get('preferences',{})
        brightness=QSlider(Qt.Horizontal);brightness.setRange(0,100);brightness.setValue(int(p.get('brightness_preference',75)))
        volume=QSlider(Qt.Horizontal);volume.setRange(0,100);volume.setValue(int(p.get('volume_preference',60)))
        timeout=QComboBox();timeout.addItems(['1','2','5','10','30']);timeout.setCurrentText(str(p.get('screen_timeout_minutes',5)))
        motion=QCheckBox('Reduce interface animations');motion.setChecked(bool(p.get('reduce_motion',False)))
        v.addWidget(QLabel('Brightness preference'));v.addWidget(brightness)
        v.addWidget(QLabel('Volume preference'));v.addWidget(volume)
        v.addWidget(QLabel('Screen timeout preference (minutes)'));v.addWidget(timeout);v.addWidget(motion)
        def save():
            data={'brightness_preference':brightness.value(),'volume_preference':volume.value(),
                  'screen_timeout_minutes':int(timeout.currentText()),'reduce_motion':motion.isChecked()}
            if self.invoke('/api/device/preferences',data) is not None:self.message('Preferences saved; physical controls not connected')
        v.addWidget(btn('Save device preferences',save,True))
        v.addWidget(QLabel('Physical backlight, volume and sleep require separate device backend integration.'))

    def page_lock(self,v):
        info=self.fetch('/api/lock/status',{})
        configured=info.get('pin_configured',False)
        v.addWidget(heading('Nova screen lock'))
        v.addWidget(QLabel('UI session lock only. Not encrypted storage or host OS authentication.'))
        if self.locked:
            v.addWidget(heading('Session locked','small'))
            pin=QLineEdit();pin.setPlaceholderText('Enter PIN');pin.setEchoMode(QLineEdit.Password)
            v.addWidget(pin)
            def unlock():
                result=self.invoke('/api/lock/verify',{'pin':pin.text()})
                if result and result.get('unlocked'):
                    self.locked=False;self.home()
            v.addWidget(btn('Unlock Nova',unlock,True))
            pin.returnPressed.connect(unlock)
            return
        if configured:
            v.addWidget(btn('Lock graphical session',self.lock_session,True))
        old=QLineEdit();old.setPlaceholderText('Current PIN (for changes)');old.setEchoMode(QLineEdit.Password)
        new=QLineEdit();new.setPlaceholderText('New 4–12 digit PIN');new.setEchoMode(QLineEdit.Password)
        if configured:v.addWidget(old)
        v.addWidget(new)
        def set_pin():
            if self.invoke('/api/lock/setup',{'pin':new.text(),'current_pin':old.text()}) is not None:
                self.message('Screen lock PIN saved')
                self.open_page('lock',False)
        v.addWidget(btn('Change PIN' if configured else 'Create PIN',set_pin,True))

    def lock_session(self):
        self.locked=True
        self.open_page('lock',False)

    def page_components(self,v):
        v.addWidget(heading('Components'))
        data=self.fetch('/api/integration',{})
        if not data:
            v.addWidget(QLabel('Component catalog unavailable'));return
        counts=data.get('counts',{})
        v.addWidget(heading(f"{counts.get('source_present','?')} source modules · {counts.get('binary_installed',0)} installed binaries",'small'))
        services=data.get('guest_services',{})
        v.addWidget(QLabel('Guest services: '+', '.join(f'{k}={s}' for k,s in services.items())))
        v.addWidget(QLabel('Rust bridge: '+('connected' if self.native.get('connected') else 'not connected')))
        v.addWidget(QLabel('A module being present in source does NOT mean it is running as an app.'))
        items=data.get('components',[])
        lst=QListWidget()
        for component in items:
            mark='●' if component.get('binary_installed') else '○'
            lst.addItem(f"{mark}  {component.get('name','?')}  [{component.get('kind','?')}]  {component.get('status','')}")
        v.addWidget(lst)

    def page_recovery(self,v):
        v.addWidget(heading('Recovery and backups'))
        v.addWidget(QLabel('Snapshots include Nova GUI data and files, but not the original Rust contacts database.'))
        backups=self.fetch('/api/backups',[])
        for item in backups[-10:]:
            v.addWidget(QLabel(f"{item['name']} — {item['bytes']} bytes"))
        def create():
            if self.invoke('/api/backups/create',{}):
                self.message('Recovery snapshot saved.');self.open_page('recovery',False)
        v.addWidget(btn('Create backup',create,True))
        v.addWidget(QLabel('Restoring a backup creates a separate review folder, never overwrites live files.'))

    def page_packages(self,v):
        v.addWidget(heading('Nova data packages'))
        v.addWidget(QLabel('Checksum-verified resources only. Executable third-party apps and APKs are not supported.'))
        packages=self.fetch('/api/packages',[])
        for item in packages:
            row=QHBoxLayout()
            row.addWidget(QLabel(item['id']+'  '+str(item['version'])))
            def remove(_=False,n=item['id']):
                if self.invoke('/api/packages/uninstall',{'id':n}):self.open_page('packages',False)
            row.addWidget(btn('Remove',remove))
            v.addLayout(row)
        def install():
            import base64
            name,_=QFileDialog.getOpenFileName(self,'Install Nova resource bundle','','ZIP archives (*.zip)')
            if not name:return
            contents=Path(name).read_bytes()
            if len(contents)>4*1024*1024:return self.message('Package exceeds 4 MB',False)
            if self.invoke('/api/packages/install',{'base64':base64.b64encode(contents).decode('ascii')}):
                self.open_page('packages',False)
        v.addWidget(btn('Install resource bundle',install,True))

    def page_system(self,v):
        v.addWidget(heading('About Nova OS'))
        self.refresh_state()
        s=self.system
        health=self.fetch('/api/health',{})
        for title,value in [('Mode','Native Qt Wayland shell + Linux ARM64'),
                            ('Backend health','ready' if health.get('ready') else 'degraded'),
                            ('Qt event loop', 'heartbeat active' if health.get('gui_event_loop_active') else 'not observed'),
                            ('Linux host',s.get('os','?')),
                            ('Architecture',s.get('arch','?')),
                            ('RAM (MB)',str(s.get('memory_mb','?'))),
                            ('Network',str(s.get('network',{}).get('interfaces',[]))),
                            ('Battery',str(s.get('battery',{}).get('percent','unavailable'))),
                            ('Rust core bridge','connected' if self.native.get('connected') else 'not connected')]:
            line=QLabel(title+'  —  '+value);line.setWordWrap(True);v.addWidget(line)
        diag=self.fetch('/api/platform/diagnostics',{})
        if diag:
            v.addWidget(heading('Measured resources','small'))
            for key,label in [('ram_available_mb','Available RAM (MB)'),('storage_free_mb','Free Nova storage (MB)'),('audio_devices','ALSA audio device detected'),('network_interfaces','Network interfaces')]:
                v.addWidget(QLabel(label+': '+str(diag.get(key,'unavailable'))))
        v.addSpacing(15)
        v.addWidget(QLabel('Kernel: Linux · PID 1: systemd · compositor: Weston. The independent Nova kernel/init/compositor are not running in this image.'))
        v.addWidget(btn('Refresh system',lambda:self.open_page('system',False),True))
        v.addWidget(btn('Exit graphical session',self.close))

    def page_camera(self,v):
        v.addWidget(heading('Camera'))
        v.addWidget(QLabel('Camera capture is not supported in this QEMU build.'))
        v.addWidget(QLabel('A real camera driver, media pipeline and device permissions are required.'))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--base',default=os.environ.get('NOVA_GUI_BACKEND','http://127.0.0.1:8767'))
    parser.add_argument('--window',action='store_true',help='Show a normal window rather than fullscreen')
    parser.add_argument('--app',choices=[app[0] for app in APPS], help='Start directly in a selected Nova Qt screen')
    parser.add_argument('--child',action='store_true',help='Run as a managed child window; no child spawning')
    parser.add_argument('--check-backend',action='store_true',help='Print backend and Rust connection status, no GUI')
    args=parser.parse_args()
    client=NovaClient(args.base)
    try:status=client.connect()
    except (NovaApiError,ValueError) as exc:
        print('Nova backend error:',exc,file=sys.stderr)
        return 2
    if args.check_backend:
        print('Nova native GUI backend connection: OK; Rust connected:',status.get('connected'))
        return 0
    # Qt5 WebEngine initialization must happen before QApplication is created.
    # Do not initialize Chromium as root in Colab/offscreen preview.
    if not (hasattr(os, 'geteuid') and os.geteuid()==0) and os.environ.get('QT_QPA_PLATFORM')!='offscreen':
        try:
            from PyQt5 import QtWebEngineWidgets  # noqa: F401
        except ImportError:
            pass
    app=QApplication(sys.argv[:1]);app.setApplicationName('Nova OS')
    app.setFont(QFont('DejaVu Sans',11))
    if args.child:os.environ['NOVA_CHILD_APP']='1'
    win=NovaWindow(client)
    if args.app:win.open_page(args.app,False)
    if args.window: win.show()
    else: win.showFullScreen()
    QTimer.singleShot(600,win._gui_heartbeat)
    return app.exec_()

if __name__=='__main__':raise SystemExit(main())
