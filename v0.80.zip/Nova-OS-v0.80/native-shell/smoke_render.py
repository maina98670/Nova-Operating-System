#!/usr/bin/env python3
"""Optional native Qt render smoke test for Linux / Colab offscreen display.

Passing this test shows Qt widgets can be painted; it is not a QEMU boot test.
"""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import argparse
import sys
from PyQt5.QtWidgets import QApplication
from backend import NovaClient
from nova_shell import NovaWindow

parser=argparse.ArgumentParser()
parser.add_argument('--out',default='/tmp/nova-native-shell.png')
parser.add_argument('--page',choices=['home','files','settings','notes','contacts','messages','system','components','quick','notifications','recents','packages','recovery','wifi','bluetooth','device','lock','browser','music','clock','store','terminal','email','video','calendar'],default='home')
args=parser.parse_args()

client=NovaClient()
status=client.connect()
app=QApplication(sys.argv[:1])
win=NovaWindow(client)
win.resize(1100,740)
win.show()
app.processEvents()
win.open_page(args.page)
app.processEvents()
if win.last_page_error:
    raise RuntimeError('Qt page failed to render: '+win.last_page_error)
result=win.grab().save(args.out,'PNG')
print('Rendered:',result,'Screen:',args.out,'Rust bridge:',status.get('connected'))
if not result:raise SystemExit(3)
win.close()
