"""Safety and phone-porting utility tests (all offline)."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest

TOOLS=Path(__file__).resolve().parents[1]/'tools'
ROOT=TOOLS.parents[1]

def load(name):
    sp=importlib.util.spec_from_file_location(name,TOOLS/(name+'.py'))
    mod=importlib.util.module_from_spec(sp)
    sp.loader.exec_module(mod)
    return mod

preflight=load('preflight')
inspector=load('inspect_phone')
overlay=load('build_userspace_overlay')

class PhonePortSafety(unittest.TestCase):
    def setUp(self):
        self.profile=json.loads((TOOLS.parent/'profiles'/'device-profile.template.json').read_text())

    def test_default_profile_must_be_blocked(self):
        blockers=preflight.check(self.profile, None, Path('/tmp'))
        self.assertGreater(len(blockers),10)
        self.assertTrue(any('No validated device-specific' in b for b in blockers))

    def test_mismatched_codename_rejected(self):
        self.profile['device']['codename']='pixel_foo'
        report={'device':{'manufacturer':'Brand','model':'Phone','codename':'different','architecture':'arm64-v8a'},'partition_names':[]}
        blockers=preflight.check(self.profile,report,Path('/tmp'))
        self.assertTrue(any('DEVICE MISMATCH: codename' in b for b in blockers))

    def test_missing_or_external_images_rejected(self):
        self.profile['required_partitions']=['boot']
        self.profile['image_manifest']=[{'partition':'boot','device_codename':'','path':'../../etc/passwd','sha256':'0'*64,'size_bytes':7}]
        blockers=preflight.check(self.profile,None,Path('/tmp/project'))
        self.assertTrue(any('inside profile workspace' in b for b in blockers))

    def test_manifest_hash_tampering_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            (base/'boot.img').write_bytes(b'DUMMY BOOT IMAGE - NOT FLASHABLE')
            self.profile['device']['codename']='test'
            self.profile['required_partitions']=['boot']
            self.profile['image_manifest']=[{'partition':'boot','device_codename':'test','path':'boot.img','sha256':'1'*64,'size_bytes':len((base/'boot.img').read_bytes())}]
            blockers=preflight.check(self.profile,None,base)
            self.assertIn('Image hash mismatch: boot',blockers)

    def test_adb_inventory_property_allowlist_no_serial(self):
        self.assertNotIn('serial', ' '.join(inspector.PROPS.values()).lower())
        self.assertNotIn('imei', ' '.join(inspector.PROPS.values()).lower())
        self.assertEqual(inspector.PROPS['codename'],'ro.product.device')

    def test_inventory_fake_adb_read_only(self):
        with tempfile.TemporaryDirectory() as d:
            adb=Path(d)/'adb'
            adb.write_text('#!/usr/bin/env python3\nimport sys\na=sys.argv[1:]\n'
              'if a==["get-state"]:print("device")\n'
              'elif a[:3]==["shell","getprop","ro.product.model"]:print("Safe Test Phone")\n'
              'elif a==["shell","ls","-1","/dev/block/by-name"]:print("boot\\nsystem")\n'
              'elif a==["shell","uname","-r"]:print("5.10")\n'
              'elif a[:2]==["shell","getprop"]:print("arm64-v8a" if a[2]=="ro.product.cpu.abi" else "test")\n'
              'else:sys.exit(2)\n')
            adb.chmod(0o755)
            out=inspector.inspect(str(adb))
            self.assertEqual(out['device']['model'],'Safe Test Phone')
            self.assertIn('boot',out['partition_names'])
            self.assertFalse(any('serial' in key for key in out['device']))

    def test_userspace_overlay_has_no_partition_image(self):
        with tempfile.TemporaryDirectory() as d:
            output=Path(d)/'userspace.tar.gz'
            count=overlay.build(output)
            self.assertGreater(count,5)
            with tarfile.open(output,'r:gz') as tf:
                names=tf.getnames()
                self.assertIn('opt/nova/graphics-shell/server.py',names)
                self.assertIn('opt/nova/native-shell/modern_webview.py',names)
                self.assertIn('usr/share/nova/overlay-manifest.json',names)
                self.assertFalse(any(n.endswith(('/boot.img','/system.img','/vendor_boot.img','/init_boot.img')) for n in names))

    def test_preflight_cli_defaults_to_not_ready(self):
        cmd=[sys.executable,str(TOOLS/'preflight.py'),'--profile',str(TOOLS.parent/'profiles'/'device-profile.template.json')]
        proc=subprocess.run(cmd,capture_output=True,text=True)
        self.assertEqual(proc.returncode,2)
        self.assertIn('NOT_READY',proc.stdout)

if __name__=='__main__':unittest.main()
