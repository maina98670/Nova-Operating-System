#!/usr/bin/env python3
"""Validate device evidence and artifacts; NEVER flash or modify a phone."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

NEEDED_DEVICE = ("manufacturer", "model", "codename", "soc", "architecture", "kernel_release")
SAFE_PART = re.compile(r"^[a-z][a-z0-9_]{1,50}$")

def check(profile, report=None, base=None):
    """Return list of blockers. Passing is a documentation gate, not flashing permission."""
    blockers=[]
    if profile.get("schema_version") != 1 or profile.get("nova_os_version") != "0.80":
        blockers.append("Unsupported profile schema or Nova OS version")
    device=profile.get("device",{})
    for k in NEEDED_DEVICE:
        if not isinstance(device.get(k),str) or not device[k].strip():
            blockers.append("Device field missing: "+k)
    if device.get("architecture") not in ("arm64-v8a", "aarch64", "arm64"):
        blockers.append("Device must be verified ARM64, not inferred from branding")
    for key in ("a_b_slots", "dynamic_partitions"):
        if not isinstance(device.get(key),bool):
            blockers.append("Device layout unresolved: "+key)
    if device.get("boot_header_version") not in (0,1,2,3,4):
        blockers.append("Boot image header version unknown or unsupported")
    flags=profile.get("preconditions",{})
    for key in (
        "owner_and_flash_authorization_confirmed", "data_backup_off_device_verified",
        "official_stock_firmware_and_recovery_verified", "bootloader_unlock_supported_and_authorized",
        "partition_layout_verified_for_exact_build", "boot_init_boot_vendor_boot_and_avb_layout_verified",
        "device_kernel_and_dtb_compatible", "required_kernel_modules_and_firmware_available",
        "display_input_storage_driver_support_verified", "verified_boot_strategy_reviewed",
        "native_nova_arm64_userspace_built_and_abi_tested", "arm64_qemu_graphical_boot_passed",
        "target_device_non_destructive_boot_test_passed", "restore_procedure_rehearsed"
    ):
        if flags.get(key) is not True:
            blockers.append("Unverified required evidence: "+key)
    required=profile.get("required_partitions",[])
    if not isinstance(required,list) or not required:
        blockers.append("Device-specific required_partitions list not established")
        required=[]
    if report is None:
        blockers.append("Read-only device report missing; cannot compare physical device")
    else:
        observed=report.get("device",{})
        for k in ("manufacturer","model","codename"):
            if str(device.get(k,"")).casefold() != str(observed.get(k,"")).casefold():
                blockers.append("DEVICE MISMATCH: "+k)
        if not observed.get("architecture", "").startswith(("arm64","aarch64")):
            blockers.append("Connected device CPU ABI is not confirmed ARM64")
        slot=observed.get("slot_suffix")
        if slot in ("_a", "_b") and device.get("a_b_slots") is False:
            blockers.append("SLOT MISMATCH: report shows A/B but profile declares non-A/B")
        dynamic=observed.get("dynamic_partitions")
        if dynamic in ("true", "false") and isinstance(device.get("dynamic_partitions"),bool):
            if (dynamic == "true") != device["dynamic_partitions"]:
                blockers.append("PARTITION MISMATCH: dynamic partition flag disagrees with report")
        found=set(report.get("partition_names",[]))
        for partition in required:
            if isinstance(partition,str) and not (
                partition in found or partition+"_a" in found or partition+"_b" in found
            ):
                blockers.append("Required partition not observed on connected device: "+partition)
    manifest=profile.get("image_manifest",[])
    if not isinstance(manifest,list) or not manifest:
        blockers.append("No validated device-specific flash images (correct: this kit provides none)")
        manifest=[]
    covered=set()
    base = Path(base or ".").resolve()
    for entry in manifest:
        if not isinstance(entry,dict):
            blockers.append("Invalid manifest entry")
            continue
        partition=entry.get("partition", "")
        if not isinstance(partition,str) or not SAFE_PART.fullmatch(partition):
            blockers.append("Invalid image target partition")
            continue
        covered.add(partition)
        if partition not in required:
            blockers.append("Image partition not listed in required_partitions: "+partition)
        if entry.get("device_codename") != device.get("codename"):
            blockers.append("Image codename does not match device profile: "+partition)
        path=entry.get("path", "")
        if not isinstance(path,str) or Path(path).is_absolute():
            blockers.append("Unsafe or missing relative image path: "+partition)
            continue
        candidate=(base / path).resolve()
        if not candidate.is_relative_to(base) or not candidate.is_file():
            blockers.append("Image not present inside profile workspace: "+partition)
            continue
        digest=hashlib.sha256()
        with candidate.open("rb") as handle:
            header=handle.read(8)
            digest.update(header)
            for chunk in iter(lambda:handle.read(1024*1024),b""):
                digest.update(chunk)
        actual=digest.hexdigest()
        expected_magic={"boot":b"ANDROID!", "init_boot":b"ANDROID!", "vendor_boot":b"VNDRBOOT", "vbmeta":b"AVB0"}
        if partition in expected_magic and not header.startswith(expected_magic[partition]):
            blockers.append("Image header is not a recognizable Android image for: "+partition)
        if actual != entry.get("sha256"):
            blockers.append("Image hash mismatch: "+partition)
        if candidate.stat().st_size != entry.get("size_bytes"):
            blockers.append("Image size mismatch: "+partition)
    for partition in required:
        if partition not in covered:
            blockers.append("Missing matched image for required partition: "+str(partition))
    return blockers


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--profile",required=True)
    ap.add_argument("--report",help="JSON report from inspect_phone.py")
    ap.add_argument("--json-out", help="Write machine-readable blocker results")
    args=ap.parse_args(argv)
    profile_path=Path(args.profile).resolve()
    try:
        profile=json.loads(profile_path.read_text())
        report=json.loads(Path(args.report).read_text()) if args.report else None
    except (OSError,ValueError) as exc:
        print("Invalid profile/report:",exc,file=sys.stderr)
        return 2
    blockers=check(profile,report,profile_path.parent)
    result={"nova_os_version":"0.80","status":"NOT_READY" if blockers else "MANIFEST_GATE_PASSED_REQUIRES_MANUAL_REVIEW","blockers":blockers,"flash_operations_performed":False,"note":"This validator never authorizes an automatic flash or unlock."}
    if args.json_out: Path(args.json_out).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
    return 2 if blockers else 0

if __name__=="__main__":
    sys.exit(main())
