#!/usr/bin/env bash
# Read-only source/phone-porting checks. This script NEVER communicates with a phone.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
python3 scripts/audit-source.py
python3 -m unittest discover -s tests -q
python3 -m unittest discover -s phone-port/tests -q
# Preflight template SHOULD FAIL: if it somehow passes, stop.
if python3 phone-port/tools/preflight.py --profile phone-port/profiles/device-profile.template.json >/dev/null; then
  echo 'ERROR: Default device template was unexpectedly allowed!' >&2
  exit 3
fi
echo 'Nova source/tests PASS. Phone flashing gate correctly remains BLOCKED.'
