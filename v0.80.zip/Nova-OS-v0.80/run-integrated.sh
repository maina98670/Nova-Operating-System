#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x native-bridge/target/release/nova-graphics-bridge ]]; then
  echo 'Building original Nova Rust core integration first...'
  ./build-native.sh
fi
exec ./graphics-shell/run-nova.sh "$@"
