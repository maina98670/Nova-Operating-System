#!/usr/bin/env bash
# Run the native Qt GUI on an Ubuntu/Debian machine with a graphical session.
# Dependencies: sudo apt install python3-pyqt5 qtwayland5
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${NOVA_GUI_PYTHON:-/usr/bin/python3}"
if ! "$PYTHON_BIN" -c 'from PyQt5.QtWidgets import QApplication' >/dev/null 2>&1; then
  echo 'PyQt5 missing: sudo apt install python3-pyqt5 qtwayland5' >&2; exit 2
fi
if [[ -n "${WAYLAND_DISPLAY:-}" ]]; then export QT_QPA_PLATFORM=wayland; fi
if [[ -z "${WAYLAND_DISPLAY:-}" && -n "${DISPLAY:-}" ]]; then export QT_QPA_PLATFORM=xcb; fi
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
  echo 'No graphical session. On Colab, use the notebook offscreen smoke test instead.' >&2; exit 2
fi
if [[ -x "$ROOT/native-bridge/target/release/nova-graphics-bridge" ]]; then
  export NOVA_BRIDGE_BIN="$ROOT/native-bridge/target/release/nova-graphics-bridge"
fi
"$PYTHON_BIN" "$ROOT/graphics-shell/server.py" --no-browser --port 8767 &
BACKEND_PID=$!
trap 'kill "$BACKEND_PID" 2>/dev/null || true' EXIT INT TERM
for i in $(seq 1 40); do
  if "$PYTHON_BIN" -c 'import urllib.request; urllib.request.urlopen("http://127.0.0.1:8767/api/system",timeout=1)' >/dev/null 2>&1; then break; fi
  if ! kill -0 "$BACKEND_PID" 2>/dev/null; then echo 'Nova backend failed to start' >&2; exit 3; fi
  sleep .25
done
export NOVA_SEPARATE_APPS=1
"$PYTHON_BIN" "$ROOT/native-shell/nova_shell.py" --window
