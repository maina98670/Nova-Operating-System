#!/usr/bin/env python3
"""Read-only Android runtime prerequisites; does not install APKs or Waydroid."""
import json
import os
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'integration'))
from android_compat import AndroidBridge
base=Path(os.environ.get('NOVA_CONFIG_DIR',str(Path.home()/'.config/nova-os')))
print(json.dumps(AndroidBridge(base).status(),indent=2))
