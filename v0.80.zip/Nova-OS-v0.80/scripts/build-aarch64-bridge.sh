#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v cargo >/dev/null || { echo 'Rust cargo missing. Install via rustup.' >&2; exit 2; }
command -v rustup >/dev/null || { echo 'rustup missing. Install via rustup.rs.' >&2; exit 2; }
if ! command -v aarch64-linux-gnu-gcc >/dev/null; then
  echo 'Install cross compiler: sudo apt install gcc-aarch64-linux-gnu' >&2; exit 2
fi
rustup target add aarch64-unknown-linux-gnu
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER=aarch64-linux-gnu-gcc
cargo build --release --target aarch64-unknown-linux-gnu --manifest-path "$ROOT/native-bridge/Cargo.toml"
file "$ROOT/native-bridge/target/aarch64-unknown-linux-gnu/release/nova-graphics-bridge"
echo 'ARM64 Nova Rust bridge compiled. Build VM with NOVA_REQUIRE_RUST_BRIDGE=1 ./vm/build-arm64-qemu.sh'
