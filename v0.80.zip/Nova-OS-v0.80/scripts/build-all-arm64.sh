#!/usr/bin/env bash
# End-to-end build pipeline: original source -> original ARM64 apps/libs ->
# native bridge -> original Nova IPC daemon -> Debian ARM64 graphical VM disk.
# Not a verified boot until qemu actually reaches desktop; no phone hardware.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
for c in python3 cargo rustup file aarch64-linux-gnu-gcc; do
  command -v "$c" >/dev/null || { echo "Missing $c" >&2; exit 2; }
done
python3 scripts/audit-source.py
python3 scripts/preflight.py --strict-source
python3 scripts/generate-registry.py
python3 -m unittest discover -s tests -v
if [[ "${NOVA_SKIP_HOST_RUST_TESTS:-0}" != 1 ]]; then
  ./scripts/build-workspace.sh
fi
./scripts/build-original-arm64.sh
./scripts/build-aarch64-bridge.sh
./scripts/build-native-runtime-arm64.sh
./scripts/build-m0-m3-arm64.sh
NOVA_REQUIRE_RUST_BRIDGE=1 \
NOVA_REQUIRE_ORIGINAL_RUNTIME=1 \
NOVA_REQUIRE_ALL_BINARIES=1 \
  ./vm/build-arm64-qemu.sh
python3 scripts/validate-boot-artifacts.py
printf '\nNOVA ARM64 CANDIDATE BUILT (BOOT STILL UNVERIFIED).\nRun: python3 vm/smoke-arm64-qemu.py\nOr view: ./vm/run-arm64-qemu.sh\n'
