#!/usr/bin/env bash
# Build integrated M2 early-init, retain M1 original ARM64 splash,
# and optionally select a precompiled wlroots 0.17 M3 compositor.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/boot/integrated/out"
mkdir -p "$OUT"
for tool in cargo rustup aarch64-linux-gnu-gcc file python3; do
 command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 2; }
done
rustup target add aarch64-unknown-linux-gnu
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER=aarch64-linux-gnu-gcc
cargo build --manifest-path "$ROOT/boot/integrated/nova-early-init/Cargo.toml" --release --target aarch64-unknown-linux-gnu
cp "$ROOT/boot/integrated/nova-early-init/target/aarch64-unknown-linux-gnu/release/nova-early-init" "$OUT/nova-early-init"
# Build directly from original M2 sources when ARM64 DRM headers are available;
# otherwise retain the original precompiled static ARM64 milestone artifact.
if aarch64-linux-gnu-gcc -std=gnu11 -O2 -static -I/usr/include -fsyntax-only \
  "$ROOT/boot/legacy/m2/nova_m2_splash.c" >/dev/null 2>&1; then
  if aarch64-linux-gnu-gcc -std=gnu11 -O2 -static \
   "$ROOT/boot/legacy/m2/nova_m2_splash.c" -o "$OUT/nova-splash"; then
   echo 'M1/M2 splash cross-compiled from original C source.'
  fi
fi
if [[ ! -f "$OUT/nova-splash" ]]; then
  cp "$ROOT/boot/legacy/m2/nova-splash" "$OUT/nova-splash"
  echo 'Using original provided static ARM64 M2 splash; new compilation unavailable.'
fi
python3 "$ROOT/scripts/stage-m0-m3.py" --verify-elf "$OUT/nova-early-init" "$OUT/nova-splash"
file "$OUT/nova-early-init" "$OUT/nova-splash"
echo 'M0/M1/M2 staged; M3 needs wlroots 0.17 ARM64 binary + dependency verification.'
echo "Optional: NOVA_M3_BIN=/path/to/aarch64/nova-display ./vm/build-arm64-qemu.sh"
