#!/usr/bin/env bash
# Run from the ARM64 guest image builder, AFTER debootstrap and BEFORE ext4 pack.
# M3 is pinned to wlroots 0.17. Fail clearly on incompatible Debian releases.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOTFS="${1:-$ROOT/vm/out/rootfs}"
[[ -x "$ROOTFS/bin/sh" ]] || { echo 'Prepare ARM64 Debian rootfs first.' >&2; exit 2; }
command -v sudo >/dev/null || exit 2
if ! sudo chroot "$ROOTFS" apt-cache show libwlroots-0.17-dev >/dev/null 2>&1; then
  echo 'M3 cannot build: guest repository has no libwlroots-0.17-dev.' >&2
  echo 'Original M3 C source targets wlroots 0.17, not 0.18/0.19.' >&2
  echo 'Use a compatible ARM64 wlroots 0.17 repository or port the M3 code first.' >&2
  exit 3
fi
sudo chroot "$ROOTFS" env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    meson ninja-build pkg-config libwlroots-0.17-dev wayland-protocols libwayland-dev libxkbcommon-dev libpixman-1-dev
sudo chroot "$ROOTFS" /usr/bin/env sh -c 'pkg-config --exists wlroots-0.17 && pkg-config --exists wayland-server' || {
 echo 'wlroots 0.17 pkg-config file missing despite package installation.' >&2; exit 3;
}
sudo install -d "$ROOTFS/opt/nova-m3-source"
sudo cp "$ROOT/boot/legacy/m3/nova-display.c" "$ROOT/boot/legacy/m3/meson.build" "$ROOTFS/opt/nova-m3-source/"
sudo chroot "$ROOTFS" meson setup /opt/nova-m3-source/build /opt/nova-m3-source
sudo chroot "$ROOTFS" ninja -C /opt/nova-m3-source/build
sudo test -x "$ROOTFS/opt/nova-m3-source/build/nova-display"
echo "$ROOTFS/opt/nova-m3-source/build/nova-display"
