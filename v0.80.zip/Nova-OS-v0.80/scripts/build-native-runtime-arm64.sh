#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for cmd in cargo rustup aarch64-linux-gnu-gcc file; do command -v "$cmd" >/dev/null || { echo "Missing tool: $cmd" >&2; exit 2; }; done
rustup target add aarch64-unknown-linux-gnu
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER=aarch64-linux-gnu-gcc
cargo build --release --manifest-path "$ROOT/native-runtime/Cargo.toml" --target aarch64-unknown-linux-gnu
BIN="$ROOT/native-runtime/target/aarch64-unknown-linux-gnu/release/nova-runtime-daemon"
file "$BIN" | grep -Eq '(ARM aarch64|ARM64|aarch64)' || { echo 'Not aarch64'; exit 3; }
mkdir -p "$ROOT/native-bin"
install -m755 "$BIN" "$ROOT/native-bin/nova-runtime-daemon"
echo 'Original App Manager + protocol service executable built and staged; QEMU boot still needs testing.'
