#!/usr/bin/env bash
# Compile all 104 original workspace members for ARM64 Linux. An ALL-workspace
# build is required; an acceptance-test binary is never automatically launched.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for cmd in cargo rustup aarch64-linux-gnu-gcc file python3; do
  command -v "$cmd" >/dev/null || { echo "Missing host tool: $cmd" >&2; exit 2; }
done
rustup target add aarch64-unknown-linux-gnu
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER=aarch64-linux-gnu-gcc
cd "$ROOT/source-v0.60"
# No --offline: Cargo may need dependencies on first build.
cargo check --workspace --target aarch64-unknown-linux-gnu
cargo build --workspace --release --target aarch64-unknown-linux-gnu
if [[ "${NOVA_RUN_ALL_TESTS:-0}" == 1 ]]; then
  echo 'Running original workspace host tests (not ARM64 execution)...'
  cargo test --workspace
fi
cd "$ROOT"
python3 scripts/stage-original-binaries.py --strict
printf '[nova] Rust workspace ARM64 binaries staged (not necessarily runnable without IPC/backend devices).\n'
