#!/usr/bin/env bash
# Compile and test all declared workspace members; never hide Rust errors.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v cargo >/dev/null || { echo 'Install Rust/Cargo from https://rustup.rs' >&2; exit 2; }
cd "$ROOT/source-v0.60"
echo '[nova] cargo check --workspace'
cargo check --workspace
echo '[nova] cargo test --workspace (may expose existing upstream failures)'
cargo test --workspace
printf '[nova] all current v0.60 Rust workspace members checked and tested.\n'
