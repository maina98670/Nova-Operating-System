#!/usr/bin/env python3
"""Inventory the entire preserved original Nova workspace without treating presence as runtime integration."""
from pathlib import Path
import json, hashlib, tomllib, zipfile
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'source-v0.60'
WORK=tomllib.loads((SOURCE/'Cargo.toml').read_text())['workspace']['members']
components=[]
for path in WORK:
    directory=SOURCE/path
    t=tomllib.loads((directory/'Cargo.toml').read_text())
    name=t.get('package',{}).get('name',directory.name)
    kind=path.split('/')[0]
    has_binary=(directory/'src'/'main.rs').is_file() or bool(t.get('bin'))
    manifest=t.get('package',{}).get('name')
    deps=list(t.get('dependencies',{}))
    components.append({'name':name, 'directory':path, 'kind':kind,
                       'has_binary':has_binary,
                       'internal_dependencies':sorted(d for d in deps if d.startswith('nova-')),
                       'source':'preserved', 'runtime':'not_verifiable_from_source'})
archives=[]
for f in sorted((ROOT/'history'/'snapshots').glob('v*.zip')):
    with zipfile.ZipFile(f) as z:
        archives.append({'name':f.name,'entries':len(z.namelist()),'size_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
result={
 'release':'0.71-native-graphical-integration',
 'note':'Source availability != binary installation != process running != device functionality.',
 'workspace_count':len(components),
 'counts':{x:sum(c['kind']==x for c in components) for x in ('libs','apps','tools')},
 'components':components,
 'history':archives,
 'boot_prototypes':[p.name for p in sorted((ROOT/'boot'/'legacy').iterdir()) if p.is_dir()],
 'running_components_by_design':['Linux ARM64 kernel','systemd','Nova native Rust bridge (when installed)','Nova graphical API service','Weston','Native Nova Qt Wayland graphical shell'],
 'original_nova_init_pid1':False,
 'original_nova_compositor_active':False,
 'original_nova_app_manager_supervising_apps':False,
 'original_nova_device_drivers_active':False,
}
(ROOT/'integration'/'registry.json').write_text(json.dumps(result,indent=2)+'\n')
print('Nova original source indexed:',len(components),'members',result['counts'])
