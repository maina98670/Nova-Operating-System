#!/usr/bin/env python3
"""Local Nova development maintenance. No automatic physical phone flashing."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('hardware-status')
    hardware = sub.add_parser('hardware-evidence')
    hardware.add_argument('--evidence',required=True)
    hardware.add_argument('--integration',action='store_true')
    sub.add_parser('power-status')
    power = sub.add_parser('suspend')
    power.add_argument('--confirm',action='store_true')
    keys = sub.add_parser('keygen')
    keys.add_argument('--private',required=True); keys.add_argument('--public',required=True)
    bundle = sub.add_parser('bundle')
    for key in ('rootfs','kernel','initramfs','version','device','private-key','output'):
        bundle.add_argument('--'+key,required=True)
    initialize = sub.add_parser('initialize')
    for key in ('workspace','bundle','public-key','device'):
        initialize.add_argument('--'+key,required=True)
    stage = sub.add_parser('stage-update')
    for key in ('workspace','bundle','public-key'):
        stage.add_argument('--'+key,required=True)
    for name in ('update-status','select-boot','mark-healthy','rollback','backup','repair-restore','reset-data'):
        cmd = sub.add_parser(name); cmd.add_argument('--workspace',required=True)
    restore = sub.add_parser('restore')
    restore.add_argument('--workspace',required=True); restore.add_argument('--name',required=True)
    soak = sub.add_parser('soak')
    soak.add_argument('--output',required=True)
    soak.add_argument('--duration-seconds',type=float,default=1)
    soak.add_argument('--interval-seconds',type=float,default=1)
    soak.add_argument('--device-id'); soak.add_argument('--health-url')
    watch = sub.add_parser('watchdog')
    watch.add_argument('--output',required=True);watch.add_argument('--timeout',type=float,default=10)
    watch.add_argument('--workspace');watch.add_argument('child',nargs=argparse.REMAINDER)
    release = sub.add_parser('package-source')
    for key in ('output','private-key','public-key'):
        release.add_argument('--'+key,required=True)
    release.add_argument('--require-final-acceptance',action='store_true')
    release.add_argument('--evidence',default=str(ROOT/'evidence/final-acceptance.json'))
    verify = sub.add_parser('verify-release')
    for key in ('archive','signed-manifest','public-key'):
        verify.add_argument('--'+key,required=True)
    args = parser.parse_args()
    available = ROOT/'maintenance'
    needed = ('hardware' if args.command.startswith('hardware') else
              'stability' if args.command=='soak' else
              'watchdog' if args.command=='watchdog' else
              'release' if args.command in ('package-source','verify-release') else 'updates')
    if not (available/(needed+'.py')).is_file():
        raise ValueError('This command belongs to a later guide version')
    if args.command == 'hardware-status':
        from maintenance.hardware import observations
        result = observations()
    elif args.command == 'hardware-evidence':
        from maintenance.hardware import validate_evidence
        result = validate_evidence(args.evidence,integration=args.integration)
        print(json.dumps(result,indent=2)); return 0 if result['accepted'] else 2
    elif args.command == 'power-status':
        from maintenance.power import status
        result = status()
    elif args.command == 'suspend':
        from maintenance.power import suspend
        result = suspend(confirm=args.confirm)
    elif args.command == 'keygen':
        from maintenance.signing import generate_keys
        generate_keys(args.private,args.public); result={'created':True,'private_key_written_to':args.private}
    elif args.command == 'bundle':
        from maintenance.updates import build_bundle
        result=build_bundle({'rootfs.ext4':args.rootfs,'kernel':args.kernel,'initramfs':args.initramfs},
                            args.version,args.device,args.private_key,args.output)
    elif args.command == 'initialize':
        from maintenance.updates import initialize
        result=initialize(args.workspace,args.bundle,args.public_key,args.device)
    elif args.command == 'stage-update':
        from maintenance.updates import stage_update
        result=stage_update(args.workspace,args.bundle,args.public_key)
    elif args.command in ('update-status','select-boot','mark-healthy','rollback'):
        from maintenance import updates
        function={'update-status':updates.status,'select-boot':updates.select_boot,
                  'mark-healthy':updates.mark_healthy,'rollback':updates.rollback}[args.command]
        result=function(args.workspace)
    elif args.command in ('backup','restore','repair-restore','reset-data'):
        from maintenance import recovery
        if args.command=='restore':result=recovery.recover(args.workspace,args.name)
        else:
            function={'backup':recovery.snapshot,'repair-restore':recovery.repair_interrupted_restore,
                      'reset-data':recovery.factory_reset}[args.command]
            result=function(args.workspace)
    elif args.command=='soak':
        from maintenance.stability import collect
        result=collect(args.output,duration=args.duration_seconds,interval=args.interval_seconds,
                       device_id=args.device_id,health_url=args.health_url)
    elif args.command=='watchdog':
        from maintenance.watchdog import supervise
        result=supervise(args.child[1:] if args.child[:1]==['--'] else args.child,args.output,
                         timeout=args.timeout,workspace=args.workspace)
    elif args.command=='package-source':
        from integration.boot_evidence import source_fingerprint
        from maintenance.release import acceptance,source_archive,signed_manifest
        from maintenance.signing import crypto
        # Check signing support before creating any output.
        crypto()
        if args.require_final_acceptance:
            gate=acceptance(args.evidence,source_fingerprint(ROOT))
            if not gate['accepted']:
                print(json.dumps(gate,indent=2));return 2
        version=json.loads((ROOT/'docs/guide-milestones.json').read_text())['current_integration_version']
        result=source_archive(ROOT,args.output,version)
        signed_manifest(result,args.private_key,args.public_key,args.output+'.signed.json')
    elif args.command=='verify-release':
        from maintenance.release import verify_archive
        result=verify_archive(args.archive,args.signed_manifest,args.public_key)
    print(json.dumps(result,indent=2)); return 0


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except (OSError,ValueError,PermissionError,RuntimeError,KeyError) as exc:
        print(json.dumps({'error':str(exc),'phone_flash_operations_performed':False}),file=sys.stderr)
        raise SystemExit(2)
