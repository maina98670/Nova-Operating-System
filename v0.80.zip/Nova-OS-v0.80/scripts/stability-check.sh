#!/usr/bin/env bash
# Strict Ubuntu end-to-end pre-hardware release gate. No silent fallback.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 scripts/preflight.py --strict-source
python3 -m unittest discover -s tests -v
./scripts/build-all-arm64.sh
case "${NOVA_BOOT_CYCLES:-2}" in
  1|2|3) ;;
  *) echo 'NOVA_BOOT_CYCLES must be 1, 2 or 3' >&2; exit 2;;
esac
for ((cycle=1; cycle<=${NOVA_BOOT_CYCLES:-2}; cycle++)); do
  printf '\nTesting ARM64 boot cycle %s/%s\n' "$cycle" "${NOVA_BOOT_CYCLES:-2}"
  python3 vm/smoke-arm64-qemu.py --timeout "${NOVA_BOOT_TIMEOUT:-600}"
done
python3 scripts/release-gate.py --require-boot
printf '\nSource and QEMU event-loop boot tests PASS.\nManual VNC/GTK visual confirmation and missing independent compositor/init work still required.\n'
