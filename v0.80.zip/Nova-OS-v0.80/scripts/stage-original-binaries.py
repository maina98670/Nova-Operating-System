#!/usr/bin/env python3
"""Stage genuine original Nova app/selected CLI binaries, never hostile acceptance tools.

Does not spawn any original Nova program; launching requires implemented system
service wiring, app IPC and hardware permissions.
"""
from pathlib import Path
import argparse, json, subprocess, shutil, sys
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--strict',action='store_true')
parser.add_argument('--target',default='aarch64-unknown-linux-gnu')
args=parser.parse_args()
entries=json.loads((ROOT/'integration'/'registry.json').read_text())['components']
allow_tools={'nova-cli','nova-shell','nova-pack'}
selected=[c for c in entries if c['has_binary'] and (c['kind']=='apps' or c['name'] in allow_tools)]
staged=ROOT/'native-bin'
staged.mkdir(exist_ok=True)
missing=[]
for comp in selected:
    name=comp['name']
    exe=ROOT/'source-v0.60'/'target'/args.target/'release'/name
    if not exe.is_file():
        missing.append(name)
        continue
    probe=subprocess.run(['file',str(exe)],capture_output=True,text=True)
    if 'ARM aarch64' not in probe.stdout and 'ARM64' not in probe.stdout and 'aarch64' not in probe.stdout:
        raise SystemExit('Refusing incompatible binary: '+name+' '+probe.stdout)
    shutil.copy2(exe,staged/name)
    (staged/name).chmod(0o755)
print('Staged:',len(selected)-len(missing),'/',len(selected),'original app/CLI binaries')
if missing:print('Not staged:',', '.join(missing))
if missing and args.strict:sys.exit(1)
