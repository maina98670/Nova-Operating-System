#!/usr/bin/env python3
"""Host-side structural checks only; does NOT claim a successful QEMU boot."""
from pathlib import Path
import json,sys,subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'vm'/'out'
image=OUT/'nova-arm64.ext4'
boot=OUT/'rootfs'/'boot'
errors=[]
if not image.is_file():errors.append('Missing image: build vm/build-arm64-qemu.sh on Ubuntu')
else:
    try:
        r=subprocess.run(['file',str(image)],capture_output=True,text=True)
        if 'ext4' not in r.stdout and 'ext2' not in r.stdout:errors.append('Image not identified as ext family')
    except OSError:errors.append('Cannot inspect image type')
for x in ('vmlinuz-*','initrd.img-*'):
    if not list(boot.glob(x)): errors.append('Missing '+x)
for x in ('source-v0.60/Cargo.toml','integration/registry.json','vm/guest/nova-catalog.service'):
    if not (ROOT/x).is_file():errors.append('Missing integrated file '+x)
res={'source_integrity':'present' if not errors else 'failed','image_present':image.is_file(),'boot_verified':False,'issues':errors}
print(json.dumps(res,indent=2));sys.exit(bool(errors))
