# Nova OS Day 49 — Repository metadata format, M11 tag

M11 (Package Ecosystem), v0.60. Continues directly from the Day 48 package.
This is the M11 milestone package.

## Definition of Done

> Document the format for a future package repository (index, versions, signatures) without building a live server (per the Roadmap's caution against a public repository too early). A local test repository following this format can be added as a source and packages installed from it via `nova-pack`. Tag M11.

## New in this package

- `libs/nova-sign-ed25519` — Ed25519 signing/verification for repository
  metadata (RFC 8032 test vectors passing), and the device's repository
  keyring. Pinned dependency version.
- `libs/nova-pack-repo` — the signed index format: build, sign, verify,
  parse. One record per package *version*.
- `tools/nova-m11-day49-acceptance-test` — 15 checks, including that the
  Day 46-48 guarantees still hold when packages arrive through a
  repository rather than a bare directory.
- `docs/M11-PACKAGE-DAY49.md`, `docs/package-format-v1.md`,
  `docs/M11-TAG.md`.

## Changed

- `tools/nova-pack`: a source with an index is read through that index
  and verified against the device's repository keyring; a source with
  no index falls back to Day 46's directory scan and says so. An
  invalid index (unsigned, untrusted, altered, unsupported format
  version) is fatal for that source — it never silently degrades to a
  scan.

## Unchanged

Everything else from the previous package is carried forward as-is.

## This is the milestone tag

```
git tag -a v0.60 -m "M11: Package Ecosystem (Days 46-49)"
```

See `docs/M11-TAG.md` for the full acceptance summary and what M11
deliberately left for later milestones.
