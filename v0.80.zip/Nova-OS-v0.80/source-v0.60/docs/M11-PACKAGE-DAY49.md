# M11 Day 49 — Repository metadata format

**Definition of Done:** Document the format for a future package repository
(index, versions, signatures) without building a live server. A local test
repository following this format can be added as a source and packages
installed from it via `nova-pack`. Tag M11.

## The format

Two files at a repository's root:

```
nova-repo.index       the listing (flat key: value records, one per package version)
nova-repo.index.sig   key_id / algorithm / an Ed25519 signature over the index bytes
```

Full grammar and an example are in `nova-pack-repo`'s module docs. One
record per package **version**, not per package — a repository offering
three versions of one app has three records, which is what makes version
selection, and rollback to an older published version, possible at all.

## Why Ed25519, and why it's the one outside dependency

`nova-crypto` stays dependency-free deliberately: SHA-256 and HMAC-SHA256
are small and fully specified enough to check against published test
vectors line by line. Ed25519 needs field arithmetic mod 2^255-19, curve
point operations, and ways to get it wrong that don't announce themselves
by failing a test vector (non-constant-time ops, missing small-order-point
checks, malleable signatures). `ed25519-dalek` is pinned exactly, and
`nova-sign-ed25519`'s own tests check against RFC 8032 §7.1 vectors 1 and
2 verbatim.

## Why a signature is required, not optional

`RepoIndex::load_verified` has no warn-and-continue path. An index that is
unsigned, signed by an untrusted key, or altered since signing is a hard
error for that source — it does **not** fall back to a directory scan.
Falling back would let an attacker disable verification simply by breaking
the signature. A source with no index at all is a different, legitimate
case (a directory a user assembled locally never claimed to be a published
repository) and is scanned, with the difference reported to the caller.

## The index is a hint, never the truth about what arrived

Every metadata field in the index — hash, size, signer — is restated from
what was true when the index was built. `nova-pack` checks the *fetched
bytes* against the index-declared hash before doing anything else with
them; a package that no longer matches (Day 49's acceptance test alters
one byte of an already-indexed file) stops the install with
`ChecksumMismatch`, not a signature error, because that is what actually
went wrong.

## What this gives, and what it still doesn't

**Given:** a device that trusts a repository's public key can trust that
every package the index lists came from that repository and matches the
listed hash, and can detect any later corruption of the index itself.

**Not given:** proof that a specific publisher — as opposed to whoever
holds the repository's Ed25519 key — actually authored any one package.
Per-package signatures remain M10's HMAC scheme, symmetric, provable only
as "someone with the shared secret." This gap, and the fix, are written
down in `docs/package-format-v1.md` with M15 as the stated owner, rather
than left implied as solved.

## Milestone check

Day 49's acceptance test also re-runs the load-bearing guarantees from
Days 46-48 against packages arriving through a repository rather than a
bare directory: dependency resolution, the removal-would-break check,
M10 verification, and rollback all still hold. 15/15 checks pass; see
`docs/M11-TAG.md` for the full milestone summary.
