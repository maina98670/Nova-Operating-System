# M11 — Package Ecosystem — tag notes

```
git tag -a v0.60 -m "M11: Package Ecosystem (Days 46-49)"
```

## Definition of Done, and where each part is proven

| Requirement | Where |
| --- | --- |
| `nova-pack install/list/remove` work against a local test repository | Day 46, 15/15 |
| Dependency resolution refuses an unmet dependency before writing anything | Day 47, 14/14 |
| M5 permissions and M10 signatures enforced through this new install path, not bypassable | Day 47, same suite |
| Post-install integrity checking detects a deliberately corrupted package | Day 48, 14/14 |
| Rollback restores the previous working version without manual file surgery | Day 48, same suite |
| A local repository following a documented signed metadata format works as a source | Day 49, 15/15 |

154 unit tests pass across the workspace; `cargo build --workspace` and
`cargo test --workspace` both exit 0 on this package, checked before
writing it rather than asserted afterward.

## What shipped

- `libs/nova-pack-meta` — semantic versions, `PackageMeta` derived from
  package bytes, the installed-package database.
- `libs/nova-pack-deps` — dependency-plan resolution; no backtracking,
  by design (see the crate's own docs for the stated trigger to replace
  it with a real solver).
- `libs/nova-pack-integrity` — per-file SHA-256 recorded at install,
  re-checked on demand; the rollback store.
- `libs/nova-sign-ed25519` — Ed25519 for repository metadata, RFC 8032
  test vectors passing, pinned dependency.
- `libs/nova-pack-repo` — the signed repository index format.
- `tools/nova-pack` — the user-facing package manager: `install`,
  `list`, `remove [--force]`, `update`, `verify`, `rollback`, plus
  `sources`/`add-source`/`available`/`info`.

## What M11 deliberately did not attempt

- A public or networked package store. The Roadmap flags this
  explicitly as premature before Nova has real users; only the *format*
  a future store would serve is built and tested against a local
  directory.
- Per-package Ed25519 signatures. Named as the most important open item
  in `docs/package-format-v1.md`, owned by M15.
- A backtracking dependency solver. Nova's dependency resolver reports
  conflicts rather than searching around them; the trigger for
  replacing it (legitimate installs starting to fail) is written down
  rather than guessed at pre-emptively.
- Key revocation and index freshness guarantees (TUF-style timestamp/
  snapshot roles). Both named as open items with no owning milestone yet.

## Retrofit note

Building M11 required fixing six defects in code shipped in v0.53 that
had never been compiled. See `docs/M11-RETROFITS.md`. From this package
forward, every day's acceptance test is run before the day's package is
written, and release notes report what actually ran rather than asking
the reader to run it themselves.

## Next: M12

Per the Complete Build Guide's milestone table, M12 is next. Nothing in
M11 blocks it; the two items M11 leaves open for later milestones
(package-signature scheme, revocation/freshness) are recorded above so
they aren't lost between now and whichever day picks them up.
