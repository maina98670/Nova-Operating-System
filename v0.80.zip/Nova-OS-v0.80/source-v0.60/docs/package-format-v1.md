# Nova package & repository format — v1, open items

This file exists so open cryptographic and trust items are named in one
place rather than rediscovered by whoever hits them next.

## Two independent signature layers

| Layer | Scheme | Proves | Owner |
| --- | --- | --- | --- |
| Package (`.npkg`) | HMAC-SHA256 (M10 Day 43) | Integrity + possession of a shared secret | `nova-package-sign` |
| Repository index | Ed25519 (M11 Day 49) | Integrity + possession of a private key | `nova-sign-ed25519` |

They are independent on purpose. A repository's index key does not sign
packages; a package's HMAC key does not sign indexes. Merging them would
mean trusting a repository operator to author packages directly, which is
a larger grant of trust than "list packages I've checked."

## Open item: package signatures are still symmetric

M10 Day 43 states this and M11 does not close it: HMAC-SHA256 proves a
package came from *a* holder of the shared secret, not that it came from
a specific publisher a third party could check independently. Every
device that can verify a package signature holds the same key it would
need to forge one.

**What limits the exposure today:** the repository index is Ed25025-signed
and carries each package's SHA-256. A device that trusts a repository key
and checks the fetched bytes against the index-declared hash cannot be
handed a substituted package by anyone who does not also control the
index's private key. The remaining gap is intra-repository: whoever holds
the package HMAC secret can produce packages the *device* accepts,
independent of what the repository publishes.

**Proposed fix, not yet built:** move `.npkg` signing to Ed25519 (this
crate already exists), keep `nova-package-sign`'s HMAC path only as a
build-time development shortcut behind a flag that never ships enabled,
and give the package keystore the same one-key-per-purpose separation
already applied to repository keys. Owner: **M15** (Days ~73-75), because
it is a breaking change to every previously-signed `.npkg` and belongs
with the OTA/update work that already has to handle a key rotation story.

## Open item: no revocation

Neither keystore has a revocation mechanism. A compromised repository or
package key is trusted until a human removes it from
`etc/nova/keys/{trusted,repo-trusted}.tsv` by hand. No CRL, no
short-lived certificates, no OCSP-equivalent. For Nova's target devices
(occasionally-connected, low-RAM) a full PKI is likely overkill; a signed,
versioned key-revocation list distributed the same way the index is would
probably suffice. Not designed. Owner: unassigned — flag if a real
repository is stood up before this is designed.

## Open item: no transport-level freshness guarantee

The index format has no expiry. A device that has not fetched a fresh
index for months and is fed a stale-but-validly-signed old one (a replay
of an old, legitimately-signed index) would accept it. TUF-style
timestamp/snapshot roles solve this properly; Nova does not implement
them. For a locally-scanned or manually-synced repository this is a minor
risk; for a networked store it would need addressing before launch.
Owner: whichever milestone stands up network fetching (post-M11, not yet
scheduled).

## Open item: single-signer indexes only

`RepoIndex::publish` takes one signing key. No k-of-n or threshold
signing. Fine for a single build machine; would need revisiting before
multiple people can publish to the same repository independently.

## What does not need revisiting

- The package wire format itself (`NPKG` magic, manifest+binary,
  M6 Day 20) needs no change for any of the above — every fix here is at
  the signature layer, not the container layer.
- The flat `key: value` record format used by the installed-package
  database and the repository index. It has done its job (diffable,
  parseable without a library, byte-stable enough to sign) at the scale
  this project targets. Revisit only if a repository grows large enough
  that scanning the whole index becomes a real cost — no evidence of that
  yet.
