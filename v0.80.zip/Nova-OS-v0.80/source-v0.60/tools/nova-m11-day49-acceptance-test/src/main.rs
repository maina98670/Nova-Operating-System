//! Day 49 acceptance test — the literal Definition of Done:
//!
//! > A local test repository following the documented metadata format
//! > can be added as a source and packages installed from it via
//! > `nova-pack`. Tag M11.
//!
//! This is also the M11 milestone acceptance, so it re-runs the
//! milestone's load-bearing guarantees rather than only testing the
//! day's new code: a repository is useful exactly to the extent that
//! everything Days 46-48 built still holds when packages arrive
//! through it.
//!
//! The parts worth being strict about:
//!
//! - A signed index is **required** where an index exists. An
//!   unsigned, untrusted or altered index is fatal for that source; it
//!   does not quietly degrade into a directory scan, because an
//!   attacker who could force that degradation would have disabled
//!   index verification by breaking it.
//! - The index is a **hint about where to look**, never a source of
//!   truth about what arrived. A stale index whose hash no longer
//!   matches the file must stop the install.

use nova_pack::fixture::{RepoSigningKey, TestRoot};
use nova_pack::{PackError, PackManager, SourceKind};
use nova_pack_meta::{Version, VersionReq};
use nova_pack_repo::{RepoError, RepoIndex, INDEX_FILE, SIGNATURE_FILE};
use nova_sign_ed25519::{RepoKeyring, SignError};
use std::fs;
use std::path::Path;
use std::process::ExitCode;

struct Check {
    name: &'static str,
    passed: bool,
    detail: String,
}

fn check(name: &'static str, passed: bool, detail: impl Into<String>) -> Check {
    Check { name, passed, detail: detail.into() }
}

fn main() -> ExitCode {
    println!("=== Nova OS Day 49 acceptance: repository metadata format, M11 milestone ===\n");

    let root = match TestRoot::new("day49") {
        Ok(r) => r,
        Err(e) => {
            eprintln!("could not build the test root: {e}");
            return ExitCode::FAILURE;
        }
    };

    for (id, version, deps) in [
        ("org.nova.base", "0.3.4", vec![]),
        ("org.nova.textkit", "1.2.0", vec!["org.nova.base ^0.3.0"]),
        ("org.nova.editor", "1.0.0", vec!["org.nova.textkit >= 1.1.0"]),
        ("org.nova.editor", "1.1.0", vec!["org.nova.textkit >= 1.1.0"]),
    ] {
        if let Err(e) = root.publish(id, version, &deps, &["storage"]) {
            eprintln!("could not publish {id}: {e}");
            return ExitCode::FAILURE;
        }
    }

    let repo_key = match root.publish_index() {
        Ok(k) => k,
        Err(e) => {
            eprintln!("could not publish the index: {e}");
            return ExitCode::FAILURE;
        }
    };

    let mut m = match PackManager::open(root.layout()) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("could not open the package manager: {e}");
            return ExitCode::FAILURE;
        }
    };
    m.add_source(&root.repo).expect("add source");

    let mut checks: Vec<Check> = Vec::new();

    // --- 1. The documented format is on disk and parses. ---------------
    let index_path = root.repo.join(INDEX_FILE);
    let sig_path = root.repo.join(SIGNATURE_FILE);
    let index_text = fs::read_to_string(&index_path).unwrap_or_default();
    checks.push(check(
        "the repository has both an index and a detached signature",
        index_path.is_file() && sig_path.is_file(),
        format!("{} + {}", INDEX_FILE, SIGNATURE_FILE),
    ));
    checks.push(check(
        "the index declares its format version and one record per package version",
        index_text.starts_with("nova-repo-index: 1")
            && index_text.matches("[package]").count() == 4,
        format!(
            "header: {:?}; records: {}",
            index_text.lines().next().unwrap_or(""),
            index_text.matches("[package]").count()
        ),
    ));

    // --- 2. The source is read as a signed index, not scanned. ---------
    let catalog = m.catalog().expect("read catalog");
    let kind = catalog.kinds.first().map(|(_, k)| *k);
    checks.push(check(
        "the source is read through its verified index",
        kind == Some(SourceKind::SignedIndex),
        format!("source kind: {kind:?}; {} candidate(s)", catalog.candidates.len()),
    ));

    // --- 3. Installing from the indexed repository works, with deps. ---
    // Installed at 1.0.0 first and then updated to 1.1.0, deliberately
    // — a single fresh install at the newest version has no previous
    // version, and section 10 below needs one to roll back to. Testing
    // rollback against a package that was only ever installed once
    // would be testing the wrong thing.
    m.install("org.nova.editor", &VersionReq::parse("1.0.0").unwrap()).expect("install 1.0.0 first");
    let outcome = m.update("org.nova.editor").map(|o| o.expect("an update to 1.1.0 was available"));
    let chain_installed = ["org.nova.base", "org.nova.textkit", "org.nova.editor"]
        .iter()
        .all(|id| m.db().get(id).is_some());
    checks.push(check(
        "a package installs from the indexed repository, with its dependency chain",
        matches!(&outcome, Ok(o) if o.version == Version::new(1, 1, 0)) && chain_installed,
        match &outcome {
            Ok(o) => format!(
                "installed {} {}; chain: {:?}",
                o.id,
                o.version,
                m.installed().iter().map(|p| p.meta.id.clone()).collect::<Vec<_>>()
            ),
            Err(e) => format!("FAILED: {e}"),
        },
    ));
    checks.push(check(
        "what was installed from the index verifies against its recorded hashes",
        m.verify("org.nova.editor").map(|r| r.is_intact()).unwrap_or(false),
        format!("{}", m.verify("org.nova.editor").expect("verify")),
    ));

    // --- 4. An altered index is fatal, and does not fall back. ---------
    let good_index = fs::read(&index_path).expect("read index");
    let tampered = String::from_utf8_lossy(&good_index).replace("0.3.4", "0.3.5");
    fs::write(&index_path, tampered).expect("write tampered index");

    let after_tamper = m.catalog();
    checks.push(check(
        "an altered index is refused, and the source is NOT silently rescanned",
        matches!(&after_tamper, Err(PackError::Repo(RepoError::Signature(_)))),
        match &after_tamper {
            Err(e) => format!("refused: {e}"),
            Ok(c) => format!("ACCEPTED {} candidates from a tampered index", c.candidates.len()),
        },
    ));
    let install_after_tamper = m.install("org.nova.base", &VersionReq::Any);
    checks.push(check(
        "installing from a source with an altered index is refused",
        install_after_tamper.is_err(),
        match &install_after_tamper {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED FROM A TAMPERED INDEX".to_string(),
        },
    ));
    fs::write(&index_path, &good_index).expect("restore index");

    // --- 5. An index signed by an untrusted key is refused. ------------
    let impostor = RepoSigningKey::from_seed("not-our-repo", [0x99; 32]);
    root.reindex(&impostor).expect("republish with impostor key");
    let untrusted = m.catalog();
    checks.push(check(
        "an index signed by a key outside the repository keyring is refused",
        matches!(&untrusted, Err(PackError::Repo(RepoError::Signature(SignError::UntrustedKey(_))))),
        match &untrusted {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "ACCEPTED AN INDEX FROM AN UNKNOWN PUBLISHER".to_string(),
        },
    ));
    root.reindex(&repo_key).expect("republish with the real key");

    // --- 6. An index with no signature beside it is refused. -----------
    fs::remove_file(&sig_path).expect("remove signature");
    let unsigned = m.catalog();
    checks.push(check(
        "an unsigned index is refused rather than read anyway",
        matches!(&unsigned, Err(PackError::Repo(RepoError::Unsigned(_)))),
        match &unsigned {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "READ AN UNSIGNED INDEX".to_string(),
        },
    ));

    // --- 7. No index at all: scan, and say so. -------------------------
    fs::remove_file(&index_path).expect("remove index");
    let scanned = m.catalog();
    checks.push(check(
        "a directory with no index is scanned, and reported as scanned",
        matches!(&scanned, Ok(c) if c.kinds.iter().all(|(_, k)| *k == SourceKind::Scanned) && !c.candidates.is_empty()),
        match &scanned {
            Ok(c) => format!("{} candidate(s), kinds: {:?}", c.candidates.len(), c.kinds.iter().map(|(_, k)| *k).collect::<Vec<_>>()),
            Err(e) => format!("FAILED: {e}"),
        },
    ));
    root.reindex(&repo_key).expect("republish index");

    // --- 8. The index is a hint, not the truth about what arrived. -----
    // Publish a new version, index it, then change the file on disk
    // without re-indexing: a stale index whose hash no longer matches.
    root.publish("org.nova.base", "0.4.0", &[], &["storage"]).expect("publish 0.4.0");
    root.reindex(&repo_key).expect("reindex");
    let stale_target = root.repo.join("org.nova.base-0.4.0.npkg");
    let mut bytes = fs::read(&stale_target).expect("read published package");
    bytes[30] ^= 0x01;
    fs::write(&stale_target, &bytes).expect("alter the published file");

    let stale = m.install("org.nova.base", &VersionReq::parse("0.4.0").unwrap());
    checks.push(check(
        "a file that no longer matches the hash in the index stops the install",
        matches!(&stale, Err(PackError::ChecksumMismatch { .. })),
        match &stale {
            Err(e) => format!("refused: {e}"),
            Ok(_) => "INSTALLED BYTES THE INDEX DID NOT DESCRIBE".to_string(),
        },
    ));

    // --- 9. The index round-trips through the documented format. -------
    let reparsed = RepoIndex::load_verified(&root.repo, &RepoKeyring::load(&root.layout().repo_keyring_path()).unwrap());
    checks.push(check(
        "the published index parses back into the same records it was built from",
        matches!(&reparsed, Ok(idx) if idx.versions_of("org.nova.editor").len() == 2),
        match &reparsed {
            Ok(idx) => format!("{} entries; org.nova.editor versions: {}", idx.entries.len(), idx.versions_of("org.nova.editor").len()),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    // --- 10. M11 milestone: the earlier days still hold. ---------------
    // Repair the deliberately-altered file so this section tests the
    // milestone rather than the mess the previous check made.
    bytes[30] ^= 0x01;
    fs::write(&stale_target, &bytes).expect("repair");
    root.reindex(&repo_key).expect("reindex");

    let unsigned_pkg = nova_pack::fixture::package("org.nova.sneaky", "1.0.0", &[], &[]);
    checks.push(check(
        "M10 still holds through the repository path: unsigned package refused",
        matches!(m.install_bytes(&unsigned_pkg, "day49-unsigned"), Err(PackError::Verify(_))),
        "a signed index does not make its packages trusted — each is still verified".to_string(),
    ));

    // Give editor a previous version to roll back to: this test's
    // earlier installs only ever put 1.1.0 on the device.
    m.install("org.nova.editor", &VersionReq::parse("1.0.0").unwrap()).expect("pin 1.0.0");
    m.update("org.nova.editor").expect("update").expect("1.1.0 should be newer");

    let rolled = m.rollback("org.nova.editor");
    checks.push(check(
        "M11 Day 48 still holds: a package installed from the repository can be rolled back",
        matches!(&rolled, Ok(o) if o.version == Version::new(1, 0, 0)),
        match &rolled {
            Ok(o) => format!("rolled back to {}", o.version),
            Err(e) => format!("FAILED: {e}"),
        },
    ));

    let would_break = m.remove("org.nova.textkit");
    checks.push(check(
        "M11 Day 47 still holds: a removal that would break a dependent is refused",
        would_break.is_err(),
        match &would_break {
            Err(e) => format!("refused: {e}"),
            Ok(()) => "BROKE THE EDITOR".to_string(),
        },
    ));

    report_all(checks, &root, &index_path)
}

fn report_all(checks: Vec<Check>, root: &TestRoot, index_path: &Path) -> ExitCode {
    println!("Checks:");
    let mut failed = 0;
    for c in &checks {
        println!("  [{}] {}", if c.passed { "PASS" } else { "FAIL" }, c.name);
        println!("         {}", c.detail);
        if !c.passed {
            failed += 1;
        }
    }
    println!();
    if failed == 0 {
        println!("Day 49 acceptance: PASS ({} checks)", checks.len());
        println!();
        println!("M11 — Package Ecosystem — is complete:");
        println!("  Day 46  nova-pack install/list/remove/update against a local repository");
        println!("  Day 47  dependency resolution; M5 permissions and M10 signatures enforced here too");
        println!("  Day 48  post-install integrity checking and rollback");
        println!("  Day 49  a documented, signed repository metadata format");
        println!();
        println!("Index format lives at {}. Tag with:", index_path.display());
        println!("  git tag -a v0.60 -m \"M11: Package Ecosystem\"   (see docs/M11-TAG.md)");
        root.cleanup();
        ExitCode::SUCCESS
    } else {
        println!("Day 49 acceptance: FAIL ({failed} of {} checks failed)", checks.len());
        println!("Test root left in place for inspection: {}", root.dir.display());
        ExitCode::FAILURE
    }
}
