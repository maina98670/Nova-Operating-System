"""APK staging and Android runtime boundaries; no actual Android container required."""
from __future__ import annotations
import base64
import hashlib
import io
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integration'))
from android_compat import AndroidBridge, inspect_apk
from platform_readiness import report


def apk_bytes():
    buf=io.BytesIO()
    with ZipFile(buf,'w') as z:
        z.writestr('AndroidManifest.xml',b'non-empty-manifest')
        z.writestr('classes.dex',b'dex\n035\x00' + bytes(50))
        z.writestr('lib/arm64-v8a/libdemo.so',b'\x7fELF' + bytes(30))
    return buf.getvalue()

class AndroidTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.bridge=AndroidBridge(Path(self.tmp.name),enabled=False)

    def test_inspection_and_staging(self):
        blob=apk_bytes()
        record=self.bridge.begin('demo.apk',len(blob),hashlib.sha256(blob).hexdigest())
        ident=record['id']
        self.bridge.append(ident,0,base64.b64encode(blob[:50]).decode())
        self.bridge.append(ident,50,base64.b64encode(blob[50:]).decode())
        info=self.bridge.finish(ident)
        self.assertTrue(info['ready'])
        self.assertIn('arm64-v8a',info['inspection']['native_abis'])
        self.assertFalse(info['inspection']['signature_verified'])
        self.assertEqual(len(self.bridge.list_staged()),1)
        self.assertEqual(self.bridge.finish(ident)['id'],ident)

    def test_reject_unknown_file_and_wrong_offset(self):
        blob=apk_bytes(); ident=self.bridge.begin('demo.apk',len(blob),hashlib.sha256(blob).hexdigest())['id']
        with self.assertRaises(ValueError):self.bridge.append(ident,1,base64.b64encode(blob).decode())
        with self.assertRaises(ValueError):self.bridge.append('..',0,'AAAA')
        with self.assertRaises(ValueError):self.bridge.append(ident,0,'invalid_')
        with self.assertRaises(ValueError):self.bridge.finish(ident)

    def test_checksum_mismatch_blocks_finalization(self):
        blob=apk_bytes();ident=self.bridge.begin('demo.apk',len(blob),'0'*64)['id']
        self.bridge.append(ident,0,base64.b64encode(blob).decode())
        with self.assertRaisesRegex(ValueError,'checksum'):
            self.bridge.finish(ident)

    def test_missing_manifest_rejected(self):
        f=Path(self.tmp.name)/'bad.apk'
        with ZipFile(f,'w') as z:z.writestr('classes.dex',b'dex\n035\x00')
        with self.assertRaisesRegex(ValueError,'Manifest'):inspect_apk(f)

    def test_zip_member_traversal_rejected(self):
        f=Path(self.tmp.name)/'bad.apk'
        with ZipFile(f,'w') as z:
            z.writestr('AndroidManifest.xml','abc');z.writestr('classes.dex','abc');z.writestr('../bad','data')
        with self.assertRaisesRegex(ValueError,'Unsafe'):inspect_apk(f)

    def test_no_runtime_install_without_optin(self):
        with self.assertRaises(PermissionError):self.bridge.install('a'*32)
        with self.assertRaises(PermissionError):self.bridge.launch('com.demo.app')
        with self.assertRaises(PermissionError):self.bridge.remove('com.demo.app')

    def test_bad_names_rejected(self):
        for name in ('../../evil.apk','test.zip','a/evil.apk','x'*200+'.apk'):
            with self.assertRaises(ValueError):self.bridge.begin(name,123,'1'*64)
        with self.assertRaises(ValueError):self.bridge.begin('test.apk',1000,'abc')

    def test_status_does_not_claim_android_running(self):
        state=self.bridge.status()
        self.assertFalse(state['execution_available'])
        self.assertFalse(state['enabled'])
        self.assertIn('missing',state)

    def test_readiness_has_fourteen_areas(self):
        r=report(self.bridge.status(),bridge=False,smoke=False)
        self.assertEqual(len(r['areas']),14)
        self.assertFalse(r['arm64_boot_verified'])
        self.assertIn('APK',r['areas'][12]['name'])

if __name__=='__main__':unittest.main()
