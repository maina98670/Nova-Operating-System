import importlib.util, json, pathlib, subprocess, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]

class RuntimeIntegrationTests(unittest.TestCase):
    def test_all_original_source_and_milestones_retained(self):
        data=json.loads((ROOT/'integration'/'registry.json').read_text())
        self.assertEqual(data['workspace_count'],104)
        self.assertEqual(data['counts'],{'libs':48,'apps':12,'tools':44})
        self.assertEqual(len(data['history']),9)
        self.assertEqual(data['boot_prototypes'],['m0','m1','m2','m3'])
        for c in data['components']:
            self.assertTrue((ROOT/'source-v0.60'/c['directory']/'Cargo.toml').is_file())

    def test_runtime_catalog_detects_staged_binary_without_claiming_running(self):
        spec=importlib.util.spec_from_file_location('catalog',ROOT/'integration'/'runtime.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as d:
            initial=module.snapshot(d)
            self.assertEqual(initial['counts']['source_present'],104)
            self.assertEqual(initial['counts']['binary_installed'],0)
            pathlib.Path(d,'nova-settings').write_bytes(b'ELF placeholder for catalog unit test')
            updated=module.snapshot(d)
            self.assertEqual(updated['counts']['binary_installed'],1)
            settings=next(c for c in updated['components'] if c['name']=='nova-settings')
            self.assertEqual(settings['status'],'installed_binary_not_proven_running')

    def test_native_daemon_uses_real_original_crates(self):
        manifest=(ROOT/'native-runtime'/'Cargo.toml').read_text()
        for required in ('nova-app-manager','nova-compositor-core','nova-ipc','nova-fsmgr'):
            self.assertIn(required,manifest)
        code=(ROOT/'native-runtime/src/main.rs').read_text()
        self.assertIn('apps.serve(nova_ipc::SOCKET_PATH)',code)
        self.assertIn('compositor.serve(nova_compositor_core::protocol::SOCKET_PATH)',code)
        self.assertIn('does NOT render',code)

    def test_guest_installs_original_archives_and_runtime(self):
        script=(ROOT/'vm/build-arm64-qemu.sh').read_text()
        for required in ('/opt/nova/history','/opt/nova/boot','/opt/nova/integration',
                         'nova-catalog.service','nova-runtime.service','NOVA_REQUIRE_ORIGINAL_RUNTIME',
                         'NOVA_REQUIRE_ALL_BINARIES','systemctl enable nova-runtime.service'):
            self.assertIn(required,script)

    def test_build_scripts_syntax(self):
        files=[ROOT/p for p in ('vm/build-arm64-qemu.sh','vm/run-arm64-qemu.sh',
            'scripts/build-original-arm64.sh','scripts/build-native-runtime-arm64.sh',
            'scripts/build-aarch64-bridge.sh')]
        p=subprocess.run(['bash','-n',*[str(f) for f in files]],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)

if __name__=='__main__':unittest.main()
