"""Connectivity and device safety, API and modern GUI wiring tests."""
import ast
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from integration.connectivity import Connectivity, split_nmcli
from integration.device_preferences import configure_pin, verify_pin, validate_preferences, PinGuard, DEFAULT_DEVICE

class Result:
    def __init__(self,stdout='',returncode=0,stderr=''):
        self.stdout=stdout;self.returncode=returncode;self.stderr=stderr

class ConnectivityUnit(unittest.TestCase):
    def setUp(self):
        self.calls=[]
        self.mapping={
            ('nmcli','-t','-f','DEVICE,TYPE,STATE,CONNECTION','device','status'):'wlan0:wifi:connected:My WiFi\neth0:ethernet:connected:Wired',
            ('nmcli','radio','wifi'):'enabled',
            ('bluetoothctl','show'):'Controller 11:22:33:44:55:66\n\tPowered: yes',
            ('bluetoothctl','devices'):'Device AA:BB:CC:DD:EE:FF Headphones',
        }
    def fake_run(self,args,**kw):
        self.calls.append(args)
        if tuple(args) in self.mapping:return Result(self.mapping[tuple(args)])
        return Result()
    def make(self,authorized=False, colab=False):
        env={'NOVA_ENABLE_RADIO_CONTROL':'1'} if authorized else {}
        if colab:env['NOVA_COLAB_MODE']='1'
        return Connectivity(self.fake_run,lambda p:'/usr/bin/'+p,env)
    def test_parser_handles_escaped_colons(self):
        self.assertEqual(split_nmcli('wlan0:wifi:connected:Lab\\: Floor'),['wlan0','wifi','connected','Lab: Floor'])
    def test_observes_real_adapters_without_pretending(self):
        c=self.make(); s=c.status()
        self.assertTrue(s['wifi']['connected']);self.assertEqual(s['wifi']['network'],'My WiFi')
        self.assertEqual(s['bluetooth']['devices'][0]['name'],'Headphones')
        self.assertFalse(s['wifi']['can_control']);self.assertFalse(s['bluetooth']['can_control'])
    def test_no_tool_displays_unavailable(self):
        c=Connectivity(self.fake_run,lambda p:None,{})
        s=c.status()
        self.assertFalse(s['wifi']['available']);self.assertFalse(s['bluetooth']['available'])
    def test_mutation_disabled_by_default(self):
        c=self.make()
        with self.assertRaisesRegex(ValueError,'Radio control disabled'):c.operate('wifi','enable',{})
        self.assertNotIn(['nmcli','radio','wifi','on'],self.calls)
    def test_colab_blocks_host_mutations_even_if_enabled(self):
        c=self.make(True,True)
        with self.assertRaisesRegex(ValueError,'Radio control disabled'):c.operate('bluetooth','enable',{})
    def test_enable_host_guest_explicitly(self):
        c=self.make(True)
        r=c.operate('wifi','enable',{})
        self.assertTrue(r['ok']);self.assertIn(['nmcli','radio','wifi','on'],self.calls)
    def test_reject_bluetooth_injection(self):
        c=self.make(True)
        with self.assertRaisesRegex(ValueError,'Invalid Bluetooth'):c.operate('bluetooth','pair',{'address':'00:11; rm -rf /'})
    def test_reject_invalid_wifi_ssid(self):
        c=self.make(True)
        with self.assertRaisesRegex(ValueError,'Invalid network'):c.operate('wifi','connect',{'ssid':''})
    def test_reject_unknown_actions(self):
        with self.assertRaises(ValueError):self.make(True).operate('wifi','shell',{'cmd':'id'})

class PreferenceUnit(unittest.TestCase):
    def test_preferences_validate_and_persist_contract(self):
        v=validate_preferences({'brightness_preference':26,'volume_preference':50},DEFAULT_DEVICE)
        self.assertEqual(v['brightness_preference'],26)
        for changes in ({'brightness_preference':101},{'reduce_motion':'false'},{'screen_timeout_minutes':7},{'unknown':123}):
            with self.assertRaises(ValueError):validate_preferences(changes,DEFAULT_DEVICE)
    def test_hash_pin_and_reject_wrong(self):
        credential=configure_pin('8317')
        self.assertEqual(set(credential), {'salt','digest','scheme'})
        self.assertNotEqual(credential['digest'], '8317')
        self.assertTrue(verify_pin('8317',credential));self.assertFalse(verify_pin('0000',credential))
    def test_reject_weak_pin_types(self):
        for pin in (1234,'12','abc1','1234567890123'):
            with self.assertRaises(ValueError):configure_pin(pin)
    def test_lockout_after_failed_attempts(self):
        guard=PinGuard();c=configure_pin('1234')
        for i in range(5):self.assertFalse(guard.check('wrong',c))
        with self.assertRaisesRegex(ValueError,'Too many attempts'):guard.check('1234',c)

class ApiIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        cls.base='http://127.0.0.1:'+str(port)
        env={**os.environ,'NOVA_CONFIG_DIR':cls.tmp.name+'/prefs','NOVA_FILES_ROOT':cls.tmp.name+'/files',
             'NOVA_COLAB_MODE':'1','NOVA_ENABLE_RADIO_CONTROL':'1'}
        cls.process=subprocess.Popen([sys.executable,str(ROOT/'graphics-shell/server.py'),'--port',str(port),'--no-browser'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(80):
            try:
                page=urllib.request.urlopen(cls.base,timeout=1).read().decode()
                cls.token=re.search('name="nova-token" content="([^"]+)"',page).group(1)
                return
            except Exception:time.sleep(.1)
        raise RuntimeError('Server failed startup')
    @classmethod
    def tearDownClass(cls):
        cls.process.terminate();cls.process.wait(timeout=5);cls.tmp.cleanup()
    def req(self,path,payload=None,token=None):
        headers={};data=None
        if payload is not None:
            headers={'X-Nova-Token':self.token if token is None else token,'Content-Type':'application/json'}
            data=json.dumps(payload).encode()
        with urllib.request.urlopen(urllib.request.Request(self.base+path,data=data,headers=headers),timeout=10) as r:
            return json.load(r)
    def test_endpoints_do_not_claim_hardware_controls(self):
        c=self.req('/api/connectivity');self.assertIn('wifi',c);self.assertIn('bluetooth',c)
        self.assertFalse(c['host_control_opt_in'])
        d=self.req('/api/device');self.assertFalse(d['controls_are_hardware_backed'])
    def test_device_preferences_saved(self):
        d=self.req('/api/device/preferences',{'brightness_preference':19,'volume_preference':35})
        self.assertEqual(d['brightness_preference'],19)
        self.assertEqual(self.req('/api/device')['preferences']['volume_preference'],35)
    def test_radio_operation_rejected_in_colab(self):
        with self.assertRaises(urllib.error.HTTPError) as c:
            self.req('/api/connectivity/wifi/enable',{})
        self.assertEqual(c.exception.code,400)
    def test_settings_required_authorization(self):
        with self.assertRaises(urllib.error.HTTPError) as c:
            self.req('/api/device/preferences',{'volume_preference':75},token='no')
        self.assertEqual(c.exception.code,403)
    def test_pin_created_and_rate_limited(self):
        self.assertFalse(self.req('/api/lock/status')['pin_configured'])
        self.req('/api/lock/setup',{'pin':'8642'})
        self.assertTrue(self.req('/api/lock/status')['pin_configured'])
        with self.assertRaises(urllib.error.HTTPError):self.req('/api/lock/verify',{'pin':'wrong'})
        self.assertTrue(self.req('/api/lock/verify',{'pin':'8642'})['unlocked'])
        self.assertFalse('8642' in (Path(self.tmp.name)/'prefs/lock.json').read_text())

class BackupV075(unittest.TestCase):
    def test_device_preferences_included_and_pin_excluded(self):
        from integration.platform_services import make_backup, restore_backup
        from zipfile import ZipFile
        with tempfile.TemporaryDirectory() as tmp:
            config=Path(tmp)/'config';config.mkdir()
            files=Path(tmp)/'files';files.mkdir()
            (config/'device-preferences.json').write_text('{"brightness_preference": 40}')
            (config/'lock.json').write_text('{"digest":"secret"}')
            archive=make_backup(config,files)
            with ZipFile(config/'backups'/archive['name']) as z:
                self.assertIn('config/device-preferences.json',z.namelist())
                self.assertNotIn('config/lock.json',z.namelist())
            result=restore_backup(config,files,archive['name'])
            self.assertTrue(Path(result['recovered_to']).joinpath('config/device-preferences.json').is_file())

class StaticSourceTests(unittest.TestCase):
    def test_qt_pages_and_multitasking(self):
        src=(ROOT/'native-shell/nova_shell.py').read_text()
        ast.parse(src)
        for page in ['wifi','bluetooth','device','lock','quick','home','recents']:
            self.assertIn('def page_'+page+'(',src)
        self.assertIn('QLocalServer',src);self.assertIn('def focus_app(',src)
    def test_colab_web_pages_and_version(self):
        js=(ROOT/'graphics-shell/static/app.js').read_text()
        for fn in ['renderWifi','renderBluetooth','renderDevice','renderLock','renderNotifications','renderRecents']:
            self.assertIn('function '+fn+'(',js)
        self.assertIn('v0.75',(ROOT/'graphics-shell/static/index.html').read_text())
