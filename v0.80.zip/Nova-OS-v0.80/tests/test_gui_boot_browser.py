"""Chromium integration test of the Nova login -> real launcher DOM.

Not a proof of VM pixels. Run independently via python3 -m unittest
or alongside source tests when system Chromium + Playwright are installed.
"""
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request

ROOT=Path(__file__).resolve().parents[1]

@unittest.skipUnless(os.environ.get('NOVA_RUN_BROWSER_E2E') == '1',
                     'Set NOVA_RUN_BROWSER_E2E=1 (requires Playwright and Chromium)')
class BrowserGuiBootTests(unittest.TestCase):
    def test_boot_login_home_and_app(self):
        from playwright.sync_api import sync_playwright
        with tempfile.TemporaryDirectory(prefix='nova-boot-gui-') as temp:
            base=Path(temp)
            with socket.socket() as sock:
                sock.bind(('127.0.0.1',0))
                port=sock.getsockname()[1]
            env={**os.environ,'NOVA_CONFIG_DIR':str(base/'config'),
                 'NOVA_FILES_ROOT':str(base/'files'),'NOVA_ENFORCE_AUTH':'1'}
            server=subprocess.Popen([sys.executable,str(ROOT/'graphics-shell/server.py'),
                '--no-browser','--port',str(port)],cwd=ROOT,env=env,
                stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            try:
                for attempt in range(80):
                    try:
                        urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=.3)
                        break
                    except Exception:time.sleep(.1)
                else:self.fail('Nova HTTP backend did not start')
                with sync_playwright() as pw:
                    browser=pw.chromium.launch(headless=True,
                        executable_path=os.environ.get('NOVA_CHROMIUM','/usr/bin/chromium'),
                        args=['--no-sandbox','--disable-dev-shm-usage'])
                    page=browser.new_page(viewport={'width':410,'height':850})
                    page.goto(f'http://127.0.0.1:{port}/',wait_until='load')
                    page.wait_for_function("window.__NOVA_UI_STATE__?.phase==='login'",timeout=15000)
                    self.assertTrue(page.locator('#auth-overlay').is_visible())
                    self.assertGreaterEqual(page.locator('#home-apps .app-item').count(),8)
                    page.locator('#auth-name').fill('Nova Tester')
                    page.locator('#auth-password').fill('test-password-ABC123')
                    page.locator('#auth-submit').click()
                    page.wait_for_function("window.__NOVA_UI_STATE__?.phase==='home'",timeout=15000)
                    self.assertFalse(page.locator('#auth-overlay').is_visible())
                    self.assertGreaterEqual(page.locator('#home-apps .app-item').count(),8)
                    self.assertTrue(page.locator('#home').is_visible())
                    page.locator('[data-go="android"]').first.click()
                    page.locator('#app-title').wait_for(timeout=5000)
                    self.assertIn('Android',page.locator('#app-title').inner_text())
                    page.screenshot(path=str(base/'nova-boot-home-test.png'))
                    browser.close()
            finally:
                server.terminate()
                try:server.communicate(timeout=6)
                except subprocess.TimeoutExpired:server.kill();server.wait(timeout=2)

if __name__=='__main__': unittest.main()
