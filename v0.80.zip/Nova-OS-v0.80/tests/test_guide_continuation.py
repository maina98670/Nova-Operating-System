"""Regression checks for guide alignment and stale boot acceptance evidence."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from integration.boot_evidence import REQUIRED, artifact_fingerprint, source_fingerprint, validate_boot


class BootEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        boot = self.root / 'vm/out/rootfs/boot'
        boot.mkdir(parents=True)
        (boot / 'vmlinuz-6.1').write_bytes(b'kernel')
        (boot / 'initrd.img-6.1').write_bytes(b'initramfs')
        (self.root / 'vm/out/nova-arm64.ext4').write_bytes(b'disk')
        (self.root / 'integration').mkdir()
        (self.root / 'integration/runtime.py').write_text('first revision')
        self.report = {**dict.fromkeys(REQUIRED, True), 'release': '0.80',
                       'evidence_schema': 2, 'vm_ram_mb': 1024,
                       'gui_phase': 'login', 'observed_at_unix': int(time.time()),
                       'source_sha256': source_fingerprint(self.root),
                       'artifacts': artifact_fingerprint(self.root)}

    def test_current_observed_boot_evidence_is_accepted(self):
        self.assertEqual(validate_boot(self.root, self.report), [])

    def test_changed_source_invalidates_old_boot(self):
        (self.root / 'integration/runtime.py').write_text('second revision')
        self.assertIn('Source changed since the boot test', validate_boot(self.root, self.report))

    def test_replaced_disk_invalidates_old_boot_even_same_length(self):
        (self.root / 'vm/out/nova-arm64.ext4').write_bytes(b'evil')
        self.assertIn('VM artifacts changed since the boot test', validate_boot(self.root, self.report))

    def test_event_loop_without_launcher_dom_cannot_pass(self):
        self.report['gui_dom_verified'] = False
        self.assertIn('gui_dom_verified was not verified', validate_boot(self.root, self.report))

    def test_strings_are_not_boolean_evidence(self):
        self.report['smoke_passed'] = 'false'
        self.assertIn('smoke_passed was not verified', validate_boot(self.root, self.report))

    def test_two_gigabyte_pass_does_not_satisfy_one_gigabyte_guide(self):
        self.report['vm_ram_mb'] = 2048
        self.assertTrue(any('1024' in e for e in validate_boot(self.root, self.report)))

    def test_m2_cannot_be_claimed_without_serial_observation(self):
        self.report['m2_requested'] = True
        self.assertIn('Requested M2 handoff was not observed', validate_boot(self.root, self.report))

    def test_broken_report_fails_closed(self):
        self.assertTrue(validate_boot(self.root, []))
        self.assertTrue(validate_boot(self.root, {}))

    def test_missing_password_replaces_a_previous_pass(self):
        dest = self.root / 'old-result.json'
        dest.write_text(json.dumps({'smoke_passed': True}))
        env = {**os.environ}
        env.pop('NOVA_SMOKE_PASSWORD', None)
        run = subprocess.run([sys.executable, str(ROOT/'vm/smoke-arm64-qemu.py'),
                              '--result', str(dest)], env=env, capture_output=True, text=True)
        self.assertNotEqual(run.returncode, 0)
        report = json.loads(dest.read_text())
        self.assertIs(report['smoke_passed'], False)
        self.assertIn('NOVA_SMOKE_PASSWORD', report['error'])

    def test_runner_defaults_to_one_gigabyte_without_starting_qemu(self):
        # Execute the real shell runner against tiny inert files and an argv-only
        # stand-in: this verifies argument construction, not a simulated boot PASS.
        vm = self.root/'vm'
        (vm/'run.sh').write_text((ROOT/'vm/run-arm64-qemu.sh').read_text())
        fake_bin = self.root/'bin'
        fake_bin.mkdir()
        fake = fake_bin/'qemu-system-aarch64'
        fake.write_text('#!/usr/bin/env python3\nimport json,sys\nprint(json.dumps(sys.argv[1:]))\n')
        fake.chmod(0o755)
        env = {**os.environ, 'PATH': str(fake_bin)+os.pathsep+os.environ.get('PATH','')}
        env.pop('NOVA_VM_RAM_MB', None)
        env['NOVA_ENABLE_M2_INIT'] = '0'
        run = subprocess.run(['bash', str(vm/'run.sh'), '--headless'], env=env,
                             capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        argv = json.loads(run.stdout.splitlines()[-1])
        self.assertEqual(argv[argv.index('-m')+1], '1024')


class GuideVersionTests(unittest.TestCase):
    def test_build_entrypoints_are_executable(self):
        for name in ('scripts/build-all-arm64.sh', 'scripts/check-v077.sh',
                     'vm/build-arm64-qemu.sh', 'vm/run-arm64-qemu.sh'):
            self.assertTrue(os.access(ROOT/name, os.X_OK), name)

    def test_versions_match_the_supplied_guide(self):
        guide=json.loads((ROOT/'docs/guide-milestones.json').read_text())
        self.assertEqual([m['version'] for m in guide['milestones']],
                         ['0.07','0.13','0.20','0.27','0.33','0.40','0.47','0.53',
                          '0.60','0.67','0.73','0.80','0.87','0.93','1.00'])
        self.assertEqual(guide['current_integration_version'], '0.80')
        self.assertEqual(guide['next_named_milestone'], '0.87')

    def test_next_milestone_is_blocked_without_phone_acceptance(self):
        run=subprocess.run([sys.executable,str(ROOT/'scripts/guide-status.py'),
                            '--require-next-milestone'], capture_output=True,text=True)
        self.assertEqual(run.returncode,2,run.stderr)
        self.assertFalse(json.loads(run.stdout)['can_advance'])


if __name__ == '__main__':
    unittest.main()
