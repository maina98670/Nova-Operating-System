"""M0–M3 source/guest-staging integration tests (not QEMU runtime claims)."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('nova_milestones',ROOT/'scripts/stage-m0-m3.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class MilestoneBootIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.base=Path(self.t.name)
        self.guest=self.base/'guest';self.guest.mkdir()
        self.out=self.base/'out';self.out.mkdir()
        # Provided original M2 binary is a valid ARM64 ELF, copied for staged artifacts.
        splash=ROOT/'boot/legacy/m2/nova-splash'
        self.assertTrue(mod.is_arm64_elf(splash))
        shutil.copyfile(splash,self.out/'nova-splash')
    def test_m0_m3_original_files_preserved(self):
        for n in ('m0','m1','m2','m3'):
            self.assertTrue((ROOT/'boot/legacy'/n).is_dir())
    def test_m0_source_kernel_config_present(self):
        self.assertTrue((ROOT/'boot/legacy/m0/kernel.config').is_file())
        self.assertTrue((ROOT/'vm/build-arm64-qemu.sh').is_file())
    def test_m1_splash_stages_and_reports_truthfully(self):
        m=mod.stage(self.guest,self.out)
        self.assertTrue(m['m1']);self.assertFalse(m['m2_early_init'])
        self.assertFalse(m['m3_binary_staged']);self.assertFalse(m['arm64_graphical_boot_verified'])
        self.assertTrue((self.guest/'splash.raw').is_file())
        self.assertTrue((self.guest/'opt/nova/bin/nova-splash').is_file())
    def test_m2_missing_require_flag_rejects(self):
        with self.assertRaises(FileNotFoundError): mod.stage(self.guest,self.out,require_m2=True)
    def test_m2_stages_only_arch_checked_binary(self):
        # Emulates ARM64 ELF header for staging ONLY; this is NOT a compiled init.
        h=bytearray(64);h[:4]=b'\x7fELF';h[4:6]=b'\x02\x01';h[18:20]=(183).to_bytes(2,'little')
        (self.out/'nova-early-init').write_bytes(h)
        m=mod.stage(self.guest,self.out,require_m2=True)
        self.assertTrue(m['m2_early_init']);self.assertFalse(m['m2_pid1_active'])
    def test_rejects_non_arm64_boot_binary(self):
        (self.out/'nova-early-init').write_text('hello')
        with self.assertRaises(ValueError):mod.stage(self.guest,self.out)
    def test_m3_not_selected_without_binary(self):
        with self.assertRaises(ValueError):mod.stage(self.guest,self.out,backend='nova')
    def test_default_weston_not_labeled_nova(self):
        m=mod.stage(self.guest,self.out)
        self.assertEqual(m['m3_selected_backend'],'weston')
        self.assertFalse(m['m3_runtime_verified'])
        self.assertIn('NOVA_COMPOSITOR=weston',(self.guest/'etc/nova/boot.conf').read_text())
    def test_prevent_staging_over_root_filesystem(self):
        with self.assertRaises(ValueError):mod.stage(Path('/'),self.out)
    def test_copy_attempt_does_not_write_outside_guest(self):
        trap=self.base/'elsewhere';trap.mkdir()
        (self.guest/'etc').symlink_to(trap,target_is_directory=True)
        with self.assertRaises(ValueError):mod.stage(self.guest,self.out)
        self.assertEqual(list(trap.iterdir()),[])
    def test_actual_qemu_not_claimed(self):
        m=mod.stage(self.guest,self.out)
        self.assertFalse(m['arm64_graphical_boot_verified'])
    def test_new_shell_scripts_syntactically_valid(self):
        for p in ('scripts/build-m0-m3-arm64.sh','scripts/build-m3-arm64-guest.sh',
                  'vm/guest/nova-compositor-run','vm/guest/nova-desktop-session',
                  'vm/run-arm64-qemu.sh','vm/build-arm64-qemu.sh'):
            with self.subTest(p=p):
                result=subprocess.run(['bash','-n',str(ROOT/p)],capture_output=True,text=True)
                self.assertEqual(result.returncode,0,result.stderr)
if __name__=='__main__':unittest.main()
