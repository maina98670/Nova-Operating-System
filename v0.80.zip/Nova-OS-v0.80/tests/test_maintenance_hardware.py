"""Physical test evidence must identify one device and one boot session."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from maintenance.common import digest
from maintenance.hardware import COMPONENTS,validate_evidence


class HardwareEvidenceTests(unittest.TestCase):
    def fixture(self,folder):
        evidence=folder/'physical-test.txt';evidence.write_text('operator recorded measurement fixture')
        report={'schema':1,'device_id':'fixture-device','boot_id':'same-boot',
                'components':{name:{'status':'passed','device_id':'fixture-device','boot_id':'same-boot',
                    'measurement':{'result':'fixture'},'evidence_file':evidence.name,'sha256':digest(evidence)}
                    for name in COMPONENTS},
                'simultaneous_usage':{'status':'passed','boot_id':'same-boot',
                    'active_components':['camera','audio','wifi','touch'],'duration_seconds':60}}
        path=folder/'report.json';path.write_text(json.dumps(report))
        return report,path

    def test_complete_operator_evidence_schema_can_be_validated(self):
        with tempfile.TemporaryDirectory() as tmp:
            _,path=self.fixture(Path(tmp))
            self.assertTrue(validate_evidence(path,integration=True)['accepted'])

    def test_mixed_boot_sessions_cannot_pass_hardware_integration(self):
        with tempfile.TemporaryDirectory() as tmp:
            report,path=self.fixture(Path(tmp));report['components']['camera']['boot_id']='another-boot'
            path.write_text(json.dumps(report))
            self.assertFalse(validate_evidence(path,integration=True)['accepted'])

    def test_changed_evidence_file_invalidates_physical_test_record(self):
        with tempfile.TemporaryDirectory() as tmp:
            _,path=self.fixture(Path(tmp));(Path(tmp)/'physical-test.txt').write_text('changed')
            self.assertFalse(validate_evidence(path)['accepted'])

    def test_sequential_tests_are_not_a_simultaneous_usage_test(self):
        with tempfile.TemporaryDirectory() as tmp:
            report,path=self.fixture(Path(tmp));report.pop('simultaneous_usage')
            path.write_text(json.dumps(report))
            self.assertFalse(validate_evidence(path,integration=True)['accepted'])


if __name__=='__main__':unittest.main()
