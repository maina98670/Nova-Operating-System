"""Nova v0.74 application storage/reminders and build-time integration checks."""
import ast
import datetime as dt
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'native-shell'))
from mobile_store import AppData, NAMESPACES
sys.path.insert(0,str(ROOT))
from integration.reminder_service import send_due

class NativeAppDataTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)/'subdir/nova.sqlite3'
        self.data=AppData(self.path)
    def tearDown(self):self.data.close();self.temp.cleanup()

    def test_namespace_contract_eight_apps(self):
        self.assertTrue({'browser.bookmarks','browser.history','music.tracks','clock.alarms',
                         'calendar.events','email.drafts','video.history'}.issubset(NAMESPACES))

    def test_save_update_delete_persistent_data(self):
        key=self.data.save('calendar.events',{'title':'Visit doctor'})
        self.assertEqual(self.data.get('calendar.events',key)['title'],'Visit doctor')
        self.data.save('calendar.events',{'title':'Changed'},key)
        self.assertEqual(self.data.get('calendar.events',key)['title'],'Changed')
        self.data.close();self.data=AppData(self.path)
        self.assertEqual(self.data.list('calendar.events')[0]['title'],'Changed')
        self.assertTrue(self.data.delete('calendar.events',key))
        self.assertIsNone(self.data.get('calendar.events',key))

    def test_permissions(self):
        if os.name=='posix':self.assertEqual(self.path.stat().st_mode & 0o777,0o600)

    def test_reject_namespace_injection_and_bad_id(self):
        for n in ('user.passwords','calendar.events;DROP TABLE records',''):
            with self.assertRaises(ValueError):self.data.save(n,{'test':True})
        with self.assertRaises(ValueError):self.data.save('calendar.events',{'test':True},'../../oops')
        with self.assertRaises(ValueError):self.data.save('email.drafts',{'content':'x'*70000})
        with self.assertRaises(ValueError):self.data.save('email.drafts',['not an object'])

    def test_untrusted_payload_cannot_override_record_identity(self):
        key=self.data.save('email.drafts',{'id':'fake','subject':'demo'})
        self.assertEqual(self.data.list('email.drafts')[0]['id'],key)

    def test_reject_symlink_database(self):
        other=Path(self.temp.name)/'linked.sqlite3'
        other.symlink_to(self.path)
        with self.assertRaises(ValueError):AppData(other)

    def test_alarm_notification_delivered_once(self):
        moment=(dt.datetime.now()-dt.timedelta(seconds=20)).isoformat()
        self.data.save('clock.alarms',{'at':moment,'enabled':True,'fired':False,'label':'Wake'})
        called=[]
        self.assertEqual(send_due(self.data,lambda a,b:called.append((a,b))),1)
        self.assertEqual(called,[('Nova Clock','Wake')])
        self.assertEqual(send_due(self.data,lambda a,b:called.append((a,b))),0)

    def test_event_notification_delivery(self):
        moment=(dt.datetime.now()-dt.timedelta(minutes=2)).isoformat()
        self.data.save('calendar.events',{'at':moment,'remind':True,'fired':False,'title':'Appointment'})
        called=[]
        self.assertEqual(send_due(self.data,lambda a,b:called.append((a,b))),1)
        self.assertIn(('Nova Calendar','Appointment'),called)

    def test_notification_failure_retries_without_flag(self):
        moment=(dt.datetime.now()-dt.timedelta(seconds=1)).isoformat()
        key=self.data.save('clock.alarms',{'at':moment,'enabled':True,'fired':False,'label':'Alert'})
        def fail(a,b):raise ConnectionError('offline')
        with self.assertRaises(ConnectionError):send_due(self.data,fail)
        self.assertFalse(self.data.get('clock.alarms',key)['fired'])

    def test_alarm_future_does_not_trigger(self):
        moment=(dt.datetime.now()+dt.timedelta(minutes=5)).isoformat()
        self.data.save('clock.alarms',{'at':moment,'enabled':True,'fired':False,'label':'Future'})
        self.assertEqual(send_due(self.data,lambda a,b:self.fail('too early')),0)

    def test_old_alarm_does_not_flood(self):
        moment=(dt.datetime.now()-dt.timedelta(days=3)).isoformat()
        key=self.data.save('clock.alarms',{'at':moment,'enabled':True,'fired':False,'label':'Old'})
        self.assertEqual(send_due(self.data,lambda a,b:self.fail('old reminder sent')),0)
        self.assertTrue(self.data.get('clock.alarms',key)['fired'])

    def test_nova_backup_includes_mobile_db_without_overwriting_live_data(self):
        from integration.platform_services import make_backup, restore_backup
        from zipfile import ZipFile
        config=Path(self.temp.name)/'config';config.mkdir()
        files=Path(self.temp.name)/'files';files.mkdir()
        self.data.save('calendar.events',{'title':'Clinic'})
        previous=os.environ.get('NOVA_MOBILE_DATA')
        os.environ['NOVA_MOBILE_DATA']=str(self.path)
        try:
            info=make_backup(config,files)
            with ZipFile(config/'backups'/info['name']) as z:
                self.assertIn('mobile/mobile.sqlite3',z.namelist())
            result=restore_backup(config,files,info['name'])
            self.assertFalse(result['live_data_changed'])
            self.assertTrue((Path(result['recovered_to'])/'mobile/mobile.sqlite3').is_file())
        finally:
            if previous is None:os.environ.pop('NOVA_MOBILE_DATA',None)
            else:os.environ['NOVA_MOBILE_DATA']=previous

    def test_db_rejects_symlink_after_initial_creation(self):
        self.data.save('calendar.events',{'title':'saved'})
        self.assertEqual(self.data.db.execute('PRAGMA integrity_check').fetchone()[0],'ok')

class NativeAppIntegrationTests(unittest.TestCase):
    def test_eight_launchers_and_render_methods(self):
        shell=(ROOT/'native-shell/nova_shell.py').read_text()
        apps=(ROOT/'native-shell/mobile_apps.py').read_text()
        for id in ('browser','music','clock','store','terminal','email','video','calendar'):
            self.assertIn(f"('{id}',",shell)
            self.assertIn(f'def page_{id}(',apps)
        ast.parse(shell);ast.parse(apps)

    def test_separate_process_launch_wiring(self):
        shell=(ROOT/'native-shell/nova_shell.py').read_text()
        self.assertIn('QProcess(self)',shell)
        self.assertIn('NOVA_SEPARATE_APPS',shell)
        self.assertIn('--child',shell)
        self.assertIn('self.mobile.render(page,v)',shell)

    def test_guest_reminder_service_and_multimedia_dependencies(self):
        script=(ROOT/'vm/build-arm64-qemu.sh').read_text()
        self.assertIn('python3-pyqt5.qtwebengine',script)
        self.assertIn('python3-pyqt5.qtmultimedia',script)
        self.assertIn('gstreamer1.0-plugins-good',script)
        self.assertIn('nova-reminders.service',script)
        self.assertIn('reminder_service.py', (ROOT/'vm/guest/nova-reminders.service').read_text())
        for f in ('vm/build-arm64-qemu.sh','vm/guest/nova-desktop-session','run-native-desktop.sh'):
            p=subprocess.run(['bash','-n',str(ROOT/f)],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)

    def test_shell_keyboard(self):
        text=(ROOT/'native-shell/mobile_keyboard.py').read_text()
        self.assertIn('NovaKeyboard',text)
        self.assertIn('Backspace',text)
        self.assertIn('set_target',text)
        self.assertIn('self.keyboard.open',(ROOT/'native-shell/nova_shell.py').read_text())

if __name__=='__main__':unittest.main()
