"""Browser onboarding and application service tests for Nova v0.76."""
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

SERVER=Path(__file__).resolve().parents[1]/'graphics-shell/server.py'

class ModernPortalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.base=Path(cls.tmp.name)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        cls.addr=f'http://127.0.0.1:{port}'
        env={**os.environ,'NOVA_CONFIG_DIR':str(cls.base/'settings'),'NOVA_FILES_ROOT':str(cls.base/'files')}
        cls.proc=subprocess.Popen([sys.executable,str(SERVER),'--no-browser','--port',str(port)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(90):
            try:
                page=urllib.request.urlopen(cls.addr,timeout=1).read().decode()
                cls.token=re.search(r'<meta name="nova-token" content="([^"]+)"',page).group(1)
                cls.session=''
                return
            except Exception:time.sleep(.1)
        raise RuntimeError('Modern shell did not start')

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate();cls.proc.wait(timeout=5);cls.tmp.cleanup()

    def call(self,path,body=None,session=None):
        headers={'X-Nova-Web-Session':self.session if session is None else session}
        if body is not None:
            headers.update({'Content-Type':'application/json','X-Nova-Token':self.token})
            data=json.dumps(body).encode()
        else:data=None
        req=urllib.request.Request(self.addr+path,data=data,headers=headers)
        with urllib.request.urlopen(req,timeout=5) as res:
            if res.headers.get('Content-Type','').startswith('application/json'):return json.load(res)
            return res.read()

    def test_01_modern_assets(self):
        page=self.call('/')
        self.assertIn(b'modern.js',page)
        self.assertIn(b'auth-form',page)
        js=self.call('/modern.js');self.assertIn(b'page_clock',js) if False else self.assertIn(b'pages.clock',js)
        css=self.call('/modern.css');self.assertIn(b'.app-grid',css)
        legacy=self.call('/legacy');self.assertIn(b'app-root',legacy)

    def test_02_setup_and_login(self):
        self.assertTrue(self.call('/api/account/status')['setup_required'])
        with self.assertRaises(urllib.error.HTTPError) as exc:
            self.call('/api/mobile/list/clock.alarms')
        self.assertEqual(exc.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/account/create',{'name':'Test','password':'short'})
        created=self.call('/api/account/create',{'name':'Tester','password':'super-secret-2026'})
        type(self).session=created['session']
        self.assertTrue(self.call('/api/account/status')['signed_in'])
        self.assertTrue((self.base/'settings'/'portal-account.json').exists())
        self.assertNotIn('super-secret-2026',(self.base/'settings'/'portal-account.json').read_text())
        with self.assertRaises(urllib.error.HTTPError):self.call('/api/account/create',{'name':'Other','password':'very-long-1234'})
        self.call('/api/account/logout',{})
        self.assertFalse(self.call('/api/account/status')['signed_in'])
        with self.assertRaises(urllib.error.HTTPError):self.call('/api/account/login',{'password':'wrong'})
        type(self).session=self.call('/api/account/login',{'password':'super-secret-2026'})['session']

    def test_03_persistent_app_records(self):
        record=self.call('/api/mobile/save',{'namespace':'calendar.events','value':{'title':'Medical study','at':'2026-12-10T10:00:00'}})
        key=record['id']
        events=self.call('/api/mobile/list/calendar.events')
        self.assertTrue(any(e['id']==key for e in events))
        self.assertTrue(self.call('/api/mobile/delete',{'namespace':'calendar.events','id':key})['deleted'])
        self.assertEqual(self.call('/api/mobile/list/calendar.events'),[])
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/mobile/save',{'namespace':'../unsafe','value':{}})
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/mobile/list/email.drafts',session='invalid')

    def test_04_diagnostics_whitelist(self):
        self.assertIn('Supported',self.call('/api/mobile/diagnostics',{'command':'help'})['output'])
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/mobile/diagnostics',{'command':'rm -rf /'})

    def test_05_local_media(self):
        (self.base/'files'/'sample.mp3').write_bytes(b'fake-mp3')
        result=self.call('/api/mobile/play?path=sample.mp3')
        self.assertEqual(result,b'fake-mp3')
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/mobile/play?path=..%2Fescape.mp3')
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/mobile/play?path=sample.mp3',session='not-logged-in')

    def test_07_android_api_requires_login(self):
        with self.assertRaises(urllib.error.HTTPError) as err:
            self.call('/api/android/status',session='invalid')
        self.assertEqual(err.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/android/upload/start',{'name':'x.apk','bytes':1000,'sha256':'0'*64},session='invalid')
        status=self.call('/api/android/status')
        self.assertFalse(status['execution_available'])
        self.assertIn('ready_to_try',status)
        report=self.call('/api/platform/readiness')
        self.assertEqual(len(report['areas']),14)
        js=self.call('/modern.js')
        self.assertIn(b'pages.android',js)
        self.assertIn(b'pages.readiness',js)
        self.assertIn(b'apk-picker',js)

    def test_08_stage_apk_without_installing(self):
        import io,base64,hashlib
        from zipfile import ZipFile
        buffer=io.BytesIO()
        with ZipFile(buffer,'w') as zip:
            zip.writestr('AndroidManifest.xml','APK fixture')
            zip.writestr('classes.dex',b'dex\n035'+bytes(20))
        binary=buffer.getvalue()
        checksum=hashlib.sha256(binary).hexdigest()
        start=self.call('/api/android/upload/start',{'name':'sample.apk','bytes':len(binary),'sha256':checksum})
        ref=start['id']
        uploaded=self.call('/api/android/upload/chunk',{'id':ref,'offset':0,'base64':base64.b64encode(binary).decode()})
        self.assertEqual(uploaded['received'],len(binary))
        done=self.call('/api/android/upload/finish',{'id':ref})
        self.assertTrue(done['ready'])
        self.assertFalse(done['inspection']['signature_verified'])
        self.assertIn(ref,[a['id'] for a in self.call('/api/android/staged')])
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.call('/api/android/install',{'id':ref})
        self.assertEqual(error.exception.code,403)

    def test_06_original_api_retained(self):
        self.assertTrue(self.call('/api/settings')['theme'])
        self.assertIn('network',self.call('/api/system'))
        self.assertIn('components',str(self.call('/api/integration')))

if __name__=='__main__':unittest.main(verbosity=2)
