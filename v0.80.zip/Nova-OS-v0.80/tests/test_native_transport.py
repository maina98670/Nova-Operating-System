"""Checks Python HTTP -> JSON process routing with a test double.
This does NOT compile or validate the original Rust libraries.
"""
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request

SERVER = Path(__file__).resolve().parents[1] / 'graphics-shell' / 'server.py'
FAKE = r'''#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
req=json.loads(sys.stdin.read())
root=Path(os.environ['NOVA_CORE_ROOT']); root.mkdir(parents=True,exist_ok=True)
contacts=root/'fixture_contacts.json'; settings=root/'fixture_settings.json'
cmd=req['cmd']
def load(path,default):
    return json.loads(path.read_text()) if path.exists() else default
def save(path,val):
    path.write_text(json.dumps(val))
try:
    if cmd=='health': out={'core':'test fixture'}
    elif cmd=='settings_list': out=load(settings,{'language':'en','display_brightness':70,'text_scale':100,'do_not_disturb':False})
    elif cmd=='settings_set':
        d=load(settings,{});d[req['key']]=req['value'];save(settings,d);out=d
    elif cmd=='contacts_list':out=load(contacts,[])
    elif cmd=='contacts_add':
        d=load(contacts,[]);d.append({'id':len(d)+1,'name':req['name'],'phone_numbers':[req['phone']]});save(contacts,d);out={'id':len(d)}
    elif cmd=='contacts_update':
        d=load(contacts,[]);entry=next(c for c in d if c['id']==req['id']);entry.update(name=req['name'],phone_numbers=[req['phone']]);save(contacts,d);out={'updated':req['id']}
    elif cmd=='contacts_remove':
        d=load(contacts,[]);save(contacts,[c for c in d if c['id']!=req['id']]);out={'deleted':req['id']}
    elif cmd=='messages_threads':out=[]
    elif cmd.startswith('file_'):
        p=Path(os.environ['NOVA_FILES_ROOT'])/req['path']
        if cmd=='file_read':out={'content':p.read_text()}
        elif cmd=='file_write':p.write_text(req['content']);out={'saved':True}
        elif cmd=='file_create':p.write_text(req['content']);out={'created':True}
        elif cmd=='file_rename':p.rename(Path(os.environ['NOVA_FILES_ROOT'])/req['dest']);out={'renamed':True}
    else:raise ValueError('unknown')
    print(json.dumps({'ok':True,'result':out}))
except Exception as exc:
    print(json.dumps({'ok':False,'error':str(exc)}))
    sys.exit(1)
'''

class NativeTransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        t = Path(cls.tmp.name)
        (t/'bridge').write_text(FAKE)
        (t/'bridge').chmod(0o700)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0)); cls.port=sock.getsockname()[1]
        cls.host=f'http://127.0.0.1:{cls.port}'
        env = {**os.environ, 'NOVA_FILES_ROOT':str(t/'files'), 'NOVA_CONFIG_DIR':str(t/'config'), 'NOVA_BRIDGE_BIN':str(t/'bridge')}
        cls.server = subprocess.Popen([sys.executable,str(SERVER),'--port',str(cls.port),'--no-browser'], env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(50):
            try:
                html=urllib.request.urlopen(cls.host,timeout=1).read().decode()
                cls.token=re.search(r'meta name="nova-token" content="([^"]+)',html).group(1)
                break
            except Exception:time.sleep(.1)
        else:raise RuntimeError('bridge test server did not start')

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate();cls.server.wait(timeout=5);cls.tmp.cleanup()

    def call(self,route,payload=None):
        if payload is None:
            req=urllib.request.Request(self.host+route)
        else:
            req=urllib.request.Request(self.host+route,json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-Nova-Token':self.token})
        with urllib.request.urlopen(req,timeout=5) as resp:return json.loads(resp.read())

    def test_01_transport_status(self):
        self.assertTrue(self.call('/api/core/status')['connected'])
    def test_02_settings_forwarded(self):
        self.call('/api/core/settings',{'key':'language','value':'sw'})
        self.assertEqual(self.call('/api/core/settings')['language'],'sw')
    def test_03_contacts_forwarded(self):
        self.call('/api/contacts/save',{'name':'Jane','phone':'123'})
        contacts=self.call('/api/contacts')
        self.assertEqual(contacts[0]['name'],'Jane')
        self.assertEqual(contacts[0]['id'],'1')
        self.call('/api/contacts/save',{'id':'1','name':'Jane updated','phone':'456'})
        self.assertEqual(self.call('/api/contacts')[0]['name'],'Jane updated')
        self.call('/api/contacts/save',{'id':'1','delete':True})
        self.assertEqual(self.call('/api/contacts'),[])
    def test_04_fsmgr_forwarded(self):
        self.call('/api/files/create',{'name':'hello.txt','content':'hello'})
        self.assertEqual(self.call('/api/file?path=hello.txt')['content'],'hello')
        self.call('/api/files/save',{'path':'hello.txt','content':'new'})
        self.assertEqual(self.call('/api/file?path=hello.txt')['content'],'new')
        self.call('/api/files/rename',{'path':'hello.txt','name':'bye.txt'})
        self.assertEqual(self.call('/api/file?path=bye.txt')['content'],'new')

if __name__=='__main__':unittest.main()
