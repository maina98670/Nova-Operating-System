"""Platform APIs validated on host; not a claim of complete ARM64 runtime."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'integration'))
from platform_services import PackageStore, make_backup, list_backups, restore_backup, system_diagnostics


def archive_payload(appid='org.nova.demo', file_name='resources/readme.txt', tamper=False):
    contents=b'Hello Nova data package!'
    digest=hashlib.sha256(contents).hexdigest()
    if tamper:digest='0'*64
    manifest={'schema':1,'id':appid,'name':'Demo', 'version':'1.0.0','files':{file_name:digest}}
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w') as z:
        z.writestr('manifest.json',json.dumps(manifest))
        z.writestr(file_name,contents)
    return base64.b64encode(output.getvalue()).decode('ascii')


class PlatformCoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.data=Path(self.tmp.name)/'config'
        self.files=Path(self.tmp.name)/'files'
        self.data.mkdir();self.files.mkdir()
    def tearDown(self):self.tmp.cleanup()

    def test_01_packages_roundtrip(self):
        store=PackageStore(self.data)
        info=store.install_base64(archive_payload())
        self.assertEqual(info['runtime'],'resources-only')
        self.assertFalse(info['trusted_executable'])
        self.assertEqual(len(store.list()),1)
        self.assertEqual((store.root/'org.nova.demo/resources/readme.txt').read_text(),'Hello Nova data package!')
        self.assertEqual(store.uninstall('org.nova.demo')['uninstalled'],'org.nova.demo')
        self.assertEqual(store.list(),[])

    def test_02_bad_checksum_rejected(self):
        with self.assertRaisesRegex(ValueError,'checksum'):
            PackageStore(self.data).install_base64(archive_payload(tamper=True))
        self.assertFalse((self.data/'packages/org.nova.demo').exists())

    def test_03_path_traversal_and_invalid_id_rejected(self):
        for fname, appid in [('resources/../../escape','org.nova.demo'),('resources/ok','../../bad')]:
            with self.subTest(fname=fname,appid=appid), self.assertRaises(ValueError):
                PackageStore(self.data).install_base64(archive_payload(appid=appid,file_name=fname))
        self.assertFalse((Path(self.tmp.name)/'escape').exists())

    def test_04_prevent_duplicate_and_arbitrary_removal(self):
        store=PackageStore(self.data)
        store.install_base64(archive_payload())
        with self.assertRaises(ValueError):store.install_base64(archive_payload())
        with self.assertRaises(ValueError):store.uninstall('../notes')

    def test_05_backup_keeps_data_and_symlink_private(self):
        (self.files/'letter.txt').write_text('hello')
        (self.data/'settings.json').write_text('{"theme":"dark"}')
        external=Path(self.tmp.name)/'secret';external.write_text('outside')
        (self.files/'escape').symlink_to(external)
        created=make_backup(self.data,self.files)
        self.assertIn(created['name'],[p['name'] for p in list_backups(self.data)])
        archive=self.data/'backups'/created['name']
        with zipfile.ZipFile(archive) as z:
            self.assertIn('files/letter.txt',z.namelist())
            self.assertIn('config/settings.json',z.namelist())
            self.assertNotIn('files/escape',z.namelist())
        (self.files/'letter.txt').write_text('changed')
        recovered=restore_backup(self.data,self.files,created['name'])
        self.assertFalse(recovered['live_data_changed'])
        self.assertEqual((Path(recovered['recovered_to'])/'files/letter.txt').read_text(),'hello')
        self.assertEqual((self.files/'letter.txt').read_text(),'changed')

    def test_06_backup_rejects_invalid_name(self):
        with self.assertRaises(ValueError):restore_backup(self.data,self.files,'../../bad.zip')

    def test_07_reject_duplicate_zip_entries(self):
        memory=io.BytesIO()
        checksum=hashlib.sha256(b'hello').hexdigest()
        manifest={'schema':1,'id':'org.nova.demo','version':'1.0.0',
                  'files':{'resources/data.txt':checksum}}
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(memory,'w') as z:
                z.writestr('manifest.json',json.dumps(manifest))
                z.writestr('resources/data.txt',b'hello')
                z.writestr('resources/data.txt',b'hello')
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            PackageStore(self.data).install_base64(base64.b64encode(memory.getvalue()).decode())

    def test_07b_reject_extra_unlisted_resources(self):
        memory=io.BytesIO()
        checksum=hashlib.sha256(b'hello').hexdigest()
        manifest={'schema':1,'id':'org.nova.demo','version':'1.0.0',
                  'files':{'resources/data.txt':checksum}}
        with zipfile.ZipFile(memory,'w') as z:
            z.writestr('manifest.json',json.dumps(manifest))
            z.writestr('resources/data.txt',b'hello')
            z.writestr('resources/hidden.sh',b'echo bad')
        with self.assertRaisesRegex(ValueError,'manifest'):
            PackageStore(self.data).install_base64(base64.b64encode(memory.getvalue()).decode())

    def test_07c_backup_size_limit(self):
        # Sparse-looking but real data > size cap, avoid writing large fixture.
        from unittest.mock import patch
        (self.files/'big.bin').write_bytes(b'12345678')
        with patch('platform_services.MAX_BACKUP',4):
            with self.assertRaisesRegex(ValueError,'limit'):
                make_backup(self.data,self.files)
        self.assertEqual(list_backups(self.data),[])

    def test_07d_backup_recovery_does_not_replace_live_data(self):
        (self.files/'entry.txt').write_text('original')
        snapshot=make_backup(self.data,self.files)
        (self.files/'entry.txt').write_text('changed')
        restore_backup(self.data,self.files,snapshot['name'])
        self.assertEqual((self.files/'entry.txt').read_text(),'changed')

    def test_07_diagnostics_measured_not_simulated(self):
        info=system_diagnostics(self.files)
        self.assertIsInstance(info['network_interfaces'],list)
        self.assertGreaterEqual(info['storage_free_mb'],0)
        self.assertIn('health_scope',info)


class PlatformAPITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.data=Path(cls.temp.name)/'config'
        cls.files=Path(cls.temp.name)/'files'
        with socket.socket() as s:
            s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        cls.base=f'http://127.0.0.1:{port}'
        env={**os.environ,'NOVA_CONFIG_DIR':str(cls.data),'NOVA_FILES_ROOT':str(cls.files),
             'NOVA_BRIDGE_BIN':str(Path(cls.temp.name)/'nonexistent')}
        cls.server=subprocess.Popen([sys.executable,str(ROOT/'graphics-shell/server.py'),
                    '--no-browser','--port',str(port)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        for _ in range(100):
            try:
                with urllib.request.urlopen(cls.base+'/',timeout=1) as r:
                    import re
                    cls.token=re.search(r'name="nova-token" content="([^"]+)"',r.read().decode()).group(1)
                break
            except (OSError,AttributeError):time.sleep(.1)
        else:raise RuntimeError('Nova API startup failed')
    @classmethod
    def tearDownClass(cls):
        cls.server.terminate();cls.server.communicate(timeout=5);cls.temp.cleanup()
    def get(self,path):
        with urllib.request.urlopen(self.base+path,timeout=3) as r:return json.load(r)
    def post(self,path,obj,token=None):
        request=urllib.request.Request(self.base+path,json.dumps(obj).encode(),headers={
            'Content-Type':'application/json','X-Nova-Token':self.token if token is None else token})
        with urllib.request.urlopen(request,timeout=3) as r:return json.load(r)

    def test_08_platform_routes_and_auth(self):
        self.assertIn('ram_available_mb',self.get('/api/platform/diagnostics'))
        self.assertEqual(self.get('/api/packages'),[])
        with self.assertRaises(urllib.error.HTTPError) as denied:
            self.post('/api/backups/create',{},token='incorrect')
        self.assertEqual(denied.exception.code,403)
        self.assertEqual(self.get('/api/backups'),[])

    def test_09_install_and_recover_by_api(self):
        result=self.post('/api/packages/install',{'base64':archive_payload()})
        self.assertEqual(result['installed'],'org.nova.demo')
        self.assertEqual(len(self.get('/api/packages')),1)
        self.post('/api/packages/uninstall',{'id':'org.nova.demo'})
        self.assertEqual(self.get('/api/packages'),[])
        self.post('/api/files/create',{'path':'','name':'important.txt','content':'Nova boot'})
        snapshot=self.post('/api/backups/create',{})
        restored=self.post('/api/backups/recover',{'name':snapshot['name']})
        self.assertFalse(restored['live_data_changed'])

    def test_10_qt_independent_process_path(self):
        source=(ROOT/'native-shell/nova_shell.py').read_text()
        self.assertIn('def launch_app(',source)
        self.assertIn('proc.setProgram(sys.executable)',source)
        self.assertIn('NOVA_CHILD_APP',source)
        self.assertIn('def stop_app(',source)

    def test_11_guest_has_resource_limit_and_launcher(self):
        source=(ROOT/'vm/build-arm64-qemu.sh').read_text()
        session=(ROOT/'vm/guest/nova-desktop-session').read_text()
        self.assertIn('MemoryMax=512M',source)
        self.assertIn('ProtectSystem=strict',source)
        self.assertIn('NOVA_SEPARATE_APPS=1',session)

if __name__=='__main__':unittest.main()
