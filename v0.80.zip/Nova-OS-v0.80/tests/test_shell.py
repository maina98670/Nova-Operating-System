#!/usr/bin/env python3
"""Automated isolated API tests for Nova's hosted graphical shell."""
import contextlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request

SERVER = Path(__file__).resolve().parents[1] / 'graphics-shell' / 'server.py'

class ShellTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name) / 'files'
        cls.config = Path(cls.tmp.name) / 'config'
        # Pick unused local port.
        import socket
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0))
            cls.port=sock.getsockname()[1]
        env={**os.environ,'NOVA_FILES_ROOT':str(cls.root),'NOVA_CONFIG_DIR':str(cls.config)}
        cls.process=subprocess.Popen([sys.executable,str(SERVER),'--port',str(cls.port),'--no-browser'], env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        cls.host='http://127.0.0.1:'+str(cls.port)
        for _ in range(50):
            try:
                html=urllib.request.urlopen(cls.host,timeout=1).read().decode()
                cls.token=re.search(r'meta name="nova-token" content="([^"]+)',html).group(1)
                return
            except Exception:time.sleep(.1)
        raise RuntimeError('Nova test server did not start')

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate();cls.process.wait(timeout=5);cls.tmp.cleanup()

    def request(self, route, payload=None, token=None):
        headers={}
        if payload is not None:
            data=json.dumps(payload).encode('utf-8')
            headers={'Content-Type':'application/json','X-Nova-Token':self.token if token is None else token}
        else:data=None
        req=urllib.request.Request(self.host+route,data=data,headers=headers)
        with urllib.request.urlopen(req,timeout=5) as r:return json.loads(r.read())

    def test_01_status(self):
        s=self.request('/api/system')
        self.assertIn('Linux-hosted graphical shell',s['mode'])
        self.assertIn('network',s)
        self.assertIn('native_core',s)

    def test_02_file_create_edit_rename_trash(self):
        self.request('/api/files/create',{'name':'Text folder','dir':True})
        self.request('/api/files/create',{'path':'Text folder','name':'foo.txt','content':'Hello'})
        f=self.request('/api/file?path=Text%20folder%2Ffoo.txt')
        self.assertEqual(f['content'],'Hello')
        self.request('/api/files/save',{'path':'Text folder/foo.txt','content':'Updated'})
        self.assertEqual((self.root/'Text folder/foo.txt').read_text(),'Updated')
        self.request('/api/files/rename',{'path':'Text folder/foo.txt','name':'bar.txt'})
        self.assertTrue((self.root/'Text folder/bar.txt').exists())
        self.request('/api/files/trash',{'path':'Text folder/bar.txt'})
        self.assertFalse((self.root/'Text folder/bar.txt').exists())
        self.assertTrue(list((self.config/'trash').glob('*bar.txt')))

    def test_03_settings_persist(self):
        self.request('/api/settings',{'theme':'light','wallpaper':'forest','clock24':False,'name':'Test'})
        self.assertEqual(self.request('/api/settings')['name'],'Test')
        self.assertEqual(self.request('/api/settings')['clock24'],False)

    def test_04_data_apps(self):
        self.request('/api/notes/save',{'title':'Test Note','content':'Stored'})
        self.assertEqual(self.request('/api/notes')[0]['content'],'Stored')
        self.request('/api/contacts/save',{'name':'Jane','phone':'555'})
        self.assertEqual(self.request('/api/contacts')[0]['name'],'Jane')
        self.request('/api/messages/save',{'recipient':'Jane','body':'Hi'})
        self.assertTrue(self.request('/api/messages')[0]['local_only'])

    def test_05_api_security(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request('/api/settings',{'name':'Unauthorized'},token='invalid')
        self.assertEqual(caught.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request('/api/files?path=..%2F..')
        self.assertEqual(caught.exception.code,400)
        with self.assertRaises(urllib.error.HTTPError):
            self.request('/api/files/create',{'path':'','name':'../escaped'})
        outside=Path(self.tmp.name)/'escape'
        outside.mkdir()
        (self.root/'link').symlink_to(outside, target_is_directory=True)
        with self.assertRaises(urllib.error.HTTPError):
            self.request('/api/files?path=link')

    def test_07_original_components_runtime_catalog(self):
        data=self.request('/api/integration')
        self.assertEqual(data['source_count'],104)
        self.assertEqual(data['counts']['source_present'],104)
        self.assertEqual(data['counts']['libraries'],48)
        self.assertEqual(data['counts']['apps'],12)
        self.assertEqual(data['counts']['tools'],44)
        self.assertEqual(len(data['components']),104)
        self.assertIn('guest_services',data)
        self.assertFalse(data['boot']['native_nova_compositor'])
        self.assertIn('native_bridge_connected',data)

    def test_06_source_inventory(self):
        inv=self.request('/api/inventory')
        self.assertIn('org.nova.settings',inv['rust_source_apps'])

if __name__ == '__main__':unittest.main(verbosity=2)
