import os
import pathlib
import subprocess
import sys
import tempfile
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]

class UnifiedPackageTests(unittest.TestCase):
    def test_all_workspace_manifests_present(self):
        result=subprocess.run([sys.executable,str(ROOT/'scripts/audit-source.py')],cwd=ROOT,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)

    def test_m0_through_m3_preserved(self):
        for phase in ['m0','m1','m2','m3']:
            self.assertTrue((ROOT/'boot/legacy'/phase).is_dir(),phase)

    def test_wayland_is_in_guest_not_host(self):
        session=(ROOT/'vm/guest/nova-desktop-session').read_text()
        self.assertIn('/usr/local/bin/nova-compositor-run',session)
        self.assertIn('weston --backend=drm-backend.so', (ROOT/'vm/guest/nova-compositor-run').read_text())
        self.assertIn('QT_QPA_PLATFORM=wayland',session)
        self.assertIn('/opt/nova/native-shell/modern_webview.py',session)
        self.assertIn('http://127.0.0.1:8767',session)

    def test_guest_boot_installs_graphics_and_nova_service(self):
        build=(ROOT/'vm/build-arm64-qemu.sh').read_text()
        for required in ['linux-image-arm64','python3-pyqt5','qtwayland5','weston','nova-shell.service','virtio_gpu','mkfs.ext4','nova-desktop-session']:
            self.assertIn(required,build)

    def test_qemu_uses_virtual_gpu_and_input(self):
        run=(ROOT/'vm/run-arm64-qemu.sh').read_text()
        for required in ['virtio-gpu-pci','virtio-keyboard-pci','virtio-mouse-pci','-kernel','-initrd']:
            self.assertIn(required,run)

    def test_no_kernel_source_misrepresented(self):
        self.assertFalse((ROOT/'source-v0.60'/'kernel'/'Image').exists())

if __name__=='__main__':unittest.main()
