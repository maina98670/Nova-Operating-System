#!/usr/bin/env bash
# Nova OS v0.71: ARM64 Linux/QEMU graphical appliance build.
# Boot: Linux -> systemd -> Nova Python/Rust service -> Weston -> native Qt Wayland shell.
# This does not replace Linux init with the legacy Nova Init prototype.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/vm/out"
ROOTFS="$OUT/rootfs"
IMAGE="$OUT/nova-arm64.ext4"
DISTRO="${NOVA_DISTRO:-trixie}"
MIRROR="${NOVA_DEBIAN_MIRROR:-http://deb.debian.org/debian}"
IMAGE_GIB="${NOVA_DISK_GIB:-5}"

if [[ $EUID -eq 0 ]]; then echo 'Run as a normal user with sudo, not root.' >&2; exit 2; fi
command -v sudo >/dev/null || { echo 'sudo is required.' >&2; exit 2; }
case "$IMAGE_GIB" in 4|5|6|7|8|9|10|11|12) ;; *) echo 'NOVA_DISK_GIB must be 4 to 12.' >&2; exit 2;; esac
[[ ! -e "$IMAGE" ]] || { echo "Image already exists: $IMAGE. Refusing to erase it." >&2; exit 2; }
mkdir -p "$OUT"
echo '[1/8] Installing host cross-architecture image tools'
sudo apt-get update
sudo apt-get install -y debootstrap qemu-user-static binfmt-support qemu-system-arm e2fsprogs rsync ca-certificates file
if [[ $(uname -m) != aarch64 ]]; then
  sudo update-binfmts --enable qemu-aarch64 || true
  [[ -e /proc/sys/fs/binfmt_misc/qemu-aarch64 ]] || { echo 'ARM64 binfmt unavailable; a full Ubuntu/Debian host is recommended.' >&2; exit 2; }
fi
command -v qemu-aarch64-static >/dev/null || { echo 'qemu-aarch64-static not found' >&2; exit 2; }

echo '[2/8] Bootstrap ARM64 Debian root filesystem'
if [[ ! -e "$ROOTFS/bin/sh" ]]; then
  sudo debootstrap --arch=arm64 --foreign --variant=minbase "$DISTRO" "$ROOTFS" "$MIRROR"
fi
sudo install -Dm755 "$(command -v qemu-aarch64-static)" "$ROOTFS/usr/bin/qemu-aarch64-static"
if [[ ! -e "$ROOTFS/.nova-stage2-complete" ]]; then
  sudo chroot "$ROOTFS" /debootstrap/debootstrap --second-stage
  sudo touch "$ROOTFS/.nova-stage2-complete"
fi
sudo cp --remove-destination /etc/resolv.conf "$ROOTFS/etc/resolv.conf"
printf 'deb %s %s main\n' "$MIRROR" "$DISTRO" | sudo tee "$ROOTFS/etc/apt/sources.list" >/dev/null

echo '[3/8] Install Linux kernel, Weston and Qt Wayland ARM64 GUI'
sudo chroot "$ROOTFS" apt-get update
sudo chroot "$ROOTFS" env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
 linux-image-arm64 initramfs-tools systemd-sysv systemd udev dbus dbus-user-session \
 python3 python3-pyqt5 qtwayland5 python3-pyqt5.qtwebengine python3-pyqt5.qtmultimedia ca-certificates iproute2 sudo weston network-manager bluez \
 gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-libav \
 libgl1-mesa-dri libegl1 fonts-dejavu-core fonts-noto-color-emoji

# NetworkManager may manage Wi-Fi hardware once available, while networkd retains
# the QEMU wired NIC. No radio is invented by installing these utilities.
sudo install -d "$ROOTFS/etc/NetworkManager/conf.d"
sudo tee "$ROOTFS/etc/NetworkManager/conf.d/10-nova-wired.conf" >/dev/null <<'NM'
[keyfile]
unmanaged-devices=interface-name:eth*;interface-name:en*
NM

echo '[4/8] Install Nova code and configure user'
sudo chroot "$ROOTFS" useradd --create-home --shell /bin/bash nova 2>/dev/null || true
sudo chroot "$ROOTFS" usermod -aG video,render,input nova
sudo install -d "$ROOTFS/opt/nova/graphics-shell" "$ROOTFS/opt/nova/native-shell" "$ROOTFS/opt/nova/source-v0.60" "$ROOTFS/var/lib/nova"
sudo rsync -a --exclude='__pycache__' "$ROOT/graphics-shell/" "$ROOTFS/opt/nova/graphics-shell/"
sudo rsync -a --exclude='__pycache__' "$ROOT/native-shell/" "$ROOTFS/opt/nova/native-shell/"
sudo rsync -a --exclude='target' "$ROOT/source-v0.60/" "$ROOTFS/opt/nova/source-v0.60/"
# Preserve every original Nova source milestone and boot prototype in the guest.
# Source presence is for development/auditing, not automatic execution.
sudo install -d "$ROOTFS/opt/nova/boot" "$ROOTFS/opt/nova/history" "$ROOTFS/opt/nova/integration" "$ROOTFS/opt/nova/bin"
sudo rsync -a "$ROOT/boot/" "$ROOTFS/opt/nova/boot/"
# Stage the actual M0-M3 integration artifacts into guest, not just archived sources.
# M2 remains opt-in at QEMU kernel command line until it has passed a live boot.
M3_ARGS=()
# Compile original M3 in ARM64 guest *before* the disk is packed, but only
# when a wlroots 0.17 development stack is actually available.
if [[ "${NOVA_BUILD_M3:-0}" == 1 ]]; then
  "$ROOT/scripts/build-m3-arm64-guest.sh" "$ROOTFS"
  NOVA_M3_BIN="$ROOTFS/opt/nova-m3-source/build/nova-display"
fi
if [[ -n "${NOVA_M3_BIN:-}" ]]; then M3_ARGS+=(--m3-bin "$NOVA_M3_BIN"); fi
M3_BACKEND="${NOVA_COMPOSITOR_DEFAULT:-weston}"
if [[ "$M3_BACKEND" == nova && -z "${NOVA_M3_BIN:-}" ]]; then
  echo 'NOVA_COMPOSITOR_DEFAULT=nova requires an ARM64 NOVA_M3_BIN' >&2
  exit 3
fi
sudo python3 "$ROOT/scripts/stage-m0-m3.py" --rootfs "$ROOTFS" \
  --out "$ROOT/boot/integrated/out" --compositor "$M3_BACKEND" "${M3_ARGS[@]}"
sudo install -Dm755 "$ROOT/vm/guest/nova-compositor-run" "$ROOTFS/usr/local/bin/nova-compositor-run"
sudo install -Dm755 "$ROOT/scripts/boot-home-status.py" "$ROOTFS/usr/local/bin/nova-boot-status"
sudo install -Dm644 "$ROOT/vm/guest/nova-boot-splash.service" "$ROOTFS/etc/systemd/system/nova-boot-splash.service"
if [[ -f "$ROOTFS/opt/nova/bin/nova-splash" ]]; then
  sudo chroot "$ROOTFS" systemctl enable nova-boot-splash.service
fi

sudo rsync -a "$ROOT/history/" "$ROOTFS/opt/nova/history/"
sudo rsync -a --exclude='__pycache__' "$ROOT/integration/" "$ROOTFS/opt/nova/integration/"
if [[ "${NOVA_REQUIRE_ALL_BINARIES:-0}" == 1 ]]; then
  python3 "$ROOT/scripts/stage-original-binaries.py" --strict
fi
if [[ -d "$ROOT/native-bin" ]]; then
  echo '[nova] Installing selected ARM64 original Nova app and CLI binaries (not launching test tools).'
  for binary in "$ROOT/native-bin"/*; do
    [[ -f "$binary" ]] || continue
    file "$binary" | grep -Eq '(ARM aarch64|ARM64|aarch64)' || { echo "Non-ARM64 staged binary: $binary" >&2; exit 3; }
    sudo install -Dm755 "$binary" "$ROOTFS/opt/nova/bin/$(basename "$binary")"
  done
fi
sudo install -Dm644 "$ROOT/vm/guest/nova-catalog.service" "$ROOTFS/etc/systemd/system/nova-catalog.service"
sudo install -Dm644 "$ROOT/vm/guest/nova-reminders.service" "$ROOTFS/etc/systemd/system/nova-reminders.service"
sudo install -d "$ROOTFS/var/lib/nova/mobile"
sudo chroot "$ROOTFS" chown nova:nova /var/lib/nova/mobile
if [[ "${NOVA_REQUIRE_ORIGINAL_RUNTIME:-0}" == 1 && ! -x "$ROOT/native-bin/nova-runtime-daemon" ]]; then
  echo 'Required original App Manager / compositor protocol daemon missing. Run ./scripts/build-native-runtime-arm64.sh.' >&2
  exit 3
fi
if [[ -x "$ROOT/native-bin/nova-runtime-daemon" ]]; then
  sudo install -Dm644 "$ROOT/vm/guest/nova-runtime.service" "$ROOTFS/etc/systemd/system/nova-runtime.service"
  echo '[native] Original Nova App Manager + compositor protocol services will be started in guest.'
else
  echo '[native] Original Nova App Manager daemon binary absent; QEMU guest will not start that service.'
fi
# Install the original app manifests and matching binaries into their canonical
# /apps/id/bin/ layout only if binaries are available. Never register missing apps.
for appdir in "$ROOT"/source-v0.60/apps/org.nova.*; do
  [[ -d "$appdir" && -f "$appdir/nova-app.toml" ]] || continue
  appid="$(basename "$appdir")"
  appname="$(sed -n 's/^name = "\([^"]*\)"/\1/p' "$appdir/Cargo.toml" | head -1)"
  if [[ -n "$appname" && -x "$ROOT/native-bin/$appname" ]]; then
    sudo install -Dm644 "$appdir/nova-app.toml" "$ROOTFS/apps/$appid/nova-app.toml"
    sudo install -Dm755 "$ROOT/native-bin/$appname" "$ROOTFS/apps/$appid/bin/$appname"
  fi
done

sudo install -d "$ROOTFS/etc/systemd/system" "$ROOTFS/etc/systemd/network"
sudo chroot "$ROOTFS" chown -R nova:nova /var/lib/nova
sudo tee "$ROOTFS/etc/systemd/network/10-nova.network" >/dev/null <<'NETWORK'
[Match]
Name=en* eth*
[Network]
DHCP=yes
NETWORK

sudo tee "$ROOTFS/etc/systemd/system/nova-shell.service" >/dev/null <<'UNIT'
[Unit]
Description=Nova OS integrated graphical application service
After=local-fs.target nova-runtime.service
Wants=nova-runtime.service
StartLimitIntervalSec=120
StartLimitBurst=10
[Service]
Type=simple
User=nova
Group=nova
WorkingDirectory=/opt/nova
Environment=NOVA_MOBILE_DATA=/var/lib/nova/mobile/mobile.sqlite3
Environment=NOVA_CONFIG_DIR=/var/lib/nova/config
Environment=NOVA_FILES_ROOT=/var/lib/nova/files
Environment=PYTHONUNBUFFERED=1
Environment=NOVA_REQUIRE_RUST_BRIDGE=1
Environment=NOVA_ENFORCE_AUTH=1
Environment=NOVA_GUI_READY_FILE=/var/lib/nova/gui-ready.json
ExecStartPre=/usr/bin/install -d -o nova -g nova /var/lib/nova/config /var/lib/nova/files
ExecStart=/usr/bin/python3 /opt/nova/graphics-shell/server.py --no-browser --host 0.0.0.0 --port 8767
Restart=on-failure
RestartSec=3
MemoryMax=512M
TasksMax=80
NoNewPrivileges=yes
UMask=0077
PrivateTmp=yes
ProtectHome=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictSUIDSGID=yes
RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6
ProtectSystem=strict
ReadWritePaths=/var/lib/nova
[Install]
WantedBy=multi-user.target
UNIT
# ExecStartPre runs with service user, so do not ask it to change ownership.
sudo sed -i 's@ExecStartPre=/usr/bin/install -d -o nova -g nova /var/lib/nova/config /var/lib/nova/files@ExecStartPre=/usr/bin/mkdir -p /var/lib/nova/config /var/lib/nova/files@' "$ROOTFS/etc/systemd/system/nova-shell.service"
BRIDGE="${NOVA_ARM64_BRIDGE_BIN:-$ROOT/native-bridge/target/aarch64-unknown-linux-gnu/release/nova-graphics-bridge}"
if [[ -f "$BRIDGE" ]]; then
  file "$BRIDGE" | grep -Eq '(ARM aarch64|ARM64|aarch64)' || { echo "Not an ARM64 binary: $BRIDGE" >&2; exit 3; }
  sudo install -Dm755 "$BRIDGE" "$ROOTFS/opt/nova/bin/nova-graphics-bridge"
  sudo install -d "$ROOTFS/etc/systemd/system/nova-shell.service.d"
  printf '[Service]\nEnvironment=NOVA_BRIDGE_BIN=/opt/nova/bin/nova-graphics-bridge\n' | sudo tee "$ROOTFS/etc/systemd/system/nova-shell.service.d/rust.conf" >/dev/null
  echo '[native] Verifying ARM64 Rust bridge inside the actual Debian guest ABI...'
  sudo install -d "$ROOTFS/var/lib/nova/config/rust-core" "$ROOTFS/var/lib/nova/files"
  sudo chroot "$ROOTFS" env NOVA_CORE_ROOT=/var/lib/nova/config/rust-core NOVA_FILES_ROOT=/var/lib/nova/files \
    /opt/nova/bin/nova-graphics-bridge <<<'{"cmd":"health"}' || {
      echo 'ARM64 Rust bridge could not execute inside Debian guest (glibc/ABI mismatch?).' >&2
      echo 'Build against a Debian-compatible ARM64 target, or remove the bridge and use fallback.' >&2
      exit 3
    }
  # Health probe runs as root inside chroot and may create root-owned state files.
  # Return ownership to Nova before the unprivileged systemd service starts.
  sudo chroot "$ROOTFS" chown -R nova:nova /var/lib/nova
  echo '[native] ARM64 Rust bridge installed, health-checked and data ownership repaired.'
else
  if [[ "${NOVA_REQUIRE_RUST_BRIDGE:-0}" == 1 ]]; then
    echo "Required ARM64 Rust bridge missing: $BRIDGE. Run ./scripts/build-aarch64-bridge.sh first." >&2
    exit 3
  fi
  echo '[native] WARNING: no ARM64 Rust bridge; Nova UI will use Python fallback.'
fi

echo '[5/8] Install selectable Nova M3/Weston Wayland session (guest QEMU virtio GPU)'
sudo install -Dm755 "$ROOT/vm/guest/nova-desktop-session" "$ROOTFS/usr/local/bin/nova-desktop-session"
sudo install -Dm644 "$ROOT/vm/guest/weston.ini" "$ROOTFS/etc/xdg/weston/weston.ini"
sudo install -Dm644 "$ROOT/vm/guest/nova-profile" "$ROOTFS/home/nova/.profile"
sudo chroot "$ROOTFS" chown nova:nova /home/nova/.profile
sudo install -d "$ROOTFS/etc/systemd/system/getty@tty1.service.d"
sudo tee "$ROOTFS/etc/systemd/system/getty@tty1.service.d/nova-autologin.conf" >/dev/null <<'GETTY'
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin nova --noclear %I $TERM
GETTY
# Only for the non-production QEMU development image; never ship auto-login on actual phones.
sudo mkdir -p "$ROOTFS/etc/systemd/system/serial-getty@ttyAMA0.service.d"
sudo tee "$ROOTFS/etc/systemd/system/serial-getty@ttyAMA0.service.d/nova-serial.conf" >/dev/null <<'SERIAL'
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin nova --keep-baud 115200,38400,9600 %I vt220
SERIAL
sudo tee "$ROOTFS/etc/hostname" >/dev/null <<'HOST'
nova-os
HOST
sudo chroot "$ROOTFS" systemctl enable systemd-networkd nova-shell.service nova-reminders.service nova-catalog.service getty@tty1.service serial-getty@ttyAMA0.service
if [[ -x "$ROOTFS/opt/nova/bin/nova-runtime-daemon" ]]; then
  sudo chroot "$ROOTFS" systemctl enable nova-runtime.service
fi
printf 'virtio_pci\nvirtio_blk\nvirtio_net\nvirtio_gpu\n' | sudo tee -a "$ROOTFS/etc/initramfs-tools/modules" >/dev/null
sudo chroot "$ROOTFS" update-initramfs -u -k all

echo '[6/8] Confirm kernel, initramfs, integrated sources and graphical packages'
sudo chroot "$ROOTFS" /usr/bin/python3 /opt/nova/integration/runtime.py > "$OUT/component-structure.json"
sudo test -f "$ROOTFS/opt/nova/history/snapshots/v0.60.zip" || { echo 'Missing historical Nova archives in guest' >&2; exit 3; }
sudo test -f "$ROOTFS/opt/nova/boot/legacy/m0" -o -d "$ROOTFS/opt/nova/boot/legacy/m0" || { echo 'Missing M0 boot source in guest' >&2; exit 3; }
KERNEL=$(find "$ROOTFS/boot" -maxdepth 1 -type f -name 'vmlinuz-*' | sort -V | tail -1)
INITRD=$(find "$ROOTFS/boot" -maxdepth 1 -type f -name 'initrd.img-*' | sort -V | tail -1)
[[ -f "$KERNEL" && -f "$INITRD" ]] || { echo 'ARM64 kernel or initrd missing' >&2; exit 3; }
sudo test -x "$ROOTFS/usr/bin/weston" || { echo 'Missing Weston' >&2; exit 3; }
sudo test -f "$ROOTFS/usr/lib/python3/dist-packages/PyQt5/QtWidgets.abi3.so" || sudo chroot "$ROOTFS" /usr/bin/python3 -c "from PyQt5 import QtWidgets" || { echo 'Missing native Qt GUI library' >&2; exit 3; }
sudo test -f "$ROOTFS/opt/nova/native-shell/nova_shell.py" || { echo 'Missing Nova native graphical application' >&2; exit 3; }

# Do not include a cross-arch emulator inside the shipped guest image.
echo '[7/8] Create sparse ext4 disk image'
sudo rm -f "$ROOTFS/usr/bin/qemu-aarch64-static"
truncate -s "${IMAGE_GIB}G" "$IMAGE"
sudo mkfs.ext4 -q -F -d "$ROOTFS" "$IMAGE"

echo '[8/8] STABILIZATION CANDIDATE IMAGE CREATED — NOT YET BOOT VERIFIED'
echo "Image: $IMAGE"
echo 'Run ./vm/run-arm64-qemu.sh on a graphical Ubuntu desktop.'
echo 'Expected: ARM64 Linux -> optional Nova early init -> systemd -> Nova services -> M3 if validated, otherwise Weston -> Nova Qt shell.'
echo 'Run python3 vm/smoke-arm64-qemu.py for automated boot, Rust runtime and Qt event-loop checks.'
echo 'If graphical display fails, check serial logs /home/nova/nova-desktop.log.'
