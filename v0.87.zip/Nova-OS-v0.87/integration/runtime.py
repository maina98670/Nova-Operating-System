"""Truthful Nova runtime catalog: source vs built vs installed vs running.

No arbitrary command execution. Original libraries are not services; acceptance-test tools
are never registered for automatic boot. Used by the graphical About/Components screen.
"""
from pathlib import Path
import json
import os
import subprocess

HERE=Path(__file__).resolve().parent
REGISTRY=HERE/'registry.json'

# Only the explicitly supported guest systemd unit names are queried.
UNITS=('nova-shell.service','nova-catalog.service','nova-runtime.service')

def _systemd_state(name):
    if not Path('/run/systemd/system').exists():
        return 'systemd-unavailable'
    try:
        p=subprocess.run(['systemctl','is-active',name],capture_output=True,text=True,timeout=2,check=False)
        return (p.stdout.strip() or 'unknown') if p.returncode==0 else (p.stdout.strip() or 'not-running')
    except (OSError,subprocess.TimeoutExpired):
        return 'not-verifiable'

def snapshot(binary_dir=None):
    registry=json.loads(REGISTRY.read_text())
    base=HERE.parent
    bin_root=Path(binary_dir or os.environ.get('NOVA_BIN_ROOT', '/opt/nova/bin' if Path('/opt/nova/bin').is_dir() else str(base/'native-bin')))
    component_details=[]
    counts={'source_present':0,'binary_installed':0,'libraries':0,'apps':0,'tools':0}
    for c in registry['components']:
        source_dir=base/'source-v0.60'/c['directory']
        source_present=(source_dir/'Cargo.toml').is_file()
        installed=(bin_root/c['name']).is_file() if c['has_binary'] else False
        status=('source_only' if source_present else 'source_missing')
        if c['kind']=='libs':
            status='library_source_available' if source_present else 'source_missing'
        elif installed:
            status='installed_binary_not_proven_running'
        counts['source_present']+=int(source_present)
        counts['binary_installed']+=int(installed)
        counts[{'libs':'libraries','apps':'apps','tools':'tools'}[c['kind']]]+=1
        component_details.append({'name':c['name'],'kind':c['kind'],
                                  'source_present':source_present,'binary_installed':installed,
                                  'status':status})
    milestone_path=Path('/etc/nova/milestones.json')
    try: milestones=json.loads(milestone_path.read_text()) if milestone_path.is_file() else None
    except (OSError, ValueError): milestones=None
    try: boot_cmdline=Path('/proc/cmdline').read_text()
    except OSError: boot_cmdline=''
    return {'release':'0.87',
            'source_count':len(component_details),
            'counts':counts,
            'guest_services':{u:_systemd_state(u) for u in UNITS},
            'nova_protocol_sockets':{name:(Path('/run/nova')/(name+'.sock')).is_socket() for name in ('app-manager','compositor')},
            'binary_root':str(bin_root),
            'components':component_details,
            'boot':{'kernel':'host Linux or guest Linux ARM64',
                    'pid1':'systemd after optional Nova early-init handoff in QEMU image',
                    'graphics':'Weston by default; M3 wlroots selectable only when ARM64 binary built',
                    'nova_init_pid1':False,'native_nova_compositor':False,'native_qt_shell':(base/'native-shell'/'nova_shell.py').is_file(),
                    'verified_arm64_boot':False,
                    'm0_m3_guest_staging':milestones,
                    'm2_early_init_requested':('init=/sbin/nova-early-init' in boot_cmdline)},
            'caveat':'Original Nova app executable presence does not mean the app runs as a graphical window. Modem/camera/GPU/touch drivers are device-specific.'}

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--bin-root')
    args=parser.parse_args()
    print(json.dumps(snapshot(args.bin_root),indent=2))
