"""Linux power observation and an explicit, local suspend adapter."""
import os
from pathlib import Path
import shutil
import subprocess


def status(sysfs='/sys'):
    root = Path(sysfs)
    try:
        states = (root/'power/state').read_text().split()
    except OSError:
        states = []
    supplies = []
    for folder in sorted((root/'class/power_supply').glob('*')):
        info = {'name': folder.name}
        for key in ('type','status','capacity','voltage_now','current_now','energy_now','power_now'):
            try:
                info[key] = (folder/key).read_text().strip()
            except OSError:
                pass
        supplies.append(info)
    return {'supported_sleep_states': states, 'power_supplies': supplies,
            'suspend_available': 'mem' in states and shutil.which('systemctl') is not None,
            'measurement_scope': 'Current Linux host or guest; not measured phone battery life'}


def suspend(*, confirm=False, environ=None, runner=None, sysfs='/sys'):
    env = os.environ if environ is None else environ
    if not confirm or env.get('NOVA_ENABLE_POWER_CONTROL') != '1':
        raise PermissionError('Suspend requires --confirm and NOVA_ENABLE_POWER_CONTROL=1 locally')
    if not status(sysfs)['suspend_available']:
        raise ValueError('Suspend is not available on this host')
    command = runner or subprocess.run
    result = command(['systemctl','suspend'], capture_output=True, text=True, timeout=30)
    if result.returncode:
        raise ValueError('The system power manager rejected suspend')
    return {'suspend_requested': True, 'wake_and_power_draw_verified': False}
