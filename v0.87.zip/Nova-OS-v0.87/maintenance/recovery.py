"""Reversible recovery of Nova data inside a dedicated maintenance workspace."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sqlite3
import stat
import tempfile
import time
import uuid
import zipfile
from .common import atomic_json, digest, locked, workspace

MAX_BACKUP = 128 * 1024 * 1024


def safe_name(name):
    path = PurePosixPath(name)
    return (bool(name) and not path.is_absolute() and '\\' not in name
            and all(part not in ('', '.', '..') for part in name.split('/')))


def _data(root):
    data = root/'userdata'
    if data.is_symlink():
        raise ValueError('User data must be a directory inside the workspace')
    data.mkdir(exist_ok=True, mode=0o700)
    return data


def snapshot(path):
    with locked(path) as root:
        data = _data(root)
        backups = root/'recovery/backups'
        backups.mkdir(parents=True, exist_ok=True, mode=0o700)
        name = 'nova-data-' + uuid.uuid4().hex + '.zip'
        output = backups/name
        stage = output.with_suffix('.tmp')
        manifest = {'schema': 1, 'created_at_unix': int(time.time()), 'files': {}}
        total = 0
        try:
            with tempfile.TemporaryDirectory(dir=backups) as temp, zipfile.ZipFile(stage, 'x', zipfile.ZIP_DEFLATED) as archive:
                for source in sorted(data.rglob('*')):
                    if source.is_symlink():
                        raise ValueError('Backup refuses symlinks')
                    if not source.is_file():
                        continue
                    rel = source.relative_to(data).as_posix()
                    if not safe_name(rel):
                        raise ValueError('Invalid data path')
                    # SQLite WAL files are replaced by one consistent SQLite snapshot.
                    if source.name.endswith(('-wal', '-shm')):
                        continue
                    copy = source
                    with source.open('rb') as stream:
                        is_sqlite = stream.read(16) == b'SQLite format 3\0'
                    if is_sqlite:
                        copy = Path(temp)/uuid.uuid4().hex
                        original = sqlite3.connect('file:'+str(source)+'?mode=ro', uri=True)
                        target = sqlite3.connect(copy)
                        try:
                            original.backup(target)
                        finally:
                            target.close(); original.close()
                    total += copy.stat().st_size
                    if total > MAX_BACKUP:
                        raise ValueError('Data backup exceeds 128 MB development limit')
                    manifest['files'][rel] = {'sha256': digest(copy), 'bytes': copy.stat().st_size}
                    archive.write(copy, 'data/'+rel)
                archive.writestr('manifest.json', json.dumps(manifest, sort_keys=True))
            stage.chmod(0o600)
            os.replace(stage, output)
        finally:
            stage.unlink(missing_ok=True)
        return {'name': name, 'bytes': output.stat().st_size, 'files': len(manifest['files']),
                'scope': 'Maintenance workspace userdata; not a complete phone backup'}


def recover(path, name):
    if not isinstance(name, str) or not __import__('re').fullmatch(r'nova-data-[0-9a-f]{32}\.zip', name):
        raise ValueError('Invalid backup identity')
    with locked(path) as root:
        if (root/'recovery-journal.json').exists():
            raise ValueError('Resolve interrupted recovery before applying another restore')
        source = root/'recovery/backups'/name
        if source.is_symlink() or not source.is_file():
            raise ValueError('Backup not found')
        stage = Path(tempfile.mkdtemp(prefix='.restore-', dir=root))
        try:
            with zipfile.ZipFile(source) as archive:
                infos = archive.infolist()
                if len(infos) > 5001 or len({x.filename for x in infos}) != len(infos):
                    raise ValueError('Duplicate or excessive backup entries')
                if any(not safe_name(x.filename) or stat.S_ISLNK(x.external_attr >> 16) for x in infos):
                    raise ValueError('Unsafe backup entry')
                if sum(x.file_size for x in infos) > MAX_BACKUP + 1024*1024:
                    raise ValueError('Backup expands beyond limit')
                manifest = json.loads(archive.read('manifest.json'))
                if manifest.get('schema') != 1 or not isinstance(manifest.get('files'), dict):
                    raise ValueError('Unsupported backup manifest')
                expected = {'manifest.json'} | {'data/'+x for x in manifest['files']}
                if expected != {x.filename for x in infos}:
                    raise ValueError('Backup entries do not match manifest')
                for rel, check in manifest['files'].items():
                    if not safe_name(rel):
                        raise ValueError('Unsafe backup data path')
                    out = stage/rel
                    out.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open('data/'+rel) as stream, out.open('xb') as target:
                        shutil.copyfileobj(stream, target)
                    out.chmod(0o600)
                    if out.stat().st_size != check.get('bytes') or digest(out) != check.get('sha256'):
                        raise ValueError('Backup data checksum mismatch')
            old = root/('userdata-before-'+uuid.uuid4().hex)
            live = _data(root)
            atomic_json(root/'recovery-journal.json', {'old': old.name, 'staged': stage.name})
            os.replace(live, old)
            try:
                os.replace(stage, live)
            except OSError:
                os.replace(old, live)
                raise
            (root/'recovery-journal.json').unlink()
            return {'restored': name, 'previous_data': old.name, 'live_data_changed': True}
        finally:
            if stage.exists() and not (root/'recovery-journal.json').exists():
                shutil.rmtree(stage)


def repair_interrupted_restore(path):
    with locked(path) as root:
        journal_path = root/'recovery-journal.json'
        if not journal_path.exists():
            return {'repaired': False}
        journal = json.loads(journal_path.read_text())
        old, stage = journal.get('old',''), journal.get('staged','')
        if not __import__('re').fullmatch(r'userdata-before-[0-9a-f]{32}', old):
            raise ValueError('Invalid recovery journal')
        if not stage.startswith('.restore-') or not safe_name(stage) or '/' in stage:
            raise ValueError('Invalid recovery staging path')
        if not (root/'userdata').exists():
            if not (root/old).is_dir() or (root/old).is_symlink():
                raise ValueError('Recovery journal has no usable previous data')
            os.replace(root/old, root/'userdata')
        if (root/stage).is_dir() and not (root/stage).is_symlink():
            shutil.rmtree(root/stage)
        journal_path.unlink()
        return {'repaired': True}


def factory_reset(path):
    """Reset only workspace data, retaining old data for a reversible recovery."""
    with locked(path) as root:
        if (root/'recovery-journal.json').exists():
            raise ValueError('Resolve interrupted recovery before reset')
        live = _data(root)
        previous = root/('userdata-before-'+uuid.uuid4().hex)
        os.replace(live, previous)
        try:
            live.mkdir(mode=0o700)
        except OSError:
            os.replace(previous, live)
            raise
        return {'reset': True, 'previous_data': previous.name,
                'scope': 'Workspace userdata only; no phone partitions changed'}
