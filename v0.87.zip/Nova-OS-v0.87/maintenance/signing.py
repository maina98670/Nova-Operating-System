"""Ed25519 file manifests. Trust comes from a separately pinned public key."""
import base64
import json
import os
from pathlib import Path
from .common import digest


def crypto():
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
        return serialization, Ed25519PrivateKey, Ed25519PublicKey, InvalidSignature
    except ImportError as exc:
        raise RuntimeError('Install python3-cryptography for release signing and verification') from exc


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')


def generate_keys(private_path, public_path):
    serialization, private_class, _, _ = crypto()
    private_path, public_path = Path(private_path), Path(public_path)
    if private_path.exists() or public_path.exists():
        raise ValueError('Key output already exists')
    key = private_class.generate()
    fd = os.open(private_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                      serialization.NoEncryption()))
    public_path.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,
                                                         serialization.PublicFormat.SubjectPublicKeyInfo))


def sign(manifest, private_path):
    serialization, private_class, _, _ = crypto()
    key = serialization.load_pem_private_key(Path(private_path).read_bytes(), password=None)
    if not isinstance(key, private_class):
        raise ValueError('An Ed25519 signing key is required')
    return base64.b64encode(key.sign(canonical(manifest))).decode('ascii')


def verify(manifest, signature, public_path):
    serialization, _, public_class, invalid_signature = crypto()
    try:
        key = serialization.load_pem_public_key(Path(public_path).read_bytes())
        if not isinstance(key, public_class):
            raise ValueError('An Ed25519 verification key is required')
        key.verify(base64.b64decode(signature, validate=True), canonical(manifest))
    except (invalid_signature, ValueError, TypeError) as exc:
        raise ValueError('Release signature verification failed') from exc
    return True
