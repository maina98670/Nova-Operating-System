"""Signed file-based A/B image slots for a dedicated QEMU development workspace.

No partitions are written or formatted. Physical bootloader slots, verified
boot and production OTA transport are not implemented by this module.
"""
import json
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile
import zipfile
import uuid
from .common import atomic_json, digest, locked, workspace
from .signing import sign, verify

FILES = ('rootfs.ext4', 'kernel', 'initramfs')
MAX_IMAGE_BYTES = 12 * 1024**3


def build_bundle(images, version, device, private_key, output):
    if set(images) != set(FILES) or not re.fullmatch(r'\d+\.\d{2}', version):
        raise ValueError('Supply rootfs.ext4, kernel, initramfs and a guide version')
    if not re.fullmatch(r'[a-zA-Z0-9_.-]{1,80}', device):
        raise ValueError('Invalid exact device identity')
    manifest = {'schema': 1, 'version': version, 'device': device,
                'layout': 'qemu-directory-ab', 'files': {}}
    for name, value in images.items():
        path = Path(value)
        if path.is_symlink() or not path.is_file() or not 0 < path.stat().st_size <= MAX_IMAGE_BYTES:
            raise ValueError('Missing, empty or oversized image: ' + name)
        manifest['files'][name] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    output = Path(output)
    if output.exists():
        raise ValueError('Refusing to replace an existing update bundle')
    stage = output.with_name('.' + output.name + '.tmp')
    try:
        with zipfile.ZipFile(stage, 'x', zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
            archive.writestr('manifest.json', json.dumps(manifest, sort_keys=True))
            archive.writestr('manifest.sig', sign(manifest, private_key))
            for name, path in images.items():
                archive.write(path, name)
        stage.chmod(0o600)
        os.replace(stage, output)
    finally:
        stage.unlink(missing_ok=True)
    return manifest


def unpack_bundle(bundle, destination, public_key, device):
    with zipfile.ZipFile(bundle) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(FILES) | {'manifest.json', 'manifest.sig'}:
            raise ValueError('Unexpected or duplicate update entries')
        for info in archive.infolist():
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) and not stat.S_ISREG(mode)):
                raise ValueError('Update entries must be regular files')
            limit = 65536 if info.filename.startswith('manifest.') else MAX_IMAGE_BYTES
            if not 0 < info.file_size <= limit:
                raise ValueError('Update entry size limit exceeded')
        manifest = json.loads(archive.read('manifest.json'))
        if not isinstance(manifest,dict):
            raise ValueError('Update manifest must be an object')
        verify(manifest, archive.read('manifest.sig').decode('ascii'), public_key)
        if (manifest.get('schema') != 1 or manifest.get('layout') != 'qemu-directory-ab'
                or manifest.get('device') != device or set(manifest.get('files', {})) != set(FILES)):
            raise ValueError('Update device or manifest layout does not match')
        if not re.fullmatch(r'\d+\.\d{2}', str(manifest.get('version', ''))):
            raise ValueError('Invalid update version')
        for name in FILES:
            expected = manifest['files'][name]
            if (not isinstance(expected,dict) or type(expected.get('bytes')) is not int
                    or not 0 < expected['bytes'] <= MAX_IMAGE_BYTES
                    or not re.fullmatch(r'[0-9a-f]{64}',str(expected.get('sha256','')))):
                raise ValueError('Invalid image checksum or size metadata')
            with archive.open(name) as source, (destination / name).open('xb') as target:
                shutil.copyfileobj(source, target, 1024 * 1024)
                target.flush()
                os.fsync(target.fileno())
            path = destination / name
            path.chmod(0o600)
            if path.stat().st_size != expected.get('bytes') or digest(path) != expected.get('sha256'):
                raise ValueError('Update checksum mismatch: ' + name)
        atomic_json(destination / 'manifest.json', manifest)
        return manifest


def initialize(path, bundle, public_key, device):
    root = workspace(path, create=True)
    try:
        with locked(root):
            (root/'slots').mkdir(mode=0o700)
            (root/'slots/A').mkdir(mode=0o700)
            manifest = unpack_bundle(bundle, root/'slots/A', public_key, device)
            atomic_json(root/'state.json', {'schema': 1, 'device': device, 'active': 'A',
                        'pending': None, 'last_good': 'A', 'attempts': 0,
                        'max_attempts': 2, 'generation': 1, 'version': manifest['version'],
                        'layout': 'qemu-directory-ab', 'bootloader_integrated': False})
        return status(root)
    except Exception:
        # Keep failed work visible, but it cannot be selected without state.json.
        raise


def state(root):
    value = json.loads((root/'state.json').read_text())
    if (value.get('schema') != 1 or value.get('active') not in ('A', 'B') or
            value.get('last_good') not in ('A', 'B') or value.get('pending') not in (None,'A','B') or
            type(value.get('attempts')) is not int or not 0 <= value['attempts'] <= 2 or
            value.get('max_attempts') != 2):
        raise ValueError('Invalid A/B state; recovery inspection required')
    return value


def status(path):
    root = workspace(path)
    result = state(root)
    result['scope'] = 'File-based QEMU images only; no physical bootloader integration'
    return result


def stage_update(path, bundle, public_key):
    with locked(path) as root:
        current = state(root)
        if current['pending']:
            raise ValueError('A pending image must be accepted or rolled back first')
        inactive = 'B' if current['active'] == 'A' else 'A'
        stage = Path(tempfile.mkdtemp(prefix='.stage-', dir=root/'slots'))
        try:
            manifest = unpack_bundle(bundle, stage, public_key, current['device'])
            active_manifest = json.loads((root/'slots'/current['active']/'manifest.json').read_text())
            if tuple(map(int,manifest['version'].split('.'))) <= tuple(map(int,active_manifest['version'].split('.'))):
                raise ValueError('Update version must be newer than the active image')
            old = root/'slots'/inactive
            if old.exists():
                shutil.rmtree(old)
            os.replace(stage, old)
            current.update(pending=inactive, attempts=0, generation=current['generation']+1)
            atomic_json(root/'state.json', current)
        finally:
            if stage.exists():
                shutil.rmtree(stage)
        return current


def select_boot(path):
    with locked(path) as root:
        current = state(root)
        rolled_back = False
        if current['pending'] and current['attempts'] >= current['max_attempts']:
            current.update(pending=None, attempts=0, active=current['last_good'])
            rolled_back = True
        slot = current['pending'] or current['active']
        manifest = json.loads((root/'slots'/slot/'manifest.json').read_text())
        for name in FILES:
            image = root/'slots'/slot/name
            if image.is_symlink() or digest(image) != manifest['files'][name]['sha256']:
                # Never boot a damaged pending image. Retain last known good.
                if current['pending']:
                    current.update(pending=None, attempts=0, active=current['last_good'])
                    atomic_json(root/'state.json', current)
                raise ValueError('Selected slot image integrity failed: ' + name)
        if current['pending']:
            current['attempts'] += 1
        # QEMU writes journal and filesystem metadata during every normal boot.
        # Preserve the signed template and run a separate writable development
        # copy; otherwise a successful first boot looks like image corruption.
        runtime = root/'runtime-disks'
        runtime.mkdir(exist_ok=True, mode=0o700)
        writable = runtime/(slot+'-'+manifest['version']+'-'+manifest['files']['rootfs.ext4']['sha256']+'.ext4')
        if writable.is_symlink():
            raise ValueError('Writable development disk cannot be a symlink')
        if not writable.exists():
            temporary = runtime/('.copy-'+uuid.uuid4().hex)
            try:
                shutil.copyfile(root/'slots'/slot/'rootfs.ext4',temporary)
                temporary.chmod(0o600)
                os.replace(temporary,writable)
            finally:
                temporary.unlink(missing_ok=True)
        atomic_json(root/'state.json', current)
        return {'slot': slot, 'rolled_back': rolled_back, 'pending': current['pending'],
                'images': {name: str(writable if name=='rootfs.ext4' else root/'slots'/slot/name) for name in FILES},
                'scope': 'Writable QEMU copies; shared guest userdata migration between slots is not implemented'}


def mark_healthy(path):
    with locked(path) as root:
        current = state(root)
        if not current['pending'] or current['attempts'] < 1:
            raise ValueError('No attempted pending image to acknowledge')
        selected = current['pending']
        manifest = json.loads((root/'slots'/selected/'manifest.json').read_text())
        for name in FILES:
            if digest(root/'slots'/selected/name) != manifest['files'][name]['sha256']:
                raise ValueError('Cannot mark a damaged slot healthy')
        current.update(active=selected, last_good=selected, pending=None, attempts=0,
                       version=manifest['version'])
        atomic_json(root/'state.json', current)
        return current


def rollback(path):
    with locked(path) as root:
        current = state(root)
        current.update(active=current['last_good'], pending=None, attempts=0)
        atomic_json(root/'state.json', current)
        return current
