#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -c "from maintenance.signing import crypto; crypto()"
exec bash scripts/check-v077.sh "$@"
