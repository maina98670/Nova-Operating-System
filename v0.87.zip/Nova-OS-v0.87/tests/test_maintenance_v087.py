"""End-to-end image workspace and data recovery tests, not physical boot tests."""
import importlib.util
import json
from pathlib import Path
import sqlite3
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from maintenance import updates,recovery
from maintenance.common import workspace,atomic_json
from maintenance.signing import generate_keys
from maintenance.power import suspend


@unittest.skipUnless(importlib.util.find_spec('cryptography'),'python3-cryptography is required')
class UpdateRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.private=self.root/'private.pem';self.public=self.root/'public.pem'
        generate_keys(self.private,self.public)
        self.images={}
        for name in updates.FILES:
            self.images[name]=self.root/name;self.images[name].write_bytes(('initial '+name).encode())
        self.first=self.root/'first.zip'
        updates.build_bundle(self.images,'0.80','qemu-virt-arm64',self.private,self.first)
        self.ws=self.root/'device-workspace'
        updates.initialize(self.ws,self.first,self.public,'qemu-virt-arm64')

    def candidate(self,version='0.87',device='qemu-virt-arm64'):
        out=self.root/('candidate-'+version+'.zip')
        for path in self.images.values():path.write_bytes(b'new test image '+path.name.encode())
        updates.build_bundle(self.images,version,device,self.private,out)
        return out

    def test_update_boot_acknowledgement_promotes_only_new_slot(self):
        initial=(self.ws/'slots/A/rootfs.ext4').read_bytes()
        updates.stage_update(self.ws,self.candidate(),self.public)
        self.assertEqual(updates.status(self.ws)['active'],'A')
        selected=updates.select_boot(self.ws)
        self.assertEqual(selected['slot'],'B')
        self.assertEqual((self.ws/'slots/A/rootfs.ext4').read_bytes(),initial)
        self.assertEqual(updates.mark_healthy(self.ws)['active'],'B')
        self.assertIsNone(updates.status(self.ws)['pending'])

    def test_failed_attempts_automatically_select_previous_good_slot(self):
        updates.stage_update(self.ws,self.candidate(),self.public)
        self.assertEqual(updates.select_boot(self.ws)['slot'],'B')
        self.assertEqual(updates.select_boot(self.ws)['slot'],'B')
        result=updates.select_boot(self.ws)
        self.assertTrue(result['rolled_back']);self.assertEqual(result['slot'],'A')

    def test_damaged_update_does_not_change_active_state(self):
        good=self.candidate();bad=self.root/'bad.zip'
        with zipfile.ZipFile(good) as source,zipfile.ZipFile(bad,'w') as target:
            for name in source.namelist():
                target.writestr(name,b'corrupt' if name=='kernel' else source.read(name))
        with self.assertRaisesRegex(ValueError,'checksum'):
            updates.stage_update(self.ws,bad,self.public)
        self.assertEqual(updates.status(self.ws)['active'],'A')
        self.assertIsNone(updates.status(self.ws)['pending'])

    def test_foreign_key_rejected(self):
        generate_keys(self.root/'other-private.pem',self.root/'other-public.pem')
        with self.assertRaisesRegex(ValueError,'signature'):
            updates.stage_update(self.ws,self.candidate(),self.root/'other-public.pem')

    def test_wrong_device_rejected(self):
        with self.assertRaisesRegex(ValueError,'device'):
            updates.stage_update(self.ws,self.candidate(device='different-phone'),self.public)

    def test_duplicate_or_traversal_payload_rejected(self):
        bundle=self.candidate();bad=self.root/'traversal.zip'
        with zipfile.ZipFile(bundle) as source,zipfile.ZipFile(bad,'w') as target:
            for name in source.namelist():target.writestr(name,source.read(name))
            target.writestr('../escape',b'bad')
        with self.assertRaises(ValueError):updates.stage_update(self.ws,bad,self.public)
        self.assertFalse((self.root/'escape').exists())

    def test_cannot_acknowledge_an_unbooted_slot(self):
        updates.stage_update(self.ws,self.candidate(),self.public)
        with self.assertRaisesRegex(ValueError,'attempted'):updates.mark_healthy(self.ws)

    def test_replay_version_rejected(self):
        with self.assertRaisesRegex(ValueError,'newer'):
            updates.stage_update(self.ws,self.first,self.public)

    def test_second_update_does_not_overwrite_pending_slot(self):
        bundle=self.candidate();updates.stage_update(self.ws,bundle,self.public)
        with self.assertRaisesRegex(ValueError,'pending'):updates.stage_update(self.ws,bundle,self.public)

    def test_damaged_pending_slot_is_not_selected(self):
        updates.stage_update(self.ws,self.candidate(),self.public)
        (self.ws/'slots/B/kernel').write_bytes(b'damaged after staging')
        with self.assertRaisesRegex(ValueError,'integrity'):updates.select_boot(self.ws)
        self.assertIsNone(updates.status(self.ws)['pending'])
        self.assertEqual(updates.select_boot(self.ws)['slot'],'A')

    def test_data_survives_failed_update_and_live_restore(self):
        data=self.ws/'userdata';data.mkdir();(data/'note.txt').write_text('important user data')
        backup=recovery.snapshot(self.ws)
        updates.stage_update(self.ws,self.candidate(),self.public)
        updates.select_boot(self.ws);updates.select_boot(self.ws);updates.select_boot(self.ws)
        self.assertEqual((data/'note.txt').read_text(),'important user data')
        (data/'note.txt').write_text('changed')
        result=recovery.recover(self.ws,backup['name'])
        self.assertTrue(result['live_data_changed'])
        self.assertEqual((data/'note.txt').read_text(),'important user data')
        self.assertEqual((self.ws/result['previous_data']/'note.txt').read_text(),'changed')

    def test_sqlite_wal_backup_preserves_committed_records(self):
        data=self.ws/'userdata';data.mkdir()
        connection=sqlite3.connect(data/'mobile.sqlite3')
        self.addCleanup(connection.close)
        connection.execute('PRAGMA journal_mode=WAL')
        connection.execute('CREATE TABLE notes(value TEXT)')
        connection.execute("INSERT INTO notes VALUES ('committed')");connection.commit()
        snap=recovery.snapshot(self.ws)
        connection.close()
        recovery.recover(self.ws,snap['name'])
        with sqlite3.connect(data/'mobile.sqlite3') as restored:
            self.assertEqual(restored.execute('SELECT value FROM notes').fetchone()[0],'committed')

    def test_reset_is_scoped_and_keeps_previous_data(self):
        data=self.ws/'userdata';data.mkdir();(data/'note').write_text('keep')
        reset=recovery.factory_reset(self.ws)
        self.assertEqual(list(data.iterdir()),[])
        self.assertEqual((self.ws/reset['previous_data']/'note').read_text(),'keep')
        self.assertEqual(updates.status(self.ws)['active'],'A')

    def test_interrupted_restore_recovers_previous_data(self):
        old=self.ws/('userdata-before-'+'a'*32);old.mkdir();(old/'note').write_text('recover me')
        stage=self.ws/'.restore-interrupted';stage.mkdir()
        atomic_json(self.ws/'recovery-journal.json',{'old':old.name,'staged':stage.name})
        self.assertTrue(recovery.repair_interrupted_restore(self.ws)['repaired'])
        self.assertEqual((self.ws/'userdata/note').read_text(),'recover me')
        self.assertFalse(stage.exists())

    def test_backup_refuses_symlink_outside_userdata(self):
        data=self.ws/'userdata';data.mkdir();(data/'escape').symlink_to(self.private)
        with self.assertRaisesRegex(ValueError,'symlink'):recovery.snapshot(self.ws)

    def test_workspace_cannot_be_an_existing_user_directory(self):
        with self.assertRaises(ValueError):workspace(self.root,create=True)
        with self.assertRaises(ValueError):workspace('/')

    def test_suspend_is_disabled_without_explicit_local_opt_in(self):
        calls=[]
        with self.assertRaises(PermissionError):suspend(confirm=False,environ={},runner=lambda *a,**k:calls.append(a))
        with self.assertRaises(PermissionError):suspend(confirm=True,environ={},runner=lambda *a,**k:calls.append(a))
        self.assertEqual(calls,[])

    def test_qemu_runner_uses_verified_slot_paths(self):
        fake_dir=self.root/'bin';fake_dir.mkdir()
        fake=fake_dir/'qemu-system-aarch64'
        fake.write_text('#!/usr/bin/env python3\nimport sys,json\nprint(json.dumps(sys.argv[1:]))\n')
        fake.chmod(0o755)
        env={**os.environ,'PATH':str(fake_dir)+os.pathsep+os.environ.get('PATH',''),
             'NOVA_UPDATE_WORKSPACE':str(self.ws),'NOVA_ENABLE_M2_INIT':'0'}
        run=subprocess.run(['bash',str(ROOT/'vm/run-arm64-qemu.sh'),'--headless'],env=env,
                           capture_output=True,text=True)
        self.assertEqual(run.returncode,0,run.stderr)
        arguments=json.loads(run.stdout.splitlines()[-1])
        self.assertEqual(arguments[arguments.index('-kernel')+1],str(self.ws/'slots/A/kernel'))
        self.assertIn(str(self.ws/'runtime-disks'),arguments[arguments.index('-drive')+1])

    def test_writable_guest_disk_does_not_modify_signed_template(self):
        selected=updates.select_boot(self.ws)
        Path(selected['images']['rootfs.ext4']).write_bytes(b'normal guest writes')
        second=updates.select_boot(self.ws)
        self.assertEqual(Path(second['images']['rootfs.ext4']).read_bytes(),b'normal guest writes')
        self.assertEqual((self.ws/'slots/A/rootfs.ext4').read_bytes(),b'initial rootfs.ext4')


if __name__=='__main__':unittest.main()
