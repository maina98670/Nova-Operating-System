"""v0.87 regression: OS guest's strict preview API login boundary.

This is HTTP session isolation only, not Linux process isolation.
"""
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request

ROOT=Path(__file__).resolve().parents[1]

class StrictGuestAuthTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='nova77-refined-')
        base=Path(cls.tmp.name)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        cls.addr=f'http://127.0.0.1:{port}'
        env={**os.environ,'NOVA_CONFIG_DIR':str(base/'config'),
             'NOVA_FILES_ROOT':str(base/'files'),'NOVA_ENFORCE_AUTH':'1',
             'NOVA_COLAB_MODE':'0'}
        cls.proc=subprocess.Popen([sys.executable,str(ROOT/'graphics-shell/server.py'),
                 '--no-browser','--port',str(port)],cwd=ROOT,env=env,
                 stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        for _ in range(80):
            try:
                page=urllib.request.urlopen(cls.addr,timeout=.5).read().decode()
                cls.token=re.search(r'name="nova-token" content="([^"]+)"',page).group(1)
                break
            except Exception:
                time.sleep(.1)
        else:
            raise RuntimeError('Nova server failed to start')
        cls.session=None

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate()
        cls.proc.communicate(timeout=5)
        cls.tmp.cleanup()

    def req(self,url,body=None,session=None):
        hdr={'X-Nova-Web-Session':session if session is not None else (self.session or '')}
        if body is not None:
            hdr['X-Nova-Token']=self.token
            hdr['Content-Type']='application/json'
        request=urllib.request.Request(self.addr+url,
           data=json.dumps(body).encode() if body is not None else None,
           headers=hdr)
        with urllib.request.urlopen(request,timeout=5) as r:return json.load(r)

    def test_01_setup_is_public_but_data_private(self):
        self.assertTrue(self.req('/api/account/status')['setup_required'])
        for path in ('/api/files','/api/system','/api/platform/performance','/api/settings',
                     '/api/platform/acceptance','/api/notifications','/api/backups'):
            with self.subTest(path=path), self.assertRaises(urllib.error.HTTPError) as failure:
                self.req(path)
            self.assertEqual(failure.exception.code,403)

    def test_02_setup_and_legacy_guard(self):
        created=self.req('/api/account/create',{'name':'Guest','password':'Correct-123456'})
        type(self).session=created['session']
        self.assertEqual(self.req('/api/settings')['theme'],'dark')
        self.assertTrue(self.req('/api/platform/acceptance')['source_tests_are_not_boot_tests'])
        self.assertFalse(self.req('/api/platform/acceptance')['ready_for_phone_hardware'])
        with self.assertRaises(urllib.error.HTTPError) as failure:
            self.req('/api/files',session='unauthenticated')
        self.assertEqual(failure.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as failure:
            self.req('/api/settings',{'theme':'light'},session='unauthenticated')
        self.assertEqual(failure.exception.code,403)

    def test_03_measured_performance_not_claimed(self):
        metrics=self.req('/api/platform/performance')
        self.assertIn('ram',metrics)
        self.assertFalse(metrics['targets_measured'])
        self.assertIn('backend',metrics['warning'].lower())
        evidence=self.req('/api/platform/acceptance')
        self.assertEqual(evidence['manual_gates']['qemu_arm64_graphical_boot'],'unverified')
        self.assertEqual(evidence['manual_gates']['android_apk_install_launch_uninstall'],'unverified')

    def test_04_logout_revokes_data_access(self):
        self.req('/api/account/logout',{})
        with self.assertRaises(urllib.error.HTTPError) as failure:
            self.req('/api/files')
        self.assertEqual(failure.exception.code,403)
        type(self).session=self.req('/api/account/login',{'password':'Correct-123456'})['session']
        self.assertEqual(self.req('/api/settings')['theme'],'dark')

if __name__=='__main__':unittest.main()
