"""Source release packaging and evidence checks for the literal guide finish line."""
import json
import os
from pathlib import Path
import stat
import zipfile
from .common import atomic_json, digest
from .signing import sign, verify

REQUIREMENTS = ('repeatable_installation','reliable_boot_recovery','stable_core_services',
                'application_isolation','predictable_files_permissions','stable_networking',
                'responsive_gui','safe_updates_rollback','tested_security_boundaries',
                'hardware_compatibility','documented_limitations','memory_budget_1gb')


def acceptance(evidence_path, source_sha256):
    path = Path(evidence_path).resolve()
    if not path.is_file():
        return {'accepted': False, 'blockers': ['Final guide acceptance evidence is missing']}
    data = json.loads(path.read_text())
    if not isinstance(data,dict):
        return {'accepted':False,'blockers':['Final acceptance evidence must be an object']}
    errors = []
    if data.get('schema') != 1 or data.get('source_sha256') != source_sha256:
        errors.append('Evidence does not identify the current source revision')
    device = data.get('device_id')
    if not isinstance(device,str) or not device.strip():
        errors.append('An exact tested reference device is required')
    for name in REQUIREMENTS:
        item = data.get('checks',{}).get(name,{})
        if not isinstance(item,dict) or item.get('status') != 'passed' or item.get('device_id') != device:
            errors.append(name + ': no passed test on the reference device')
            continue
        rel = item.get('evidence_file','')
        target = (path.parent/rel).resolve()
        if (not rel or Path(rel).is_absolute() or not target.is_relative_to(path.parent)
                or not target.is_file() or target.is_symlink()):
            errors.append(name + ': test evidence file is missing')
        elif digest(target) != item.get('sha256'):
            errors.append(name + ': evidence checksum mismatch')
    soak = data.get('soak',{})
    if (soak.get('device_id') != device or soak.get('completed') is not True
            or type(soak.get('actual_duration_seconds')) not in (int,float)
            or soak['actual_duration_seconds'] < 172800
            or soak.get('crashes') != 0 or soak.get('memory_budget_passed') is not True):
        errors.append('A completed two-day physical 1 GB device soak with memory results is required')
    return {'accepted': not errors, 'blockers': errors,
            'scope': 'Validation of operator-recorded evidence; not independent certification'}


def source_archive(root, output, version):
    root, output = Path(root).resolve(), Path(output).resolve()
    if output.is_relative_to(root) or output.exists():
        raise ValueError('Use a new output path outside the source tree')
    output.parent.mkdir(parents=True, exist_ok=True)
    # Reproducible ZIP timestamps and stable file order. Runtime data and keys
    # are excluded even if a developer accidentally put them in the source tree.
    with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for file in sorted(root.rglob('*')):
            rel = file.relative_to(root)
            if (any(part in ('__pycache__','.git','target','.pytest_cache','out','node_modules') for part in rel.parts)
                    or file.suffix in ('.pem','.key','.sqlite3','.db','.pyc') or file.is_symlink()
                    or not file.is_file()):
                continue
            info = zipfile.ZipInfo('Nova-OS-v'+version+'/'+rel.as_posix(), (1980,1,1,0,0,0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | stat.S_IMODE(file.stat().st_mode)) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            # Stream preserved archives rather than materializing them twice.
            with file.open('rb') as source, archive.open(info,'w',force_zip64=True) as target:
                __import__('shutil').copyfileobj(source,target,1024*1024)
    return {'artifact_type': 'source_archive', 'version': version, 'file': output.name,
            'bytes': output.stat().st_size, 'sha256': digest(output),
            'bootable_image': False, 'production_stable': False}


def signed_manifest(manifest, private_key, public_key, output):
    output = Path(output)
    if output.exists():
        raise ValueError('Signed manifest output already exists')
    signature = sign(manifest, private_key)
    verify(manifest, signature, public_key)
    value = {'manifest': manifest, 'signature_algorithm': 'Ed25519', 'signature': signature,
             'trust_note': 'Pin a public key independently; a key bundled with an archive alone does not prove publisher identity'}
    atomic_json(output, value)
    return value


def verify_archive(archive, signed_path, public_key):
    value = json.loads(Path(signed_path).read_text())
    manifest = value['manifest']
    verify(manifest,value['signature'],public_key)
    if Path(archive).stat().st_size != manifest['bytes'] or digest(archive) != manifest['sha256']:
        raise ValueError('Release artifact size or checksum mismatch')
    return {'verified': True, 'version': manifest['version'],
            'artifact_type': manifest['artifact_type'], 'production_stable': manifest['production_stable']}
