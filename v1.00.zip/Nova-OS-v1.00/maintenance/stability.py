"""Timed observations; short checks never become a multi-day soak result."""
import json
import os
from pathlib import Path
import time
import urllib.parse
import urllib.request
from .common import atomic_json


def metrics():
    memory = {}
    try:
        for line in Path('/proc/meminfo').read_text().splitlines():
            key, _, value = line.partition(':')
            if key in ('MemTotal','MemAvailable'):
                memory[key] = int(value.split()[0]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    try:
        uptime = float(Path('/proc/uptime').read_text().split()[0])
    except (OSError, ValueError, IndexError):
        uptime = None
    try:
        boot_id = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    except OSError:
        boot_id = None
    return {'at_unix': time.time(), 'memory_bytes': memory, 'uptime_seconds': uptime,
            'boot_id': boot_id, 'load_average': list(os.getloadavg())}


def local_health(url):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1','localhost','::1')
            or parsed.username or parsed.password or parsed.query or parsed.fragment):
        raise ValueError('Health polling is restricted to a plain local HTTP endpoint')
    try:
        with urllib.request.urlopen(url, timeout=2) as response:
            value = json.load(response)
        return value.get('ready') is True
    except (OSError, ValueError, AttributeError):
        return False


def collect(output, *, duration=1, interval=1, device_id=None, health_url=None):
    if not 0 < duration <= 7*86400 or not 0 < interval <= 3600:
        raise ValueError('Duration must be positive and at most 7 days; interval at most 1 hour')
    if duration/interval > 100000:
        raise ValueError('Too many planned observations')
    if health_url:
        # Reject a remote target even if the first measurement never happens.
        parsed = urllib.parse.urlsplit(health_url)
        if parsed.hostname not in ('127.0.0.1','localhost','::1'):
            raise ValueError('Health polling must stay local')
    output = Path(output)
    if output.exists() or output.with_suffix('.samples.jsonl').exists():
        raise ValueError('Use a new output path for every stability run')
    output.parent.mkdir(parents=True, exist_ok=True)
    samples_path = output.with_suffix('.samples.jsonl')
    start = time.monotonic()
    result = {'schema': 1, 'state': 'running', 'started_at_unix': time.time(),
              'requested_duration_seconds': duration, 'actual_duration_seconds': 0,
              'device_id_declared': device_id, 'physical_device_independently_verified': False,
              'samples': 0, 'health_failures': 0, 'reboot_observed': False,
              'multi_day_soak_completed': False, 'sample_log': samples_path.name}
    atomic_json(output, result)
    first_boot = None
    try:
        with samples_path.open('x') as stream:
            samples_path.chmod(0o600)
            while True:
                sample = metrics()
                if first_boot is None:
                    first_boot = sample['boot_id']
                elif sample['boot_id'] != first_boot:
                    result['reboot_observed'] = True
                if health_url:
                    sample['backend_healthy'] = local_health(health_url)
                    result['health_failures'] += int(not sample['backend_healthy'])
                stream.write(json.dumps(sample, sort_keys=True)+'\n')
                stream.flush()
                result['samples'] += 1
                elapsed = time.monotonic()-start
                result['actual_duration_seconds'] = elapsed
                atomic_json(output, result)
                if elapsed >= duration:
                    break
                time.sleep(min(interval, duration-elapsed))
        result['state'] = 'completed'
    except BaseException:
        result['state'] = 'interrupted'
        raise
    finally:
        result['actual_duration_seconds'] = time.monotonic()-start
        # Elapsed time is necessary, but not sufficient for guide acceptance.
        # Memory leak, power/wake and physical reference device evidence are separate.
        result['multi_day_soak_completed'] = (result['state']=='completed'
            and result['actual_duration_seconds'] >= 172800 and result['health_failures']==0
            and not result['reboot_observed'])
        result['guide_m16_accepted'] = False
        atomic_json(output, result)
    return result
