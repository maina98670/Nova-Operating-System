"""Watch only a child launched by this tool; never arbitrary host services."""
import os
from pathlib import Path
import signal
import subprocess
import time
from .common import atomic_json


def supervise(command, output, *, timeout=10, workspace=None):
    if not command or not 0.05 <= timeout <= 3600:
        raise ValueError('Supply a child command and a timeout from 0.05 to 3600 seconds')
    output = Path(output)
    if output.exists():
        raise ValueError('Crash report already exists')
    started = time.monotonic()
    child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
    timed_out = False
    try:
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=2)
        report = {'schema': 1, 'at_unix': int(time.time()), 'child_pid': child.pid,
                  'exit_code': code, 'timeout': timed_out,
                  'duration_seconds': time.monotonic()-started,
                  'unexpected_exit': code != 0, 'recovery_action': None,
                  'logs_collected': False,
                  'scope': 'This launched child only; no OS-wide hang detection'}
        if workspace and (timed_out or code != 0):
            from .updates import rollback
            rollback(workspace)
            report['recovery_action'] = 'directory-ab-pending-update-rolled-back'
        atomic_json(output, report)
        return report
    finally:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=2)
