#!/usr/bin/env python3
"""Read-only Nova v1.00 boot-to-home diagnostics inside the ARM64 QEMU guest.

This reports observed components; source presence is not boot proof, and a
Qt DOM heartbeat is not independent proof of visible pixels.
"""
from __future__ import annotations
import json
from pathlib import Path
import subprocess
import sys
import urllib.request


def read(path):
    try:return Path(path).read_text(errors='replace').strip()
    except OSError:return ''


def service(name):
    try:
        run=subprocess.run(['systemctl','is-active',name],capture_output=True,
                           text=True,timeout=3,check=False)
        return run.stdout.strip() or 'unknown'
    except (OSError,subprocess.TimeoutExpired):return 'unavailable'


def main():
    units=['nova-shell.service','nova-runtime.service','nova-catalog.service',
           'nova-reminders.service','getty@tty1.service']
    boot_conf=read('/etc/nova/boot.conf')
    m3_backend='nova' if 'NOVA_COMPOSITOR=nova' in boot_conf else 'weston'
    data={'release':'1.00',
          'guest_kernel':read('/proc/sys/kernel/osrelease') or 'unknown',
          'kernel_init_argument':'init=/sbin/nova-early-init' in read('/proc/cmdline'),
          'pid1_name':read('/proc/1/comm') or 'unavailable',
          'm1_splash_staged':Path('/opt/nova/bin/nova-splash').is_file(),
          'm2_early_init_staged':Path('/sbin/nova-early-init').is_file(),
          'm3_requested':m3_backend,
          'm3_binary_staged':Path('/opt/nova/bin/nova-display').is_file(),
          'services':{unit:service(unit) for unit in units},
          'wayland_socket_candidates': sorted(
              str(p) for p in Path('/run/user').glob('*/wayland-*') if p.is_socket()),
          'backend_health':None,
          'ui_dom_verified':False,
          'ui_phase':'unavailable',
          'home_screen_verified':False,
          'pixels_manually_verified':False,
          'device_flash_ready':False}
    try:
        with urllib.request.urlopen('http://127.0.0.1:8767/api/health',timeout=3) as r:
            health=json.load(r)
        data['backend_health']=bool(health.get('ready'))
        data['ui_dom_verified']=bool(health.get('gui_dom_verified'))
        data['ui_phase']=health.get('gui_phase','unavailable')
        data['app_tile_count']=health.get('gui_app_tile_count',0)
        data['home_screen_verified']=bool(data['ui_dom_verified'] and data['ui_phase']=='home')
    except Exception as ex:
        data['backend_error']=str(ex)
    if not data['backend_health']:
        data['next_step']='Check journalctl -u nova-shell.service -b --no-pager'
    elif not data['ui_dom_verified']:
        data['next_step']='Check /home/nova/nova-desktop.log and the Weston/M3 logs'
    elif data['ui_phase']=='login':
        data['next_step']='Nova sign-in is displayed; sign in using the QEMU graphical screen'
    else:
        data['next_step']='Inspect the QEMU display to confirm pixels and interactive apps'
    print(json.dumps(data,indent=2))
    return 0 if data['ui_dom_verified'] else 2

if __name__=='__main__':sys.exit(main())
