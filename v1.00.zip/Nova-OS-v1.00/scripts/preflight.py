#!/usr/bin/env python3
"""Pre-hardware Nova release gates: structured evidence, never invents boot success."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSIONS = ['v0.07','v0.13','v0.20','v0.27','v0.33','v0.40','v0.47','v0.53','v0.60']


def source_report():
    checks={}
    ws=ROOT/'source-v0.60'
    members=tomllib.loads((ws/'Cargo.toml').read_text())['workspace']['members']
    checks['104_original_modules']=(len(members)==104 and len(set(members))==104 and all((ws/m/'Cargo.toml').is_file() for m in members))
    checks['historical_archives']=all((ROOT/'history/snapshots'/f'{v}.zip').is_file() for v in VERSIONS)
    checks['historical_archives_integrity']=all(zipfile.ZipFile(ROOT/'history/snapshots'/f'{v}.zip').testzip() is None for v in VERSIONS)
    checks['m0_to_m3_preserved']=all((ROOT/'boot/legacy'/m).is_dir() for m in ('m0','m1','m2','m3'))
    checks['native_qt_source']=all((ROOT/p).is_file() for p in ('native-shell/nova_shell.py','native-shell/backend.py'))
    checks['kernel_image_builder']=(ROOT/'vm/build-arm64-qemu.sh').is_file()
    checks['nova_service_bridge']=all((ROOT/p).is_file() for p in ('native-bridge/src/main.rs','native-runtime/src/main.rs'))
    checks['weston_session']=(ROOT/'vm/guest/nova-desktop-session').is_file()
    checks['boot_smoke_harness']=(ROOT/'vm/smoke-arm64-qemu.py').is_file()
    syntax_errors={}
    for path in list((ROOT/'scripts').glob('*.sh')) + list((ROOT/'vm').glob('*.sh')) + list((ROOT/'vm/guest').glob('nova-desktop-session')):
        proc=subprocess.run(['bash','-n',str(path)],capture_output=True,text=True)
        if proc.returncode: syntax_errors[str(path.relative_to(ROOT))]=proc.stderr
    checks['shell_syntax']=not bool(syntax_errors)
    return {'source_checks':checks,'workspace_modules':len(members),'syntax_errors':syntax_errors,
            'source_verified':all(checks.values())}


def boot_report():
    out=ROOT/'vm/out'
    image=out/'nova-arm64.ext4'
    boot=out/'rootfs/boot'
    return {'disk_image_exists':image.is_file(),
            'kernel_image_exists':bool(list(boot.glob('vmlinuz-*'))),
            'initramfs_exists':bool(list(boot.glob('initrd.img-*'))),
            'boot_runtime_observed':False,
            'note':'Runtime boot observation is written by vm/smoke-arm64-qemu.py; file checks alone do not verify a boot.'}


def main():
    a=argparse.ArgumentParser();a.add_argument('--strict-source',action='store_true');a.add_argument('--output');args=a.parse_args()
    report={'release':'Nova OS v1.00 Integration Foundation', 'classification':'development release candidate; NOT smartphone production ready',
            **source_report(),'arm64':boot_report(),
            'limitations':['QEMU boot not verified until smoke harness passes on Ubuntu',
                           'Linux kernel; original M2 supervisor is not permanent PID 1 (optional Nova early PID1 handoff execs systemd)',
                           'Weston is default graphics compositor; original wlroots M3 selectable only after compatible ARM64 build and live display test',
                           'Original CLI apps are not all standalone native graphical applications',
                           'Production app sandbox, OTA, modem, calls, SMS, camera and phone hardware drivers are unfinished']}
    result=json.dumps(report,indent=2)
    print(result)
    if args.output:
        Path(args.output).write_text(result+'\n')
    if args.strict_source and not report['source_verified']:
        return 1
    return 0

if __name__=='__main__':sys.exit(main())
