#!/usr/bin/env python3
"""Verify the packaged v1.00 file manifest. Detects missing/changed source assets.

This is NOT a trusted publisher signature; verify ZIP provenance separately.
"""
import argparse
import hashlib
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'MANIFEST.sha256'
SKIP={'MANIFEST.sha256'}

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()

def current():
    return {p.relative_to(ROOT).as_posix():digest(p) for p in ROOT.rglob('*')
            if p.is_file() and not p.is_symlink() and
            '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and
            p.relative_to(ROOT).as_posix() not in SKIP and
            not p.relative_to(ROOT).as_posix().startswith('vm/out/') and
            not p.name.startswith('verification-report-') and
            not p.relative_to(ROOT).as_posix().startswith('native-bridge/target/')}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--write',action='store_true')
    args=ap.parse_args()
    got=current()
    if args.write:
        MANIFEST.write_text(''.join(f'{hash0}  {path}\n' for path,hash0 in sorted(got.items())))
        print('Wrote',len(got),'file hashes to',MANIFEST)
        return 0
    if not MANIFEST.exists():
        print('Missing source manifest',file=sys.stderr);return 2
    expected={}
    for line in MANIFEST.read_text().splitlines():
        if not line.strip():continue
        value,name=line.split('  ',1)
        expected[name]=value
    altered=[name for name in sorted(set(expected)|set(got)) if expected.get(name)!=got.get(name)]
    if altered:
        print('Source archive differs from recorded manifest:',altered[:20],file=sys.stderr)
        return 1
    print('Source manifest verified:',len(got),'files')
    print('Note: Checksums detect accidental changes, not malicious replacement of manifest and files.')
    return 0
if __name__=='__main__':raise SystemExit(main())
