"""Short real-time observation tests do not claim a physical multi-day soak."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from maintenance.stability import collect,local_health
from maintenance.hardware import observations,validate_evidence


class StabilityHardwareTests(unittest.TestCase):
    def test_short_real_run_records_time_without_accepting_m16(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'short.json'
            result=collect(path,duration=.03,interval=.01)
            self.assertGreaterEqual(result['actual_duration_seconds'],.03)
            self.assertGreaterEqual(result['samples'],2)
            self.assertFalse(result['multi_day_soak_completed'])
            self.assertFalse(result['guide_m16_accepted'])
            self.assertEqual(json.loads(path.read_text())['state'],'completed')
            self.assertTrue(path.with_suffix('.samples.jsonl').is_file())

    def test_remote_health_poll_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'local'):local_health('https://example.org/api/health')

    def test_invalid_soak_parameters_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            for duration,interval in ((0,1),(1,0),(8*86400,60),(86400,.001)):
                with self.assertRaises(ValueError):collect(Path(tmp)/'no.json',duration=duration,interval=interval)

    def test_existing_soak_evidence_cannot_be_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'keep.json';path.write_text('original')
            with self.assertRaises(ValueError):collect(path,duration=.01)
            self.assertEqual(path.read_text(),'original')

    def test_hardware_nodes_never_automatically_pass_components(self):
        result=observations()
        self.assertFalse(result['device_functions_verified'])
        self.assertTrue(all(x=='unverified' for x in result['components'].values()))

    def test_empty_hardware_evidence_cannot_pass_integration(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'evidence.json';path.write_text('{}')
            result=validate_evidence(path,integration=True)
            self.assertFalse(result['accepted'])
            self.assertGreater(len(result['blockers']),10)


if __name__=='__main__':unittest.main()
