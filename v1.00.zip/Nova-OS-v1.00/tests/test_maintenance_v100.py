"""Signed source release and launched-child watchdog checks."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from maintenance.release import acceptance,source_archive,signed_manifest,verify_archive
from maintenance.signing import generate_keys
from maintenance.watchdog import supervise


class ReleaseWatchdogTests(unittest.TestCase):
    def test_real_hung_child_is_terminated_and_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=supervise([sys.executable,'-c','import time;time.sleep(30)'],Path(tmp)/'hang.json',timeout=.08)
            self.assertTrue(report['timeout'])
            self.assertNotEqual(report['exit_code'],0)
            self.assertLess(report['duration_seconds'],5)
            self.assertFalse(report['logs_collected'])

    def test_crashing_child_produces_private_crash_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'crash.json'
            report=supervise([sys.executable,'-c','raise RuntimeError("test")'],path,timeout=2)
            self.assertTrue(report['unexpected_exit']);self.assertFalse(report['timeout'])
            self.assertEqual(path.stat().st_mode&0o777,0o600)

    def test_successful_child_does_not_trigger_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=supervise([sys.executable,'-c','pass'],Path(tmp)/'ok.json',timeout=2)
            self.assertEqual(report['exit_code'],0)
            self.assertIsNone(report['recovery_action'])

    def test_hung_child_triggers_pending_update_rollback(self):
        from maintenance.updates import FILES,build_bundle,initialize,stage_update,status
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            generate_keys(base/'key.pem',base/'public.pem')
            images={name:base/name for name in FILES}
            for name,path in images.items():path.write_bytes(name.encode())
            build_bundle(images,'0.80','qemu-virt-arm64',base/'key.pem',base/'old.zip')
            build_bundle(images,'0.87','qemu-virt-arm64',base/'key.pem',base/'new.zip')
            initialize(base/'workspace',base/'old.zip',base/'public.pem','qemu-virt-arm64')
            stage_update(base/'workspace',base/'new.zip',base/'public.pem')
            result=supervise([sys.executable,'-c','import time;time.sleep(30)'],base/'hang.json',
                             timeout=.08,workspace=base/'workspace')
            self.assertEqual(result['recovery_action'],'directory-ab-pending-update-rolled-back')
            self.assertIsNone(status(base/'workspace')['pending'])

    def test_source_packages_are_reproducible_and_exclude_keys(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);root=base/'src';root.mkdir()
            (root/'hello.py').write_text('print("Nova")\n')
            (root/'secret.pem').write_text('private key must not ship')
            a=source_archive(root,base/'one.zip','1.00')
            b=source_archive(root,base/'two.zip','1.00')
            self.assertEqual(a['sha256'],b['sha256'])
            self.assertFalse(a['bootable_image'])
            with zipfile.ZipFile(base/'one.zip') as z:
                self.assertNotIn('Nova-OS-v1.00/secret.pem',z.namelist())

    def test_signed_release_verifies_and_detects_artifact_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);root=base/'src';root.mkdir();(root/'test.py').write_text('pass\n')
            manifest=source_archive(root,base/'release.zip','1.00')
            generate_keys(base/'key.pem',base/'public.pem')
            signed_manifest(manifest,base/'key.pem',base/'public.pem',base/'signed.json')
            self.assertTrue(verify_archive(base/'release.zip',base/'signed.json',base/'public.pem')['verified'])
            (base/'release.zip').write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError,'checksum'):verify_archive(base/'release.zip',base/'signed.json',base/'public.pem')

    def test_final_acceptance_cannot_be_inferred_from_a_version_label(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);path=base/'evidence.json'
            path.write_text(json.dumps({'schema':1,'version':'1.00','source_sha256':'a'*64,'checks':{}}))
            gate=acceptance(path,'a'*64)
            self.assertFalse(gate['accepted']);self.assertGreater(len(gate['blockers']),10)


if __name__=='__main__':unittest.main()
