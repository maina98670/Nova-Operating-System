"""Native GUI transport integration tests, requires only standard Python."""
import importlib.util
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
SHELL=ROOT/'native-shell'
sys.path.insert(0,str(SHELL))
from backend import NovaClient, NovaApiError

class NativeTransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0))
            cls.port=sock.getsockname()[1]
        env={**os.environ,'NOVA_CONFIG_DIR':cls.tmp.name+'/config','NOVA_FILES_ROOT':cls.tmp.name+'/files','NOVA_BRIDGE_BIN':cls.tmp.name+'/missing-bridge'}
        cls.server=subprocess.Popen([sys.executable,str(ROOT/'graphics-shell/server.py'),'--port',str(cls.port),'--no-browser'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        cls.client=NovaClient('http://127.0.0.1:'+str(cls.port))
        for i in range(70):
            try:
                cls.status=cls.client.connect();break
            except NovaApiError:time.sleep(.1)
        else:raise AssertionError('Could not start Nova backend')

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate();cls.server.wait(timeout=5);cls.tmp.cleanup()

    def test_01_native_transport_authentication(self):
        self.assertTrue(self.client.token)
        self.assertIn('connected',self.status)
        self.assertIn('1.00',self.client.get('/api/system')['version'])
        invalid=NovaClient(self.client.base,token='bad')
        with self.assertRaises(NovaApiError):invalid.post('/api/settings',{'name':'bad'})

    def test_02_native_settings_and_notes(self):
        self.assertEqual(self.client.post('/api/settings',{'accent':'teal'})['accent'],'teal')
        saved=self.client.post('/api/notes/save',{'title':'Native test','content':'Real storage'})
        self.assertEqual(saved[-1]['content'],'Real storage')
        self.assertEqual(self.client.get('/api/notes')[-1]['title'],'Native test')

    def test_03_native_files_and_contacts(self):
        self.client.post('/api/files/create',{'path':'','name':'nova.txt','content':'Hello native Nova'})
        self.assertEqual(self.client.get('/api/file',path='nova.txt')['content'],'Hello native Nova')
        self.client.post('/api/files/save',{'path':'nova.txt','content':'Saved'})
        self.assertEqual(self.client.get('/api/file',path='nova.txt')['content'],'Saved')
        self.assertIn('Jane',str(self.client.post('/api/contacts/save',{'name':'Jane','phone':'123'})))
        self.assertTrue(self.client.get('/api/integration')['source_count']>=104)

    def test_04_reject_nonlocal_server(self):
        for bad in ('https://example.com','http://example.com','file:///etc/passwd','http://127.0.0.1:8767/path'):
            with self.assertRaises(ValueError):NovaClient(bad)

    def test_05_guest_native_boot_wiring(self):
        builder=(ROOT/'vm/build-arm64-qemu.sh').read_text()
        session=(ROOT/'vm/guest/nova-desktop-session').read_text()
        self.assertIn('python3-pyqt5 qtwayland5',builder)
        self.assertIn('/opt/nova/native-shell/nova_shell.py',builder)
        self.assertIn('/opt/nova/native-shell/modern_webview.py',session)
        self.assertIn('QT_QPA_PLATFORM=wayland',session)
        self.assertNotIn('chromium --',session.lower())
        self.assertIn('/usr/local/bin/nova-compositor-run',session)
        self.assertIn('weston --backend=drm-backend.so', (ROOT/'vm/guest/nova-compositor-run').read_text())
        for f in ['vm/build-arm64-qemu.sh','vm/guest/nova-desktop-session','vm/run-arm64-qemu.sh']:
            p=subprocess.run(['bash','-n',str(ROOT/f)],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,f+': '+p.stderr)

    def test_06_native_qt_source_syntax(self):
        for p in SHELL.glob('*.py'):
            compile(p.read_text(),str(p),'exec')

if __name__=='__main__':unittest.main()
