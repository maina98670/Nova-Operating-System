"""Release candidate guarantees checked without requiring Cargo, Qt or QEMU."""
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parents[1]


def url_get(base,route):
    with urllib.request.urlopen(base+route,timeout=3) as response:
        return json.loads(response.read())

class TestStabilizationAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.conf=Path(cls.tmp.name)/'config'
        cls.files=Path(cls.tmp.name)/'files'
        with socket.socket() as sk:
            sk.bind(('127.0.0.1',0)); cls.port=sk.getsockname()[1]
        cls.base='http://127.0.0.1:'+str(cls.port)
        cls.env={**os.environ,'NOVA_CONFIG_DIR':str(cls.conf),'NOVA_FILES_ROOT':str(cls.files),
                 'NOVA_BRIDGE_BIN':str(Path(cls.tmp.name)/'missing-native-bridge')}
        cls.process=subprocess.Popen([sys.executable,str(ROOT/'graphics-shell/server.py'),
                                      '--no-browser','--port',str(cls.port)],env=cls.env,
                                      stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(70):
            try:
                url_get(cls.base,'/api/health');break
            except (OSError,ValueError):time.sleep(.1)
        else:raise RuntimeError('Nova test backend failed')
        with urllib.request.urlopen(cls.base+'/',timeout=3) as r:
            import re
            cls.token=re.search(r'<meta\s+name="nova-token"\s+content="([^"]+)"',r.read().decode()).group(1)

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate();cls.process.wait(timeout=5);cls.tmp.cleanup()

    def post(self,route,obj,token=None):
        req=urllib.request.Request(self.base+route,
            data=json.dumps(obj).encode('utf-8'),
            headers={'Content-Type':'application/json','X-Nova-Token':token if token is not None else self.token})
        with urllib.request.urlopen(req,timeout=4) as resp:
            return json.loads(resp.read())

    def test_01_health_does_not_pretend_rust_is_available(self):
        health=url_get(self.base,'/api/health')
        self.assertEqual(health['release'],'1.00-integration-foundation')
        self.assertTrue(health['backend_ready'])
        self.assertFalse(health['original_rust_bridge_healthy'])
        self.assertFalse(health['gui_event_loop_active'])

    def test_02_graphical_event_loop_marker_needs_freshness(self):
        marker=self.conf/'gui-ready.json'
        marker.parent.mkdir(parents=True,exist_ok=True)
        marker.write_text(json.dumps({'status':'event-loop-active','timestamp':time.time()-100}))
        self.assertFalse(url_get(self.base,'/api/health')['gui_event_loop_active'])
        marker.write_text(json.dumps({'status':'event-loop-active','timestamp':time.time()}))
        self.assertTrue(url_get(self.base,'/api/health')['gui_event_loop_active'])
        marker.unlink()

    def test_03_files_are_persistent_and_settings_private(self):
        saved=self.post('/api/settings',{'name':'Stabilization Test'})
        self.assertEqual(saved['name'],'Stabilization Test')
        self.assertEqual(url_get(self.base,'/api/settings')['name'],'Stabilization Test')
        st=(self.conf/'settings.json').stat()
        self.assertEqual(stat.S_IMODE(st.st_mode),0o600)
        self.post('/api/files/create',{'path':'','name':'rc1.txt','content':'stable'})
        self.assertEqual(url_get(self.base,'/api/file?path=rc1.txt')['content'],'stable')

    def test_04_mutations_reject_bad_token(self):
        with self.assertRaises(urllib.error.HTTPError) as err:
            self.post('/api/settings',{'name':'unauthorized'},token='wrong')
        self.assertEqual(err.exception.code,403)

    def test_05_file_escape_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as err:
            self.post('/api/files/create',{'path':'../','name':'escape.txt','content':'x'})
        self.assertEqual(err.exception.code,400)

    def test_06_symlink_cannot_escape_nova_files(self):
        outsider=Path(self.tmp.name)/'outside'
        outsider.mkdir(exist_ok=True)
        link=self.files/'external'
        link.symlink_to(outsider,target_is_directory=True)
        with self.assertRaises(urllib.error.HTTPError):
            self.post('/api/files/create',{'path':'external','name':'escape.txt','content':'x'})
        self.assertFalse((outsider/'escape.txt').exists())
        link.unlink()

    def test_07_broken_rust_executable_not_reported_healthy(self):
        bridge=Path(self.tmp.name)/'fake-bridge'
        bridge.write_text('#!/bin/sh\necho bad-response\n')
        bridge.chmod(0o700)
        # Health endpoint itself must degrade, even if a binary exists.
        import importlib.util
        script=ROOT/'graphics-shell/server.py'
        cmd=[sys.executable,'-c',
             'import runpy,json; m=runpy.run_path('+repr(str(script))+'); print(json.dumps(m["health_snapshot"]()))']
        env={**self.env,'NOVA_BRIDGE_BIN':str(bridge)}
        ret=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=10)
        self.assertEqual(ret.returncode,0,ret.stderr)
        self.assertFalse(json.loads(ret.stdout)['original_rust_bridge_healthy'])

    def test_08_strict_mode_refuses_to_start_without_bridge(self):
        with socket.socket() as s:
            s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        env={**self.env,'NOVA_REQUIRE_RUST_BRIDGE':'1'}
        res=subprocess.run([sys.executable,str(ROOT/'graphics-shell/server.py'),
                            '--no-browser','--port',str(port)],env=env,capture_output=True,text=True,timeout=5)
        self.assertNotEqual(res.returncode,0)
        self.assertIn('Native Nova Rust bridge not built',res.stderr)

    def test_09_source_release_gates_pass(self):
        proc=subprocess.run([sys.executable,str(ROOT/'scripts/preflight.py'),'--strict-source'],
                            capture_output=True,text=True,timeout=30)
        self.assertEqual(proc.returncode,0,proc.stdout+'\n'+proc.stderr)
        results=json.loads(proc.stdout)
        self.assertEqual(results['workspace_modules'],104)
        self.assertTrue(results['source_verified'])
        self.assertFalse(results['arm64']['boot_runtime_observed'])

    def test_10_notifications_roundtrip_and_read(self):
        events=self.post('/api/notifications/post',{'title':'First event','body':'Displayed in native shell'})
        self.assertEqual(events[-1]['title'],'First event')
        self.assertFalse(events[-1]['read'])
        event_id=events[-1]['id']
        events=self.post('/api/notifications/read',{'id':event_id})
        self.assertTrue(events[-1]['read'])
        self.assertTrue(url_get(self.base,'/api/notifications')[-1]['read'])
        self.assertEqual(self.post('/api/notifications/clear',{}),[])

    def test_11_native_recent_views_and_notifications_are_present(self):
        source=(ROOT/'native-shell/nova_shell.py').read_text()
        self.assertIn('def page_recents',source)
        self.assertIn('def page_notifications',source)
        self.assertIn('def _gui_heartbeat',source)
        self.assertIn("'notifications','Notifications'",source)

    def test_12_vm_smoke_checks_actual_guest_services(self):
        text=(ROOT/'vm/smoke-arm64-qemu.py').read_text()
        self.assertIn('qemu-system-aarch64',text)
        self.assertIn('gui_event_loop_active',text)
        self.assertIn('original_runtime_active',text)
        self.assertIn('rust_bridge_connected',text)
        self.assertIn('persistent_data_roundtrip',text)
        self.assertIn("'pixels_manually_verified':False",text)

if __name__=='__main__':unittest.main()
